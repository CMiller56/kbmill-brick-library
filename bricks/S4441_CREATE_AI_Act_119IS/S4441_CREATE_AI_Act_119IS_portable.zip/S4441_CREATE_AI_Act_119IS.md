---
kb_id: s-4441-introduced-in-senate-is
title: S. 4441 Introduced in Senate (IS)
author: Unknown Author
created_date: 2026-09-16
classification: Internal
confidence_level: High
domain_tags: ["security", "rmf", "ato", "software", "api", "mcp", "general"]
document_type: Technical Reference
primary_subject: Be it enacted by the Senate and House of Representatives of the
United States of America in Congress assembled,
sources: [{"filename": "BILLS-119s4441is.md", "path": "kbs/_ingest_jobs/S4441_CREATE_AI_119IS/md_clean/BILLS-119s4441is.md", "page_count": 1}]
ingest_provenance: {"captured_at": "2026-09-16T10:41:05.379236", "page_count": 1, "extraction_methods": {"txt": 1}, "avg_extraction_quality": 1.0, "docling_triage_pages": 0, "docling_triage_rate": 0.0, "extraction_stats": null}
dark_data_inferred_fields: ["author", "classification", "confidence_level", "created_date", "document_type", "document_type_confidence", "document_type_inferred", "domain_tags", "ingest_provenance", "kb_id", "primary_subject", "sources", "title"]
kb_name: S4441_CREATE_AI_Act_119IS
document_type_inferred: True
document_type_confidence: 0.551
kb_name: S4441_CREATE_AI_Act_119IS
created: 2026-09-16T10:41:05.379318
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 5
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-09-16T10:41:10.461922
  chunk_count: 5
  strict_air_gapped: true
---

--- chunk_id: chunk-0000
source_document: BILLS-119s4441is.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 466
content_hash: 9c456abc8d415527
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: S. 4441 Introduced in Senate (IS)
document_type: technical_reference

## S. 4441 Introduced in Senate (IS)

Be it enacted by the Senate and House of Representatives of the
United States of America in Congress assembled,

### SECTION 1. Short Title. This Act may be cited as the ``Creating Resources for Every
American To Experiment with Artificial Intelligence Act'' or the
``CREATE AI Act''. ### SEC. 2. National Artificial Intelligence Research Resource. (a) In General.--The National Artificial Intelligence Initiative
Act of 2020 (15 U.S.C. 9401 et seq.) is amended by adding at the end
the following:

    ``TITLE LVI--NATIONAL ARTIFICIAL INTELLIGENCE RESEARCH RESOURCE

``Sec. 5601. Definitions. ``Sec. 5602. Establishment; governance. ``Sec. 5603. Resources of the NAIRR. ``Sec. 5604. NAIRR processes and procedures. ``SEC. 5601. DEFINITIONS. ``In this title:
            ``(1) Executive agency.--The term `Executive agency' has
        the meaning given such term in section 105 of title 5, United
        States Code. ``(2) National artificial intelligence research resource;
        nairr.--The terms `National Artificial Intelligence Research
        Resource' and `NAIRR' have the meaning given the term `National
        Artificial Intelligence Research Resource' in section 5106(g). ``(3) Program management office.--The term `Program
        Management Office' means the Program Management Office
        established under section 5602(c). ``(4) Resource of the nairr.--The term `resource of the
        NAIRR' means a resource described in section 5603(1). ``SEC. 5602. ESTABLISHMENT; GOVERNANCE. ``(a) Establishment.--Not later than 1 year after the date of
enactment of the Creating Resources for Every American To Experiment
with Artificial Intelligence Act, the Director of the National Science
Foundation shall establish the National Artificial Intelligence
Research Resource to--
            ``(1) advance artificial intelligence research and research
        that employs artificial intelligence; and
            ``(2) develop artificial intelligence skills for the United
        States workforce. ``(b) Function.--The function of the NAIRR shall be to connect
United States researchers and educators to computational, data,
software, and educational resources, provided by Executive agencies,
State governments, or nongovernmental entities. ``(c) Program Management Office.--
            ``(1) Establishment.--The Director of the National Science
        Foundation shall--
                    ``(A) establish within the Office of Advanced
                Cyberinfrastructure (or a successor office) of the
                National Science Foundation a Program Management Office
                to oversee the functions of the NAIRR; and
                    ``(B) appoint an individual to head the Program
                Management Office.

--- chunk_id: chunk-0001
source_document: BILLS-119s4441is.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: 5f0e824aa839246d
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
section_heading: S. 4441 Introduced in Senate (IS)
document_type: technical_reference

``(b) Function.--The function of the NAIRR shall be to connect
United States researchers and educators to computational, data,
software, and educational resources, provided by Executive agencies,
State governments, or nongovernmental entities. ``(c) Program Management Office.--
            ``(1) Establishment.--The Director of the National Science
        Foundation shall--
                    ``(A) establish within the Office of Advanced
                Cyberinfrastructure (or a successor office) of the
                National Science Foundation a Program Management Office
                to oversee the functions of the NAIRR; and
                    ``(B) appoint an individual to head the Program
                Management Office. ``(2) Duties.--The duties of the Program Management Office
        shall include--
                    ``(A) developing the budget for the NAIRR;
                    ``(B) as needed, and with appropriate oversight,
                delegating operational tasks to 1 or more
                nongovernmental organizations that shall be selected
                through a competitive and transparent process;
                    ``(C) coordinating resource contributions from
                participating Executive agencies, State governments,
                and nongovernmental entities; and
                    ``(D) establishing policies and procedures for the
                NAIRR that carry out all requirements of section 5604. ``(d) Reporting.--The Director of the National Science Foundation
shall develop, and make publicly available, an annual report on the
progress of the NAIRR. ``SEC. 5603. RESOURCES OF THE NAIRR. ``The head of the Program Management Office shall--
            ``(1) coordinate and provision resources of the NAIRR,
        which shall include computational resources, data, software,
        models, testbeds, and educational resources;
            ``(2) establish processes to manage the acquisition and
        integration of new resources of the NAIRR, and intake of in-
        kind contribution of resources of the NAIRR, from Executive
        agencies, State governments, or nongovernmental entities; and
            ``(3) publicly report a summary of categories of available
        resources of the NAIRR. ``SEC. 5604. NAIRR PROCESSES AND PROCEDURES. ``(a) User Eligibility.--
            ``(1) Eligible users.--Subject to paragraph (3), the
        following users shall be eligible for access to the NAIRR:
                    ``(A) A researcher, educator, or student based in
                the United States that is affiliated with an entity
                described in paragraph (2). ``(B) An employee of an entity described in
                subclause (III) or (IV) of paragraph (2)(A)(ii) with a
                demonstrable mission-need. ``(2) Entities described.--An entity described in this
        paragraph is one of the following:
                    ``(A) An entity that--
                            ``(i) is based in the United States; and
                            ``(ii) is--
                                    ``(I) an institution of higher
                                education (as such term is defined in
                                section 101(a) of the Higher Education Act of 1965 (20 U.S.C.

--- chunk_id: chunk-0002
source_document: BILLS-119s4441is.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 433
content_hash: 0f791e70408b1827
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: S. 4441 Introduced in Senate (IS)
document_type: technical_reference

``(B) An employee of an entity described in
                subclause (III) or (IV) of paragraph (2)(A)(ii) with a
                demonstrable mission-need. ``(2) Entities described.--An entity described in this
        paragraph is one of the following:
                    ``(A) An entity that--
                            ``(i) is based in the United States; and
                            ``(ii) is--
                                    ``(I) an institution of higher
                                education (as such term is defined in
                                section 101(a) of the Higher Education Act of 1965 (20 U.S.C. 1001(a)));
                                    ``(II) a nonprofit institution (as
                                such term is defined in section 4 of
                                the Stevenson-Wydler Technology
                                Innovation Act of 1980 (15 U.S.C. 3703));
                                    ``(III) an Executive agency,
                                Congress, an agency of the legislative
                                branch, or an agency of the judicial
                                branch;
                                    ``(IV) a federally funded research
                                and development center;
                                    ``(V) a small business concern (as
                                such term is defined in section 3 of
                                the Small Business Act (15 U.S.C. 632),
                                notwithstanding section 121.103 of
                                title 13, Code of Federal Regulations)
                                that has received funding from an
                                Executive agency, including through the
                                Small Business Innovation Research
                                Program or the Small Business
                                Technology Transfer Program (as
                                described in section 9 of the Small
                                Business Act (15 U.S.C. 638)); or
                                    ``(VI) a consortium composed of
                                entities described in subclauses (I)
                                through (V). ``(B) An entity that is determined to be eligible
                by the Director of the National Science Foundation and
                the Director of the Office of Science and Technology
                Policy. ``(3) Excluded entities.--
                    ``(A) In general.--No individual is authorized to
                be an eligible user under paragraph (1) if the
                individual is employed by a foreign country that is
                listed in section 4872(f)(2) of title 10, United States
                Code, or is otherwise authorized by such country to act
                for or on its behalf. ``(B) Enforcement.--The Director of the National
                Science Foundation shall ensure that individuals
                authorized as eligible users meet the requirements of
                subparagraph (A). ``(4) User access selection.--The head of the Program
        Management Office shall establish an application process for
        eligible users to request access to the NAIRR.

--- chunk_id: chunk-0003
source_document: BILLS-119s4441is.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 468
content_hash: 783054889b04bc41
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: S. 4441 Introduced in Senate (IS)
document_type: technical_reference

``(B) Enforcement.--The Director of the National
                Science Foundation shall ensure that individuals
                authorized as eligible users meet the requirements of
                subparagraph (A). ``(4) User access selection.--The head of the Program
        Management Office shall establish an application process for
        eligible users to request access to the NAIRR. ``(b) Research Security.--The head of the Program Management Office
shall--
            ``(1) ensure conformance with the requirements of National
        Security Presidential Memorandum-33 (relating to supported
        research and development national policy), issued January 2021,
        and its implementation guidance on research security and
        research integrity, or any successor policy document or
        guidance; and
            ``(2)(A) designate a member of the Program Management
        Office as a research security point of contact with
        responsibility for overseeing conformance with National
        Security Presidential Memorandum-33 and its implementation
        guidance, or any successor policy document or guidance; and
            ``(B) if the head of the Program Management Office
        delegates responsibilities to another entity under section
        5602(c)(2)(B), require the entity to designate a member of the
        leadership team for such entity to serve as a research security
        point of contact as described in subparagraph (A), with respect
        to the delegated responsibilities. ``(c) Open Source.--The head of the Program Management Office shall
establish policies to encourage software developed to administer the
NAIRR, and software developed using resources of the NAIRR, to be open-
source. ``(d) Fee Schedule.--
            ``(1) In general.--The head of the Program Management
        Office may establish a fee schedule for access to the NAIRR. Access to the NAIRR may only require a fee if the fee is
        assessed according to such fee schedule. Such fee schedule--
                    ``(A) may differ by type of eligible user and type
                of affiliated entity described in subsection (a);
                    ``(B) shall include a free tier of access based on
                available funds and anticipated costs and demand;
                    ``(C) may include cost-based charges for specified
                eligible users; and
                    ``(D) shall ensure that the primary purpose of the
                NAIRR is to support research. ``(2) Retention and use of funds.--
                    ``(A) Retaining of funds.--Notwithstanding section
                3302 of title 31, United States Code, the head of the
                Program Management Office may retain fees collected
                under this subsection.

--- chunk_id: chunk-0004
source_document: BILLS-119s4441is.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 389
content_hash: e248d61686887027
prev_chunk_id: chunk-0003
next_chunk_id: null
section_heading: S. 4441 Introduced in Senate (IS)
document_type: technical_reference

Such fee schedule--
                    ``(A) may differ by type of eligible user and type
                of affiliated entity described in subsection (a);
                    ``(B) shall include a free tier of access based on
                available funds and anticipated costs and demand;
                    ``(C) may include cost-based charges for specified
                eligible users; and
                    ``(D) shall ensure that the primary purpose of the
                NAIRR is to support research. ``(2) Retention and use of funds.--
                    ``(A) Retaining of funds.--Notwithstanding section
                3302 of title 31, United States Code, the head of the
                Program Management Office may retain fees collected
                under this subsection. ``(B) Availability and use of funds.--Amounts
                retained under subparagraph (A) shall--
                            ``(i) remain available until expended; and
                            ``(ii) be available to the head of the
                        Program Management Office, without further
                        appropriation, for the purposes of this title. ``(e) Advanced Cyberinfrastructure Advisory Committee.--
            ``(1) In general.--The Director of the National Science
        Foundation shall establish an advisory committee to assess, and
        make recommendations regarding, the activities of the Office of
        Advanced Cyberinfrastructure, including the management of the
        NAIRR. ``(2) Members.--The membership requirements for the
        committee established under paragraph (1) shall be the same as
        the membership requirements described in section 10386(b) of
        the Research and Development, Innovation, and Competition Act
        (42 U.S.C. 19106(b)). ``(3) Nonapplicability of faca.--Chapter 10 of title 5,
        United States Code, shall not apply to the committee
        established under paragraph (1).''. (b) Conforming Amendments.--The table of contents in section 2(b)
of the William M. (Mac) Thornberry National Defense Authorization Act
for Fiscal Year 2021 (Public Law 116-283; 134 Stat. 3388) is amended by
inserting after the items relating to title LV the following:

    ``TITLE LVI--NATIONAL ARTIFICIAL INTELLIGENCE RESEARCH RESOURCE

``Sec. 5601. Definitions. ``Sec. 5602. Establishment; governance. ``Sec. 5603. Resources of the NAIRR. ``Sec. 5604. NAIRR processes and procedures.''.
