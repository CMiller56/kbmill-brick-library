# Residual board — S4441_CREATE_AI_Act_119IS

Status: **success**

## Counts
- in kb: 5  |  muted / off RAG: 0  |  on RAG path: 5
- embedded rows: 5
- reconciled: True

## Quality score (if present)
- avg_extraction_quality: **1.0**
- measures: text-layer coverage / extractability (pages that produced usable text), not character-level OCR accuracy

## Limits / open items
- (none recorded)

