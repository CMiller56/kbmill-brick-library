# Residual board — HR2385_CREATE_AI_Act_119IH

Status: **success**

## Counts
- in kb: 16  |  muted / off RAG: 0  |  on RAG path: 16
- embedded rows: 16
- reconciled: True

## Quality score (if present)
- avg_extraction_quality: **1.0**
- measures: text-layer coverage / extractability (pages that produced usable text), not character-level OCR accuracy

## Limits / open items
- (none recorded)

