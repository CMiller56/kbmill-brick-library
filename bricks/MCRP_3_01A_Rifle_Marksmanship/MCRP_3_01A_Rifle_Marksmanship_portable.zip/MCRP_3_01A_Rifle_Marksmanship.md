---
kb_id: mcrp-3-01a-rifle-marksmanship
title: MCRP 3-01A Rifle Marksmanship
author: United States Marine Corps
created_date: 2001
classification: public
confidence_level: High
domain_tags: ["usmc", "marine_corps", "mcrp_3_01a", "rifle_marksmanship", "marksmanship", "us_gov", "doctrine"]
document_type: technical_reference
primary_subject: US Marine Corps Reference Publication MCRP 3-01A Rifle Marksmanship (29 March 2001) — individual rifle marksmanship techniques, positions, engagement, and maintenance doctrine
intended_audience: Students of small-arms marksmanship doctrine; integrators testing pre-digital manual structure (TOC leaders, numbered paras, glossary) on residual-honest retrieval
sources: [{"filename": "MCRP3-01A.pdf", "path": "MCRP3-01A.pdf", "page_count": 117}]
ingest_provenance: {"captured_at": "2026-07-30T21:03:39.284519", "page_count": 117, "extraction_methods": {"docling": 3, "pymupdf": 114}, "avg_extraction_quality": 0.9749, "docling_triage_pages": 4, "docling_triage_rate": 0.0342, "extraction_stats": {"page_count": 117, "total_document_pages": 117, "page_range": null, "docling_triage_count": 4, "docling_executed_count": 4, "docling_page_count": 4, "docling_triage_rate": 0.0342, "camelot_pages": 0, "tables_extracted": 0, "pass1_ms": 962.64, "pass2_ms": 13808.93, "total_ms": 14782.77, "pages_per_sec": 7.91}}
dark_data_inferred_fields: ["ingest_provenance", "kb_id", "sources"]
date: 2001
source_rights: US Government work (USMC MCRP 3-01A, 2001). Public domain in the US; not an official Marine Corps redistribution or endorsement.
kb_name: MCRP_3_01A_Rifle_Marksmanship
created: 2026-07-30T21:03:39.284609
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 283
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-07-30T21:03:50.541624
  chunk_count: 283
  strict_air_gapped: true
---

## Extracted Images

Images were extracted from the source documents and saved alongside this Markdown for portability.

![Figure from page 1](images/p001_img00.png)
*Context (from source page): ## Rifle Marksmanship

![Figure from page 1](images/p001_img00.png)

## U.S. Marine Corps

## MCRP 3-01A

PCN 144 000091 00...*
*(Dimensions: 284×297)*

![Figure from page 3](images/p003_img00.jpeg)
*Context (from source page): DEPARTMENT OF THE NAVY
Headquarters United States Marine Corps
Washington, D.C. 20380-1775
29 March 2001
FOREWORD
1.  PURPOSE
Marine Corps Reference Publication (MCRP) 3-01A, Rifle Marksmanship, provides techniques
and procedures for Marine Corps rif...*
*(Dimensions: 201×74)*

![Figure from page 4](images/p004_img00.png)
*Context (from source page): 1-2
MCWP 2-12. MAGTF Intelligence Analysis and Production...*

![Figure from page 14](images/p014_img00.png)
*Context (from source page): CHAPTER 2. INTRODUCTION TO THE M16A2 SERVICE RIFLE
Note
+The procedures in this manual are written
for right-handed Marines; left-handed
Marines should reverse instructions as
necessary.
2001.
DESCRIPTION
The M16A2 service rifle is a lightweight, 5.5...*
*(Dimensions: 505×279)*

![Figure from page 15](images/p015_img00.png)
*Context (from source page): 2-2 _______________________________________________________________________________________________ MCRP 3-01A
Burst
The selector lever in the burst position allows the rifle
to continue its cycle of operation until interrupted by
the burst cam. With...*
*(Dimensions: 427×269)*

![Figure from page 15](images/p015_img01.png)
*Context (from source page): 2-2 _______________________________________________________________________________________________ MCRP 3-01A
Burst
The selector lever in the burst position allows the rifle
to continue its cycle of operation until interrupted by
the burst cam. With...*
*(Dimensions: 488×137)*

![Figure from page 16](images/p016_img00.png)
*Context (from source page): Rifle Marksmanship _______________________________________________________________________________________ 2-3
Bolt Catch
If the charging handle is pulled to the rear when the
lower portion of the bolt catch is depressed, the bolt
carrier group will ...*
*(Dimensions: 323×315)*

![Figure from page 16](images/p016_img01.png)
*Context (from source page): Rifle Marksmanship _______________________________________________________________________________________ 2-3
Bolt Catch
If the charging handle is pulled to the rear when the
lower portion of the bolt catch is depressed, the bolt
carrier group will ...*
*(Dimensions: 250×173)*

![Figure from page 17](images/p017_img00.png)
*Context (from source page): 2-4 ________________________________________________________
Extracting
As the bolt carrier group continues to move to the rear,
the extractor claw withdraws the cartridge case from
the chamber. See figure 2-8.
Figure 2-7. Unlocking.
Figure 2-8. Extr...*
*(Dimensions: 253×157)*

![Figure from page 17](images/p017_img01.png)
*Context (from source page): 2-4 ________________________________________________________
Extracting
As the bolt carrier group continues to move to the rear,
the extractor claw withdraws the cartridge case from
the chamber. See figure 2-8.
Figure 2-7. Unlocking.
Figure 2-8. Extr...*
*(Dimensions: 240×180)*

![Figure from page 17](images/p017_img02.png)
*Context (from source page): 2-4 ________________________________________________________
Extracting
As the bolt carrier group continues to move to the rear,
the extractor claw withdraws the cartridge case from
the chamber. See figure 2-8.
Figure 2-7. Unlocking.
Figure 2-8. Extr...*
*(Dimensions: 258×208)*

![Figure from page 17](images/p017_img03.png)
*Context (from source page): 2-4 ________________________________________________________
Extracting
As the bolt carrier group continues to move to the rear,
the extractor claw withdraws the cartridge case from
the chamber. See figure 2-8.
Figure 2-7. Unlocking.
Figure 2-8. Extr...*
*(Dimensions: 253×160)*

![Figure from page 17](images/p017_img04.png)
*Context (from source page): 2-4 ________________________________________________________
Extracting
As the bolt carrier group continues to move to the rear,
the extractor claw withdraws the cartridge case from
the chamber. See figure 2-8.
Figure 2-7. Unlocking.
Figure 2-8. Extr...*
*(Dimensions: 251×183)*

![Figure from page 18](images/p018_img00.png)
*Context (from source page): Rifle Marksmanship ___________________________________
Feeding
Once rearward motion causes the bolt carrier group to
clear the top of the magazine, the expansion of the
magazine spring forces a round into the path of the
bolt. After the action spring...*
*(Dimensions: 203×162)*

![Figure from page 18](images/p018_img01.png)
*Context (from source page): Rifle Marksmanship ___________________________________
Feeding
Once rearward motion causes the bolt carrier group to
clear the top of the magazine, the expansion of the
magazine spring forces a round into the path of the
bolt. After the action spring...*
*(Dimensions: 241×187)*

![Figure from page 18](images/p018_img02.png)
*Context (from source page): Rifle Marksmanship ___________________________________
Feeding
Once rearward motion causes the bolt carrier group to
clear the top of the magazine, the expansion of the
magazine spring forces a round into the path of the
bolt. After the action spring...*
*(Dimensions: 247×202)*

![Figure from page 18](images/p018_img03.png)
*Context (from source page): Rifle Marksmanship ___________________________________
Feeding
Once rearward motion causes the bolt carrier group to
clear the top of the magazine, the expansion of the
magazine spring forces a round into the path of the
bolt. After the action spring...*
*(Dimensions: 274×181)*

![Figure from page 19](images/p019_img00.jpeg)
*Context (from source page): 2-6 _______________________________________________________________________________________________ MCRP 3-01A
M193 Ball
This ammunition is a 5.56mm centerfire cartridge with
a 55-grain gilded-metal jacket, lead alloy core bullet.
The primer and case...*
*(Dimensions: 237×165)*

![Figure from page 19](images/p019_img01.png)
*Context (from source page): 2-6 _______________________________________________________________________________________________ MCRP 3-01A
M193 Ball
This ammunition is a 5.56mm centerfire cartridge with
a 55-grain gilded-metal jacket, lead alloy core bullet.
The primer and case...*
*(Dimensions: 103×217)*

![Figure from page 20](images/p020_img00.jpeg)
*Context (from source page): Rifle Marksmanship ___________________________________
l Move the take down pin from the left to the right as
far as it will go to allow the lower receiver to pivot
down from the upper receiver.
l Move the receiver pivot pin from left to right as far...*
*(Dimensions: 216×181)*

![Figure from page 20](images/p020_img01.jpeg)
*Context (from source page): Rifle Marksmanship ___________________________________
l Move the take down pin from the left to the right as
far as it will go to allow the lower receiver to pivot
down from the upper receiver.
l Move the receiver pivot pin from left to right as far...*
*(Dimensions: 216×117)*

![Figure from page 21](images/p021_img00.jpeg)
*Context (from source page): 2-8 ________________________________________________________
stoppage of the rifle caused by dirty or damaged mag-
azines. To disassemble the magazine—
l 
Pry up and push base plate out from the magazine.
l 
Jiggle the spring and follower to remove. ...*
*(Dimensions: 229×155)*

![Figure from page 21](images/p021_img01.jpeg)
*Context (from source page): 2-8 ________________________________________________________
stoppage of the rifle caused by dirty or damaged mag-
azines. To disassemble the magazine—
l 
Pry up and push base plate out from the magazine.
l 
Jiggle the spring and follower to remove. ...*
*(Dimensions: 216×198)*

![Figure from page 26](images/p026_img00.jpeg)
*Context (from source page): 3-2 ________________________________________________________
l 
Conduct a chamber check.
l 
Bring the left hand back against the magazine well.
l 
Extend the fingers of the left hand and cover the
ejection port (see fig. 3-1).
l 
Grasp the charging h...*
*(Dimensions: 216×204)*

![Figure from page 26](images/p026_img01.jpeg)
*Context (from source page): 3-2 ________________________________________________________
l 
Conduct a chamber check.
l 
Bring the left hand back against the magazine well.
l 
Extend the fingers of the left hand and cover the
ejection port (see fig. 3-1).
l 
Grasp the charging h...*
*(Dimensions: 216×154)*

![Figure from page 27](images/p027_img00.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 3-3
Loading the Rifle
Perform the following steps to load the rifle (take the
rifle to Condition 3):
l Ensure the rifle is on safe.
l Withdraw ...*
*(Dimensions: 216×210)*

![Figure from page 27](images/p027_img01.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 3-3
Loading the Rifle
Perform the following steps to load the rifle (take the
rifle to Condition 3):
l Ensure the rifle is on safe.
l Withdraw ...*
*(Dimensions: 234×176)*

![Figure from page 28](images/p028_img00.jpeg)
*Context (from source page): 3-4 ________________________________________________________
l 
Cup the left hand under the ejection port, rotate the
weapon until the ejection port faces down. 
l 
Pull the charging handle to the rear and catch the
round in the left hand (see fig. 3...*
*(Dimensions: 234×167)*

![Figure from page 28](images/p028_img01.jpeg)
*Context (from source page): 3-4 ________________________________________________________
l 
Cup the left hand under the ejection port, rotate the
weapon until the ejection port faces down. 
l 
Pull the charging handle to the rear and catch the
round in the left hand (see fig. 3...*
*(Dimensions: 234×175)*

![Figure from page 28](images/p028_img02.jpeg)
*Context (from source page): 3-4 ________________________________________________________
l 
Cup the left hand under the ejection port, rotate the
weapon until the ejection port faces down. 
l 
Pull the charging handle to the rear and catch the
round in the left hand (see fig. 3...*
*(Dimensions: 234×210)*

![Figure from page 29](images/p029_img00.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 3-5
3005.
Filling, Stowing,
and Withdrawing Magazines
Filling the Magazine with Loose Rounds 
Perform the following steps to fill the magazine:...*
*(Dimensions: 252×173)*

![Figure from page 29](images/p029_img01.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 3-5
3005.
Filling, Stowing,
and Withdrawing Magazines
Filling the Magazine with Loose Rounds 
Perform the following steps to fill the magazine:...*
*(Dimensions: 121×132)*

![Figure from page 29](images/p029_img02.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 3-5
3005.
Filling, Stowing,
and Withdrawing Magazines
Filling the Magazine with Loose Rounds 
Perform the following steps to fill the magazine:...*
*(Dimensions: 234×103)*

![Figure from page 30](images/p030_img00.jpeg)
*Context (from source page): 3-6 ________________________________________________________
Withdrawing Magazines
Magazine Pouch
With the right hand, withdraw magazines from the
magazine pouch on the right side of the body. With the
left hand, withdraw magazines from the magazine
...*
*(Dimensions: 234×167)*

![Figure from page 30](images/p030_img01.jpeg)
*Context (from source page): 3-6 ________________________________________________________
Withdrawing Magazines
Magazine Pouch
With the right hand, withdraw magazines from the
magazine pouch on the right side of the body. With the
left hand, withdraw magazines from the magazine
...*
*(Dimensions: 234×167)*

![Figure from page 31](images/p031_img00.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Retain your empty magazines. When there is a lull in
the action, refill those magazines so they will be
available for future use.
During a lull in the action, replace your magazine
when you know ...*
*(Dimensions: 234×167)*

![Figure from page 31](images/p031_img01.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Retain your empty magazines. When there is a lull in
the action, refill those magazines so they will be
available for future use.
During a lull in the action, replace your magazine
when you know ...*
*(Dimensions: 234×178)*

![Figure from page 32](images/p032_img00.jpeg)
*Context (from source page): 3-8 _______________________________________________________________________________________________ MCRP 3-01A
Indicator: Brass is obstructing chamber area
(usually indicating a double feed or failure to eject).
See figure 3-15.
To return the weapon ...*
*(Dimensions: 216×137)*

![Figure from page 32](images/p032_img01.jpeg)
*Context (from source page): 3-8 _______________________________________________________________________________________________ MCRP 3-01A
Indicator: Brass is obstructing chamber area
(usually indicating a double feed or failure to eject).
See figure 3-15.
To return the weapon ...*
*(Dimensions: 216×138)*

![Figure from page 33](images/p033_img00.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 3-9
l Place 
the 
buttstock
along the side of the
body at approximately
hip level.
l Angle the muzzle up-
ward about 45 degrees
in a safe direc...*
*(Dimensions: 216×164)*

![Figure from page 33](images/p033_img01.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 3-9
l Place 
the 
buttstock
along the side of the
body at approximately
hip level.
l Angle the muzzle up-
ward about 45 degrees
in a safe direc...*
*(Dimensions: 216×172)*

![Figure from page 33](images/p033_img02.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 3-9
l Place 
the 
buttstock
along the side of the
body at approximately
hip level.
l Angle the muzzle up-
ward about 45 degrees
in a safe direc...*
*(Dimensions: 122×187)*

![Figure from page 33](images/p033_img03.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 3-9
l Place 
the 
buttstock
along the side of the
body at approximately
hip level.
l Angle the muzzle up-
ward about 45 degrees
in a safe direc...*
*(Dimensions: 144×219)*

![Figure from page 34](images/p034_img00.jpeg)
*Context (from source page): 3-10 ______________________________________________________________________________________________ MCRP 3-01A
l 
Lower the sights to just below eye level so that a
clear field of view is maintained so that a target may
be identified (see fig. 3-21)....*
*(Dimensions: 151×218)*

![Figure from page 34](images/p034_img01.jpeg)
*Context (from source page): 3-10 ______________________________________________________________________________________________ MCRP 3-01A
l 
Lower the sights to just below eye level so that a
clear field of view is maintained so that a target may
be identified (see fig. 3-21)....*
*(Dimensions: 86×246)*

![Figure from page 34](images/p034_img02.jpeg)
*Context (from source page): 3-10 ______________________________________________________________________________________________ MCRP 3-01A
l 
Lower the sights to just below eye level so that a
clear field of view is maintained so that a target may
be identified (see fig. 3-21)....*
*(Dimensions: 86×258)*

![Figure from page 34](images/p034_img03.jpeg)
*Context (from source page): 3-10 ______________________________________________________________________________________________ MCRP 3-01A
l 
Lower the sights to just below eye level so that a
clear field of view is maintained so that a target may
be identified (see fig. 3-21)....*
*(Dimensions: 87×216)*

![Figure from page 35](images/p035_img00.jpeg)
*Context (from source page): Rifle Marksmanship______________________________________________________________________________________ 3-11
l With the right hand, grasp the sling.
l With the left hand, grasp the handguards.
l Pull up on the rifle with both hands.
l Slide the slin...*
*(Dimensions: 120×181)*

![Figure from page 36](images/p036_img00.jpeg)
*Context (from source page): 3-12 _______________________________________________________
procedures for the rifle for the loading; unloading; and
unloading and showing clear.
Procedures for “Load” 
On the command “Load,” the Marine will perform the
following steps to take the r...*
*(Dimensions: 162×183)*

![Figure from page 38](images/p038_img00.jpeg)
*Context (from source page): CHAPTER 4. FUNDAMENTALS OF MARKSMANSHIP
The fundamentals of marksmanship are aiming, breathing, and trigger control.
These techniques provide the foundation for all marksmanship principles and
skills. For rifle fire to be effective, it must be accura...*
*(Dimensions: 240×230)*

![Figure from page 38](images/p038_img01.jpeg)
*Context (from source page): CHAPTER 4. FUNDAMENTALS OF MARKSMANSHIP
The fundamentals of marksmanship are aiming, breathing, and trigger control.
These techniques provide the foundation for all marksmanship principles and
skills. For rifle fire to be effective, it must be accura...*
*(Dimensions: 240×222)*

![Figure from page 39](images/p039_img00.jpeg)
*Context (from source page): 4-2 _______________________________________________________________________________________________ MCRP 3-01A
the correct aiming point so that point of aim/point of
impact is achieved.
The sighting system for the M16A2 rifle is designed to
work usin...*
*(Dimensions: 180×169)*

![Figure from page 39](images/p039_img01.jpeg)
*Context (from source page): 4-2 _______________________________________________________________________________________________ MCRP 3-01A
the correct aiming point so that point of aim/point of
impact is achieved.
The sighting system for the M16A2 rifle is designed to
work usin...*
*(Dimensions: 173×173)*

![Figure from page 39](images/p039_img02.jpeg)
*Context (from source page): 4-2 _______________________________________________________________________________________________ MCRP 3-01A
the correct aiming point so that point of aim/point of
impact is achieved.
The sighting system for the M16A2 rifle is designed to
work usin...*
*(Dimensions: 187×172)*

![Figure from page 39](images/p039_img03.jpeg)
*Context (from source page): 4-2 _______________________________________________________________________________________________ MCRP 3-01A
the correct aiming point so that point of aim/point of
impact is achieved.
The sighting system for the M16A2 rifle is designed to
work usin...*
*(Dimensions: 169×169)*

![Figure from page 40](images/p040_img00.jpeg)
*Context (from source page): ![Figure 4-4. Importance of Correct Sight Alignment.](images/p040_img00.jpeg)
*Figure 4-4. Importance of Correct Sight Alignment.*

Figure 4-4. Importance of Correct Sight Alignment.

Figure 4-5. Stock Weld.

![Figure 4-5. Stock Weld.](images/p040_im...*
*(Dimensions: 530×480)*

![Figure from page 40](images/p040_img01.jpeg)
*Context (from source page): ![Figure 4-4. Importance of Correct Sight Alignment.](images/p040_img00.jpeg)
*Figure 4-4. Importance of Correct Sight Alignment.*

Figure 4-4. Importance of Correct Sight Alignment.

Figure 4-5. Stock Weld.

![Figure 4-5. Stock Weld.](images/p040_im...*
*(Dimensions: 203×255)*

![Figure from page 40](images/p040_img02.jpeg)
*Context (from source page): ![Figure 4-4. Importance of Correct Sight Alignment.](images/p040_img00.jpeg)
*Figure 4-4. Importance of Correct Sight Alignment.*

Figure 4-4. Importance of Correct Sight Alignment.

Figure 4-5. Stock Weld.

![Figure 4-5. Stock Weld.](images/p040_im...*
*(Dimensions: 276×221)*

![Figure from page 41](images/p041_img00.jpeg)
*Context (from source page): 4-4 ________________________________________________________
If the eye is too close to the rear sight aperture, it will
be difficult to line up the front sight post in the rear
sight aperture (see fig. 4-7). Moving the eye back from
the rear sight a...*
*(Dimensions: 287×201)*

![Figure from page 41](images/p041_img01.jpeg)
*Context (from source page): 4-4 ________________________________________________________
If the eye is too close to the rear sight aperture, it will
be difficult to line up the front sight post in the rear
sight aperture (see fig. 4-7). Moving the eye back from
the rear sight a...*
*(Dimensions: 104×104)*

![Figure from page 41](images/p041_img02.jpeg)
*Context (from source page): 4-4 ________________________________________________________
If the eye is too close to the rear sight aperture, it will
be difficult to line up the front sight post in the rear
sight aperture (see fig. 4-7). Moving the eye back from
the rear sight a...*
*(Dimensions: 112×112)*

![Figure from page 41](images/p041_img03.jpeg)
*Context (from source page): 4-4 ________________________________________________________
If the eye is too close to the rear sight aperture, it will
be difficult to line up the front sight post in the rear
sight aperture (see fig. 4-7). Moving the eye back from
the rear sight a...*
*(Dimensions: 284×226)*

![Figure from page 42](images/p042_img00.jpeg)
*Context (from source page): Rifle Marksmanship ____________________________________
ical to accurate engagement as the range to the target
increases. To be accurate at longer ranges, the Marine
must take the time to slow down and accurately apply
the fundamentals.
As the distan...*
*(Dimensions: 219×219)*

![Figure from page 42](images/p042_img01.jpeg)
*Context (from source page): Rifle Marksmanship ____________________________________
ical to accurate engagement as the range to the target
increases. To be accurate at longer ranges, the Marine
must take the time to slow down and accurately apply
the fundamentals.
As the distan...*
*(Dimensions: 224×224)*

![Figure from page 43](images/p043_img00.jpeg)
*Context (from source page): 4-6 ________________________________________________________
It may be necessary to take several deep breaths before
holding the breath. A Marine should not make an ex-
aggerated effort to perform breath control. A natural
respiratory pause will help...*
*(Dimensions: 249×177)*

![Figure from page 46](images/p046_img00.jpeg)
*Context (from source page): 5-2 _______________________________________________________________________________________________ MCRP 3-01A
Hasty Sling
Application
The hasty sling is used in all firing positions. The
hasty sling is advantageous in combat because it can
be acquir...*
*(Dimensions: 103×180)*

![Figure from page 46](images/p046_img01.jpeg)
*Context (from source page): 5-2 _______________________________________________________________________________________________ MCRP 3-01A
Hasty Sling
Application
The hasty sling is used in all firing positions. The
hasty sling is advantageous in combat because it can
be acquir...*
*(Dimensions: 105×180)*

![Figure from page 46](images/p046_img02.jpeg)
*Context (from source page): 5-2 _______________________________________________________________________________________________ MCRP 3-01A
Hasty Sling
Application
The hasty sling is used in all firing positions. The
hasty sling is advantageous in combat because it can
be acquir...*
*(Dimensions: 162×196)*

![Figure from page 46](images/p046_img03.jpeg)
*Context (from source page): 5-2 _______________________________________________________________________________________________ MCRP 3-01A
Hasty Sling
Application
The hasty sling is used in all firing positions. The
hasty sling is advantageous in combat because it can
be acquir...*
*(Dimensions: 230×129)*

![Figure from page 47](images/p047_img00.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 5-3
creased by pushing the elbow outboard. See figure
5-5. (This enables one sling setting to fit all posi-
tions.) It is important for the has...*
*(Dimensions: 180×144)*

![Figure from page 47](images/p047_img01.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 5-3
creased by pushing the elbow outboard. See figure
5-5. (This enables one sling setting to fit all posi-
tions.) It is important for the has...*
*(Dimensions: 162×185)*

![Figure from page 47](images/p047_img02.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 5-3
creased by pushing the elbow outboard. See figure
5-5. (This enables one sling setting to fit all posi-
tions.) It is important for the has...*
*(Dimensions: 180×226)*

![Figure from page 48](images/p048_img00.jpeg)
*Context (from source page): 5-4 ________________________________________________________
Tension on the rifle sling is correct when it causes the
rifle butt to be forced rearward into the pocket of the
shoulder. This serves to keep the butt plate in the
shoulder pocket during r...*
*(Dimensions: 229×159)*

![Figure from page 48](images/p048_img01.jpeg)
*Context (from source page): 5-4 ________________________________________________________
Tension on the rifle sling is correct when it causes the
rifle butt to be forced rearward into the pocket of the
shoulder. This serves to keep the butt plate in the
shoulder pocket during r...*
*(Dimensions: 230×128)*

![Figure from page 49](images/p049_img00.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
to keep the hand from slipping on the handguard dur-
ing recoil. See figure 5-10.
When the wrist of the left hand is straight and locked,
it creates resistance on the sling close to the muzzle.
T...*
*(Dimensions: 230×165)*

![Figure from page 49](images/p049_img01.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
to keep the hand from slipping on the handguard dur-
ing recoil. See figure 5-10.
When the wrist of the left hand is straight and locked,
it creates resistance on the sling close to the muzzle.
T...*
*(Dimensions: 234×167)*

![Figure from page 49](images/p049_img02.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
to keep the hand from slipping on the handguard dur-
ing recoil. See figure 5-10.
When the wrist of the left hand is straight and locked,
it creates resistance on the sling close to the muzzle.
T...*
*(Dimensions: 234×152)*

![Figure from page 49](images/p049_img03.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
to keep the hand from slipping on the handguard dur-
ing recoil. See figure 5-10.
When the wrist of the left hand is straight and locked,
it creates resistance on the sling close to the muzzle.
T...*
*(Dimensions: 234×96)*

![Figure from page 50](images/p050_img00.jpeg)
*Context (from source page): 5-6 _______________________________________________________________________________________________ MCRP 3-01A
Grip of the Right Hand
Grasp the pistol grip with the right hand and place the
forefinger on the trigger, with the thumb and remain-
ing fi...*
*(Dimensions: 120×145)*

![Figure from page 50](images/p050_img01.jpeg)
*Context (from source page): 5-6 _______________________________________________________________________________________________ MCRP 3-01A
Grip of the Right Hand
Grasp the pistol grip with the right hand and place the
forefinger on the trigger, with the thumb and remain-
ing fi...*
*(Dimensions: 180×172)*

![Figure from page 50](images/p050_img02.jpeg)
*Context (from source page): 5-6 _______________________________________________________________________________________________ MCRP 3-01A
Grip of the Right Hand
Grasp the pistol grip with the right hand and place the
forefinger on the trigger, with the thumb and remain-
ing fi...*
*(Dimensions: 193×114)*

![Figure from page 52](images/p052_img00.jpeg)
*Context (from source page): 5-8 ________________________________________________________
body slightly forward or back using the left elbow as a
pivot and by digging the toes in.
l 
Pushing the body forward causes the sights to settle
lower on the target.
l 
Pulling the body ba...*
*(Dimensions: 85×144)*

![Figure from page 52](images/p052_img01.jpeg)
*Context (from source page): 5-8 ________________________________________________________
body slightly forward or back using the left elbow as a
pivot and by digging the toes in.
l 
Pushing the body forward causes the sights to settle
lower on the target.
l 
Pulling the body ba...*
*(Dimensions: 93×146)*

![Figure from page 53](images/p053_img00.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Straight Leg Prone Position with the 
Hasty Sling
Apply the seven factors to this position (para. 5003).
To assume the straight leg prone position with the
hasty sling, either move forward or dro...*
*(Dimensions: 198×146)*

![Figure from page 53](images/p053_img01.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Straight Leg Prone Position with the 
Hasty Sling
Apply the seven factors to this position (para. 5003).
To assume the straight leg prone position with the
hasty sling, either move forward or dro...*
*(Dimensions: 216×82)*

![Figure from page 53](images/p053_img02.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Straight Leg Prone Position with the 
Hasty Sling
Apply the seven factors to this position (para. 5003).
To assume the straight leg prone position with the
hasty sling, either move forward or dro...*
*(Dimensions: 126×127)*

![Figure from page 53](images/p053_img03.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Straight Leg Prone Position with the 
Hasty Sling
Apply the seven factors to this position (para. 5003).
To assume the straight leg prone position with the
hasty sling, either move forward or dro...*
*(Dimensions: 311×79)*

![Figure from page 53](images/p053_img04.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Straight Leg Prone Position with the 
Hasty Sling
Apply the seven factors to this position (para. 5003).
To assume the straight leg prone position with the
hasty sling, either move forward or dro...*
*(Dimensions: 270×79)*

![Figure from page 54](images/p054_img00.jpeg)
*Context (from source page): 5-10 ______________________________________________________________________________________________ MCRP 3-01A
Straight Leg Prone Position with the Loop 
Sling
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume stra...*
*(Dimensions: 234×78)*

![Figure from page 54](images/p054_img01.jpeg)
*Context (from source page): 5-10 ______________________________________________________________________________________________ MCRP 3-01A
Straight Leg Prone Position with the Loop 
Sling
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume stra...*
*(Dimensions: 315×79)*

![Figure from page 54](images/p054_img02.jpeg)
*Context (from source page): 5-10 ______________________________________________________________________________________________ MCRP 3-01A
Straight Leg Prone Position with the Loop 
Sling
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume stra...*
*(Dimensions: 144×128)*

![Figure from page 54](images/p054_img03.jpeg)
*Context (from source page): 5-10 ______________________________________________________________________________________________ MCRP 3-01A
Straight Leg Prone Position with the Loop 
Sling
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume stra...*
*(Dimensions: 281×79)*

![Figure from page 54](images/p054_img04.jpeg)
*Context (from source page): 5-10 ______________________________________________________________________________________________ MCRP 3-01A
Straight Leg Prone Position with the Loop 
Sling
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume stra...*
*(Dimensions: 331×79)*

![Figure from page 54](images/p054_img05.jpeg)
*Context (from source page): 5-10 ______________________________________________________________________________________________ MCRP 3-01A
Straight Leg Prone Position with the Loop 
Sling
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume stra...*
*(Dimensions: 158×140)*

![Figure from page 55](images/p055_img00.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Cocked Leg Prone Position with the 
Hasty Sling
Apply the seven factors to this position (para. 5003).
To assume the cocked leg prone position with the
hasty sling, either move forward or drop ba...*
*(Dimensions: 305×79)*

![Figure from page 55](images/p055_img01.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Cocked Leg Prone Position with the 
Hasty Sling
Apply the seven factors to this position (para. 5003).
To assume the cocked leg prone position with the
hasty sling, either move forward or drop ba...*
*(Dimensions: 300×79)*

![Figure from page 55](images/p055_img02.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Cocked Leg Prone Position with the 
Hasty Sling
Apply the seven factors to this position (para. 5003).
To assume the cocked leg prone position with the
hasty sling, either move forward or drop ba...*
*(Dimensions: 158×149)*

![Figure from page 56](images/p056_img00.jpeg)
*Context (from source page): 5-12 _______________________________________________________
l 
Grasp the pistol grip with the right hand.
l 
Roll the body to the right while lowering the right
elbow to the ground. The right shoulder is higher
than the left shoulder in the cocked l...*
*(Dimensions: 180×107)*

![Figure from page 56](images/p056_img01.jpeg)
*Context (from source page): 5-12 _______________________________________________________
l 
Grasp the pistol grip with the right hand.
l 
Roll the body to the right while lowering the right
elbow to the ground. The right shoulder is higher
than the left shoulder in the cocked l...*
*(Dimensions: 166×95)*

![Figure from page 56](images/p056_img02.jpeg)
*Context (from source page): 5-12 _______________________________________________________
l 
Grasp the pistol grip with the right hand.
l 
Roll the body to the right while lowering the right
elbow to the ground. The right shoulder is higher
than the left shoulder in the cocked l...*
*(Dimensions: 126×161)*

![Figure from page 57](images/p057_img00.jpeg)
*Context (from source page): Rifle Marksmanship______________________________________________________________________________________ 5-13
Crossed Ankle Sitting Position with the 
Loop Sling 
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume c...*
*(Dimensions: 198×133)*

![Figure from page 57](images/p057_img01.jpeg)
*Context (from source page): Rifle Marksmanship______________________________________________________________________________________ 5-13
Crossed Ankle Sitting Position with the 
Loop Sling 
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume c...*
*(Dimensions: 158×151)*

![Figure from page 57](images/p057_img02.jpeg)
*Context (from source page): Rifle Marksmanship______________________________________________________________________________________ 5-13
Crossed Ankle Sitting Position with the 
Loop Sling 
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume c...*
*(Dimensions: 166×105)*

![Figure from page 57](images/p057_img03.jpeg)
*Context (from source page): Rifle Marksmanship______________________________________________________________________________________ 5-13
Crossed Ankle Sitting Position with the 
Loop Sling 
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume c...*
*(Dimensions: 162×100)*

![Figure from page 57](images/p057_img04.jpeg)
*Context (from source page): Rifle Marksmanship______________________________________________________________________________________ 5-13
Crossed Ankle Sitting Position with the 
Loop Sling 
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume c...*
*(Dimensions: 122×140)*

![Figure from page 58](images/p058_img00.jpeg)
*Context (from source page): 5-14 _______________________________________________________
l 
Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture.
l 
Rotate the left hand up, pinching the handguard be-
tween ...*
*(Dimensions: 162×112)*

![Figure from page 58](images/p058_img01.jpeg)
*Context (from source page): 5-14 _______________________________________________________
l 
Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture.
l 
Rotate the left hand up, pinching the handguard be-
tween ...*
*(Dimensions: 162×110)*

![Figure from page 58](images/p058_img02.jpeg)
*Context (from source page): 5-14 _______________________________________________________
l 
Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture.
l 
Rotate the left hand up, pinching the handguard be-
tween ...*
*(Dimensions: 115×128)*

![Figure from page 59](images/p059_img00.jpeg)
*Context (from source page): Rifle Marksmanship______________________________________________________________________________________ 5-15
l Rotate the left hand up, pinching the handguard be-
tween the thumb and forefinger.
l Place the flat portion of the back of the left arm, ...*
*(Dimensions: 162×117)*

![Figure from page 59](images/p059_img01.jpeg)
*Context (from source page): Rifle Marksmanship______________________________________________________________________________________ 5-15
l Rotate the left hand up, pinching the handguard be-
tween the thumb and forefinger.
l Place the flat portion of the back of the left arm, ...*
*(Dimensions: 158×134)*

![Figure from page 59](images/p059_img02.jpeg)
*Context (from source page): Rifle Marksmanship______________________________________________________________________________________ 5-15
l Rotate the left hand up, pinching the handguard be-
tween the thumb and forefinger.
l Place the flat portion of the back of the left arm, ...*
*(Dimensions: 162×112)*

![Figure from page 60](images/p060_img00.jpeg)
*Context (from source page): 5-16 _______________________________________________________
Moving Forward into Position
To move forward into the kneeling position, the
Marine steps forward toward the target with his left
foot and kneels down on his right knee.
Dropping Back into ...*
*(Dimensions: 162×110)*

![Figure from page 60](images/p060_img01.jpeg)
*Context (from source page): 5-16 _______________________________________________________
Moving Forward into Position
To move forward into the kneeling position, the
Marine steps forward toward the target with his left
foot and kneels down on his right knee.
Dropping Back into ...*
*(Dimensions: 158×121)*

![Figure from page 60](images/p060_img02.jpeg)
*Context (from source page): 5-16 _______________________________________________________
Moving Forward into Position
To move forward into the kneeling position, the
Marine steps forward toward the target with his left
foot and kneels down on his right knee.
Dropping Back into ...*
*(Dimensions: 151×130)*

![Figure from page 60](images/p060_img03.jpeg)
*Context (from source page): 5-16 _______________________________________________________
Moving Forward into Position
To move forward into the kneeling position, the
Marine steps forward toward the target with his left
foot and kneels down on his right knee.
Dropping Back into ...*
*(Dimensions: 151×133)*

![Figure from page 60](images/p060_img04.jpeg)
*Context (from source page): 5-16 _______________________________________________________
Moving Forward into Position
To move forward into the kneeling position, the
Marine steps forward toward the target with his left
foot and kneels down on his right knee.
Dropping Back into ...*
*(Dimensions: 151×122)*

![Figure from page 60](images/p060_img05.jpeg)
*Context (from source page): 5-16 _______________________________________________________
Moving Forward into Position
To move forward into the kneeling position, the
Marine steps forward toward the target with his left
foot and kneels down on his right knee.
Dropping Back into ...*
*(Dimensions: 94×148)*

![Figure from page 61](images/p061_img00.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
contact. The upper portion of the triceps or the arm-
pit will not rest on the knee.
l Bend the right elbow to provide the least muscular
tension possible, lowering it to a natural position.
l Ad...*
*(Dimensions: 151×121)*

![Figure from page 61](images/p061_img01.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
contact. The upper portion of the triceps or the arm-
pit will not rest on the knee.
l Bend the right elbow to provide the least muscular
tension possible, lowering it to a natural position.
l Ad...*
*(Dimensions: 79×139)*

![Figure from page 61](images/p061_img02.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
contact. The upper portion of the triceps or the arm-
pit will not rest on the knee.
l Bend the right elbow to provide the least muscular
tension possible, lowering it to a natural position.
l Ad...*
*(Dimensions: 151×123)*

![Figure from page 62](images/p062_img00.jpeg)
*Context (from source page): 5-18 _______________________________________________________
ception of the right foot. The right ankle is straight and
the foot is stretched out with the bootlaces in contact
with the ground. The buttocks are in contact with the
heel of the right fo...*
*(Dimensions: 115×187)*

![Figure from page 62](images/p062_img01.jpeg)
*Context (from source page): 5-18 _______________________________________________________
ception of the right foot. The right ankle is straight and
the foot is stretched out with the bootlaces in contact
with the ground. The buttocks are in contact with the
heel of the right fo...*
*(Dimensions: 115×168)*

![Figure from page 63](images/p063_img00.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Standing Position with the Parade Sling
The parade sling is used to emphasize marksmanship
fundamentals while firing from the standing position
on KD courses during entry-level training. To achie...*
*(Dimensions: 144×212)*

![Figure from page 63](images/p063_img01.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Standing Position with the Parade Sling
The parade sling is used to emphasize marksmanship
fundamentals while firing from the standing position
on KD courses during entry-level training. To achie...*
*(Dimensions: 144×207)*

![Figure from page 63](images/p063_img02.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Standing Position with the Parade Sling
The parade sling is used to emphasize marksmanship
fundamentals while firing from the standing position
on KD courses during entry-level training. To achie...*
*(Dimensions: 122×237)*

![Figure from page 63](images/p063_img03.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Standing Position with the Parade Sling
The parade sling is used to emphasize marksmanship
fundamentals while firing from the standing position
on KD courses during entry-level training. To achie...*
*(Dimensions: 174×137)*

![Figure from page 65](images/p065_img00.jpeg)
*Context (from source page): 6-2 ________________________________________________________
block upon impact. This can cause injury to a Marine
by secondary fragmentation.
Firing From Specific Types of Cover
Effective cover allows a Marine to engage enemy tar-
gets while protecti...*
*(Dimensions: 234×114)*

![Figure from page 65](images/p065_img01.jpeg)
*Context (from source page): 6-2 ________________________________________________________
block upon impact. This can cause injury to a Marine
by secondary fragmentation.
Firing From Specific Types of Cover
Effective cover allows a Marine to engage enemy tar-
gets while protecti...*
*(Dimensions: 232×109)*

![Figure from page 65](images/p065_img02.jpeg)
*Context (from source page): 6-2 ________________________________________________________
block upon impact. This can cause injury to a Marine
by secondary fragmentation.
Firing From Specific Types of Cover
Effective cover allows a Marine to engage enemy tar-
gets while protecti...*
*(Dimensions: 234×117)*

![Figure from page 65](images/p065_img03.jpeg)
*Context (from source page): 6-2 ________________________________________________________
block upon impact. This can cause injury to a Marine
by secondary fragmentation.
Firing From Specific Types of Cover
Effective cover allows a Marine to engage enemy tar-
gets while protecti...*
*(Dimensions: 234×217)*

![Figure from page 66](images/p066_img00.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Supported. When additional stability is needed, a
Marine can establish a supported position by placing
the rifle handguards or his forearm in the “V” formed
by the side and bottom of the windowsi...*
*(Dimensions: 234×132)*

![Figure from page 66](images/p066_img01.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Supported. When additional stability is needed, a
Marine can establish a supported position by placing
the rifle handguards or his forearm in the “V” formed
by the side and bottom of the windowsi...*
*(Dimensions: 234×158)*

![Figure from page 66](images/p066_img02.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Supported. When additional stability is needed, a
Marine can establish a supported position by placing
the rifle handguards or his forearm in the “V” formed
by the side and bottom of the windowsi...*
*(Dimensions: 180×185)*

![Figure from page 66](images/p066_img03.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Supported. When additional stability is needed, a
Marine can establish a supported position by placing
the rifle handguards or his forearm in the “V” formed
by the side and bottom of the windowsi...*
*(Dimensions: 180×171)*

![Figure from page 66](images/p066_img04.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
Supported. When additional stability is needed, a
Marine can establish a supported position by placing
the rifle handguards or his forearm in the “V” formed
by the side and bottom of the windowsi...*
*(Dimensions: 180×120)*

![Figure from page 67](images/p067_img00.jpeg)
*Context (from source page): 6-4 ________________________________________________________
However, this position limits lateral mobility and it is
more difficult to maneuver from.
At the back of the vehicle, only the axle and the wheel
provide cover. If the Marine must shoot fro...*
*(Dimensions: 216×129)*

![Figure from page 67](images/p067_img01.jpeg)
*Context (from source page): 6-4 ________________________________________________________
However, this position limits lateral mobility and it is
more difficult to maneuver from.
At the back of the vehicle, only the axle and the wheel
provide cover. If the Marine must shoot fro...*
*(Dimensions: 108×209)*

![Figure from page 68](images/p068_img00.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 6-5
If, however, a right-handed
Marine must fire from the
left side of cover, he fires
right-handed but adjusts his
position behind cover and
u...*
*(Dimensions: 100×233)*

![Figure from page 68](images/p068_img01.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 6-5
If, however, a right-handed
Marine must fire from the
left side of cover, he fires
right-handed but adjusts his
position behind cover and
u...*
*(Dimensions: 234×183)*

![Figure from page 68](images/p068_img02.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 6-5
If, however, a right-handed
Marine must fire from the
left side of cover, he fires
right-handed but adjusts his
position behind cover and
u...*
*(Dimensions: 234×186)*

![Figure from page 68](images/p068_img03.jpeg)
*Context (from source page): Rifle Marksmanship________________________________________________________________________________________ 6-5
If, however, a right-handed
Marine must fire from the
left side of cover, he fires
right-handed but adjusts his
position behind cover and
u...*
*(Dimensions: 234×183)*

![Figure from page 69](images/p069_img00.jpeg)
*Context (from source page): 6-6 ________________________________________________________
Resting the Magazine
The bottom, front or side of the rifle magazine can rest
on or against support to provide additional stability
(see figs. 6-15, 6-16, and 6-17).
  CAUTION
The back of t...*
*(Dimensions: 234×187)*

![Figure from page 69](images/p069_img01.jpeg)
*Context (from source page): 6-6 ________________________________________________________
Resting the Magazine
The bottom, front or side of the rifle magazine can rest
on or against support to provide additional stability
(see figs. 6-15, 6-16, and 6-17).
  CAUTION
The back of t...*
*(Dimensions: 234×187)*

![Figure from page 69](images/p069_img02.jpeg)
*Context (from source page): 6-6 ________________________________________________________
Resting the Magazine
The bottom, front or side of the rifle magazine can rest
on or against support to provide additional stability
(see figs. 6-15, 6-16, and 6-17).
  CAUTION
The back of t...*
*(Dimensions: 234×187)*

![Figure from page 70](images/p070_img00.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
can pull down on the handguards to further stabilize
the weapon.
Rifle in Shoulder Pocket
Regardless of the combat situation or the height of the
cover, the rifle butt must remain in the shoulder...*
*(Dimensions: 234×185)*

![Figure from page 70](images/p070_img01.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
can pull down on the handguards to further stabilize
the weapon.
Rifle in Shoulder Pocket
Regardless of the combat situation or the height of the
cover, the rifle butt must remain in the shoulder...*
*(Dimensions: 195×192)*

![Figure from page 70](images/p070_img02.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
can pull down on the handguards to further stabilize
the weapon.
Rifle in Shoulder Pocket
Regardless of the combat situation or the height of the
cover, the rifle butt must remain in the shoulder...*
*(Dimensions: 234×174)*

![Figure from page 71](images/p071_img00.jpeg)
*Context (from source page): 6-8 ________________________________________________________
Types of Supported Positions
Supported Prone
If possible, a Marine should use the supported prone
position when firing from behind cover. This position
is the steadiest, provides the lowest...*
*(Dimensions: 234×114)*

![Figure from page 71](images/p071_img01.jpeg)
*Context (from source page): 6-8 ________________________________________________________
Types of Supported Positions
Supported Prone
If possible, a Marine should use the supported prone
position when firing from behind cover. This position
is the steadiest, provides the lowest...*
*(Dimensions: 234×239)*

![Figure from page 71](images/p071_img02.jpeg)
*Context (from source page): 6-8 ________________________________________________________
Types of Supported Positions
Supported Prone
If possible, a Marine should use the supported prone
position when firing from behind cover. This position
is the steadiest, provides the lowest...*
*(Dimensions: 234×161)*

![Figure from page 72](images/p072_img00.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
l Support the position by placing the handguards, the
forearm, or the magazine on or against support (see
fig. 6-27).
l If the rifle is resting on support, the Marine may not
need to stabilize th...*
*(Dimensions: 234×174)*

![Figure from page 72](images/p072_img01.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
l Support the position by placing the handguards, the
forearm, or the magazine on or against support (see
fig. 6-27).
l If the rifle is resting on support, the Marine may not
need to stabilize th...*
*(Dimensions: 234×175)*

![Figure from page 72](images/p072_img02.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
l Support the position by placing the handguards, the
forearm, or the magazine on or against support (see
fig. 6-27).
l If the rifle is resting on support, the Marine may not
need to stabilize th...*
*(Dimensions: 234×187)*

![Figure from page 72](images/p072_img03.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
l Support the position by placing the handguards, the
forearm, or the magazine on or against support (see
fig. 6-27).
l If the rifle is resting on support, the Marine may not
need to stabilize th...*
*(Dimensions: 234×185)*

![Figure from page 72](images/p072_img04.jpeg)
*Context (from source page): Rifle Marksmanship____________________________________
l Support the position by placing the handguards, the
forearm, or the magazine on or against support (see
fig. 6-27).
l If the rifle is resting on support, the Marine may not
need to stabilize th...*
*(Dimensions: 234×187)*

![Figure from page 73](images/p073_img00.jpeg)
*Context (from source page): 6-10 _______________________________________________________
l 
Support the position by placing the handguards, the
forearm, or the magazine on or against support. In
addition, the position (e.g., the side of the body)
may rest against support (see f...*
*(Dimensions: 180×228)*

![Figure from page 75](images/p075_img00.jpeg)
*Context (from source page): CHAPTER 7. RIFLE PRESENTATION
Note
+The procedures in this manual are
written for right-handed Marines; left-
handed Marines should reverse instructions
as necessary.
7001.
Presentation of the Rifle
In a combat environment, targets may present them-
...*
*(Dimensions: 168×223)*

![Figure from page 75](images/p075_img01.jpeg)
*Context (from source page): CHAPTER 7. RIFLE PRESENTATION
Note
+The procedures in this manual are
written for right-handed Marines; left-
handed Marines should reverse instructions
as necessary.
7001.
Presentation of the Rifle
In a combat environment, targets may present them-
...*
*(Dimensions: 312×214)*

![Figure from page 76](images/p076_img00.jpeg)
*Context (from source page): 7-2 _______________________________________________________________________________________________ MCRP 3-01A
To present the rifle from the Alert and from the Ready,
a Marine performs the following steps once a target
appears:
l While looking at the...*
*(Dimensions: 202×151)*

![Figure from page 76](images/p076_img01.jpeg)
*Context (from source page): 7-2 _______________________________________________________________________________________________ MCRP 3-01A
To present the rifle from the Alert and from the Ready,
a Marine performs the following steps once a target
appears:
l While looking at the...*
*(Dimensions: 200×153)*

![Figure from page 76](images/p076_img02.jpeg)
*Context (from source page): 7-2 _______________________________________________________________________________________________ MCRP 3-01A
To present the rifle from the Alert and from the Ready,
a Marine performs the following steps once a target
appears:
l While looking at the...*
*(Dimensions: 201×152)*

![Figure from page 76](images/p076_img03.jpeg)
*Context (from source page): 7-2 _______________________________________________________________________________________________ MCRP 3-01A
To present the rifle from the Alert and from the Ready,
a Marine performs the following steps once a target
appears:
l While looking at the...*
*(Dimensions: 144×236)*

![Figure from page 77](images/p077_img00.jpeg)
*Context (from source page): Rifle Marksmanship ________________________________________________________________________________________ 7-3
Note
If the rifle is in the shoulder properly, the
aiming eye will be able to look through the
rear sight as soon as the stock makes
conta...*
*(Dimensions: 312×224)*

![Figure from page 77](images/p077_img01.jpeg)
*Context (from source page): Rifle Marksmanship ________________________________________________________________________________________ 7-3
Note
If the rifle is in the shoulder properly, the
aiming eye will be able to look through the
rear sight as soon as the stock makes
conta...*
*(Dimensions: 104×221)*

![Figure from page 77](images/p077_img02.jpeg)
*Context (from source page): Rifle Marksmanship ________________________________________________________________________________________ 7-3
Note
If the rifle is in the shoulder properly, the
aiming eye will be able to look through the
rear sight as soon as the stock makes
conta...*
*(Dimensions: 204×249)*

![Figure from page 78](images/p078_img00.jpeg)
*Context (from source page): 7-4 ________________________________________________________
l As the sights become level with the aiming eye, vi-
sually locate the target through the rear sight aper-
ture. As the rifle sights settle, shift the focus back to
the front sight post to...*
*(Dimensions: 274×161)*

![Figure from page 78](images/p078_img01.jpeg)
*Context (from source page): 7-4 ________________________________________________________
l As the sights become level with the aiming eye, vi-
sually locate the target through the rear sight aper-
ture. As the rifle sights settle, shift the focus back to
the front sight post to...*
*(Dimensions: 140×187)*

![Figure from page 78](images/p078_img02.jpeg)
*Context (from source page): 7-4 ________________________________________________________
l As the sights become level with the aiming eye, vi-
sually locate the target through the rear sight aper-
ture. As the rifle sights settle, shift the focus back to
the front sight post to...*
*(Dimensions: 314×90)*

![Figure from page 79](images/p079_img00.jpeg)
*Context (from source page): Rifle Marksmanship ________________________________________________________________________________________ 7-5
l Uncross the legs to an open leg position.
l Tuck the right foot underneath the left thigh, as
close to the buttocks as possible (see fig...*
*(Dimensions: 191×252)*

![Figure from page 79](images/p079_img01.jpeg)
*Context (from source page): Rifle Marksmanship ________________________________________________________________________________________ 7-5
l Uncross the legs to an open leg position.
l Tuck the right foot underneath the left thigh, as
close to the buttocks as possible (see fig...*
*(Dimensions: 197×255)*

![Figure from page 79](images/p079_img02.jpeg)
*Context (from source page): Rifle Marksmanship ________________________________________________________________________________________ 7-5
l Uncross the legs to an open leg position.
l Tuck the right foot underneath the left thigh, as
close to the buttocks as possible (see fig...*
*(Dimensions: 172×260)*

![Figure from page 80](images/p080_img00.jpeg)
*Context (from source page): CHAPTER 8. EFFE
Wind, temperature, and precipitation can
dition, all weather conditions have a 
Marines. Marines must use techniques to
ature, and precipitation (snow, sleet, and
can develop the confidence required to re
fects of weather during comba...*
*(Dimensions: 323×233)*

![Figure from page 80](images/p080_img01.jpeg)
*Context (from source page): CHAPTER 8. EFFE
Wind, temperature, and precipitation can
dition, all weather conditions have a 
Marines. Marines must use techniques to
ature, and precipitation (snow, sleet, and
can develop the confidence required to re
fects of weather during comba...*
*(Dimensions: 242×284)*

![Figure from page 81](images/p081_img00.jpeg)
*Context (from source page): 8-2 ________________________________________________________
value, full value, or no value. The target is always lo-
cated at 12 o’clock.
Wind Velocity
There are two methods used to determine wind veloci-
ty: observation and flag. The flag method is...*
*(Dimensions: 287×203)*

![Figure from page 82](images/p082_img00.jpeg)
*Context (from source page): Figure 8-4. Windage Click Chart for the Observation Method.

|             | WINDS CAN BEFELT LIGHTLY ON FACE AND LEAVES AREIN CONSTANT   | WINDS CAN BEFELT LIGHTLY ON FACE AND LEAVES AREIN CONSTANT   | WINDS RAISE DUST ANDLOOSE PAPER   | WINDS RAISE...*
*(Dimensions: 515×331)*

![Figure from page 82](images/p082_img01.jpeg)
*Context (from source page): Figure 8-4. Windage Click Chart for the Observation Method.

|             | WINDS CAN BEFELT LIGHTLY ON FACE AND LEAVES AREIN CONSTANT   | WINDS CAN BEFELT LIGHTLY ON FACE AND LEAVES AREIN CONSTANT   | WINDS RAISE DUST ANDLOOSE PAPER   | WINDS RAISE...*
*(Dimensions: 572×368)*

![Figure from page 83](images/p083_img00.jpeg)
*Context (from source page): 8-4 _______________________________________________________________________________________________ MCRP 3-01A
Once the rifle is zeroed, a change in temperature of 20
degrees or more can cause the bullet to strike above or
below the point of aim. The...*
*(Dimensions: 271×164)*

![Figure from page 85](images/p085_img00.jpeg)
*Context (from source page): CHAPTER 9. ZEROING
To be combat effective, it is essential for the Marine to know how to zero his rifle.
Zeroing is adjusting the sights on the weapon to cause the shots to impact where
the Marine aims. This must be done while compensating for the ef...*
*(Dimensions: 674×220)*

![Figure from page 86](images/p086_img00.jpeg)
*Context (from source page): 9-2 _______________________________________________________________________________________________ MCRP 3-01A
Range
Range is the KD from the rifle muzzle to the target.
9002.
Types of Zeros
Battlesight Zero (BZO)
A BZO is the elevation and windage s...*
*(Dimensions: 121×115)*

![Figure from page 86](images/p086_img01.jpeg)
*Context (from source page): 9-2 _______________________________________________________________________________________________ MCRP 3-01A
Range
Range is the KD from the rifle muzzle to the target.
9002.
Types of Zeros
Battlesight Zero (BZO)
A BZO is the elevation and windage s...*
*(Dimensions: 135×146)*

![Figure from page 86](images/p086_img02.jpeg)
*Context (from source page): 9-2 _______________________________________________________________________________________________ MCRP 3-01A
Range
Range is the KD from the rifle muzzle to the target.
9002.
Types of Zeros
Battlesight Zero (BZO)
A BZO is the elevation and windage s...*
*(Dimensions: 213×234)*

![Figure from page 87](images/p087_img00.jpeg)
*Context (from source page): Rifle Marksmanship ____________________________________
If the elevation knob is turned so the number 8/3
aligns with the elevation index line, the 3 indicates 300
yards/meters (see fig. 9-6).
When the rear sight elevation knob is set on 8/3 for
800 ...*
*(Dimensions: 246×152)*

![Figure from page 87](images/p087_img01.jpeg)
*Context (from source page): Rifle Marksmanship ____________________________________
If the elevation knob is turned so the number 8/3
aligns with the elevation index line, the 3 indicates 300
yards/meters (see fig. 9-6).
When the rear sight elevation knob is set on 8/3 for
800 ...*
*(Dimensions: 311×155)*

![Figure from page 87](images/p087_img02.jpeg)
*Context (from source page): Rifle Marksmanship ____________________________________
If the elevation knob is turned so the number 8/3
aligns with the elevation index line, the 3 indicates 300
yards/meters (see fig. 9-6).
When the rear sight elevation knob is set on 8/3 for
800 ...*
*(Dimensions: 309×167)*

![Figure from page 87](images/p087_img03.jpeg)
*Context (from source page): Rifle Marksmanship ____________________________________
If the elevation knob is turned so the number 8/3
aligns with the elevation index line, the 3 indicates 300
yards/meters (see fig. 9-6).
When the rear sight elevation knob is set on 8/3 for
800 ...*
*(Dimensions: 247×190)*

![Figure from page 88](images/p088_img00.jpeg)
*Context (from source page): 9-4 ________________________________________________________
Rear Sight Elevation Rule
One click of rear sight elevation adjustment will move
the strike of the round on the target approximately 1
inch for every 100 yards of range to the target or 2.5...*
*(Dimensions: 312×166)*

![Figure from page 88](images/p088_img01.jpeg)
*Context (from source page): 9-4 ________________________________________________________
Rear Sight Elevation Rule
One click of rear sight elevation adjustment will move
the strike of the round on the target approximately 1
inch for every 100 yards of range to the target or 2.5...*
*(Dimensions: 246×159)*

![Figure from page 88](images/p088_img02.jpeg)
*Context (from source page): 9-4 ________________________________________________________
Rear Sight Elevation Rule
One click of rear sight elevation adjustment will move
the strike of the round on the target approximately 1
inch for every 100 yards of range to the target or 2.5...*
*(Dimensions: 163×206)*

![Figure from page 89](images/p089_img00.jpeg)
*Context (from source page): Rifle Marksmanship ____________________________________
the target.) Zeroing is conducted at a range of 300
yards/meters. To prepare a rifle for zeroing, the rifle
sights must be adjusted to the initial sight settings as
outlined in paragraph 9005. P...*
*(Dimensions: 481×452)*

![Figure from page 90](images/p090_img00.jpeg)
*Context (from source page): 9-6 _______________________________________________________________________________________________ MCRP 3-01A
crosses the line of sight on its upward path of trajecto-
ry at 36 yards/30 meters, and again farther down range
at 300 yards/meters (see f...*
*(Dimensions: 667×162)*

![Figure from page 93](images/p093_img00.jpeg)
*Context (from source page): 10-2 _______________________________________________________
an area, take note of anything that looks out of place or
unusual and study it in more detail. This will greatly
increase your chances of spotting a hidden enemy.
Identifying Target Locatio...*
*(Dimensions: 377×253)*

![Figure from page 94](images/p094_img00.jpeg)
*Context (from source page): Rifle Marksmanship ____________________________________
After reaching the opposite flank, systematically cover
the area between 40 and 90 meters from your position.
The second search of the terrain includes about 10
meters of the area examined durin...*
*(Dimensions: 304×259)*

![Figure from page 95](images/p095_img00.jpeg)
*Context (from source page): 10-4 _______________________________________________________
range. In addition, a Marine’s eye relief and percep-
tion of the front sight post affect the amount of the tar-
get that is visible. To use this method, a Marine must
apply the following g...*
*(Dimensions: 323×191)*

![Figure from page 96](images/p096_img00.jpeg)
*Context (from source page): Rifle Marksmanship ____________________________________
l A target that contrasts with its background will
appear to be closer than a target that blends in with
its background.
l A partially exposed object will appear to be farther
away than it is.
l...*
*(Dimensions: 324×183)*

![Figure from page 97](images/p097_img00.jpeg)
*Context (from source page): 10-6 ______________________________________________________________________________________________ MCRP 3-01A
Inside the BZO. If the rifle is properly zeroed for 300
yards/meters, the trajectory (path of the bullet) will
rise approximately 4.5 inche...*
*(Dimensions: 653×237)*

![Figure from page 97](images/p097_img01.jpeg)
*Context (from source page): 10-6 ______________________________________________________________________________________________ MCRP 3-01A
Inside the BZO. If the rifle is properly zeroed for 300
yards/meters, the trajectory (path of the bullet) will
rise approximately 4.5 inche...*
*(Dimensions: 470×249)*

![Figure from page 101](images/p101_img00.jpeg)
*Context (from source page): 10-10 ______________________________________________________
l At a range of 200 meters, hold two points of aim in
the direction the target is moving.
For a target moving at a 45-degree angle (an oblique
target) across the line of sight, the lead is ...*
*(Dimensions: 480×254)*

![Figure from page 101](images/p101_img01.jpeg)
*Context (from source page): 10-10 ______________________________________________________
l At a range of 200 meters, hold two points of aim in
the direction the target is moving.
For a target moving at a 45-degree angle (an oblique
target) across the line of sight, the lead is ...*
*(Dimensions: 228×246)*

![Figure from page 102](images/p102_img00.jpeg)
*Context (from source page): Rifle Marksmanship ____________________________________
The trigger is pulled simultaneously with the estab-
lishment of sight picture. To execute the ambush
method, a Marine performs the following steps:
l Select an aiming point ahead of the target....*
*(Dimensions: 256×268)*

![Figure from page 104](images/p104_img00.jpeg)
*Context (from source page): Rifle Marksmanship _____________________________________________________________________________________ 10-13
to reference the exact position of the object.
This illusion can be prevented by visually
aligning the object against something else,
such ...*
*(Dimensions: 453×228)*

![Figure from page 104](images/p104_img01.jpeg)
*Context (from source page): Rifle Marksmanship _____________________________________________________________________________________ 10-13
to reference the exact position of the object.
This illusion can be prevented by visually
aligning the object against something else,
such ...*
*(Dimensions: 324×298)*

![Figure from page 107](images/p107_img00.jpeg)
*Context (from source page): Appendix A
DATA BOOK
Note
The principles for recording data in the data
book are the same for the Entry Level Rifle
(ELR) Program and the Sustainment Level
Rifle (SLR) Program. This appendix pro-
vides generic information for completing
the data book...*
*(Dimensions: 616×179)*

![Figure from page 109](images/p109_img00.jpeg)
*Context (from source page): Rifle Marksmanship ______________________________________________________________________________________ A-3
Now plot the precise location of the first shot by writ-
ing the numeral 1 on the large target diagram provided
in the block marked PLOT.   ...*
*(Dimensions: 616×431)*

![Figure from page 110](images/p110_img00.jpeg)
*Context (from source page): A-4 _______________________________________________________________________________________________ MCRP 3-01A
Elevation. Locate the closest horizontal grid line to
the center of the plotted shot group. Follow the line
across to the numbered vertical...*
*(Dimensions: 617×435)*

![Figure from page 112](images/p112_img00.jpeg)
*Context (from source page): A-6 _______________________________________________________________________________________________ MCRP 3-01A
Determine Windage Adjustment
The chart beneath the flag indicates the number of
clicks on the rear sight windage knob to offset the ef-
fec...*
*(Dimensions: 617×569)*

---

--- chunk_id: chunk-0000
source_document: MCRP3-01A.pdf
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 24
content_hash: 7508516badfd8230
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: Rifle Marksmanship
document_type: technical_reference

## Rifle Marksmanship

![Figure from page 1](images/p001_img00.png)

### U.S. Marine Corps
### MCRP 3-01A
PCN 144 000091 00

--- chunk_id: chunk-0001
source_document: MCRP3-01A.pdf
page: 2
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 236
content_hash: 1c5c8d684de74ebc
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
document_type: technical_reference

To Our Readers
Changes:  Readers of this publication are encouraged to submit suggestions and changes that
will improve it. Recommendations may be sent directly to Commanding General, Marine
Corps Combat Development Command, Doctrine Division (C 42), 3300 Russell Road, Suite
318A, Quantico, VA 22134-5021 or by fax to 703-784-2917 (DSN 278-2917) or by E-mail to
morgann@mccdc.usmc.mil. Recommendations should include the following information:
l 
Location of change
Publication number and title
Current page number
Paragraph number (if applicable)
Line number
Figure or table number (if applicable)
l 
Nature of change
Add, delete
Proposed new text, preferably double-spaced and typewritten
l 
Justification and/or source of change
Additional copies:  A printed copy of this publication may be obtained from Marine Corps
Logistics Base, Albany, GA 31704-5001, by following the instructions in MCBul 5600,
Marine Corps Doctrinal Publications Status. An electronic copy may be obtained from the
Doctrine Division, MCCDC, world wide web home page which is found at the following uni-
versal reference locator:  http://www.doctrine.usmc.mil. Unless otherwise stated, whenever the masculine gender is used, both 
men and women are included.

--- chunk_id: chunk-0002
source_document: MCRP3-01A.pdf
page: 3
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 244
content_hash: d491b170c22ebedf
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: 1.  PURPOSE
document_type: technical_reference

DEPARTMENT OF THE NAVY
Headquarters United States Marine Corps
Washington, D.C. 20380-1775
29 March 2001
FOREWORD
1. PURPOSE
Marine Corps Reference Publication (MCRP) 3-01A, Rifle Marksmanship, provides techniques
and procedures for Marine Corps rifle marksmanship. 2. SCOPE
Every Marine is first and foremost a rifleman. MCRP 3-01A reflects this ethos and the Marine
Corps’ warfighting philosophy. This publication discusses the individual skills required for
effective rifle marksmanship and standardizes the techniques and procedures used throughout the
Marine Corps. It constitutes the doctrinal basis for all entry-level and sustainment-level rifle
marksmanship training. 3. SUPERSESSION 
MCRP 3-01A supersedes the discussion of rifle marksmanship in Fleet Marine Force Manual
(FMFM) 0-8, Basic Marksmanship, and FMFM 0-9, Field Firing for the M16A2 Rifle. The
discussion of pistol marksmanship in FMFM 0-8 remains in effect until it is superseded by
MCRP 3-01B, Pistol Marksmanship, which is currently under development. 4. CERTIFICATION
Reviewed and approved this date. BY DIRECTION OF THE COMMANDANT OF THE MARINE CORPS
B. B. KNUTSON, JR. Lieutenant General, U. S. Marine Corps
Commanding General
Marine Corps Combat Development Command
Quantico, Virginia
DISTRIBUTION:  144 000091 00

--- chunk_id: chunk-0003
source_document: MCRP3-01A.pdf
page: 3
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 8
content_hash: 5d2f058e3d3aadb0
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: Figures
document_type: technical_reference

## Figures

![Figure from page 3](images/p003_img00.jpeg)

--- chunk_id: chunk-0004
source_document: MCRP3-01A.pdf
page: 4
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 10
content_hash: 0ef955b8849ded2d
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
document_type: technical_reference

1-2
MCWP 2-12. MAGTF Intelligence Analysis and Production

--- chunk_id: chunk-0005
source_document: MCRP3-01A.pdf
page: 5
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 4
content_hash: 4e375225bec86687
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
document_type: technical_reference

Table of Contents

--- chunk_id: chunk-0006
source_document: MCRP3-01A.pdf
page: 5
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 290
content_hash: 0b6172e7630e1f97
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: Chapter 1. Introduction to Rifle Marksmanship
document_type: technical_reference

Chapter 1. Introduction to Rifle Marksmanship
1001
Role of the Marine Rifleman . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 1-1
1002
Conditions Affecting Marksmanship in Combat . . . . . . . . . . . . . . . . . . . . . . 1-1
1003
Combat Mindset. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 1-1
Physical Preparation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 1-2
Mental Preparation. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 1-2

--- chunk_id: chunk-0007
source_document: MCRP3-01A.pdf
page: 5
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 669
content_hash: 70a0c8122b9a9aa2
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: Chapter 2. Introduction to the M16A2 Service Rifle
document_type: technical_reference

Chapter 2. Introduction to the M16A2 Service Rifle
2001
Description. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-1
2002
Operational Controls . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-1
Selector Lever . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-1
Magazine Release Button . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-2
Charging Handle . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-2
Bolt Catch . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-3
2003
Cycle of Operation. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-3
Firing . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-3
Unlocking . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-3
Extracting. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

--- chunk_id: chunk-0008
source_document: MCRP3-01A.pdf
page: 5
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 669
content_hash: a82e1b98f4131207
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: Chapter 2. Introduction to the M16A2 Service Rifle
document_type: technical_reference

. . 2-4
Ejecting . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-4
Cocking . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-4
Feeding . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-5
Chambering . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-5
Locking . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-5
2004
Ammunition . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-5
M193 Ball . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-6
M855 Ball . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-6
M196 and M856 Tracer. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-6
M199 Dummy . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

--- chunk_id: chunk-0009
source_document: MCRP3-01A.pdf
page: 5
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 646
content_hash: a6a482c7480e143e
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
section_heading: Chapter 2. Introduction to the M16A2 Service Rifle
document_type: technical_reference

. . . . . . . . . . . . . 2-6
M200 Blank . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-6
2005
Preventive Maintenance. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-6
Main Group Disassembly . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-6
Magazine Disassembly . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-7
Cleaning. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-8
Inspection. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-9
Lubrication. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-9
Reassembly . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-9
2006
Function Check . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-10
2007
User Serviceability Inspection . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-10

--- chunk_id: chunk-0010
source_document: MCRP3-01A.pdf
page: 6
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 349
content_hash: 83e871258f7c83a7
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
document_type: technical_reference

iv ________________________________________________________________________________________________ MCRP 3-01A
2008
Field Maintenance . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-11
2009
Cleaning the Rifle in Various Conditions . . . . . . . . . . . . . . . . . . . . . . . . . . 2-11
Hot, Wet Tropical . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-11
Hot, Dry Desert . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-11
Arctic or Low Temperature . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-11
Heavy Rain and Fording . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2-11

--- chunk_id: chunk-0011
source_document: MCRP3-01A.pdf
page: 6
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 648
content_hash: 1c92b88b6c201dd6
prev_chunk_id: chunk-0010
next_chunk_id: chunk-0012
section_heading: Chapter 3. Weapons Handling
document_type: technical_reference

Chapter 3. Weapons Handling
3001
Safety Rules . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-1
3002
Weapons Condition . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-1
3003
Determining a Weapon’s Condition (Chamber Check) . . . . . . . . . . . . . . . . . 3-1
3004
Weapons Commands . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-2
Loading the Rifle . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-3
Making the Rifle Ready . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-3
Fire . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-3
Cease-Fire . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-3
Unloading the Rifle . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-3
Unloading and Showing the Rifle Clear . . . . . . . . . . . . . . . . . . . . . . . . . . 3-4
3005
Filling, Stowing, and Withdrawing Magazines . . . . . . . . . . . . . . . . . . . . . . .

--- chunk_id: chunk-0012
source_document: MCRP3-01A.pdf
page: 6
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 660
content_hash: 6e7469feaadfc81f
prev_chunk_id: chunk-0011
next_chunk_id: chunk-0013
section_heading: Chapter 3. Weapons Handling
document_type: technical_reference

. . 3-5
Filling the Magazine with Loose Rounds . . . . . . . . . . . . . . . . . . . . . . . . . 3-5
Filling the Magazine Using a 10-round
Stripper Clip and Magazine Filler . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-5
Stowing Magazines . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-5
Withdrawing Magazines . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-6
3006
Reloading the Rifle. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-6
Principles of Reloading . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-6
Condition 1 Reload . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-7
Dry Reload . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-7
3007
Remedial Action. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-7
Observe for Indicators . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-7
Audible Pop or Reduced Recoil. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-8
3008
Weapons Carries. . . . . . . . .

--- chunk_id: chunk-0013
source_document: MCRP3-01A.pdf
page: 6
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 356
content_hash: 79004fdec7c578f0
prev_chunk_id: chunk-0012
next_chunk_id: chunk-0014
section_heading: Chapter 3. Weapons Handling
document_type: technical_reference

. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-8
Tactical Carry. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-8
Alert Carry . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-9
Ready Carry . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-9
3009
Weapons Transports . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-10
Strong Side Sling Arms Transport (Muzzle Up) . . . . . . . . . . . . . . . . . . . 3-10

--- chunk_id: chunk-0014
source_document: MCRP3-01A.pdf
page: 7
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 565
content_hash: e72ed9445787ab34
prev_chunk_id: chunk-0013
next_chunk_id: chunk-0015
document_type: technical_reference

Rifle Marksmanship __________________________________________________________________________________________ v
Weak Side Sling Arms Transport (Muzzle Down) . . . . . . . . . . . . . . . . . 3-10
Cross Body Sling Arms Transport. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-10
3010
Transferring the Rifle. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-11
Show Clear Transfer . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-11
Condition Unknown Transfer . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-11
3011
Clearing Barrel Procedures . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-11
Purpose of a Clearing Barrel . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-11
Procedures for “Load” . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-12
Procedures for “Make Ready”. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-12
Procedures for “Unload” . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 3-12
Procedures for “Unload and Show Clear”. . . . . . . . . . . . . . . . . . . . . . . . 3-12

--- chunk_id: chunk-0015
source_document: MCRP3-01A.pdf
page: 7
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 650
content_hash: 5122ce7b5f60fd9b
prev_chunk_id: chunk-0014
next_chunk_id: chunk-0016
section_heading: Chapter 4. Fundamentals of Marksmanship
document_type: technical_reference

Chapter 4. Fundamentals of Marksmanship
4001
Aiming . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4-1
Sight Alignment. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4-1
Sight Picture. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4-1
Importance of Correct Sight Alignment . . . . . . . . . . . . . . . . . . . . . . . . . . 4-2
Factors Affecting Sight Alignment and Sight Picture . . . . . . . . . . . . . . . . 4-2
Acquiring and Maintaining Sight Alignment and Sight Picture . . . . . . . . 4-4
Size and Distance to the Target . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4-4
4002
Breath Control . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4-5
Breath Control During Long-range or Precision Fire (Slow Fire) . . . . . . 4-5
Breath Control During All Other Combat Situations . . . . . . . . . . . . . . . . 4-5
4003
Trigger Control . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4-6
Grip . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4-6
Trigger Finger Placement . . . . . . . . . . . . . .

--- chunk_id: chunk-0016
source_document: MCRP3-01A.pdf
page: 7
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 336
content_hash: c2ac3500ccc15e8e
prev_chunk_id: chunk-0015
next_chunk_id: chunk-0017
section_heading: Chapter 4. Fundamentals of Marksmanship
document_type: technical_reference

. . . . . . . . . . . . . . . . . . . . . . . . . 4-6
Types of Trigger Control. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4-6
Resetting the Trigger . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4-6
4004
Follow-Through/Recovery. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4-7
Follow-Through. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4-7
Recovery . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4-7

--- chunk_id: chunk-0017
source_document: MCRP3-01A.pdf
page: 7
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 613
content_hash: 43de5bd397e160b4
prev_chunk_id: chunk-0016
next_chunk_id: chunk-0018
section_heading: Chapter 5. Rifle Firing Positions
document_type: technical_reference

Chapter 5. Rifle Firing Positions
5001
Selecting a Firing Position . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-1
Stability . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-1
Mobility . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-1
Observation of the Enemy . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-1
5002
Types and Uses of the Rifle Web Sling . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-1
Hasty Sling. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-2
Loop Sling . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-3
5003
Factors Common to All Shooting Positions. . . . . . . . . . . . . . . . . . . . . . . . . . 5-4
Left Hand. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-4
Rifle Butt in the Pocket of the Shoulder . . . . . . . . . . . . . . . . . . . . . . . . . . 5-5

--- chunk_id: chunk-0018
source_document: MCRP3-01A.pdf
page: 8
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 664
content_hash: 24a7d7e9a2c6fb9a
prev_chunk_id: chunk-0017
next_chunk_id: chunk-0019
document_type: technical_reference

vi ________________________________________________________________________________________________ MCRP 3-01A
Grip of the Right Hand. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-6
Right Elbow . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-6
Stock Weld. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-6
Breathing . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-6
Muscular Tension/Relaxation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-6
5004
Elements of a Good Shooting Position. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-7
Bone Support . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-7
Muscular Relaxation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-7
Natural Point of Aim . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-7
5005
Prone Position. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-8
Application. . . . . . . . . . . . . . . . . . . . . . . . . . . . .

--- chunk_id: chunk-0019
source_document: MCRP3-01A.pdf
page: 8
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 637
content_hash: 9be633c9c3f57fd1
prev_chunk_id: chunk-0018
next_chunk_id: chunk-0020
document_type: technical_reference

. . . . . . . . . . . . . . . . . . . . . . 5-8
Assuming the Prone Position . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-8
Straight Leg Prone Position with the Hasty Sling . . . . . . . . . . . . . . . . . . . 5-9
Straight Leg Prone Position with the Loop Sling . . . . . . . . . . . . . . . . . . 5-10
Cocked Leg Prone Position with the Hasty Sling . . . . . . . . . . . . . . . . . . 5-11
Cocked Leg Prone Position with the Loop Sling. . . . . . . . . . . . . . . . . . . 5-11
5006
Sitting Position . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-12
Crossed Ankle Sitting Position with the Hasty Sling . . . . . . . . . . . . . . . 5-12
Crossed Ankle Sitting Position with the Loop Sling . . . . . . . . . . . . . . . . 5-13
Crossed Leg Sitting Position with the Hasty Sling . . . . . . . . . . . . . . . . . 5-13
Crossed Leg Sitting Position with the Loop Sling. . . . . . . . . . . . . . . . . . 5-14
Open Leg Sitting Position with the Hasty Sling . . . . . . . . . . . . . . . . . . . 5-14
Open Leg Sitting Position with the Loop Sling . . . . . . . . . . . . . . . . . . . . 5-15
5007
Kneeling Position . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-15
Description. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

--- chunk_id: chunk-0020
source_document: MCRP3-01A.pdf
page: 8
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 454
content_hash: 2285a238c7e34d46
prev_chunk_id: chunk-0019
next_chunk_id: chunk-0021
document_type: technical_reference

. . 5-15
Assuming the Kneeling Position . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-15
High Kneeling Position with the Hasty Sling . . . . . . . . . . . . . . . . . . . . . 5-16
High Kneeling Position with the Loop Sling. . . . . . . . . . . . . . . . . . . . . . 5-17
Medium Kneeling Position . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-17
Low Kneeling Position. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-18
5008
Standing Position . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-18
Description. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5-18
Standing Position with the Hasty Sling . . . . . . . . . . . . . . . . . . . . . . . . . . 5-18
Standing Position with the Parade Sling . . . . . . . . . . . . . . . . . . . . . . . . . 5-19

--- chunk_id: chunk-0021
source_document: MCRP3-01A.pdf
page: 8
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 450
content_hash: 98f50e3c597f28fd
prev_chunk_id: chunk-0020
next_chunk_id: chunk-0022
section_heading: Chapter 6. Use of Cover and Concealment
document_type: technical_reference

Chapter 6. Use of Cover and Concealment
6001
Cover and Concealment . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 6-1
Types of Cover. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 6-1
Common Cover Materials . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 6-1
Firing From Specific Types of Cover . . . . . . . . . . . . . . . . . . . . . . . . . . . . 6-2
6002
Supported Firing Positions . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 6-4
Considerations Using Cover and Concealment . . . . . . . . . . . . . . . . . . . . . 6-4
Seven Factors . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 6-6
Types of Supported Positions . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 6-8

--- chunk_id: chunk-0022
source_document: MCRP3-01A.pdf
page: 9
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 266
content_hash: bc36df4376eaaa4a
prev_chunk_id: chunk-0021
next_chunk_id: chunk-0023
document_type: technical_reference

Rifle Marksmanship ________________________________________________________________________________________ vii
6003
Searching for and Engaging Targets From Behind Cover. . . . . . . . . . . . . . 6-10
Pie Technique . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 6-10
Rollout Technique . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 6-10
Combining Techniques . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 6-10
6004
Moving Out From Behind Cover. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 6-11

--- chunk_id: chunk-0023
source_document: MCRP3-01A.pdf
page: 9
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: f4cec7b2f131fffa
prev_chunk_id: chunk-0022
next_chunk_id: chunk-0024
section_heading: Chapter 7. Rifle Presentation
document_type: technical_reference

Chapter 7. Rifle Presentation
7001
Presentation of the Rifle. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 7-1
Presenting the Rifle From the Tactical Carry . . . . . . . . . . . . . . . . . . . . . . 7-1
Presenting the Rifle From the Alert Carry and From the Ready Carry. . . 7-1
Presenting the Rifle From the Strong Side Sling Arms Transport . . . . . . 7-2
Presenting the Rifle From the Weak Side Sling Arms Transport . . . . . . . 7-3
7002
Search and Assess . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 7-4
Purpose . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 7-4
Technique . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 7-4
Searching and Assessing to a Higher Profile. . . . . . . . . . . . . . . . . . . . . . . 7-4

--- chunk_id: chunk-0024
source_document: MCRP3-01A.pdf
page: 9
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 641
content_hash: 3b7b7288c20f6f68
prev_chunk_id: chunk-0023
next_chunk_id: chunk-0025
section_heading: Chapter 8. Effects of Weather
document_type: technical_reference

Chapter 8. Effects of Weather
8001
Physical Effects of Wind on the Bullet . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 8-1
Physical Effects . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 8-1
Determining Windage Adjustments to Offset Wind Effects . . . . . . . . . . . 8-1
8002
Physical Effects of Temperature and
Precipitation on the Bullet and the Rifle . . . . . . . . . . . . . . . . . . . . . . . . . . . . 8-2
Temperature. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 8-2
Precipitation. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 8-4
8003
Physical and Psychological Effects of Weather on Marines . . . . . . . . . . . . . 8-4
Wind . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 8-4
Temperature. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 8-4
Precipitation. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 8-4
Light. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 8-5

--- chunk_id: chunk-0025
source_document: MCRP3-01A.pdf
page: 9
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 669
content_hash: b77b7b159982113a
prev_chunk_id: chunk-0024
next_chunk_id: chunk-0026
section_heading: Chapter 9. Zeroing
document_type: technical_reference

Chapter 9. Zeroing
9001
Elements of Zeroing. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-1
Line of Sight . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-1
Aiming Point . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-1
Centerline of Bore . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-1
Trajectory. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-1
Range . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-2
9002
Types of Zeros . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-2
Battlesight Zero (BZO) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-2
Zero . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-2
True Zero . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

--- chunk_id: chunk-0026
source_document: MCRP3-01A.pdf
page: 9
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 13
content_hash: 8402aa73a543af92
prev_chunk_id: chunk-0025
next_chunk_id: chunk-0027
section_heading: Chapter 9. Zeroing
document_type: technical_reference

. . . . . . . . . 9-2

--- chunk_id: chunk-0027
source_document: MCRP3-01A.pdf
page: 10
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 660
content_hash: 91c9a93ac93e6e25
prev_chunk_id: chunk-0026
next_chunk_id: chunk-0028
document_type: technical_reference

viii _______________________________________________________________________________________________ MCRP 3-01A
9003
M16A2 Sighting System . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-2
Front Sight . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-2
Rear Sight. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-2
9004
Windage and Elevation Rules . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-3
Front Sight Elevation Rule. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-3
Rear Sight Elevation Rule . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-4
Windage Rule. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-4
9005
Initial Sight Settings . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-4
Front Sight Post . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-4
Rear Sight Elevation Knob . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-4
Windage Knob . . . . . . . . . . . . . . . . . . . . . . . . . . .

--- chunk_id: chunk-0028
source_document: MCRP3-01A.pdf
page: 10
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 662
content_hash: 048ccebcd5889fab
prev_chunk_id: chunk-0027
next_chunk_id: chunk-0029
document_type: technical_reference

. . . . . . . . . . . . . . . . . . . . . 9-4
9006
Zeroing Process . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-4
9007
Battlesight Zero . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-5
9008
Factors Causing a BZO to be Reconfirmed . . . . . . . . . . . . . . . . . . . . . . . . . . 9-6
Maintenance. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-6
Temperature . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-6
Climate. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-6
Ammunition . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-6
Ground Elevation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-6
Uniform . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-6
9009
Factors Affecting the Accuracy of a BZO . . . . . . . . . . . . . . . . . . . . . . . . . . . 9-7

--- chunk_id: chunk-0029
source_document: MCRP3-01A.pdf
page: 10
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 662
content_hash: 53c7f6e65ac9cdb7
prev_chunk_id: chunk-0028
next_chunk_id: chunk-0030
section_heading: Chapter 10. Engagement Techniques
document_type: technical_reference

Chapter 10. Engagement Techniques
10001 Target Detection. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-1
Target Indicators . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-1
Identifying Target Location . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-2
Maintaining Observation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-3
Remembering Target Location . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-3
10002 Range Estimation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-3
Range Estimation Methods . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-3
Factors Affecting Range Estimation . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-4
10003 Offset Aiming. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-5
Point of Aim Technique. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-5
Known Strike of the Round . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-6
10004 Techniques of Fire . . . . . . . . . . . . . . . . . . . . . . . .

--- chunk_id: chunk-0030
source_document: MCRP3-01A.pdf
page: 10
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 300
content_hash: ec8e076e1db243db
prev_chunk_id: chunk-0029
next_chunk_id: chunk-0031
section_heading: Chapter 10. Engagement Techniques
document_type: technical_reference

. . . . . . . . . . . . . . . . . . . . . . 10-7
Two-Shot Technique . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-7
Single Shot Technique . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-7
Sustained Rate of Fire . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-7
Three-Round Burst Technique. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-7
10005 Engaging Immediate Threat Targets . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-7

--- chunk_id: chunk-0031
source_document: MCRP3-01A.pdf
page: 11
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 662
content_hash: 71d5108b303bd82e
prev_chunk_id: chunk-0030
next_chunk_id: chunk-0032
document_type: technical_reference

Rifle Marksmanship _________________________________________________________________________________________ ix
10006 Engaging Multiple Targets. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-7
Prioritizing Targets . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-8
Technique of Engagement. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-8
Firing Position . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-8
10007 Engaging Moving Targets . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-8
Types of Moving Targets. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-9
Leads . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-9
Engagement Methods . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-10
Marksmanship Fundamentals . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-11
10008 Engaging Targets at Unknown Distances . . . . . . . . . . . . . . . . . . . . . . . . . 10-11
Hasty Sight Setting . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-11
Point of Aim Technique. . . . . . . . . . . . . . . . . . . . . . . . . . .

--- chunk_id: chunk-0032
source_document: MCRP3-01A.pdf
page: 11
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 658
content_hash: 4652a44897e67382
prev_chunk_id: chunk-0031
next_chunk_id: chunk-0033
document_type: technical_reference

. . . . . . . . . . . . 10-12
10009 Engaging Targets During Low Light and Darkness . . . . . . . . . . . . . . . . . 10-12
Night Vision. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-12
Searching Methods . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-12
Types of Illumination . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-13
Effects of Illumination. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-14
10010 Engaging Targets while Wearing the Field Protective Mask . . . . . . . . . . 10-14
Marksmanship Fundamentals . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-14
Firing Position . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10-14
Appendices
A
Data Book . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .A-1
Data Book . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .A-1
Recording Data Before Firing . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .A-1
Recording Data During Firing. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

--- chunk_id: chunk-0033
source_document: MCRP3-01A.pdf
page: 11
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 130
content_hash: 70c033473eac70bc
prev_chunk_id: chunk-0032
next_chunk_id: chunk-0034
document_type: technical_reference

. . . .A-2
Recording Data After Firing . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .A-5
B
Glossary . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .B-1

--- chunk_id: chunk-0034
source_document: MCRP3-01A.pdf
page: 12
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: a64e48e0d064cad2
prev_chunk_id: chunk-0033
next_chunk_id: chunk-0035
section_heading: CHAPTER 1. INTRODUCTION TO RIFLE MARKSMANSHIP
document_type: technical_reference

CHAPTER 1. INTRODUCTION TO RIFLE MARKSMANSHIP
All Marines share a common warfighting belief: “Every Marine a rifleman.” This
simple credo reinforces the belief that all Marines are forged from a common
experience, share a common set of values, and are trained as members of an
expeditionary force in readiness. As such, there are no “rear area” Marines, and no
one is very far from the fighting during expeditionary operations. The Marine
rifleman of the next conflict will be as in past conflicts: among the first to confront
the enemy and the last to hang his weapon in the rack after the conflict is won. 1001. ROLE OF THE MARINE RIFLEMAN
Marine Corps forces are employed across the entire
range of military operations. At one end is war, which
is characterized by large-scale, sustained combat oper-
ations. At the other end of the scale are those actions
referred to as military operations other than war
(MOOTW). MOOTW focuses on deterring aggres-
sion, resolving conflict, promoting peace, and support-
ing civil authorities. These operations can occur
before, during, and after combat operations. Training
and preparation for MOOTW should not detract from
the Corps’ primary mission of training Marines to
fight and win in combat. MOOTW normally does not
involve combat. However, Marines always need to be
prepared to protect themselves and respond to chang-
ing threats and unexpected situations. Whenever the
situation warrants the application of deadly force, the
Marine rifleman must be able to deliver well aimed
shots to eliminate the threat. Sometimes the need for a
well aimed shot may even be heightened by the pres-
ence of noncombatants in close proximity to the target. The proficient rifleman handles this challenge without
unnecessarily escalating the level of violence or caus-
ing unnecessary collateral damage. The Marine rifle-
man must have the versatility, flexibility, and skills to
deal with a situation at any level of intensity across the
entire range of military operations. To be combat ready, the Marine must be skilled in the
techniques and procedures of rifle marksmanship and
take proper care of his rifle. Even when equipped with
the best rifle in the world, a unit with poorly trained ri-
flemen cannot be depended upon to accomplish their
mission. Usually, poorly trained riflemen either fail to
fire their weapon or they waste ammunition by firing
ineffectively.

--- chunk_id: chunk-0035
source_document: MCRP3-01A.pdf
page: 12
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 426
content_hash: e73b3f488567978a
prev_chunk_id: chunk-0034
next_chunk_id: chunk-0036
section_heading: CHAPTER 1. INTRODUCTION TO RIFLE MARKSMANSHIP
document_type: technical_reference

Even when equipped with
the best rifle in the world, a unit with poorly trained ri-
flemen cannot be depended upon to accomplish their
mission. Usually, poorly trained riflemen either fail to
fire their weapon or they waste ammunition by firing
ineffectively. To send Marines into harm’s way with-
out thorough training in the use of their individual
weapons carries undue risks for every Marine in the
unit. On the other hand, well trained riflemen can de-
liver accurate fire against the enemy under the most
adverse conditions. A well trained rifleman is not only
confident that he can help his unit accomplish it’s mis-
sion, he is confident that he can protect his fellow
Marines and himself. 1002. CONDITIONS AFFECTING 
MARKSMANSHIP IN COMBAT
Many factors affect the application of marksmanship
in combat; among them are—
l Most targets are linear in nature and will consist of
a number of men or objects irregularly spaced along
covered or concealed areas. l Most targets can be detected by smoke, flash, dust,
noise or movement, but will only be visible for a
brief moment before taking cover. l The nature of the target, irregularities of terrain and
vegetation will often require a rifleman to use a
position other than prone in order to fire effectively
on the target. l The time in which a target can be engaged is often
fleeting. 1003. COMBAT MINDSET
In a combat environment, the Marine must be con-
stantly prepared for possible target engagement. When
a target presents itself in combat, there may be very lit-
tle time to take action. A Marine must be able to en-
gage the target quickly and accurately. The unique
demands of combat (i.e., stress, uncertainty) dictate
that the Marine be both physically and mentally pre-
pared to engage enemy targets. It will not be enough to
simply know marksmanship techniques and proce-
dures. The Marine must develop the mental discipline

--- chunk_id: chunk-0036
source_document: MCRP3-01A.pdf
page: 13
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: 915c7321199d0fba
prev_chunk_id: chunk-0035
next_chunk_id: chunk-0037
document_type: technical_reference

1-2 ________________________________________________________
to prepare for enemy contact. In the confusion, noise,
and stress of the combat environment, the Marine must
have the ability to eliminate any hesitation, fear or un-
certainty of action and to focus on the actions required
to fire well-aimed shots. This is accomplished through
establishment of a combat mindset. The key factors in
the development of a combat mindset include both
physical and mental preparation. Physical Preparation
In combat, targets can present themselves without
warning. Therefore, it is essential for the Marine to
maintain proper balance and control of his weapon at
all times so he can quickly assume a firing position,
present the weapon, and accurately engage the target. However, speed alone does not equate to effective tar-
get engagement. The Marine should fire only as fast as
he can fire accurately, never exceeding his physical
ability to apply the fundamentals of marksmanship. To
be effective in combat, the Marine must train to per-
fect the physical skills of shooting so those skills be-
come second nature. Mastery of physical skills allow
the Marine to concentrate on the mental aspects of tar-
get engagement; e.g., scanning for targets, detection of
targets, selection and use of cover. The more physical
skills that a Marine can perform automatically, the
more concentration he can give to the mental side of
target engagement. Mental Preparation
While combat is unpredictable and constantly chang-
ing, the Marine can prepare himself mentally for con-
frontation with the enemy. The stress of battle,
p
r
r
r

___________________________________________ MCRP 3-01A
coupled with the often limited time available to en-
gage targets, requires concentration on the mental as-
pects of target engagement; e.g., scanning for targets,
detection of targets, and the selection and use of cover. Knowledge of the Combat Environment
The Marine must be constantly aware of the sur-
roundings to include the terrain, available cover, pos-
sible areas of enemy contact, backdrop of the target,
etc. This awareness will enable the Marine to select
and assume a firing position and to quickly and accu-
rately engage targets. Plan of Action
In combat, the situation will dictate the action to be
taken. The Marine must understand the situation, iden-
tify and evaluate possible courses of action, and then
develop a plan for target engagement that accomplish-
es the mission.

--- chunk_id: chunk-0037
source_document: MCRP3-01A.pdf
page: 13
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 198
content_hash: 1c295a1d99b8f6a9
prev_chunk_id: chunk-0036
next_chunk_id: chunk-0038
document_type: technical_reference

Plan of Action
In combat, the situation will dictate the action to be
taken. The Marine must understand the situation, iden-
tify and evaluate possible courses of action, and then
develop a plan for target engagement that accomplish-
es the mission. Confidence
The Marine must believe in his ability to engage tar-
gets accurately in any combat situation. A Marine’s
level of confidence is rooted in the belief that future
challenges will be overcome—particularly the chal-
lenge of firing well aimed shots in a combat environ-
ment where the enemy may be returning fire. A key
factor in a Marine’s level of confidence is the degree
to which he has mastered the techniques and proce-
dures of the rifle marksmanship. Mastery of rifle
marksmanship can only be obtained by quality instruc-
tion. Quality instruction is the foundation for practical
application of the marksmanship fundamentals during
range and field firing.

--- chunk_id: chunk-0038
source_document: MCRP3-01A.pdf
page: 14
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 404
content_hash: c54d79b21df8a01d
prev_chunk_id: chunk-0037
next_chunk_id: chunk-0039
section_heading: CHAPTER 2. INTRODUCTION TO THE M16A2 SERVICE RIFLE
document_type: technical_reference

CHAPTER 2. INTRODUCTION TO THE M16A2 SERVICE RIFLE
Note
+The procedures in this manual are written
for right-handed Marines; left-handed
Marines should reverse instructions as
necessary. 2001. DESCRIPTION
The M16A2 service rifle is a lightweight, 5.56
millimeter (mm), magazine-fed, gas-operated, air-
cooled, shoulder-fired rifle. (Fig. 2-1 shows a right-
side view and fig. 2-2, on page 2-2, shows the left-side
view.) The rifle fires in either semiautomatic (single-
shot) mode or a three-round burst through the use of a
selector lever. The M16A2 service rifle has a
maximum effective range of 550 meters for individual
or point targets. The bore and chamber are chrome-
plated to reduce wear and fouling. The handguards are
aluminum-lined and are vented to permit air to
circulate around the barrel for cooling purposes and to
protect the gas tube. An aluminum receiver helps
reduce the overall weight of the rifle. The trigger
guard is equipped with a spring-loaded retaining pin
that, when depressed, allows the trigger guard to be
rotated out of the way for access to the trigger while
wearing heavy gloves. An ejection port cover prevents
dirt and sand from getting into the rifle through the
ejection port. The ejection port cover should be closed
when the rifle is not being fired. It is automatically
opened by the action of the bolt carrier. The muzzle
compensator serves as a flash suppressor and assists in
reducing muzzle climb. 2002. OPERATIONAL CONTROLS
Selector Lever
The selector lever has three settings—safe, semi, and
burst. The setting selected depends on the firing
situation. See figure 2-3 on page 2-2. Safe
The selector lever in the safe position prevents the rifle
from firing. Semi
The selector lever in the semi position allows one shot
to be fired with each pull of the trigger. Figure 2-1. M16A2 Service Rifle (Right Side View).

--- chunk_id: chunk-0039
source_document: MCRP3-01A.pdf
page: 14
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 24
content_hash: d09033444d405da0
prev_chunk_id: chunk-0038
next_chunk_id: chunk-0040
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 2-1. M16A2 Service Rifle (Right Side View).](images/p014_img00.png)
*Figure 2-1. M16A2 Service Rifle (Right Side View).*

--- chunk_id: chunk-0040
source_document: MCRP3-01A.pdf
page: 15
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 268
content_hash: 1ec5cedafef0d372
prev_chunk_id: chunk-0039
next_chunk_id: chunk-0041
document_type: technical_reference

2-2 _______________________________________________________________________________________________ MCRP 3-01A
Burst
The selector lever in the burst position allows the rifle
to continue its cycle of operation until interrupted by
the burst cam. With each pull of the trigger, the burst
cam limits the maximum number of rounds fired to
three. The burst cam is not “self-indexing.” If burst is
selected, the burst cam does not automatically reset to
the first shot position of the three-round burst. One,
two or three shots may be fired on the first pull of the
trigger. Each subsequent pull of the trigger results in a
complete three-round burst unless the trigger is
released before the cycle is complete. If the trigger is
released during the burst and the three-round cycle is
interrupted, the next pull of the trigger fires the rounds
remaining in the interrupted three-round cycle. Magazine Release Button
The magazine release button releases the magazine
from the magazine well. See figure 2-4. Charging Handle
When the charging handle is pulled to the rear, the bolt
unlocks from the barrel extension locking lugs and the
bolt carrier group moves to the rear of the receiver. See figure 2-5. Figure 2-2. M16A2 Service Rifle (Left Side View). Figure 2-3. Selector Lever.

--- chunk_id: chunk-0041
source_document: MCRP3-01A.pdf
page: 15
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 34
content_hash: 2dfa79eea72cf669
prev_chunk_id: chunk-0040
next_chunk_id: chunk-0042
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 2-2. M16A2 Service Rifle (Left Side View).](images/p015_img00.png)
*Figure 2-2. M16A2 Service Rifle (Left Side View).*

![Figure 2-3. Selector Lever.](images/p015_img01.png)
*Figure 2-3. Selector Lever.*

--- chunk_id: chunk-0042
source_document: MCRP3-01A.pdf
page: 16
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 309
content_hash: c7f570f840afb6e8
prev_chunk_id: chunk-0041
next_chunk_id: chunk-0043
document_type: technical_reference

Rifle Marksmanship _______________________________________________________________________________________ 2-3
Bolt Catch
If the charging handle is pulled to the rear when the
lower portion of the bolt catch is depressed, the bolt
carrier group will lock to the rear. When the bolt car-
rier group is locked to the rear and the upper portion of
the bolt catch is depressed, the bolt carrier group will
slide forward, driven by the buffer assembly and
action spring, into the firing position. 2003. CYCLE OF OPERATION
Firing
The hammer releases and strikes the head of the firing
pin, driving the firing pin into the round’s primer. The
primer ignites the powder in the cartridge. Gas
generated by the rapid burning of powder propels the
projectile through the barrel. After the projectile pas-
ses the gas port, a portion of the expanding gas enters
the gas port and gas tube. The gas tube directs the gas
rearward into the bolt carrier key and causes the bolt
carrier to move rearward. See figure 2-6 on page 2-4. Unlocking
Figure 2-7 on page 2-4 illustrates unlocking of the
bolt. As the bolt carrier moves to the rear, the bolt cam
pin follows the path of the cam track located in the
bolt carrier. This causes the bolt assembly to rotate
until the bolt-locking lugs are no longer aligned
behind the barrel extension locking lugs. Figure 2-4. Magazine Release Button. Figure 2-5. Charging Handle.

--- chunk_id: chunk-0043
source_document: MCRP3-01A.pdf
page: 16
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 40
content_hash: 01c4690e5fcd4e29
prev_chunk_id: chunk-0042
next_chunk_id: chunk-0044
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 2-7 on page 2-4 illustrates unlocking of the](images/p016_img00.png)
*Figure 2-7 on page 2-4 illustrates unlocking of the*

![Figure 2-4. Magazine Release Button.](images/p016_img01.png)
*Figure 2-4. Magazine Release Button.*

--- chunk_id: chunk-0044
source_document: MCRP3-01A.pdf
page: 17
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 189
content_hash: 664270a423d04457
prev_chunk_id: chunk-0043
next_chunk_id: chunk-0045
document_type: technical_reference

2-4 ________________________________________________________
Extracting
As the bolt carrier group continues to move to the rear,
the extractor claw withdraws the cartridge case from
the chamber. See figure 2-8. Figure 2-7. Unlocking. Figure 2-8. Extracting. Figure 2-6. Firing. ___________________________________________ MCRP 3-01A
Ejecting
The ejector, located in the bolt face, is compressed
into the bolt body by the base of the cartridge case. The rearward movement of the bolt carrier group al-
lows the nose of the cartridge case to clear the front of
the ejection port. The cartridge case is thrown out by
the action of the ejector and spring. See figure 2-9. Cocking
Continuing its rearward travel, the bolt carrier over-
rides the hammer, forces it down into the receiver,
compresses the hammer spring, and causes the
disconnector to engage the lower hammer hook. See
figure 2-10. Figure 2-9. Ejecting. Figure 2-10. Cocking.

--- chunk_id: chunk-0045
source_document: MCRP3-01A.pdf
page: 17
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 40
content_hash: 0c20c5f3066ac9d9
prev_chunk_id: chunk-0044
next_chunk_id: chunk-0046
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 2-7. Unlocking.](images/p017_img00.png)
*Figure 2-7. Unlocking.*

![Figure 2-8. Extracting.](images/p017_img01.png)
*Figure 2-8. Extracting.*

![Figure 2-6. Firing.](images/p017_img02.png)
*Figure 2-6. Firing.*

![figure 2-10.](images/p017_img03.png)
*figure 2-10.*

![Figure 2-9. Ejecting.](images/p017_img04.png)
*Figure 2-9. Ejecting.*

--- chunk_id: chunk-0046
source_document: MCRP3-01A.pdf
page: 18
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 321
content_hash: a628f7a0a503bef3
prev_chunk_id: chunk-0045
next_chunk_id: chunk-0047
document_type: technical_reference

Rifle Marksmanship ___________________________________
Feeding
Once rearward motion causes the bolt carrier group to
clear the top of the magazine, the expansion of the
magazine spring forces a round into the path of the
bolt. After the action spring overcomes and absorbs
the rearward motion of the bolt carrier group, it ex-
pands and sends the buffer assembly and bolt carrier
group forward with enough force to strip a round from
the magazine. See figure 2-11. Chambering
As the bolt carrier group continues to move forward,
pushing a fresh round in front of it, the face of the bolt
thrusts the new round into the chamber. The extractor
claw grips the rim of the cartridge case. The ejector is
forced into its hole, compressing the ejector spring. See figure 2-12. Figure 2-11. Feeding. Figure 2-12. Chambering. ________________________________________________________ 2-5
o
e
e
s
-
r
m
,
t
r
s
Locking
As the bolt carrier group continues to move forward,
the bolt-locking lugs are forced against the barrel ex-
tension and the bolt cam pin is forced along the cam
track. The bolt rotates and aligns the bolt locking lugs
behind the barrel extension locking lugs. The weapon
is ready to fire. See figure 2-13. 2004. Ammunition
Four types of ammunition are authorized for use with
the M16A2 service rifle: ball (M193 and M855), tracer
(M196 and M856), dummy (M199), and blank (M200)
(see fig. 2-14). Figure 2-13. Locking. Figure 2-14. Authorized Ammunition.

--- chunk_id: chunk-0047
source_document: MCRP3-01A.pdf
page: 18
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 37
content_hash: 586ecb3a9fe1e082
prev_chunk_id: chunk-0046
next_chunk_id: chunk-0048
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 2-11. Feeding.](images/p018_img00.png)
*Figure 2-11. Feeding.*

![Figure 2-12. Chambering.](images/p018_img01.png)
*Figure 2-12. Chambering.*

![Figure 2-13. Locking.](images/p018_img02.png)
*Figure 2-13. Locking.*

![Figure 2-14. Authorized Ammunition.](images/p018_img03.png)
*Figure 2-14. Authorized Ammunition.*

--- chunk_id: chunk-0048
source_document: MCRP3-01A.pdf
page: 19
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 516
content_hash: fda23d2319d1ae9a
prev_chunk_id: chunk-0047
next_chunk_id: chunk-0049
document_type: technical_reference

2-6 _______________________________________________________________________________________________ MCRP 3-01A
M193 Ball
This ammunition is a 5.56mm centerfire cartridge with
a 55-grain gilded-metal jacket, lead alloy core bullet. The primer and case are waterproofed. The M193 ball
ammunition has no identifying marks. M855 Ball
This ammunition is the primary ammunition for the
M16A2 rifle. Identified by a green tip, its 5.56mm
centerfire cartridge has better penetration than the
M193. It has a 62-grain gilded-metal jacket bullet. The
rear two-thirds of the core of the projectile is lead
alloy and the front one-third is a solid steel penetrator. The primer and case are waterproofed. M196 and M856 Tracer
This ammunition has the same basic characteristics as
ball ammunition. Identified by a bright red tip, its
primary uses include observation firing, incendiary
effect, and signaling. Tracer ammunition should be
intermixed with ball ammunition in a ratio no greater
than 1:1. The preferred ratio is one tracer to four balls
(1:4) to prevent metal fouling in the bore. M199 Dummy
This ammunition has six grooves along the side of the
case. It contains no propellants or primer. The primer
well is open to prevent damage to the firing pin. The
dummy cartridge is used during dry fire and other
training purposes. M200 Blank
This ammunition has the case mouth closed with a
seven-petal rosette crimp. It contains no projectile. Blank ammunition, identified by its violet tip, is used
for training purposes. 2005. Preventive Maintenance
Normal care and cleaning of the rifle will result in
proper functioning of its all parts. Only issue-type
cleaning materials maybe used. Improper maintenance
can cause stoppages, reducing combat readiness and
effectiveness. Main Group Disassembly
The M16A2 service rifle is disassembled into three
main groups (see fig. 2-15). Before disassembling the
M16A2 service rifle—
l 
Ensure the rifle is in Condition 4 (see para. 3002). l 
Remove the sling. Note
To facilitate control and ease of disas-
sembly, the handguards may be removed
using the “buddy system” as described in
Technical Manual (TM) 05538C-10/1A,
Operator’s Manual w/Components List
Rifle, 5.56-mm, M16A2E W/E (1005-01-
128-9936). Upper Receiver
To disassemble the upper
receiver—
l 
Place the rifle on the butt-
stock. Press down on the
slip ring with both hands. Pull the handguards free
(see fig. 2-16). Use caution when the
handguards are off the
rifle. Handguards pro-
vide protection for the
gas tube.

--- chunk_id: chunk-0049
source_document: MCRP3-01A.pdf
page: 19
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 52
content_hash: 08337b42ee0603db
prev_chunk_id: chunk-0048
next_chunk_id: chunk-0050
document_type: technical_reference

Use caution when the
handguards are off the
rifle. Handguards pro-
vide protection for the
gas tube. Damage to
the gas tube adversely
affects the functioning
of the rifle. Figure 2-15. Three Main Groups. Figure 2-16. Removing
the Handguards.

--- chunk_id: chunk-0050
source_document: MCRP3-01A.pdf
page: 19
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 24
content_hash: 235793552e7bf246
prev_chunk_id: chunk-0049
next_chunk_id: chunk-0051
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 2-15. Three Main Groups.](images/p019_img00.jpeg)
*Figure 2-15. Three Main Groups.*

![Figure 2-16. Removing](images/p019_img01.png)
*Figure 2-16. Removing*

--- chunk_id: chunk-0051
source_document: MCRP3-01A.pdf
page: 20
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 506
content_hash: 02f30d75824c4c24
prev_chunk_id: chunk-0050
next_chunk_id: chunk-0052
document_type: technical_reference

Rifle Marksmanship ___________________________________
l Move the take down pin from the left to the right as
far as it will go to allow the lower receiver to pivot
down from the upper receiver. l Move the receiver pivot pin from left to right as far
as it will go and separate the upper and lower
receivers. l Pull back the charging handle and bolt carrier about
3 inches and remove the bolt carrier group. l Remove the charging handle by sliding it back and
down, out of the upper receiver. No further disassembly is conducted on the upper re-
ceiver group. Bolt Carrier
To disassemble the bolt carrier—
l Remove the firing pin retaining pin. l Push the bolt back into the bolt carrier to the locked
position. l Tap the base of the bolt carrier against the palm of
your hand so the firing pin will drop out. l Rotate the bolt cam pin one-quarter turn and lift the
bolt cam pin out. l Withdraw the bolt assembly from the carrier. l Press on the extractor’s rear and use the firing pin to
push out the extractor-retaining pin. Remove the
extractor and spring (the spring is permanently
attached to the extractor). (See fig. 2-17.)
  CAUTION
Be careful not to damage the tip of the
firing pin while pushing out the extractor-
retaining pin. Figure 2-17. Bolt Carrier Disassembled. ________________________________________________________ 2-7
s
t
r
r
t
d
-
d
f
e
o
e
y
Note
The extractor assembly has a rubber insert
within the spring. Do not attempt to re-
move it. If the spring comes loose, put the
large end of the spring in the extractor and
seat it. Push in the extractor pin. Lower Receiver
To disassemble the lower receiver—
l 
Press in the buffer and depress the buffer retainer. Note
It may be necessary to use the edge of the
charging handle to depress the buffer re-
tainer. l 
Press the hammer downward and ease the buffer
and action spring forward and out of the receiver. l 
Separate the parts. See figure 2-18. No further disassembly of the lower receiver is per-
formed. Note
In combat situations, the rifle may be par-
tially disassembled in any sequence. How-
ever, combat situations are the exception,
not the rule.

--- chunk_id: chunk-0052
source_document: MCRP3-01A.pdf
page: 20
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 98
content_hash: 7410bf73c12f7fd9
prev_chunk_id: chunk-0051
next_chunk_id: chunk-0053
document_type: technical_reference

Note
In combat situations, the rifle may be par-
tially disassembled in any sequence. How-
ever, combat situations are the exception,
not the rule. Under normal operating cir-
cumstances, disassemble the rifle in the
sequence just performed. Any further dis-
assembly of the rifle is to be performed by a
qualified armorer. Magazine Disassembly
The magazine should be disassembled regularly for
cleaning to avoid the possibility of malfunction or
Figure 2-18. Lower Receiver Disassembled.

--- chunk_id: chunk-0053
source_document: MCRP3-01A.pdf
page: 20
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 29
content_hash: d936942e95458b69
prev_chunk_id: chunk-0052
next_chunk_id: chunk-0054
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 2-17. Bolt Carrier Disassembled.](images/p020_img00.jpeg)
*Figure 2-17. Bolt Carrier Disassembled.*

![Figure 2-18. Lower Receiver Disassembled.](images/p020_img01.jpeg)
*Figure 2-18. Lower Receiver Disassembled.*

--- chunk_id: chunk-0054
source_document: MCRP3-01A.pdf
page: 21
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: 1f546d463d806bcd
prev_chunk_id: chunk-0053
next_chunk_id: chunk-0055
document_type: technical_reference

2-8 ________________________________________________________
stoppage of the rifle caused by dirty or damaged mag-
azines. To disassemble the magazine—
l 
Pry up and push base plate out from the magazine. l 
Jiggle the spring and follower to remove. Do not re-
move the follower from the spring. See figure 2-19. Cleaning
Cleaning Materials
The following cleaning materials are used in preven-
tive maintenance (see fig. 2-20):
l 
Cleaner, lubricant, and preservative (CLP). Always
shake the bottle well before use. l 
Rod in three sections and a handle assembly. l 
Patch holder section, swabs, patches, pipe cleaners,
and clean rags. l 
Brushes: bore, chamber, and general purpose. Figure 2-19. Magazine Disassembled. Figure 2-20. Cleaning Materials. ___________________________________________ MCRP 3-01A
Cleaning the Upper Receiver
Basic cleaning of the upper receiver group should in-
clude the following:
l 
Attach the three rod sections together but leave each
one about two turns short of being tight. l 
Attach the patch holder onto the rod. l 
Point the muzzle down and insert the non-patch end
of the rod into the chamber. Attach the handle to the
cleaning rod section and pull a CLP-moistened
5.56mm patch through the bore. l 
Attach the bore brush to the rod but leave it two
turns short of being tight. Put a few drops of CLP
on the bore brush. Insert the rod into the barrel from
the chamber end, attach the handle, and pull the
brush through the bore. Repeat 3 times. Remove
bore brush and attach the patch holder to the rod
with a CLP moistened patch insert the rod into the
barrel from the chamber end, attach the handle, and
pull the patch through the bore. l 
Inspect the bore for cleanliness by holding the
muzzle to your eye and looking into the bore. l 
Repeat the above steps until the patches come out of
the bore clean. l 
Attach the chamber brush and one section of the
cleaning rod to the handle. Moisten it well with
CLP and insert it into the chamber. l 
Scrub the chamber and bolt lugs using a combina-
tion of a plunging and clockwise rotating action. Note
Do not reverse direction of the brush while
it is in the chamber. l 
Clean the interior portion of the upper receiver with
the general-purpose brush and CLP.

--- chunk_id: chunk-0055
source_document: MCRP3-01A.pdf
page: 21
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 185
content_hash: c17df07221461440
prev_chunk_id: chunk-0054
next_chunk_id: chunk-0056
document_type: technical_reference

Note
Do not reverse direction of the brush while
it is in the chamber. l 
Clean the interior portion of the upper receiver with
the general-purpose brush and CLP. l 
Dry the bore, chamber, and the interior of the re-
ceiver with rifle patches, swabs, and clean rags until
they come out clean. Then moisten all interior sur-
faces with CLP. l 
Wipe the barrel, gas tube, and handguards clean
with a rag. Cleaning the Bolt Carrier Group
l 
Clean the outer and inner surfaces of the bolt carrier
with a general-purpose brush. l 
Clean the bolt carrier key with a pipe cleaner. l 
Clean the locking lugs, gas rings, and exterior of the
bolt with the general-purpose brush. l 
Insert a swab into the rear of the bolt and swab out
the firing pin recess and gas ports.

--- chunk_id: chunk-0056
source_document: MCRP3-01A.pdf
page: 21
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 24
content_hash: 875969cd58ba4f59
prev_chunk_id: chunk-0055
next_chunk_id: chunk-0057
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 2-19. Magazine Disassembled.](images/p021_img00.jpeg)
*Figure 2-19. Magazine Disassembled.*

![Figure 2-20. Cleaning Materials.](images/p021_img01.jpeg)
*Figure 2-20. Cleaning Materials.*

--- chunk_id: chunk-0057
source_document: MCRP3-01A.pdf
page: 22
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 505
content_hash: a4b2c4d7ae8db50a
prev_chunk_id: chunk-0056
next_chunk_id: chunk-0058
document_type: technical_reference

Rifle Marksmanship _______________________________________________________________________________________ 2-9
l Clean the extractor with the general-purpose brush,
ensuring all the carbon is removed from underneath
the extractor lip. l Clean extractor pin, firing pin, and firing pin retain-
ing pin using the general-purpose brush and CLP. l Clean charging handle assembly with the general-
purpose brush and patches. Cleaning the Lower Receiver
l Wipe dirt from the firing mechanism using a
general-purpose brush, clean patch, pipe cleaners,
and swabs. l Clean the outside of the receiver with the general-
purpose brush and CLP. Clean the buttplate and
rear sling swivel, ensuring drain hole is clear of dirt. l Wipe the inside of the buffer tube, buffer, and ac-
tion spring. l Wipe the inside of the magazine well with a rag. l Wipe out the inside of the pistol grip and ensure that
it is clean. Cleaning the Magazine
l Clean the inside of the magazine with the general-
purpose brush and CLP. l Wipe dry. l Keep the spring lightly oiled. Inspection
While cleaning the rifle, and during each succeeding
step in the preventive maintenance process, inspect
each part for cracks and chips and ensure parts are not
bent or badly worn. Report any damaged part to the
armorer. Inspection is a critical step to ensure the
combat readiness of your rifle. It is performed nor-
mally during rifle cleaning (prior to lubrication), how-
ever, it can be performed throughout the preventive
maintenance process. Lubrication
Lubrication is performed as part of the detailed pro-
cedure for preventive maintenance. Lubrication pro-
cedures are also performed in preparation for firing. Lubricant
In all but the coldest arctic conditions, CLP is the lu-
bricant for the rifle. Remember to remove excess CLP
from the bore and chamber before firing. l 
Lightly lube means that a film of CLP barely visible
to the eye should be applied. l 
Generously lube means the CLP should be applied
heavily enough that it can be spread with the finger. Upper Receiver
l 
Lightly lube the inside of the upper receiver, bore,
chamber, outer surfaces of the barrel, and surfaces
under the handguard. l 
Depress the front sight detent and apply two or
three drops of CLP to the front sight detent. Depress
several times to work lubrication into the spring.

--- chunk_id: chunk-0058
source_document: MCRP3-01A.pdf
page: 22
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 264
content_hash: a819d091870bf889
prev_chunk_id: chunk-0057
next_chunk_id: chunk-0059
document_type: technical_reference

l 
Depress the front sight detent and apply two or
three drops of CLP to the front sight detent. Depress
several times to work lubrication into the spring. l 
Lubricate the moving parts and elevation screw
shaft of the rear sight. Bolt Carrier Group
l 
Generously lube the outside of the cam pin area, the
bolt rings, and outside the bolt body. l 
Lightly lube the charging handle and the inner and
outer surfaces of the bolt carrier. Lower Receiver
l 
Lightly lube the inside of the lower receiver exten-
sion. l 
Generously lube the moving parts inside the lower
receiver and their pins. Reassembly
Reassembling the Rifle
l 
Return all cleaning gear into the buttstock of the
rifle and close the buttplate. l 
Connect the buffer and action spring and insert
them into the buffer tube/stock. l 
Place the extractor and spring back on the bolt. Depress the extractor to align the holes and reinsert
the extractor pin. l 
Insert the bolt into the carrier. Do not switch bolts
between rifles. l 
Hold the bolt carrier with the bolt carrier key at 12
o’clock. Insert the bolt into the bolt carrier with the
extractor at 12 o’clock.

--- chunk_id: chunk-0059
source_document: MCRP3-01A.pdf
page: 23
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: 65d05410176def94
prev_chunk_id: chunk-0058
next_chunk_id: chunk-0060
document_type: technical_reference

2-10 _______________________________________________________
l 
Rotate the bolt counterclockwise until the cam
pinhole aligns to the cam pin slot in the bolt carrier. l 
Insert the bolt cam pin through the bolt carrier and
into the bolt. Rotate the cam pin 1/4 turn right or
left. Pull the bolt forward until it stops. l 
Drop in the firing pin from the rear of the bolt car-
rier and seat it. l 
Replace the firing pin retaining pin. Ensure the head
of the firing pin retaining pin is recessed inside the
bolt carrier. The firing pin should not fall out when
the bolt carrier group is turned upside down. l 
Place the charging handle in the upper receiver by
lining it up with the grooves in the receiver. Push
the charging handle partially in. l 
With the bolt in the unlocked position, place bolt
carrier key into the groove of the charging handle. l 
Push the charging handle and bolt carrier group into
the upper receiver until the charging handle locks. l 
Join the upper and lower receivers and engage the
receiver pivot pin. l 
Ensure the selector lever is on safe before closing
the upper receiver. Close the upper and lower re-
ceiver groups. Push in the takedown pin. l 
Install the handguards. l 
Attach the sling. Reassembling the Magazine
To reassemble the magazine—
l 
Insert the follower and jiggle the spring to install. l 
Slide the base under all four tabs until the base
catches. Make sure the printing is on the outside. 2006. Function Check
A function check is performed to ensure the rifle oper-
ates properly. To perform a function check:
WARNING
WARNING
WARNING
WARNING
A
R
N
I
N
G
Ensure the cam pin is installed in the bolt group
or the rifle may explode while firing. ___________________________________________ MCRP 3-01A
l 
Place the weapon in Condition 4 (see para. 3002). l 
Pull the charging handle to the rear and release. En-
sure the selector lever is on safe and pull the trigger. The hammer should not fall. l 
Place the selector lever on semi. Pull the trigger and
hold it to the rear. The hammer should fall. Pull the
charging handle to the rear and release. Release the
trigger and pull again. The hammer should fall. l 
Pull the charging handle to the rear and release.

--- chunk_id: chunk-0060
source_document: MCRP3-01A.pdf
page: 23
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 328
content_hash: b7bb033d7fd372a6
prev_chunk_id: chunk-0059
next_chunk_id: chunk-0061
document_type: technical_reference

The hammer should fall. l 
Pull the charging handle to the rear and release. Place the selector lever on burst. Pull the trigger and
hold it to the rear. The hammer should fall. Pull the
charging handle to the rear three times and release. Release the trigger and pull again. The hammer
should fall. l 
Pull the charging handle to the rear and release. Place the selector lever on safe. 2007. User Serviceability Inspection
Individual Marines must perform user serviceability
inspections on their weapons before firing them. This
inspection ensures the weapon is in an acceptable op-
erating condition. l 
Place rifle in Condition 4 (see para. 3002). l 
Conduct a function check. l 
Check the rifle to ensure the following:
l 
Compensator is tight. l 
Barrel is tight. l 
Front sight post is straight. l 
Front sight post is adjustable. l 
Handguards are serviceable. l 
Rear sight elevation and windage knobs are adjust-
able and have distinct clicks. l 
Stock is tight on the lower receiver. l 
Weapon is properly lubricated for operational con-
ditions. l 
Barrel is clear of obstructions. l 
Gas rings are serviceable. l 
Ensure magazines are serviceable. l 
Load the rifle with an empty magazine. Ensure that
the magazine can be seated. l 
Without depressing the bolt catch, pull the charging
handle to the rear. Ensure that the bolt locks to the
rear. l 
Depress the upper portion of the bolt catch and
observe bolt moving forward on an empty chamber.

--- chunk_id: chunk-0061
source_document: MCRP3-01A.pdf
page: 24
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: 7bd8879a74d12c4a
prev_chunk_id: chunk-0060
next_chunk_id: chunk-0062
document_type: technical_reference

Rifle Marksmanship _____________________________________________________________________________________ 2-11
Ensure the bolt moves completely forward and
locks in the chamber. l Repeat this procedure with all magazines. 2008. Field Maintenance
Preventive maintenance in the field is performed when
detailed disassembly and cleaning is not practical due
to operational tempo or the level of threat. To perform
limited field preventive maintenance—
l Place the rifle in Condition 4 (see paragraph 3002). l Break the rifle down by removing the rear take
down pin and rotating the upper receiver and barrel
forward. l Remove the bolt carrier group. l Do not disassemble the bolt carrier group further. l Clean the bolt carrier group. l Clean the upper and lower receiver groups (without
further disassembly). l Clean the bore and chamber. l Lubricate the rifle. l Reassemble the rifle and perform a user serviceabil-
ity inspection. 2009. Cleaning the Rifle in Various 
Conditions
The climatic conditions in various locations require
special knowledge about cleaning and maintaining the
rifle. The conditions that will affect the rifle the most
are: hot, wet tropical; hot, dry desert; arctic or low
temperature; and heavy rain and fording. Hot, Wet Tropical
l Perform normal maintenance. l Clean and lubricate your rifle more often. Inspect
hidden surfaces for corrosion. Pay particular atten-
tion to spring-loaded detentes. l Use lubricant more liberally. l Unload and check the inside of the magazine more
frequently. Wipe dry and check for corrosion. l When practical, keep the rifle covered. Hot, Dry Desert
Hot dry climates are usually areas that contain blow-
ing sand and fine dust. Dust and sand will get into the
rifle and magazines, causing stoppages. It is impera-
tive to pay particular attention to the cleaning and
lubrication of the rifle in this type of climate. Corrosion is less likely to form in these environments,
and lubrication will attract more dirt. For this reason,
use lubrication more sparingly. Whenever practical, keep the rifle covered. Arctic or Low Temperature
l 
Clean and lubricate the rifle in a warm room, with
the rifle at room temperature, if possible. Lubri-
cating oil, arctic weapons (LAW) can be used
below a temperature of 0 degrees Fahrenheit and
must be used below -35 degrees Fahrenheit. l 
Keep the rifle covered when moving from a warm
to a cold environment to allow gradual cooling of
the rifle.

--- chunk_id: chunk-0062
source_document: MCRP3-01A.pdf
page: 24
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 326
content_hash: 2fea5695b7f1fbf6
prev_chunk_id: chunk-0061
next_chunk_id: chunk-0063
document_type: technical_reference

Lubri-
cating oil, arctic weapons (LAW) can be used
below a temperature of 0 degrees Fahrenheit and
must be used below -35 degrees Fahrenheit. l 
Keep the rifle covered when moving from a warm
to a cold environment to allow gradual cooling of
the rifle. This prevents the condensation of moisture
and freezing. Condensation will form on the rifle
when it is moved from outdoors to indoors. If
possible, leave the rifle in a protected but cold area
outdoors. When bringing the rifle inside to a warm
place, it should be disassembled and wiped down
several times as it warms. l 
Always try to keep the rifle dry. l 
Unload and perform a function check every 30 min-
utes, if possible, to help prevent freezing of func-
tional parts. l 
Do not lay a warm rifle in snow or ice. l 
Keep the inside of the magazine and ammunition
wiped dry. Moisture will freeze and cause stop-
pages. Heavy Rain and Fording
l 
Keep the rifle dry and covered when practical. l 
Keep water out of the barrel if possible. If water
does get in, drain and (if possible) dry with a patch. If water is in the barrel, point the muzzle down and
break the seal by doing a chamber check so the
water will drain. If water is in the stock of the
weapon, ensure the drain hole in the stock is clear
so the water can run out. l 
Perform normal maintenance.

--- chunk_id: chunk-0063
source_document: MCRP3-01A.pdf
page: 25
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: 7fbd520889e40411
prev_chunk_id: chunk-0062
next_chunk_id: chunk-0064
section_heading: CHAPTER 3. WEA
document_type: technical_reference

CHAPTER 3. WEA
Weapons handling procedures provide 
Marine to handle, operate, and employ
weapons handling procedures ensure 
negligent discharges and reinforcing p
engagement. Weapons handling proced
during combat operations. Note
+The procedures in this manual are written
for right-handed Marines; left-handed
Marines should reverse instructions as
necessary. 3001. Safety Rules
Safe handling of the rifle is critical. If proper weapons
handling procedures are not used, a Marine risks his
safety and the safety of his fellow Marines. During
combat, a Marine must react quickly, safely, and be
mentally prepared to engage targets. To ensure that
only the intended target is engaged, a Marine must
apply the following safety rules at all times:
Rule 1—Treat every weapon as if it were loaded. When a Marine takes charge of a rifle in any situation,
he must treat the weapon as if it were loaded,
determine its condition (see para. 3003), and continue
applying the other safety rules. Rule 2—Never point a weapon at anything you do
not intend to shoot. A Marine must maintain muzzle
awareness at all times. Rule 3—Keep your finger straight and off the
trigger until you are ready to fire. A target must be
identified before taking the weapon off safe and
moving the finger to the trigger. Rule 4—Keep the weapon on safe until you intend
to fire. A target must be identified before taking the
weapon off safe. This rule is intended to eliminate the
chance of the weapon discharging by accident (e.g.,
brush snagging the trigger). WEAPONS HANDLING
de a consistent and standardized way for a
loy the rifle safely and effectively. Proper
ure the safety of Marines by eliminating
g positive identification of targets before
cedures apply at all levels of training and
s
s
g
e
t
t
. ,
,
e
o
e
e
e
d
d
e
e
,
3002. Weapons Conditions
A weapon’s readiness is described by one of four
conditions. The steps in the loading and unloading
process take the rifle through four specific conditions
of readiness for live fire. Condition 1. Safety on, magazine inserted, round
in chamber, bolt forward, ejection
port cover closed. Condition 2. Not applicable to the M16A2 rifle. Condition 3. Safety on, magazine inserted, cham-
ber empty, bolt forward, ejection
port cover closed. Condition 4.

--- chunk_id: chunk-0064
source_document: MCRP3-01A.pdf
page: 25
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 170
content_hash: 16e1bc6d487a117a
prev_chunk_id: chunk-0063
next_chunk_id: chunk-0065
section_heading: CHAPTER 3. WEA
document_type: technical_reference

Safety on, magazine inserted, cham-
ber empty, bolt forward, ejection
port cover closed. Condition 4. Safety on, magazine removed, cham-
ber empty, bolt forward, ejection
port cover closed. 3003. Determining a Weapon’s 
Condition (Chamber Check)
A Marine must know the condition of his weapon at
all times. When a Marine takes charge of a weapon in
any situation, he must determine its condition. Situations include coming across an unmanned rifle in
combat, taking charge of any weapon after it has been
unmanned (e.g., out of a rifle rack, stored in a vehicle),
or taking charge of another Marine’s weapon. To
determine the condition of the weapon in any of these
situations, the Marine should:
l 
Determine if a magazine is present. l 
Ensure the rifle is on safe.

--- chunk_id: chunk-0065
source_document: MCRP3-01A.pdf
page: 26
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 457
content_hash: fc06aadfc5c07c5a
prev_chunk_id: chunk-0064
next_chunk_id: chunk-0066
document_type: technical_reference

3-2 ________________________________________________________
l 
Conduct a chamber check. l 
Bring the left hand back against the magazine well. l 
Extend the fingers of the left hand and cover the
ejection port (see fig. 3-1). l 
Grasp the charging handle with the index and
middle fingers of the right hand. l 
Pull the charging handle slightly to the rear and
visually and physically inspect the chamber (see
fig. 3-2). Right-handed Marines, insert one finger
of the left hand into the ejection port and feel
whether a round is present. Left-handed Marines,
insert the thumb of the right hand into the ejection
port and feel whether a round is present. Figure 3-1. Position of Hand. Figure 3-2. Chamber Check. ___________________________________________ MCRP 3-01A
Note
The same procedure is used in daylight as
during low visibility. A chamber check
may be conducted at any time. CAUTION
Pulling the charging handle too far to the
rear while inspecting the chamber may
cause double feed or ejection of one round
of ammunition. l 
Release the charging handle and observe the bolt
going forward. l 
Tap the forward assist. l 
Close the ejection port cover (if time and the
situation permit). l 
Remove the magazine (if present) and observe if
ammunition is present. If time permits, count the
rounds. Reinsert the magazine into magazine well. 3004. Weapons Commands
Weapons commands dictate the specific steps required
to load and unload the rifle. Six commands are used in
weapons handling:
Load. This command is used to take the weapon from
Condition 4 to Condition 3. Make Ready. This command is used to take the
weapon from Condition 3 to Condition 1. Fire. This command is used to specify when a Marine
may engage targets. Cease-Fire. This command is used to specify when a
Marine must stop target engagement. Unload. This command is used to take the weapon
from any condition to Condition 4. Unload and Show Clear. This command is used
when an observer must check the weapon to verify
that no ammunition is present before the rifle is placed
in Condition 4.

--- chunk_id: chunk-0066
source_document: MCRP3-01A.pdf
page: 26
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 34
content_hash: 47a78239de5bdce0
prev_chunk_id: chunk-0065
next_chunk_id: chunk-0067
section_heading: Figures
document_type: technical_reference

## Figures

![fig. 3-2). Right-handed Marines, insert one finger](images/p026_img00.jpeg)
*fig. 3-2). Right-handed Marines, insert one finger*

![Figure 3-1. Position of Hand.](images/p026_img01.jpeg)
*Figure 3-1. Position of Hand.*

--- chunk_id: chunk-0067
source_document: MCRP3-01A.pdf
page: 27
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 416
content_hash: 32e1c0cb6d3d874f
prev_chunk_id: chunk-0066
next_chunk_id: chunk-0068
document_type: technical_reference

Rifle Marksmanship________________________________________________________________________________________ 3-3
Loading the Rifle
Perform the following steps to load the rifle (take the
rifle to Condition 3):
l Ensure the rifle is on safe. l Withdraw the magazine from the magazine pouch. l Observe the magazine to ensure it is filled. l Fully insert the magazine in the magazine well. Without releasing the magazine, tug downward on
the magazine to ensure it is seated. l Close the ejection port cover. l Fasten the magazine pouch. Making the Rifle Ready
Perform the following steps to make the rifle ready for
firing (take the rifle to Condition 1):
l Pull the charging handle to the rear and release. There are two methods of doing this:
l Grip the pistol grip firmly with the right hand and
pull the charging handle with the left hand to its
rearmost position and release (see fig. 3-3). Or grip the handguards firmly with the left hand and
pull the charging handle with the right hand to its
rearmost position and release (see fig. 3-4). l 
To ensure ammunition has been chambered,
conduct a chamber check (see para. 3003) to ensure
a round has been chambered. l 
Check the sights (to ensure proper battlesight zero
[BZO] setting, correct rear sight aperture, etc.). l 
Close ejection port cover. Fire 
On the command “Fire,” aim the rifle, take the rifle off
safe, and pull the trigger. Cease-Fire
On the command “Cease Fire,” perform the following
steps:
l 
Place your trigger finger straight along the receiver. l 
Place the weapon on safe. Unloading the Rifle 
Perform the following steps to unload the rifle (take
the rifle to Condition 4):
l 
Ensure the weapon is on safe. l 
Remove the magazine from the rifle and retain it on
your person. Figure 3-3. Pulling the Charging Handle
with the Left Hand. Figure 3-4. Pulling the Charging Handle
with the Right Hand.

--- chunk_id: chunk-0068
source_document: MCRP3-01A.pdf
page: 27
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 34
content_hash: c99578c46c7eb481
prev_chunk_id: chunk-0067
next_chunk_id: chunk-0069
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 3-3. Pulling the Charging Handle](images/p027_img00.jpeg)
*Figure 3-3. Pulling the Charging Handle*

![Figure 3-4. Pulling the Charging Handle](images/p027_img01.jpeg)
*Figure 3-4. Pulling the Charging Handle*

--- chunk_id: chunk-0069
source_document: MCRP3-01A.pdf
page: 28
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 485
content_hash: 18fd4b6e2757cbcd
prev_chunk_id: chunk-0068
next_chunk_id: chunk-0070
document_type: technical_reference

3-4 ________________________________________________________
l 
Cup the left hand under the ejection port, rotate the
weapon until the ejection port faces down. l 
Pull the charging handle to the rear and catch the
round in the left hand (see fig. 3-5). l 
Lock the bolt to the rear. l 
Put the weapon on safe if the selector lever would
not move to safe earlier. l 
Ensure the chamber is empty and that no ammuni-
tion is present. l 
Depress the bolt catch and observe the bolt moving
forward on an empty chamber (see fig. 3-6). l 
Close the ejection port cover. l 
Check the sights (for proper BZO setting, correct
rear sight aperture, etc.). l 
Place any ejected round into the magazine and
return the magazine to the magazine pouch and
close the magazine pouch. Figure 3-5. Catching the Round. Figure 3-6. Observing the Chamber. ___________________________________________ MCRP 3-01A
Unloading and Showing the Rifle Clear 
Perform the following steps to unload the rifle and
show it clear to an observer (take the rifle to Condition
4). The Marine—
l 
Ensures the weapon is on safe. l 
Removes the magazine from the rifle and retains it. l 
Cups the left hand under the ejection port, rotates
the weapon until the ejection port faces down. l 
Pulls the charging handle to the rear and catches the
round in the left hand. l 
Locks the bolt to the rear and ensures the chamber
is empty and that no ammunition is present. l 
Has another Marine inspect the weapon to ensure
no ammunition is present (see fig. 3-7). The observer—
l 
Visually inspects the chamber to ensure it is empty,
no ammunition is present, and the magazine is
removed. l 
Ensures the weapon is on safe. l 
Acknowledges the rifle is clear. The Marine, after receiving acknowledgment that the
rifle is clear—
l 
Depresses the bolt catch and observes the bolt
moving forward on an empty chamber. l 
Closes the ejection port cover. l 
Checks the sights (for proper BZO setting, correct
rear sight aperture, etc.). l 
Places any ejected round into the magazine and
returns the magazine to the magazine pouch and
closes the magazine pouch. Figure 3-7. Observer Inspection.

--- chunk_id: chunk-0070
source_document: MCRP3-01A.pdf
page: 28
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 40
content_hash: b8b402954d1cf363
prev_chunk_id: chunk-0069
next_chunk_id: chunk-0071
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 3-5. Catching the Round.](images/p028_img00.jpeg)
*Figure 3-5. Catching the Round.*

![Figure 3-6. Observing the Chamber.](images/p028_img01.jpeg)
*Figure 3-6. Observing the Chamber.*

![Figure 3-7. Observer Inspection.](images/p028_img02.jpeg)
*Figure 3-7. Observer Inspection.*

--- chunk_id: chunk-0071
source_document: MCRP3-01A.pdf
page: 29
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 512
content_hash: 1a44a14c8a1699ee
prev_chunk_id: chunk-0070
next_chunk_id: chunk-0072
section_heading: 3005. Filling, Stowing,
document_type: technical_reference

Rifle Marksmanship________________________________________________________________________________________ 3-5
3005. Filling, Stowing,
and Withdrawing Magazines
Filling the Magazine with Loose Rounds 
Perform the following steps to fill the magazine:
l Remove a magazine from the magazine pouch. l Place a round on top of the follower. l Press down until the round is held between the
follower and magazine feed lips (see fig. 3-8). l Repeat until the desired number of rounds is
inserted. The recommended number of rounds per
magazine is 28 or 29. Thirty rounds in the magazine
may prohibit the magazine from seating properly on
a closed bolt. l Tap the back of the magazine to ensure the rounds
are seated against the back of the magazine. Filling the 
Magazine Using a 
10-round Stripper 
Clip and 
Magazine Filler 
The magazine can also
be filled quickly using
a 10-round stripper
clip and the magazine
filler (see fig. 3-9). Perform the following steps to fill the magazine with
the 10-round stripper clip (see fig. 3-10):
l 
Remove a magazine from the magazine pouch. l 
Slide the magazine filler into place. l 
Place a 10-round stripper clip into the narrow
portion of the magazine filler. l 
Using thumb pressure on the rear of the top
cartridge, press down firmly until all ten rounds are
below the feed lips of the magazine. l 
Remove the empty stripper clip while holding the
magazine filler in place. l 
Repeat until the desired number of rounds is
inserted. The recommended number of rounds per
magazine is 28 or 29. Thirty rounds in the magazine
may prohibit the magazine from seating properly on
a closed bolt. l 
Remove magazine filler and retain it for future use. l 
Tap the back of the magazine to ensure the rounds
are seated against the back of the magazine. Stowing Magazines
Magazine Pouch
In a magazine pouch, filled magazines are stored with
rounds down and projectiles pointing away from the
body. Load-bearing Vest
In a load-bearing vest, filled magazines are stored with
rounds down and projectiles pointing outboard. Empty or Partially Filled Magazines
Empty or partially filled magazines are stored with the
follower up to allow the selection of filled magazines
by touch (i.e., at night). Figure 3-8. Filling the Magazine. Figure 3-9. Magazine
Filler and 10-round
Figure 3-10. Filling the Magazine with a Stripper 
Clip and Magazine Filler.

--- chunk_id: chunk-0072
source_document: MCRP3-01A.pdf
page: 29
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 45
content_hash: 04ecf0aa5504af76
prev_chunk_id: chunk-0071
next_chunk_id: chunk-0073
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 3-8. Filling the Magazine.](images/p029_img00.jpeg)
*Figure 3-8. Filling the Magazine.*

![Figure 3-9. Magazine](images/p029_img01.jpeg)
*Figure 3-9. Magazine*

![Figure 3-10. Filling the Magazine with a Stripper](images/p029_img02.jpeg)
*Figure 3-10. Filling the Magazine with a Stripper*

--- chunk_id: chunk-0073
source_document: MCRP3-01A.pdf
page: 30
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: 694a90f3c7f926df
prev_chunk_id: chunk-0072
next_chunk_id: chunk-0074
document_type: technical_reference

3-6 ________________________________________________________
Withdrawing Magazines
Magazine Pouch
With the right hand, withdraw magazines from the
magazine pouch on the right side of the body. With the
left hand, withdraw magazines from the magazine
pouch on the left side of the body. To withdraw
magazines from a magazine pouch—
l 
Use the thumb and index finger, pinch the magazine
pouch release to open the magazine pouch. l 
Slide the thumb over the magazines, feeling for a
base plate indicating a filled magazine. Continue
sliding the thumb until it rests on the back of the
magazine. l 
Grasp the magazine with the thumb, index finger,
and middle finger and lift the magazine directly out
of the pouch. l 
Once the magazine is clear of the pouch, curl the
ring finger and little finger underneath the magazine
and rotate it up to observe rounds in the magazine. Load-bearing Vest
With the right hand, withdraw magazines from the left
side of the vest (see fig. 3-11). With the left hand,
withdraw magazines from the right side of the vest
(see fig. 3-12). To withdraw magazines from a load-bearing vest:
l 
With the thumb and index finger, unfasten the snap
on the vest pouch. l 
Slide the thumb over the magazine, feeling for a
base plate indicating a filled magazine. l 
Rotate the hand over the magazine while sliding the
thumb to the back of the magazine. l 
Grasp the magazine with the thumb, index finger,
and middle finger, while curling the ring finger and
little finger on top of the base plate. Figure 3-11. Withdrawing a Magazine
with the Right Hand. ___________________________________________ MCRP 3-01A
l 
Lift the magazine directly out of the pouch and
rotate it up to observe the rounds in the magazine. 3006. Reloading the Rifle
Principles of Reloading 
The first priority when performing a reload is to get
the rifle reloaded and back into action. The second
priority when performing a reload is to retain the
magazine so when you move, the magazine moves
with you. When time permits, retain magazines
securely on your person (e.g., in magazine pouch, flak
jacket, and cargo pocket). The combat situation may
dictate dropping the magazine to the deck when
performing a reload. This is acceptable as long as it is
picked up before moving to another location. Take cover before reloading.

--- chunk_id: chunk-0074
source_document: MCRP3-01A.pdf
page: 30
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 185
content_hash: 0894b922e76f63b9
prev_chunk_id: chunk-0073
next_chunk_id: chunk-0075
document_type: technical_reference

This is acceptable as long as it is
picked up before moving to another location. Take cover before reloading. Always reload before
leaving cover to take advantage of the protection
provided by cover. When moving, your focus should be on moving,
therefore every effort should be made to not reload
while on the move. When reloading, your focus is on the magazine
change. When reloading, draw the weapon in close to your
body so you can see what you are doing and retain
positive control of the magazine. When the new magazine is inserted, tug on it to ensure
it is seated. Do not slam the magazine into the weapon
hard enough to cause a round to partially pop out of
the magazine. This action will cause a double feed and
require remedial action. Figure 3-12. Withdrawing a Magazine

--- chunk_id: chunk-0075
source_document: MCRP3-01A.pdf
page: 30
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 29
content_hash: 92a128dfb4d3b95c
prev_chunk_id: chunk-0074
next_chunk_id: chunk-0076
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 3-11. Withdrawing a Magazine](images/p030_img00.jpeg)
*Figure 3-11. Withdrawing a Magazine*

![Figure 3-12. Withdrawing a Magazine](images/p030_img01.jpeg)
*Figure 3-12. Withdrawing a Magazine*

--- chunk_id: chunk-0076
source_document: MCRP3-01A.pdf
page: 31
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 490
content_hash: d647dfb5e1a5995c
prev_chunk_id: chunk-0075
next_chunk_id: chunk-0077
document_type: technical_reference

Rifle Marksmanship____________________________________
Retain your empty magazines. When there is a lull in
the action, refill those magazines so they will be
available for future use. During a lull in the action, replace your magazine
when you know you are low on ammunition. This
ensures a full magazine of ammunition in the rifle
should action resume. Do not wait until the magazine
is completely empty to replace it. Condition 1 Reload 
A condition 1 reload is performed when the weapon is
in condition 1 by replacing the magazine before it runs
out of ammunition. To perform a condition 1 reload,
perform the following steps:
l Withdraw a filled magazine from the magazine
pouch. With the same hand, press the magazine
button and remove the partially filled magazine so it
can be retained in the remaining fingers. l Fully insert the filled magazine into the magazine
well and tug downward on the magazine to ensure it
is properly seated. l Store the partially filled magazine in the magazine
pouch with rounds up and projectiles pointing away
from the body. l Fasten the magazine pouch. Dry Reload
A dry reload is required when the magazine in the
weapon has been emptied and the bolt has locked to
the rear. To perform a dry reload—
l Press the magazine release button. l Remove the empty magazine and retain it on your
person when time permits. l Fully insert a filled magazine into the magazine
well and tug downward on the magazine to ensure it
is properly seated. l Depress the bolt catch to allow the bolt carrier to
move forward and observe the round being
chambered. This places the rifle in Condition 1. 3007. Remedial Action
If the rifle fails to fire, a Marine performs remedial
action. Remedial action is the process of investigating

________________________________________________________ 3-7
n
e
e
s
e
e
s
s
,
e
e
t
e
t
e
y
e
o
r
e
t
o
g
l
g
the cause of the stoppage, clearing the stoppage, and
returning the weapon to operation. Observe for Indicators
Once the rifle ceases firing, the Marine must visually
or physically observe the ejection port to identify the
problem before he can clear it.

--- chunk_id: chunk-0077
source_document: MCRP3-01A.pdf
page: 31
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 212
content_hash: 1df20b44b06c4f26
prev_chunk_id: chunk-0076
next_chunk_id: chunk-0078
document_type: technical_reference

Remedial action is the process of investigating

________________________________________________________ 3-7
n
e
e
s
e
e
s
s
,
e
e
t
e
t
e
y
e
o
r
e
t
o
g
l
g
the cause of the stoppage, clearing the stoppage, and
returning the weapon to operation. Observe for Indicators
Once the rifle ceases firing, the Marine must visually
or physically observe the ejection port to identify the
problem before he can clear it. The steps taken to clear
the weapon are based on observation of one of the
following three indicators:
Indicator: The bolt is forward or the ejection port
cover is closed. See figures 3-13 and 3-14. To return the weapon to operation—
l 
Seek cover if the tactical situation permits. l 
Tap—Tap the bottom of the magazine. l 
Rack—Pull the charging handle to the rear and
release it. l 
Bang—Sight in and attempt to fire. Figure 3-14. Ejection Port Cover Closed. Figure 3-13. Bolt Forward.

--- chunk_id: chunk-0078
source_document: MCRP3-01A.pdf
page: 31
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 29
content_hash: 108d0bbec333d133
prev_chunk_id: chunk-0077
next_chunk_id: chunk-0079
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 3-14. Ejection Port Cover Closed.](images/p031_img00.jpeg)
*Figure 3-14. Ejection Port Cover Closed.*

![Figure 3-13. Bolt Forward.](images/p031_img01.jpeg)
*Figure 3-13. Bolt Forward.*

--- chunk_id: chunk-0079
source_document: MCRP3-01A.pdf
page: 32
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: beb08e1a3428d57a
prev_chunk_id: chunk-0078
next_chunk_id: chunk-0080
document_type: technical_reference

3-8 _______________________________________________________________________________________________ MCRP 3-01A
Indicator: Brass is obstructing chamber area
(usually indicating a double feed or failure to eject). See figure 3-15. To return the weapon to operation—
l 
Seek cover if the tactical situation permits. l 
Attempt to remove the magazine. l 
Attempt to lock the bolt to the rear
If the bolt will not lock to the rear, rotate the rifle so
the ejection port is facing down; hold the charging
handle to the rear as far as it will go and shake the rifle
to free the round(s). If the rounds do not shake free,
hold the charging handle to the rear and strike the butt
of the rifle on the ground or manually clear the round. Conduct a reload. Sight in and attempt to fire. Indicator: The bolt is locked to the rear. See figure
3-16. To clear return the weapon to operation—
Note
Although a dry weapon is not considered a
true stoppage or mechanical failure, the
Marine must take action to return the
weapon to operation. l 
Seek cover if the tactical situation permits. l 
Conduct a dry reload. l 
Sight in and attempt to fire. Audible Pop or Reduced Recoil
An audible pop occurs when only a portion of the
propellant is ignited. It is normally identifiable by
reduced recoil and is sometimes accompanied by
excessive smoke escaping from the chamber area. To
clear the rifle in a combat environment:
l 
Place the rifle in Condition 4. l 
Move take down pin from left to right as far as it
will go to allow the lower receiver to pivot. l 
Remove the bolt carrier group. l 
Inspect the bore for an obstruction from the
chamber end. l 
Insert a cleaning rod into the bore from the muzzle
end and clear the obstruction. l 
Reassemble the rifle. l 
Conduct a reload. l 
Sight in and attempt to fire. 3008. Weapons Carries
Weapons carries provide an effective way to handle
the rifle while remaining alert to enemy engagement. Weapons carries are tied to threat conditions and are
assumed in response to a specific threat situation. The
weapons carry assumed prepares the Marine, both
mentally and physically, for target engagement. The
sling provides additional support for the weapon when
firing; therefore, the hasty sling should be used in
conjunction with the carries.

--- chunk_id: chunk-0080
source_document: MCRP3-01A.pdf
page: 32
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 177
content_hash: 70f16e54c48e136b
prev_chunk_id: chunk-0079
next_chunk_id: chunk-0081
document_type: technical_reference

The
weapons carry assumed prepares the Marine, both
mentally and physically, for target engagement. The
sling provides additional support for the weapon when
firing; therefore, the hasty sling should be used in
conjunction with the carries. Tactical Carry
A Marine carries the rifle at the tactical carry if no
immediate threat is present. The tactical carry permits
control of the rifle while a Marine is moving, yet it still
allows quick engagement of the enemy. A Marine
performs the following steps to assume the tactical
carry:
l 
Place left hand on the handguards, right hand
around the pistol grip, trigger finger straight along
the receiver (see fig. 3-17), and right thumb on top
of the selector lever (see fig. 3-18). Figure 3-15. Brass Obstructing the Chamber. Figure 3-16. Bolt Locked to the Rear.

--- chunk_id: chunk-0081
source_document: MCRP3-01A.pdf
page: 32
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 37
content_hash: 65100f95d86dcc1d
prev_chunk_id: chunk-0080
next_chunk_id: chunk-0082
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 3-15. Brass Obstructing the Chamber.](images/p032_img00.jpeg)
*Figure 3-15. Brass Obstructing the Chamber.*

![Figure 3-16. Bolt Locked to the Rear.](images/p032_img01.jpeg)
*Figure 3-16. Bolt Locked to the Rear.*

--- chunk_id: chunk-0082
source_document: MCRP3-01A.pdf
page: 33
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 424
content_hash: f840fb3c90c3463e
prev_chunk_id: chunk-0081
next_chunk_id: chunk-0083
document_type: technical_reference

Rifle Marksmanship________________________________________________________________________________________ 3-9
l Place 
the 
buttstock
along the side of the
body at approximately
hip level. l Angle the muzzle up-
ward about 45 degrees
in a safe direction. l Position the muzzle in
front of the eyes,
slightly below eye
level (see fig. 3-19). l Move the head and the
eyes with the muzzle
as it moves. Alert Carry
A Marine carries the rifle at the alert if enemy contact
is likely. The alert is also used for moving in close
terrain (e.g., urban, jungle). A Marine can engage the
enemy faster from the alert than from the tactical
carry. However, the alert is more tiring than the
tactical carry and its use can be physically demanding. A Marine performs the following steps to assume the
alert:
l 
Place the left hand on the handguards, the right
hand around the pistol grip, the trigger finger
straight along the receiver (see fig. 3-17), and the
right thumb on top of the selector lever (see fig. 3-
18). l 
Place the buttstock in the shoulder. l 
Angle the muzzle downward about 45 degrees and
point it in a safe direction or the general direction of
likely enemy contact (see fig. 3-20). Ready Carry
A Marine carries the rifle at the ready if contact with
the enemy is imminent. The ready allows immediate
target engagement, but it is very tiring to maintain
over a long period of time. A Marine performs the
following steps to assume the ready:
l 
Place left hand on handguards, right hand around
the pistol grip, the trigger finger straight along the
receiver (see fig. 3-17), and the right thumb on top
of the selector lever (see fig. 3-18). l 
Place the buttstock in the shoulder. l 
Point the muzzle in the direction of the enemy. Figure 3-17. Straight Trigger Finger. Figure 3-18. Thumb on Selector Lever. Figure 3-19. Tactical Carry. Figure 3-20. Alert Carry.

--- chunk_id: chunk-0083
source_document: MCRP3-01A.pdf
page: 33
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 48
content_hash: 40cc485c77ac2e2e
prev_chunk_id: chunk-0082
next_chunk_id: chunk-0084
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 3-17. Straight Trigger Finger.](images/p033_img00.jpeg)
*Figure 3-17. Straight Trigger Finger.*

![Figure 3-18. Thumb on Selector Lever.](images/p033_img01.jpeg)
*Figure 3-18. Thumb on Selector Lever.*

![Figure 3-19.](images/p033_img02.jpeg)
*Figure 3-19.*

![Figure 3-20. Alert Carry.](images/p033_img03.jpeg)
*Figure 3-20. Alert Carry.*

--- chunk_id: chunk-0084
source_document: MCRP3-01A.pdf
page: 34
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: 137b4576b43150de
prev_chunk_id: chunk-0083
next_chunk_id: chunk-0085
document_type: technical_reference

3-10 ______________________________________________________________________________________________ MCRP 3-01A
l 
Lower the sights to just below eye level so that a
clear field of view is maintained so that a target may
be identified (see fig. 3-21). 3009. Weapons Transports
Weapons transports are used to carry the rifle over the
back or shoulders when moving for long periods; they
provide a more relaxed position for walking. Weapons
transports are used if no immediate threat is present. They are also used whenever one or both hands are
needed for other work. Strong Side Sling 
Arms Transport 
(Muzzle Up)
To assume the strong side
sling arms (muzzle up)
transport from the tactical
carry, a Marine performs
the following steps (see fig. 3-22):
l 
Release the hold on the
pistol grip. l 
Lower the buttstock and
bring the rifle to a
vertical position. l 
With the right hand,
grasp the sling above the
left forearm. l 
With the left hand, guide the rifle around the right
shoulder. l 
With the right hand, apply downward pressure on
the sling. This stabilizes the rifle on the shoulder. Weak Side Sling Arms
Transport (Muzzle Down)
The weak side sling arms
(muzzle down) transport
can be used in inclement
weather to keep moisture
out of the rifle’s bore. To
assume this transport from
the tactical carry, a Marine
performs the following
steps (see fig. 3-23):
l 
Release the hold on the
pistol grip. l 
With the left hand, rotate
muzzle down and bring
the rifle to a vertical po-
sition on the left side of
the body. The pistol grip
is pointed outboard. l 
With right hand, place
sling on left shoulder. l 
Grasp sling above the
waist with the left hand. l 
With the left hand, apply downward pressure on the
sling. This stabilizes the rifle on the shoulder. Cross Body Sling 
Arms Transport
A Marine uses the cross
body sling arms transport if
he requires both hands for
work. The rifle is slung
across the back with the
muzzle up or down. Normally, the rifle is
carried with the muzzle
down to prevent pointing
the muzzle in an unsafe
direction. To assume a cross body
sling transport, a Marine
performs the following
steps from weak side sling
arms (muzzle down) (see
fig. 3-24):
Figure 3-21. Ready Carry. Figure 3-22. Strong 
Side Sling Arms
Transport (Muzzle Up). Figure 3-23.

--- chunk_id: chunk-0085
source_document: MCRP3-01A.pdf
page: 34
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 33
content_hash: d6a5eb25be5ea6d1
prev_chunk_id: chunk-0084
next_chunk_id: chunk-0086
document_type: technical_reference

Strong 
Side Sling Arms
Transport (Muzzle Up). Figure 3-23. Weak 
Side Sling
Arms Transport
(Muzzle Down.)
Figure 3-24. Cross 
Body Sling
Arms Transport
(Muzzle Down).

--- chunk_id: chunk-0086
source_document: MCRP3-01A.pdf
page: 34
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 34
content_hash: 9dd58bf4d9125619
prev_chunk_id: chunk-0085
next_chunk_id: chunk-0087
section_heading: Figures
document_type: technical_reference

## Figures

![fig. 3-24):](images/p034_img00.jpeg)
*fig. 3-24):*

![Figure 3-21. Ready Carry.](images/p034_img01.jpeg)
*Figure 3-21. Ready Carry.*

![Figure 3-22. Strong](images/p034_img02.jpeg)
*Figure 3-22. Strong*

![Figure 3-23. Weak](images/p034_img03.jpeg)
*Figure 3-23. Weak*

--- chunk_id: chunk-0087
source_document: MCRP3-01A.pdf
page: 35
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 485
content_hash: b6fad2034a91d7f8
prev_chunk_id: chunk-0086
next_chunk_id: chunk-0088
document_type: technical_reference

Rifle Marksmanship______________________________________________________________________________________ 3-11
l With the right hand, grasp the sling. l With the left hand, grasp the handguards. l Pull up on the rifle with both hands. l Slide the sling over the head. l Position the rifle so that it rests comfortably across
the back. To assume a cross body
sling transport, a Marine
performs the following
steps from strong side sling
arms (muzzle up) (see fig. 3-25):
l With the left hand, grasp
the sling. l With the right hand,
grasp the pistol grip. l Pull up on the rifle with
both hands. l Slide sling over head. l Position the rifle so that
it rests comfortably
across the back. Note
Ensure the muzzle of the rifle is maintained
in a safe direction when assuming this
transport. 3010. Transferring the Rifle
Proper weapons handling is required every time a
Marine picks up a weapon, passes a weapon to another
Marine, or receives a weapon from another Marine. It
is the responsibility of the Marine receiving or taking
charge of a weapon to determine its condition. Depending on the situation, there are two procedures
that can be used to transfer a rifle from one Marine to
another Marine: show clear transfer and condition
unknown transfer. Show Clear Transfer
When time and the tactical situation permit, the
Marine should transfer the rifle using the show clear
transfer. To properly pass a rifle between Marines, the
Marine handing off the rifle must perform the
following procedures:
l 
Ensure the rifle is on safe. l 
Remove the magazine if it is present. l 
Lock the bolt to the rear. l 
Visually inspect the chamber to ensure there is no
ammunition present. l 
Leave the bolt locked to the rear and hand the
weapon to the other Marine. The Marine receiving the weapon must:
l 
Ensure the rifle is on safe. l 
Visually inspect the chamber to ensure there is no
ammunition present. l 
Release the bolt catch and observe the bolt going
forward on an empty chamber. l 
Close the ejection port cover. Condition Unknown Transfer
There are times when time or the tactical situation
does not permit a show clear transfer of the rifle.

--- chunk_id: chunk-0088
source_document: MCRP3-01A.pdf
page: 35
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 272
content_hash: ab29e6e8c2862df2
prev_chunk_id: chunk-0087
next_chunk_id: chunk-0089
document_type: technical_reference

l 
Close the ejection port cover. Condition Unknown Transfer
There are times when time or the tactical situation
does not permit a show clear transfer of the rifle. The
procedures for the condition unknown transfer are
conducted by a Marine when he takes charge of a rifle
in any situation when the condition of the rifle is
unknown (e.g., an unmanned rifle from a casualty, a
rifle stored in a rifle rack). To properly take charge of
a rifle when its condition is unknown, the Marine must
perform the following procedures:
l 
Ensure the rifle is on safe. l 
Conduct a chamber check to determine the con-
dition of the weapon (see para. 3003). l 
Remove the magazine and observe if ammunition is
present. If time permits, count the rounds. l 
Insert the magazine into the magazine well. l 
Close the ejection port cover. 3011. Clearing Barrel Procedures
Purpose of a Clearing Barrel
The sole purpose of a clearing barrel is to provide a
safe direction in which to point a weapon when
loading; unloading; and unloading and showing clear. See figure 3-26 on page 3-12. Clearing barrel
procedures are identical to the weapons handling
Figure 3-25. Cross 
Body Sling Arms. Transport (Muzzle Up).

--- chunk_id: chunk-0089
source_document: MCRP3-01A.pdf
page: 35
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 10
content_hash: 3c2fc525d4010be4
prev_chunk_id: chunk-0088
next_chunk_id: chunk-0090
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 3-25. Cross](images/p035_img00.jpeg)
*Figure 3-25. Cross*

--- chunk_id: chunk-0090
source_document: MCRP3-01A.pdf
page: 36
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 509
content_hash: 8946dae17cd12d6f
prev_chunk_id: chunk-0089
next_chunk_id: chunk-0091
document_type: technical_reference

3-12 _______________________________________________________
procedures for the rifle for the loading; unloading; and
unloading and showing clear. Procedures for “Load” 
On the command “Load,” the Marine will perform the
following steps to take the rifle from Condition 4 to
Condition 3:
l 
With a straight trigger finger, point the rifle in the
clearing barrel. l 
Ensure the rifle is on safe. l 
Withdraw a magazine from the magazine pouch. l 
Observe the magazine to ensure it is filled. l 
Fully insert the magazine into the magazine well. l 
Without releasing the magazine, tug downward on
the magazine to ensure it is seated. l 
Fasten the magazine pouch. l 
Close the ejection port cover. Procedures for “Make Ready” 
If standard operating procedures (SOP) or rules of
engagement (ROE) require the rifle to be carried in
Condition 1, the Marine will “Make Ready” at the
clearing barrel. On the command “Make Ready,” the
Marine will perform the following steps to take the
rifle from Condition 3 to Condition 1:
l 
Pull the charging handle to the rear and release. There are two methods of doing this:
n  Grip the pistol grip firmly with the right hand
and pull the charging handle with the left hand to
its rearmost position and release. n  Or grip the handguards firmly with the left hand
and pull the charging handle with the right hand
to its rearmost position and release. Figure 3-26. Clearing Barrel. ___________________________________________ MCRP 3-01A
l 
To ensure ammunition has been chambered,
conduct a chamber check. l 
Check the sights (to ensure proper BZO setting,
correct rear sight aperture, etc.). l 
Close the ejection port cover. Procedures for “Unload” 
On the command “Unload,” the Marine will perform
the following steps to take the rifle from any condition
to Condition 4:
l 
With a straight trigger finger, point the rifle in the
clearing barrel. l 
Ensure the weapon is on safe. l 
Remove the magazine from the rifle and retain it on
your person. l 
While cupping the left hand under the ejection port,
rotate weapon until the ejection port is facing down. l 
Pull the charging handle to the rear and catch the
round in the left hand (see fig. 3-17). l 
Lock the bolt to the rear. l 
Put weapon on safe if not already on safe.

--- chunk_id: chunk-0091
source_document: MCRP3-01A.pdf
page: 36
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 254
content_hash: 4e27c5b22382d6db
prev_chunk_id: chunk-0090
next_chunk_id: chunk-0092
document_type: technical_reference

l 
Lock the bolt to the rear. l 
Put weapon on safe if not already on safe. l 
Ensure that the chamber is empty and that no
ammunition is present. l 
Release the charging handle and observe the bolt
moving forward on an empty chamber. l 
Close the ejection port cover. l 
Check the sights (for proper BZO setting, correct
rear sight aperture, etc.). l 
Place any ejected round into the magazine and
return the magazine to the magazine pouch and
close the magazine pouch. Procedures for “Unload and Show Clear” 
On the command “Unload and Show Clear,” the
Marine will perform the following steps to take the
rifle from any condition to Condition 4:
l 
With a straight trigger finger, point the rifle in the
clearing barrel. l 
Ensure the weapon is on safe. l 
Remove the magazine from the rifle and retain it on
your person. l 
While cupping the left hand under the ejection port,
rotate the weapon until the ejection port is facing
down. l 
Pull the charging handle to the rear and catch the
round in the left hand. l 
Lock the bolt to the rear.

--- chunk_id: chunk-0092
source_document: MCRP3-01A.pdf
page: 36
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 13
content_hash: e78a043866bfa8bd
prev_chunk_id: chunk-0091
next_chunk_id: chunk-0093
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 3-26. Clearing Barrel.](images/p036_img00.jpeg)
*Figure 3-26. Clearing Barrel.*

--- chunk_id: chunk-0093
source_document: MCRP3-01A.pdf
page: 37
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 177
content_hash: 6cbd397140b3af5d
prev_chunk_id: chunk-0092
next_chunk_id: chunk-0094
document_type: technical_reference

Rifle Marksmanship____________________________________
l Ensure the chamber is empty and no ammunition is
present. l Have an observer inspect the weapon to ensure no
ammunition is present. The observer:
n  Visually inspects chamber to ensure it is empty,
no ammunition is present, and the magazine is
removed. n  Ensures the weapon is on safe. n  Acknowledges the rifle is clear. ______________________________________________________ 3-13
s
o
,
s
l 
After receiving acknowledgment from the observer
that the rifle is clear, the Marine releases the bolt
catch and observes the bolt moving forward on an
empty chamber. l 
Close the ejection port cover. l 
Check the sights (for proper BZO setting, correct
rear sight aperture, etc.). l 
Place any ejected round into the magazine and
return the magazine to the magazine pouch and
close the magazine pouch.

--- chunk_id: chunk-0094
source_document: MCRP3-01A.pdf
page: 38
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 477
content_hash: 6b1d4a6c52505edf
prev_chunk_id: chunk-0093
next_chunk_id: chunk-0095
section_heading: CHAPTER 4. FUNDAMENTALS OF MARKSMANSHIP
document_type: technical_reference

CHAPTER 4. FUNDAMENTALS OF MARKSMANSHIP
The fundamentals of marksmanship are aiming, breathing, and trigger control. These techniques provide the foundation for all marksmanship principles and
skills. For rifle fire to be effective, it must be accurate. A rifleman who merely
sprays shots in the vicinity of the enemy produces little effect. The fundamentals
of marksmanship, when applied correctly, form the basis for delivering accurate
fire on enemy targets. These skills must be developed so that they are applied in-
stinctively. During combat, the fundamentals of marksmanship must be applied in
a time frame consistent with the size and the distance of the target. At longer rang-
es, the target appears to be smaller and a more precise shot is required to accurate-
ly engage the target. The fundamentals are more critical to accurate engagement
as the range to the target increases. To be accurate at longer ranges, the Marine
must take the time to slow down and accurately apply the fundamentals. At short-
er ranges, the enemy must be engaged quickly before he engages the Marine. As
the size of the target increases, and the distance to the target decreases, the funda-
mentals, while still necessary, become less critical to accuracy. Note
+The procedures in this manual are
written for right-handed Marines; left-
handed Marines should reverse instructions
as necessary. 4001. Aiming
Sight Alignment
Sight alignment is the relationship between the front
sight post and rear sight aperture and the aiming eye. This relationship is the most critical to aiming and
must remain consistent from shot to shot. To achieve
correct sight alignment (see fig. 4-1):
l Center the tip of the front sight post vertically and
horizontally in the rear sight aperture. l Imagine a horizontal line drawn through the center
of the rear sight aperture. The top of the front sight
post will appear to touch this line. l Imagine a vertical line drawn through the center of
the rear sight aperture. The line will appear to bisect
the front sight post. Sight Picture
Sight picture is the placement of the tip of the front
sight post in relation to the target while maintaining
sight alignment.

--- chunk_id: chunk-0095
source_document: MCRP3-01A.pdf
page: 38
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 142
content_hash: ad376a7f9d62d723
prev_chunk_id: chunk-0094
next_chunk_id: chunk-0096
section_heading: CHAPTER 4. FUNDAMENTALS OF MARKSMANSHIP
document_type: technical_reference

The line will appear to bisect
the front sight post. Sight Picture
Sight picture is the placement of the tip of the front
sight post in relation to the target while maintaining
sight alignment. Correct sight alignment but improper
sight placement on the target will cause the bullet to
impact the target incorrectly on the spot where the
sights were aimed when the bullet exited the muzzle. To achieve correct sight picture, place the tip of the
front sight post at the center of the target while main-
taining sight alignment (see fig. 4-2). Center mass is
Figure 4-1. Correct Sight Alignment. Figure 4-2. Correct Sight Picture.

--- chunk_id: chunk-0096
source_document: MCRP3-01A.pdf
page: 38
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 29
content_hash: 923ecba5e549eb0c
prev_chunk_id: chunk-0095
next_chunk_id: chunk-0097
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 4-1. Correct Sight Alignment.](images/p038_img00.jpeg)
*Figure 4-1. Correct Sight Alignment.*

![Figure 4-2. Correct Sight Picture.](images/p038_img01.jpeg)
*Figure 4-2. Correct Sight Picture.*

--- chunk_id: chunk-0097
source_document: MCRP3-01A.pdf
page: 39
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 453
content_hash: cce27c4ad31939f6
prev_chunk_id: chunk-0096
next_chunk_id: chunk-0098
document_type: technical_reference

4-2 _______________________________________________________________________________________________ MCRP 3-01A
the correct aiming point so that point of aim/point of
impact is achieved. The sighting system for the M16A2 rifle is designed to
work using a center mass sight picture. In combat, targets are often indistinct and oddly
shaped. The center mass hold provides a consistent
aiming point (see fig. 4-3). Importance of Correct Sight Alignment
A sight alignment error results in a misplaced shot. The error grows proportionately greater as the distance
to the target increases. An error in sight picture, how-
ever, remains constant regardless of the distance to the
target. See figure 4-4. Factors Affecting Sight Alignment and 
Sight Picture
Stock Weld
Stock weld is the point of firm contact between the
cheek and the stock of the rifle. See figure 4-5. The head should be as erect as possible to enable the
aiming eye to look straight through the rear sight aper-
ture. If the position of the Marine’s head causes him to
look across the bridge of his nose or out from under
his eyebrow, the eye will be strained. The eye func-
tions best in its natural forward position. Changing the
placement of the cheek up or down on the stock from
shot to shot may affect the zero on the rifle due to the
perception of the rear sight aperture. A consistent and
proper stock weld is critical to the aiming process be-
cause it provides consistency in eye relief, which af-
fects the ability to align the sights. Eye Relief
Eye relief is the distance between the rear sight aper-
ture and the aiming eye. See figure 4-6. Normal eye
relief is two to six inches from the rear sight aperture. The distance between the aiming eye and the rear sight
aperture depends on the size of the Marine and the fir-
ing position. While eye relief varies slightly from one
position to another, it is important to have the same
eye relief for all shots fired from a particular position. Figure 4-3. Examples of Correct Sight Picture.

--- chunk_id: chunk-0098
source_document: MCRP3-01A.pdf
page: 39
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 42
content_hash: 707203ffb54064de
prev_chunk_id: chunk-0097
next_chunk_id: chunk-0099
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 4-3. Examples of Correct Sight Picture.](images/p039_img00.jpeg)
*Figure 4-3. Examples of Correct Sight Picture.*

![figure 4-4.](images/p039_img01.jpeg)
*figure 4-4.*

![figure 4-5.](images/p039_img02.jpeg)
*figure 4-5.*

![figure 4-6. Normal eye](images/p039_img03.jpeg)
*figure 4-6. Normal eye*

--- chunk_id: chunk-0099
source_document: MCRP3-01A.pdf
page: 40
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 64
content_hash: a41d9d716432e4b9
prev_chunk_id: chunk-0098
next_chunk_id: chunk-0100
document_type: technical_reference

![Figure 4-4. Importance of Correct Sight Alignment.](images/p040_img00.jpeg)
*Figure 4-4. Importance of Correct Sight Alignment.*

Figure 4-4. Importance of Correct Sight Alignment. Figure 4-5. Stock Weld. ![Figure 4-5. Stock Weld.](images/p040_img01.jpeg)
*Figure 4-5. Stock Weld.*

Figure 4-6. Proper Eye Relief. ![Figure 4-6. Proper Eye Relief.](images/p040_img02.jpeg)
*Figure 4-6. Proper Eye Relief.*

--- chunk_id: chunk-0100
source_document: MCRP3-01A.pdf
page: 41
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: 6af84417d168373f
prev_chunk_id: chunk-0099
next_chunk_id: chunk-0101
document_type: technical_reference

4-4 ________________________________________________________
If the eye is too close to the rear sight aperture, it will
be difficult to line up the front sight post in the rear
sight aperture (see fig. 4-7). Moving the eye back from
the rear sight aperture will make the aperture appear
smaller and allow the tip of the front sight post to be
easily lined up inside the rear sight aperture. If the eye is too far from the rear sight aperture, it will
be difficult to acquire the target and to maintain a pre-
cise aiming point (see fig. 4-8). Wearing of Glasses
Wearing glasses can alter the perception of sight align-
ment and sight picture. If wearing glasses, it is critical
to look through the optic center of the lens. Acquiring and Maintaining Sight 
Alignment and Sight Picture
The human eye can focus clearly on only one object at
a time. For accurate shooting, it is important to focus
on the tip of the front sight post. When the shot is
fired, focus must be on the tip of the front sight post;
peripheral vision will include the rear sight and the
target. The rear sight and the target will appear blurry. Staring or fixing the vision on the front sight post for
longer than a few seconds can distort the image,
making it difficult to detect minute errors in sight
alignment. p
Figure 4-7. Shortened Eye Relief. ___________________________________________ MCRP 3-01A
Proper stock weld and placement of the rifle butt in the
shoulder aid in establishing sight alignment quickly. The rifle butt’s placement in the shoulder serves as the
pivot point for presenting the rifle up to a fixed point
on the cheek (stock weld). During combat, a Marine
will look at the target as the rifle is presented. As rifle
sights become level with the aiming eye, a Marine vi-
sually locates the target through the rear sight aperture. As the rifle settles, a Marine’s focus shifts back to the
front sight post to place the tip of the post on the target
and obtain sight alignment and sight picture. To main-
tain sight alignment and sight picture, the Marine’s fo-
cus should shift repeatedly from the front sight post to
the target until correct sight alignment and sight pic-
ture are obtained.

--- chunk_id: chunk-0101
source_document: MCRP3-01A.pdf
page: 41
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 186
content_hash: 5eef2e594e7a6185
prev_chunk_id: chunk-0100
next_chunk_id: chunk-0102
document_type: technical_reference

As the rifle settles, a Marine’s focus shifts back to the
front sight post to place the tip of the post on the target
and obtain sight alignment and sight picture. To main-
tain sight alignment and sight picture, the Marine’s fo-
cus should shift repeatedly from the front sight post to
the target until correct sight alignment and sight pic-
ture are obtained. This enables the detection of minute
errors in sight alignment and sight picture. Size and Distance to the Target
During combat, the fundamentals of marksmanship
must be applied in a time frame consistent with the
size and the distance to the target. Long-range Engagements
At longer ranges, the target appears smaller and a
more precise shot is required to accurately engage the
target. Sight alignment and sight picture are more crit-
Figure 4-8. Extended Eye Relief.

--- chunk_id: chunk-0102
source_document: MCRP3-01A.pdf
page: 41
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 56
content_hash: 66c76719f9680bef
prev_chunk_id: chunk-0101
next_chunk_id: chunk-0103
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 4-7. Shortened Eye Relief.](images/p041_img00.jpeg)
*Figure 4-7. Shortened Eye Relief.*

![Figure 4-8. Extended Eye Relief.](images/p041_img01.jpeg)
*Figure 4-8. Extended Eye Relief.*

![Figure 4-7. Shortened Eye Relief.](images/p041_img02.jpeg)
*Figure 4-7. Shortened Eye Relief.*

![Figure 4-8. Extended Eye Relief.](images/p041_img03.jpeg)
*Figure 4-8. Extended Eye Relief.*

--- chunk_id: chunk-0103
source_document: MCRP3-01A.pdf
page: 42
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: 8d4606cbf9b9cda4
prev_chunk_id: chunk-0102
next_chunk_id: chunk-0104
document_type: technical_reference

Rifle Marksmanship ____________________________________
ical to accurate engagement as the range to the target
increases. To be accurate at longer ranges, the Marine
must take the time to slow down and accurately apply
the fundamentals. As the distance to the target increases, the front sight
post covers more of the target, making it difficult to
establish a center of mass hold (see fig. 4-9). Since the
Marine must see the target to engage it, there is a ten-
dency to look at the target by lowering the tip of the
front sight post. This causes shots to impact low or
miss the target completely. A Marine must conscious-
ly aim at the center of mass and attempt to maintain a
center mass sight picture. Short-range Engagements
At shorter ranges, the enemy must be engaged quickly
before he engages the Marine. As distance to the target
decreases, the size of the target appears to increase,
and sight alignment becomes less critical to accuracy. At very short ranges, a deviation in sight alignment
can still produce accurate results as long as the tip of
the front sight post is in the rear sight aperture and on
the target (see fig. 4-10). The time required to engage
a target is unique to each individual. Although a
Marine must engage the target rapidly, some sem-
blance of sight alignment is still required to be accu-
rate. 4002. Breath Control
Proper breath control is critical to the aiming process. Breathing causes the body to move. This movement
Figure 4-9. Sight Picture at
Long-range Engagements. ________________________________________________________ 4-5
t
t
r
a
a
-
transfers to the rifle making it impossible to maintain
proper sight picture. Breath control allows the Marine
to fire the rifle at the moment of least movement. Breath Control During Long-range or 
Precision Fire (Slow Fire)
It is critical that Marines interrupt their breathing at a
point of natural respiratory pause before firing a long-
range shot or a precision shot from any distance. A
respiratory cycle lasts 4 to 5 seconds. Inhaling and ex-
haling each require about 2 seconds. A natural pause
of 2 to 3 seconds occurs between each respiratory cy-
cle. The pause can be extended up to 10 seconds. Dur-
ing the pause, breathing muscles are relaxed and the
sights settle at their natural point of aim.

--- chunk_id: chunk-0104
source_document: MCRP3-01A.pdf
page: 42
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 185
content_hash: a5f02bf8b8fd4898
prev_chunk_id: chunk-0103
next_chunk_id: chunk-0105
document_type: technical_reference

The pause can be extended up to 10 seconds. Dur-
ing the pause, breathing muscles are relaxed and the
sights settle at their natural point of aim. To minimize
movement, Marines must fire the shot during the natu-
ral respiratory pause. The basic technique is as fol-
lows:
l Breathe naturally until the sight picture begins to
settle. l Take a slightly deeper breath. l Exhale and stop at the natural respiratory pause. l Fire the shot during the natural respiratory pause. Note
If the sight picture does not sufficiently
settle to allow the shot to be fired, resume
normal breathing and repeat the process. Breath Control During All Other Combat 
Situations
A Marine in a combat environment may not have the
time to fire a shot during the natural respiratory pause. Figure 4-10. Sight Picture at
Short-range Engagements.

--- chunk_id: chunk-0105
source_document: MCRP3-01A.pdf
page: 42
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 29
content_hash: 6bc46b83d8b5e1bd
prev_chunk_id: chunk-0104
next_chunk_id: chunk-0106
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 4-9. Sight Picture at](images/p042_img00.jpeg)
*Figure 4-9. Sight Picture at*

![Figure 4-10. Sight Picture at](images/p042_img01.jpeg)
*Figure 4-10. Sight Picture at*

--- chunk_id: chunk-0106
source_document: MCRP3-01A.pdf
page: 43
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 490
content_hash: 60c5255ff4c4e1d7
prev_chunk_id: chunk-0105
next_chunk_id: chunk-0107
document_type: technical_reference

4-6 ________________________________________________________
It may be necessary to take several deep breaths before
holding the breath. A Marine should not make an ex-
aggerated effort to perform breath control. A natural
respiratory pause will help stabilize the shooter’s sight
picture. The basic technique is as follows:
l Take a deep breath filling the lungs with oxygen. Note
It may be necessary to take several deep
breaths quickly before holding the breath. l Hold the breath and apply pressure to the trigger. l Fire the shots. 4003. Trigger Control
Trigger control is the skillful manipulation of the trig-
ger that causes the rifle to fire without disturbing sight
alignment or sight picture. Controlling the trigger is a
mental process, while pulling the trigger is a physical
process. Grip
A firm grip is essential for effective trigger control. The grip is established before starting the application
of trigger control and it is maintained through the du-
ration of the shot. To establish a firm grip on the rifle,
position the “V” formed between the thumb and index
finger on the pistol grip behind the trigger. The fingers
and the thumb are placed around the pistol grip in a lo-
cation that allows the trigger finger to be placed natu-
rally on the trigger and the thumb in a position to
operate the safety. Once established, the grip should
be firm enough to allow manipulation of the trigger
straight to the rear without disturbing the sights. See
figure 4-11. Trigger Finger Placement
Correct trigger finger placement allows the trigger to
be pulled straight to the rear without disturbing sight
alignment. The trigger finger should contact the trig-
ger naturally. The trigger finger should not contact the
rifle receiver or trigger guard. r
p
p

___________________________________________ MCRP 3-01A
Types of Trigger Control
There are two techniques of trigger control: uninter-
rupted and interrupted
Uninterrupted Trigger Control
The preferred method of trigger control in a combat
environment is uninterrupted trigger control. After ob-
taining sight picture, the Marine applies smooth, con-
tinuous pressure rearward on the trigger until the shot
is fired. Interrupted Trigger Control
Interrupted trigger control is used at any time the sight
alignment is interrupted or the target is temporarily
obscured.

--- chunk_id: chunk-0107
source_document: MCRP3-01A.pdf
page: 43
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 257
content_hash: c6da227988f66aa2
prev_chunk_id: chunk-0106
next_chunk_id: chunk-0108
document_type: technical_reference

After ob-
taining sight picture, the Marine applies smooth, con-
tinuous pressure rearward on the trigger until the shot
is fired. Interrupted Trigger Control
Interrupted trigger control is used at any time the sight
alignment is interrupted or the target is temporarily
obscured. An example of this is extremely windy con-
ditions when the weapon will not settle, forcing the
Marine to pause until the sights return to his aiming
point. To perform interrupted trigger control:
l Move the trigger to the rear until an error is detected
in the aiming process. l When this occurs, stop the rearward motion on the
trigger, but maintain the pressure on the trigger, un-
til sight picture is achieved. l When the sight picture settles, continue the rear-
ward motion on the trigger until the shot is fired. Resetting the Trigger
During recovery, release the pressure on the trigger
slightly to reset the trigger after the first shot is deliv-
ered (indicated by an audible click). Do not remove
the finger from the trigger. This places the trigger in
position to fire the next shot without having to reestab-
lish trigger finger placement. Figure 4-11. Grip.

--- chunk_id: chunk-0108
source_document: MCRP3-01A.pdf
page: 43
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 8
content_hash: bf71b4c9718d1388
prev_chunk_id: chunk-0107
next_chunk_id: chunk-0109
section_heading: Figures
document_type: technical_reference

## Figures

![figure 4-11.](images/p043_img00.jpeg)
*figure 4-11.*

--- chunk_id: chunk-0109
source_document: MCRP3-01A.pdf
page: 44
quality: 0.96
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 130
content_hash: 155dcc30e7f82edb
prev_chunk_id: chunk-0108
next_chunk_id: chunk-0110
section_heading: 4004. Follow-Through/Recovery
document_type: technical_reference

Rifle Marksmanship ________________________________________________________________________________________ 4-7
4004. Follow-Through/Recovery
Follow-Through
Follow-through is the continued application of the
fundamentals until the round has exited the barrel. In
combat, follow-through is important to avoid altering
the impact of the round by keeping the rifle as still as
possible until the round exits the barrel. Recovery
It is important to get the rifle sights back on the target
for another shot. This is known as recovery. Shot re-
covery starts immediately after the round leaves the
barrel. To recover quickly, a Marine must physically
bring the sights back on target as quickly as possible.

--- chunk_id: chunk-0110
source_document: MCRP3-01A.pdf
page: 45
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: 371adb975352cd85
prev_chunk_id: chunk-0109
next_chunk_id: chunk-0111
section_heading: CHAPTER 5. RIFLE
document_type: technical_reference

CHAPTER 5. RIFLE
In a combat environment, a Marine must
any circumstance. There are four basic f
and standing. These positions provide a 
Any firing position must provide stabilit
my. During training, a Marine learns po
by a series of precise movements until th
purpose of this is to ensure that the Marin
assist him in holding the rifle steady. Th
tomed to the feel of the positions throug
know instinctively whether his position i
ble to assume a textbook firing position
ment time, dispersion of targets, and oth
basic positions may have to be made to
Marine must strive to assume a position 
cover and concealment from the enemy, a
Note
+The procedures in this manual are written
for right-handed Marines; left-handed
Marines should reverse instructions as
necessary. 5001. Selecting a Firing Position
The selection of a firing position (prone, sitting, kneel-
ing, standing) is based on terrain, available cover, dis-
persion of targets, and other limiting factors. A Marine
must select a position that offers stability, mobility,
and observation. Stability
A firing position must provide a stable platform for
accurate and consistent shooting. If the position is sol-
id, the front sight can be held steady and the rifle
sights should recover after recoil to the same position
on the target. This allows for rapid reengagement of
the enemy. The prone position provides the most sta-
bility for firing, while the standing position provides
the least stability. Mobility
A firing position must provide a Marine with the
mobility required to move to new cover or to another
area. The standing position permits maximum mobili-
ty, and it also allows the most lateral movement for
engagement of widely dispersed targets. The prone po-

LE FIRING POSITIONS
must be prepared to engage the enemy under
ic firing positions: prone, sitting, kneeling,
e a stable foundation for effective shooting. bility, mobility, and observation of the ene-
positions in a step-by-step process, guided
l the Marine assumes a correct position. The
arine correctly applies all of the factors that
 The Marine will gradually become accus-
ough practice and eventually will be able to
on is correct. In combat, it may not be possi-
ion due to terrain, available cover, engage-
other limiting factors. Modifications to the
e to adjust to the combat environment.

--- chunk_id: chunk-0111
source_document: MCRP3-01A.pdf
page: 45
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 350
content_hash: 07d2f4f311dca38b
prev_chunk_id: chunk-0110
next_chunk_id: chunk-0112
section_heading: CHAPTER 5. RIFLE
document_type: technical_reference

In combat, it may not be possi-
ion due to terrain, available cover, engage-
other limiting factors. Modifications to the
e to adjust to the combat environment. The
on that offers stability for firing, maximum
my, and maximum observation of the target. -
-
e
,
r
-
e
n
f
-
s
e
r
-
r
-
sition allows the least mobility and allows limited lat-
eral movement. Observation of the Enemy
A firing position must limit a Marine’s exposure to the
enemy, yet allow observation of the enemy. Manmade
structures and terrain features (e.g., vegetation, earth
contours) often dictate the shooting position. The
standing position normally provides the best field of
view, but it usually allows the most exposure to the en-
emy. The prone position normally allows the least ex-
posure, but it usually provides a limited field of view. 5002. Types and Uses of the Rifle Web 
Sling
The rifle sling, when adjusted properly, provides max-
imum stability for the weapon, and helps hold the front
sight still and reduce the effects of the rifle’s recoil. Once a sling adjustment is found that provides maxi-
mum control of the weapon, the same sling adjustment
should be maintained. Varying the sling tension exten-
sively will affect the strike of the bullet, which will
make maintaining a BZO difficult. Using the same
sling adjustment will ensure the accuracy of rounds on
target. There are two basic types of rifle sling adjust-
ments: the hasty sling and loop sling. Note
In training situations, the parade sling may
be used. See paragraph 5008.

--- chunk_id: chunk-0112
source_document: MCRP3-01A.pdf
page: 46
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 493
content_hash: 227e29eacf81373c
prev_chunk_id: chunk-0111
next_chunk_id: chunk-0113
document_type: technical_reference

5-2 _______________________________________________________________________________________________ MCRP 3-01A
Hasty Sling
Application
The hasty sling is used in all firing positions. The
hasty sling is advantageous in combat because it can
be acquired quickly and it provides added stability to
the rifle. The same sling setting can be used for all fir-
ing positions. If properly adjusted, the hasty sling sup-
ports the weight of the weapon, provides stability for
the rifle, and reduces the effects of the rifle’s recoil. When using the hasty sling, controlled muscle tension
is applied to offer resistance against the sling, enabling
the rifle sights to be held steady. Donning the Hasty
Sling
A Marine performs the follow-
ing steps to form a hasty sling:
l 
Hold the rifle vertical with
the barrel pointing upward. l 
Unhook the J-hook from the
lower sling swivel. l 
Loosen the sling keeper. l 
Adjust the sling until the
J-hook hangs below the ri-
fle butt. (The distance will
vary based on the individual
Marine, but the J-hook will
usually hang approximate-
ly 3 to 10 inches below the
rifle butt.) Secure the sling
keeper. See figure 5-1. l 
Turn the sling a half turn
outboard to allow the sling
to lay flat against the arm. l 
Attach the J-hook to the
lower sling swivel so the
open end of the J-hook fac-
es outboard, away from the
rifle. See figure 5-2. l 
While holding the rifle with
the right hand, place the left
arm through the sling near
the lower sling swivel. Slide
the arm up through the sling
below the half twist. The
sling makes contact low on
the arm just below the triceps, above the elbow. The
sling lies flat on the back of the arm. l 
With the left hand, grasp the handguard by pinching
it in the “V” formed by the thumb and forefinger. The sling lies flat against the back or side of the
wrist or on the arm near the wrist. See figure 5-3. l 
Move the left hand as required to level the rifle with
the line of sight. Placement of the forward hand
controls the tension on the sling between the back
of the wrist or arm and the upper sling swivel (see
fig. 5-4).

--- chunk_id: chunk-0113
source_document: MCRP3-01A.pdf
page: 46
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 134
content_hash: 99e3d0bc03663866
prev_chunk_id: chunk-0112
next_chunk_id: chunk-0114
document_type: technical_reference

Placement of the forward hand
controls the tension on the sling between the back
of the wrist or arm and the upper sling swivel (see
fig. 5-4). This hand placement, with a straight
locked wrist, will cause the sling to pull straight un-
der the handguards and serves to stabilize the front
sight of the rifle. l 
Move the feed end of the sling in or out of the sling
keeper to adjust the hasty sling. Sling tension is in-
Figure 5-1. J-hook 
Location. Figure 5-2. J-hook 
Turned Outboard. Figure 5-3. Sling Against the Wrist. Figure 5-4. Position of Forward Hand.

--- chunk_id: chunk-0114
source_document: MCRP3-01A.pdf
page: 46
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 56
content_hash: d2a2675eb9554a27
prev_chunk_id: chunk-0113
next_chunk_id: chunk-0115
section_heading: Figures
document_type: technical_reference

## Figures

![fig. 5-4). This hand placement, with a straight](images/p046_img00.jpeg)
*fig. 5-4). This hand placement, with a straight*

![Figure 5-1. J-hook](images/p046_img01.jpeg)
*Figure 5-1. J-hook*

![Figure 5-2. J-hook](images/p046_img02.jpeg)
*Figure 5-2. J-hook*

![Figure 5-3. Sling Against the Wrist.](images/p046_img03.jpeg)
*Figure 5-3. Sling Against the Wrist.*

--- chunk_id: chunk-0115
source_document: MCRP3-01A.pdf
page: 47
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: 8cd0ba065eab46a4
prev_chunk_id: chunk-0114
next_chunk_id: chunk-0116
document_type: technical_reference

Rifle Marksmanship________________________________________________________________________________________ 5-3
creased by pushing the elbow outboard. See figure
5-5. (This enables one sling setting to fit all posi-
tions.) It is important for the hasty sling to be ad-
justed so it supports the rifle. The sling setting must
allow the left elbow to push outboard against the
sling so the elbow is not inverted under the rifle. l Locate the sling keeper near the feed end of the
sling and secure so the backside or flat end of the
sling keeper is against the arm. Loop Sling
Application
The loop sling provides the greatest amount of stabili-
ty during firing. This stability allows the Marine to
perfect marksmanship fundamentals. A loop sling
takes longer to don or remove than a hasty sling. Therefore, it has limited combat application and is best
used where stability of hold is needed for a precision
or long-range shot. The loop sling is used in the prone,
sitting, and kneeling positions. Donning the Loop Sling
l Place the rifle butt on the right hip and cradle the ri-
fle in the right arm. l Disconnect the J-hook from the lower sling swivel. l With the M-buckle near the hook, feed the sling
through the top of the M-buckle to form a loop large
enough to slip over the arm. See figure 5-6. l Give the loop a half turn outboard and insert the left
arm through the loop, positioning the loop above
the biceps. The loop is high on the left arm above
the biceps muscle in such a position that it does not
transmit pulse beat to the rifle. l Position the M-buckle on the outside of the left arm. See figure 5-7. l 
Tighten the loop on the left arm, ensuring the
M-buckle moves toward the center of the arm as the
loop tightens. The sling must pull from the center of
the arm to be properly positioned. In this way, as
tension is applied to the sling in the firing position,
the loop will tighten. To adjust the sling for the proper length, loosen the
sling keeper and pull up or down (toward or away)
from the loop. This adjustment varies with every indi-
vidual and every firing position. The loop should not
be tightened excessively on the arm.

--- chunk_id: chunk-0116
source_document: MCRP3-01A.pdf
page: 47
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 108
content_hash: bd8ca8e11527863a
prev_chunk_id: chunk-0115
next_chunk_id: chunk-0117
document_type: technical_reference

This adjustment varies with every indi-
vidual and every firing position. The loop should not
be tightened excessively on the arm. If blood flow is
restricted, excessive pulse beat is transmitted through
the rifle sling to the rifle and causes a noticeable,
rhythmic movement of the rifle sights. When this oc-
curs, a stable hold at the desired aiming point is impos-
sible to achieve. Figure 5-5. Position of Left Elbow. Figure 5-6. Forming a Loop. Figure 5-7. Position of M-buckle.

--- chunk_id: chunk-0117
source_document: MCRP3-01A.pdf
page: 47
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 45
content_hash: 3b6532c26489fc18
prev_chunk_id: chunk-0116
next_chunk_id: chunk-0118
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-5. Position of Left Elbow.](images/p047_img00.jpeg)
*Figure 5-5. Position of Left Elbow.*

![Figure 5-6. Forming a Loop.](images/p047_img01.jpeg)
*Figure 5-6. Forming a Loop.*

![Figure 5-7. Position of M-buckle.](images/p047_img02.jpeg)
*Figure 5-7. Position of M-buckle.*

--- chunk_id: chunk-0118
source_document: MCRP3-01A.pdf
page: 48
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 493
content_hash: e0a57d486d6699d2
prev_chunk_id: chunk-0117
next_chunk_id: chunk-0119
document_type: technical_reference

5-4 ________________________________________________________
Tension on the rifle sling is correct when it causes the
rifle butt to be forced rearward into the pocket of the
shoulder. This serves to keep the butt plate in the
shoulder pocket during recoil. To increase tension on
the rifle sling, the sling must be shortened. To lessen
the tension, the rifle sling must be lengthened. Move the sling keeper toward the left arm and secure
it. The sling keeper should be positioned near the feed
end of the sling. Place the left hand over the sling from the left side and
under the rifle. The rifle handguard should rest in the
“V” formed between the thumb and forefinger and
across the palm of the hand. Move the left hand as required to achieve desired sight
picture. Adjust the length of the sling for proper sling
tension and support. See figure 5-8. 5003. Factors Common to All Shooting 
Positions 
There are seven factors that are common to all shoot-
ing positions that affect the ability to hold the rifle
steady, maintain sight alignment, and control the trig-
ger. The way these factors are applied differs slightly
for each position, but the principles of each factor re-
main the same. Left Hand 
Placement of the left hand affects placement of left el-
bow, eye relief, stock weld, and sling tension. Figure 5-8. Loop Sling Donned. ___________________________________________ MCRP 3-01A
Hasty Sling
In a hasty sling configuration, the sling is attached to
the upper and lower sling swivels of the rifle. When
the left arm is placed in the hasty sling, tension created
by the sling travels from side to side. The tension cre-
ated by the sling affects how the position is estab-
lished. There are fundamental differences between the
application of the seven factors when using the hasty
sling. The most obvious of these is placement of the
left hand and the left elbow. To maximize the support provided by the hasty sling,
the left elbow should not be inverted and under the ri-
fle. Instead, the elbow should be pushed outboard
against the sling. To achieve this, the position of the
shooter’s body must almost face the target as opposed
to being perpendicular to the target.

--- chunk_id: chunk-0119
source_document: MCRP3-01A.pdf
page: 48
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 302
content_hash: 39669fe8e46280a4
prev_chunk_id: chunk-0118
next_chunk_id: chunk-0120
document_type: technical_reference

Instead, the elbow should be pushed outboard
against the sling. To achieve this, the position of the
shooter’s body must almost face the target as opposed
to being perpendicular to the target. In addition, the
hasty sling must be loosened to allow the elbow to
push out against the sling far enough so that the elbow
is not under the rifle. The tension on the sling created by the hasty sling
causes the center of balance to change on the rifle. When the elbow is under the rifle with the hasty sling
donned, the sling pulls down on the sling swivel dis-
rupting the center of balance and causing the muzzle to
drop. Therefore, the elbow must be pushed outboard. Outboard tension on the sling by the elbow drives the
buttstock into the pocket of the shoulder. To enable
this, the sling must make contact on the arm just below
the triceps, above the elbow. See figure 5-9. To stabilize the front sight of the rifle, the forward
hand, wrist, and forearm should be straight with the
wrist locked in place; the hand should be rotated up so
the rifle rests in the “V” formed by the thumb and in-
dex finger; the fingers will not curl around the hand-
guards. Instead, they will pinch the handguard slightly
Figure 5-9. Position of Left Elbow
with Hasty Sling.

--- chunk_id: chunk-0120
source_document: MCRP3-01A.pdf
page: 48
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 32
content_hash: 13c76081771febc0
prev_chunk_id: chunk-0119
next_chunk_id: chunk-0121
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-8. Loop Sling Donned.](images/p048_img00.jpeg)
*Figure 5-8. Loop Sling Donned.*

![Figure 5-9. Position of Left Elbow](images/p048_img01.jpeg)
*Figure 5-9. Position of Left Elbow*

--- chunk_id: chunk-0121
source_document: MCRP3-01A.pdf
page: 49
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 466
content_hash: ffb07c00ac94ebf9
prev_chunk_id: chunk-0120
next_chunk_id: chunk-0122
document_type: technical_reference

Rifle Marksmanship____________________________________
to keep the hand from slipping on the handguard dur-
ing recoil. See figure 5-10. When the wrist of the left hand is straight and locked,
it creates resistance on the sling close to the muzzle. The sling is in contact with the back or side of the
wrist or on the arm near the wrist. This resistance al-
lows the front sight to be stabilized. In contrast, when the rifle rests across the palm of the
hand, the only resistance created is where the sling
meets the triceps. Since the resistance is further from
the muzzle of the rifle, it makes stabilizing the front
sight more difficult. Loop Sling
With the loop sling donned, the handguard of the rifle
rests in the “V” formed by the thumb and index finger
of the left hand. The rifle rests across the heel of the
hand. The left elbow should be positioned under the
weapon to create bone support and a consistent resis-
tance to recoil. The fingers can curl around the hand-
guard, but should apply only the minimum amount of
pressure to prevent the hand from slipping on the
handguard. See figure 5-11. Figure 5-10. Position of Left Hand
with Hasty Sling. Figure 5-11. Position of Left Hand
with Loop Sling. ________________________________________________________ 5-5
-
,
e
-
e
g
m
t
e
r
e
e
-
-
f
e
Rifle Butt in the Pocket of the Shoulder
The rifle butt placed firmly in the pocket formed in the
right shoulder provides resistance to recoil, helps
steady the rifle, and prevents the rifle butt from slip-
ping in the shoulder during firing. Consistent place-
ment of the rifle butt in the shoulder pocket is essential
to maintaining a BZO and firing tight shot groups. Hasty Sling
With the hasty sling donned, the butt of the rifle is
placed in the pocket of the shoulder. The body is
squared to the target to provide a pocket for the butt of
the weapon. Outboard tension on the sling by the left elbow drives
the buttstock into the pocket of the shoulder.

--- chunk_id: chunk-0122
source_document: MCRP3-01A.pdf
page: 49
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 166
content_hash: e2ad9851a44ce675
prev_chunk_id: chunk-0121
next_chunk_id: chunk-0123
document_type: technical_reference

The body is
squared to the target to provide a pocket for the butt of
the weapon. Outboard tension on the sling by the left elbow drives
the buttstock into the pocket of the shoulder. The rifle butt should be placed high in the shoulder to
achieve a proper stock weld, allowing the Marine to
bring the stock up to his head, rather than lower his
head to the stock, which can degrade acquisition of
sight alignment and sight picture. See figure 5-12. Loop Sling 
With the loop sling donned, the toe of the rifle butt is
placed in the pocket of the shoulder. See figure 5-13. Figure 5-12. Buttstock in the Shoulder
with Hasty Sling. Figure 5-13. Buttstock in the Shoulder
with Loop Sling.

--- chunk_id: chunk-0123
source_document: MCRP3-01A.pdf
page: 49
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 66
content_hash: 99b5edc5b73f7ad5
prev_chunk_id: chunk-0122
next_chunk_id: chunk-0124
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-10. Position of Left Hand](images/p049_img00.jpeg)
*Figure 5-10. Position of Left Hand*

![Figure 5-11. Position of Left Hand](images/p049_img01.jpeg)
*Figure 5-11. Position of Left Hand*

![Figure 5-12. Buttstock in the Shoulder](images/p049_img02.jpeg)
*Figure 5-12. Buttstock in the Shoulder*

![Figure 5-13. Buttstock in the Shoulder](images/p049_img03.jpeg)
*Figure 5-13. Buttstock in the Shoulder*

--- chunk_id: chunk-0124
source_document: MCRP3-01A.pdf
page: 50
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 477
content_hash: 7358b95703f50b51
prev_chunk_id: chunk-0123
next_chunk_id: chunk-0125
document_type: technical_reference

5-6 _______________________________________________________________________________________________ MCRP 3-01A
Grip of the Right Hand
Grasp the pistol grip with the right hand and place the
forefinger on the trigger, with the thumb and remain-
ing fingers wrapped
around the pistol grip. See figure 5-14. Firm rearward pressure
should be exerted to
help keep the rifle butt
firmly in the shoulder,
reducing the effects of
recoil (this type of pres-
sure is particularly true
with the loop sling). The trigger finger
should be placed natu-
rally on the trigger and
care should be taken to
ensure that the trigger finger can move independently
without dragging on the side of the receiver. Proper
placement of the right hand high on the pistol grip al-
lows the trigger to be moved straight to the rear with-
out disturbing sight alignment. Right Elbow
The right elbow should be positioned naturally to pro-
vide balance to the position and create a pocket in the
shoulder for the rifle butt. If the elbow is correctly po-
sitioned, it helps to form a pocket in the right shoulder
where the rifle butt rests. The exact placement of the
elbow varies with each shooting position but should
remain consistent from shot to shot, ensuring the resis-
tance to recoil remains constant. See figure 5-15. Stock Weld
The placement of the shooter’s cheek against the stock
should remain firm and consistent from shot to shot. Consistency of stock weld is achieved through proper
placement of the rifle butt in the pocket of the shoul-
der. A firm contact between the cheek and the stock
enables consistent eye relief and enables the head and
rifle to recoil as a single unit. Stock weld provides
quick recovery between rapid fire shots, keeps the
aiming eye centered in the rear sight aperture, and pre-
vents the head from bouncing off the stock during re-
coil. The head should remain erect to allow the aiming
eye to look straight through the rear sight aperture. See
figure 5-16. Breathing
Breathing causes chest movement and a corresponding
movement in the rifle and its sights. Applying breath
control will minimize this movement and the effect it
has on aiming.

--- chunk_id: chunk-0125
source_document: MCRP3-01A.pdf
page: 50
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 209
content_hash: e81de136f0c2a9a7
prev_chunk_id: chunk-0124
next_chunk_id: chunk-0126
document_type: technical_reference

Breathing
Breathing causes chest movement and a corresponding
movement in the rifle and its sights. Applying breath
control will minimize this movement and the effect it
has on aiming. Muscular Tension/Relaxation
Muscular Tension–Hasty Sling
With the hasty sling donned, the shooter must apply an
amount of controlled muscular tension in the left arm
to keep the sling taut and stabilize the weapon sights. Resistance against the hasty sling controls the point at
which the rifle sights will settle. The muscular tension
is applied outward against the sling rather than in an
effort to hold the rifle up. However, muscular tension
should not be excessive to cause the shooter to shake,
tremble, or experience fatigue. Muscular Relaxation–Loop Sling
When using the loop sling, the muscles should be re-
laxed. Relaxation prevents undue muscle strain and re-
duces excessive movement. If proper relaxation is
Figure 5-14. Grip of the 
Right Hand. Figure 5-15. Right Elbow. Figure 5-16. Stock Weld.

--- chunk_id: chunk-0126
source_document: MCRP3-01A.pdf
page: 50
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 32
content_hash: 20826e88ec7b4876
prev_chunk_id: chunk-0125
next_chunk_id: chunk-0127
section_heading: Figures
document_type: technical_reference

## Figures

![figure 5-16.](images/p050_img00.jpeg)
*figure 5-16.*

![Figure 5-14. Grip of the](images/p050_img01.jpeg)
*Figure 5-14. Grip of the*

![Figure 5-15. Right Elbow.](images/p050_img02.jpeg)
*Figure 5-15. Right Elbow.*

--- chunk_id: chunk-0127
source_document: MCRP3-01A.pdf
page: 51
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 497
content_hash: 10511e1f5378d557
prev_chunk_id: chunk-0126
next_chunk_id: chunk-0128
document_type: technical_reference

Rifle Marksmanship____________________________________
achieved, natural point of aim and sight alignment are
more easily maintained. 5004. Elements of a Good Shooting 
Position 
There are three elements of a good shooting position
that apply when using a loop sling: bone support, mus-
cular relaxation, and natural point of aim. The three el-
ements of a shooting position applied with the loop
sling do not apply in the same way as when firing with
a hasty sling. While some degree of bone support is
still achieved with the hasty sling, muscular tension is
applied rather than muscular relaxation. Natural point
of aim, however, applies to both the loop sling and the
hasty sling. Bone Support
The body’s skeletal structure provides a stable founda-
tion to support the rifle’s weight. A weak shooting po-
sition will not withstand a rifle’s repeated recoil when
firing at the sustained rate or buffeting from wind. To
attain a correct shooting position, the body’s bones
must support as much of the rifle’s weight as possible. Proper use of the sling provides additional support. The weight of the weapon should be supported by
bone rather than muscle because muscles fatigue
whereas bones do not. By establishing a strong foundation for the rifle utiliz-
ing bone support, the Marine can relax as much as pos-
sible while minimizing weapon movement due to
muscle tension. Muscular Relaxation
Once bone support is achieved, muscles are relaxed. Muscular relaxation helps to hold the rifle steady and
increase the accuracy of the aim. Muscular relaxation
also permits the use of maximum bone support to cre-
ate a minimum arc of movement and consistency in re-
sistance to recoil. Muscular relaxation cannot be
achieved without bone support. During the shooting
process, the muscles of the body must be relaxed as
much as possible. Muscles that are tense will cause ex-
cessive movement of the rifle, disturbing the aim. When proper bone support and muscular relaxation
are achieved, the rifle will settle onto the aiming point,

________________________________________________________ 5-7
e
n
-
-
p
h
s
s
t
e
-
-
n
o
s
y
e
-
-
o
d
n
-
-
e
g
s
-
n
making it possible to apply trigger control and deliver
a well-aimed shot.

--- chunk_id: chunk-0128
source_document: MCRP3-01A.pdf
page: 51
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 489
content_hash: f490001e526848ce
prev_chunk_id: chunk-0127
next_chunk_id: chunk-0129
document_type: technical_reference

Muscles that are tense will cause ex-
cessive movement of the rifle, disturbing the aim. When proper bone support and muscular relaxation
are achieved, the rifle will settle onto the aiming point,

________________________________________________________ 5-7
e
n
-
-
p
h
s
s
t
e
-
-
n
o
s
y
e
-
-
o
d
n
-
-
e
g
s
-
n
making it possible to apply trigger control and deliver
a well-aimed shot. Natural Point of Aim
The point at which the rifle sights settle when in a fir-
ing position is called the natural point of aim. Since the rifle becomes an extension of the body, it
may be necessary to adjust the position of the body un-
til the rifle sights settle naturally on the desired aiming
point on the target. When in a shooting position with proper sight align-
ment, the position of the tip of the front sight post will
indicate the natural point of aim. When completely re-
laxed, the tip of the front sight post should rest on the
desired aiming point. One method of checking for natural point of aim is to
aim in on the target, close the eyes, take a couple of
breaths, and relax as much as possible. When the eyes
are opened, the tip of the front sight post should be po-
sitioned on the desired aiming point while maintaining
sight alignment. For each shooting position, specific adjustments will
cause the rifle sights to settle center mass, achieving a
natural point of aim. In all positions, the natural point of aim can be adjust-
ed by—
l 
Varying the placement of the left hand in relation to
the handguards. l 
Moving the left hand forward on the handguards to
lower the muzzle of the weapon, causing the sights
to settle lower on the target. l 
Moving the left hand back on the handguards to
raise the muzzle of the weapon, causing the sights
to settle higher on the target. l 
Varying the placement of the stock in the shoulder. l 
Moving the stock higher in the shoulder to lower
the muzzle of the weapon, causing the sights to set-
tle lower on the target.

--- chunk_id: chunk-0129
source_document: MCRP3-01A.pdf
page: 51
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 132
content_hash: a713e818881d0739
prev_chunk_id: chunk-0128
next_chunk_id: chunk-0130
document_type: technical_reference

l 
Varying the placement of the stock in the shoulder. l 
Moving the stock higher in the shoulder to lower
the muzzle of the weapon, causing the sights to set-
tle lower on the target. l 
Moving the stock lower in the shoulder to raise the
muzzle of the weapon, causing the sights to settle
higher on the target. l 
Natural point of aim can be adjusted right or left by
adjusting body alignment in relation to the target. In the prone position, if the natural point of aim is
above or below the desired aiming point, move the

--- chunk_id: chunk-0130
source_document: MCRP3-01A.pdf
page: 52
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 506
content_hash: 006f582128562f00
prev_chunk_id: chunk-0129
next_chunk_id: chunk-0131
document_type: technical_reference

5-8 ________________________________________________________
body slightly forward or back using the left elbow as a
pivot and by digging the toes in. l 
Pushing the body forward causes the sights to settle
lower on the target. l 
Pulling the body backward causes the sights to set-
tle higher on the target. In the kneeling and sitting positions, natural point of
aim can be adjusted by varying the placement of the
left elbow on the knee. l 
Moving the left elbow forward on the knee lowers
the muzzle of the weapon, causing the sights to set-
tle lower on the target. l 
Moving the left elbow back on the knee raises the
muzzle of the weapon, causing the sights to settle
higher on the target. 5005. Prone Position 
Application 
The prone position provides a very steady foundation
for shooting and presents a low profile for maximum
concealment. However, the prone position is the least
mobile of the shooting positions and may restrict a
Marine’s field of view for observation. In this posi-
tion, the Marine’s weight is evenly distributed on the
elbows, providing maximum support and good stabili-
ty for the rifle. Assuming the Prone Position
The prone position can be assumed by either moving
forward or dropping backward into position, depend-
ing on the combat situation. Moving Forward into Position
To move forward into the prone position, the Marine
performs the following steps:
l 
With the hasty sling donned, stand erect and face
the target, keeping the feet a comfortable distance
apart (approximately shoulder width). l 
Place the left hand on the handguard, the right hand
on the pistol grip. ___________________________________________ MCRP 3-01A
l 
Lower yourself into position by dropping to both
knees (see fig. 5-17). l 
Then shift the weight forward to lower the upper
body to the ground using the right hand to break the
forward motion. See figure 5-18. Dropping Back into Position
It may be necessary to drop backward into position to
avoid crowding cover, or to avoid covering uncleared
terrain. To drop back into the prone position, the
Marine performs the following steps:
l 
Face the target. l 
Place the left hand on the handguard, the right hand
on the pistol grip. l 
Squat to the ground and break the fall with either
hand (see fig. 5-19).

--- chunk_id: chunk-0131
source_document: MCRP3-01A.pdf
page: 52
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 70
content_hash: 00609ef651677625
prev_chunk_id: chunk-0130
next_chunk_id: chunk-0132
document_type: technical_reference

l 
Squat to the ground and break the fall with either
hand (see fig. 5-19). l 
Kick both legs straight to the rear (see fig. 5-20). l 
If the fall was broken using the left hand, reestab-
lish the hasty sling. Figure 5-18. Moving Forward Into Position. Figure 5-17. Dropping to Both Knees.

--- chunk_id: chunk-0132
source_document: MCRP3-01A.pdf
page: 52
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 34
content_hash: 453e702b2aae04c9
prev_chunk_id: chunk-0131
next_chunk_id: chunk-0133
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-18. Moving Forward Into Position.](images/p052_img00.jpeg)
*Figure 5-18. Moving Forward Into Position.*

![Figure 5-17. Dropping to Both Knees.](images/p052_img01.jpeg)
*Figure 5-17. Dropping to Both Knees.*

--- chunk_id: chunk-0133
source_document: MCRP3-01A.pdf
page: 53
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 492
content_hash: d0695f0097450061
prev_chunk_id: chunk-0132
next_chunk_id: chunk-0134
document_type: technical_reference

Rifle Marksmanship____________________________________
Straight Leg Prone Position with the 
Hasty Sling
Apply the seven factors to this position (para. 5003). To assume the straight leg prone position with the
hasty sling, either move forward or drop back into po-
sition (see figs. 5-21, 5-22, and 5-23):
l Once on the ground, extend your left elbow in front
of you. Stretch your legs out behind you. Spread the
Figure 5-19. Breaking the Fall. Figure 5-20. Kicking Back Into Position. Figure 5-22. Left View. Figure 5-21
Straight Leg Prone Position with the Hasty Sling

________________________________________________________ 5-9
e
-
t
e
feet a comfortable distance apart with the toes
pointing outboard and the inner portion of the feet
in contact with the ground. l 
As much of the body mass should be aligned direct-
ly behind the rifle as possible. l 
If body alignment is correct, weapon recoil is ab-
sorbed by the whole body and not just the shoulder. l 
Grasp the pistol grip with the right hand and place
the rifle butt in the right shoulder pocket. l 
Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture. l 
Rotate the left hand up, pinching the handguard be-
tween the thumb and forefinger. l 
Slide both elbows outboard on the ground so there
is outboard tension against the sling (moving the el-
bows out tightens the sling) and both shoulders are
level. The elbows should provide a tripod of sup-
port with the body. l 
Adjust the position of the left hand on the hand-
guard to allow the sling to support the weapon and
the front sight to be centered in the rear sight aper-
ture. To adjust for elevation:
n  Move the left hand rearward or forward on the
handguards (moving the hand rearward elevates
the muzzle). n  Open or close “V” of the left hand for small ad-
justments. (closing the “V” elevate the muzzle). l 
To adjust for a minor cant in the rifle, rotate the
handguard left or right in the “V” formed by the
thumb and forefinger by rotating the pistol grip left
or right. Figure 5-23. Right View. 5-21. Front View.

--- chunk_id: chunk-0134
source_document: MCRP3-01A.pdf
page: 53
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 58
content_hash: 5ec2a136ff95b14a
prev_chunk_id: chunk-0133
next_chunk_id: chunk-0135
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-19. Breaking the Fall.](images/p053_img00.jpeg)
*Figure 5-19. Breaking the Fall.*

![Figure 5-20. Kicking Back Into Position.](images/p053_img01.jpeg)
*Figure 5-20. Kicking Back Into Position.*

![Figure 5-22. Left View.](images/p053_img02.jpeg)
*Figure 5-22. Left View.*

![Figure 5-21](images/p053_img03.jpeg)
*Figure 5-21*

![Figure 5-23. Right View.](images/p053_img04.jpeg)
*Figure 5-23. Right View.*

--- chunk_id: chunk-0135
source_document: MCRP3-01A.pdf
page: 54
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 402
content_hash: dfd29eb83b4a88cf
prev_chunk_id: chunk-0134
next_chunk_id: chunk-0136
document_type: technical_reference

5-10 ______________________________________________________________________________________________ MCRP 3-01A
Straight Leg Prone Position with the Loop 
Sling
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume straight leg prone posi-
tion with the loop sling, either move forward or drop
back into position (see figs. 5-24, 5-25, and 5-26):
l 
Once on the ground, roll the body to the left side as
you extend and invert the left elbow on the ground. Stretch your legs out behind you. Spread the feet a
comfortable distance apart with the toes pointing
outboard and the inner portion of the feet in contact
with the ground. l 
As much of the body mass should be aligned direct-
ly behind the rifle as possible. l 
If body alignment is correct, weapon recoil is ab-
sorbed by the whole body and not just the shoulder. l 
Grasp the rifle butt with the right hand and place the
rifle butt into the right shoulder pocket. l 
Grasp the pistol grip with the right hand. l 
Rotate the body to the right while the elbow is low-
ered to the ground so the shoulders are level. The
right hand pulls and holds the rifle in the shoulder. l 
Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture. l 
Move the left hand to a location under the hand-
guard, which provides maximum bone support and
stability for the weapon. This may require that you
remove the rifle from the shoulder to reposition the
left hand. Figure 5-25. Left View. Figure 5-26. Right View. Figure 5-24. Front View. Straight Leg Prone Position with the Loop Sling
Figure 5-28. Left View. Figure 5-29. Right View. Figure 5-27. Front View. Cocked Leg Prone Position with the Hasty Sling

--- chunk_id: chunk-0136
source_document: MCRP3-01A.pdf
page: 54
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 66
content_hash: 0c0ee507404590e4
prev_chunk_id: chunk-0135
next_chunk_id: chunk-0137
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-25. Left View.](images/p054_img00.jpeg)
*Figure 5-25. Left View.*

![Figure 5-26. Right View.](images/p054_img01.jpeg)
*Figure 5-26. Right View.*

![Figure 5-24. Front View.](images/p054_img02.jpeg)
*Figure 5-24. Front View.*

![Figure 5-28. Left View.](images/p054_img03.jpeg)
*Figure 5-28. Left View.*

![Figure 5-29. Right View.](images/p054_img04.jpeg)
*Figure 5-29. Right View.*

![Figure 5-27. Front View.](images/p054_img05.jpeg)
*Figure 5-27. Front View.*

--- chunk_id: chunk-0137
source_document: MCRP3-01A.pdf
page: 55
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 501
content_hash: b0867071409a652c
prev_chunk_id: chunk-0136
next_chunk_id: chunk-0138
document_type: technical_reference

Rifle Marksmanship____________________________________
Cocked Leg Prone Position with the 
Hasty Sling
Apply the seven factors to this position (para. 5003). To assume the cocked leg prone position with the
hasty sling, either move forward or drop back into po-
sition (see figs. 5-27, 5-28, and 5-29):
l Once on the ground, roll the body to the left side. The left leg is stretched out behind you, almost in a
straight line. This allows the mass of the body to be
placed behind the rifle to aid in absorbing recoil. l Turn the toe of the left foot inboard so the outside of
the left leg and foot are in contact with the ground. Bend the right leg and draw it up toward the body to
a comfortable position. Turn the right leg and foot
outboard so the inside of the right boot is in contact
with the ground. Cocking the leg will raise the dia-
phragm, making breathing easier. l Grasp the pistol grip with the right hand and place
the rifle butt in the right shoulder pocket. l Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture. l Rotate the left hand up, pinching the handguard be-
tween the thumb and forefinger. l Roll the body to the right while lowering the right
elbow to the ground. Slide both elbows outboard on
the ground so there is outboard tension against the
sling (moving the elbows out tightens the sling). The right shoulder is higher than the left shoulder in
the cocked leg position. l Adjust the position of the left hand on the hand-
guard to allow the sling to support the weapon and
Figure 5-31. Left View. Figure 5-30
Cocked Leg Prone Position with the Loop Sling

______________________________________________________ 5-11
e
-
a
e
f
o
t
t
-
e
t
h
-
t
n
e
n
-
d
the front sight to be centered in the rear sight aper-
ture. To adjust for elevation—
n  Move the left hand rearward or forward on the
handguards (moving the hand rearward elevates
the muzzle). n  Open or close “V” of the left hand for small ad-
justments (closing the “V” elevates the muzzle).

--- chunk_id: chunk-0138
source_document: MCRP3-01A.pdf
page: 55
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 358
content_hash: 038e368fda933f04
prev_chunk_id: chunk-0137
next_chunk_id: chunk-0139
document_type: technical_reference

To adjust for elevation—
n  Move the left hand rearward or forward on the
handguards (moving the hand rearward elevates
the muzzle). n  Open or close “V” of the left hand for small ad-
justments (closing the “V” elevates the muzzle). To adjust for a minor cant in the rifle, rotate the hand-
guard left or right in the “V” formed by the thumb and
forefinger by rotating the pistol grip left or right. Cocked Leg Prone Position with the Loop 
Sling
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume the cocked leg prone
position with the loop sling, either move forward or
drop back into position (see figs 5-30, 5-31, and 5-32):
l 
Once on the ground, roll the body to the left side
and extend and invert the left elbow on the ground. The left leg is stretched out behind you, almost in a
straight line. This allows the mass of the body to be
placed behind the rifle to aid in absorbing recoil. l 
Turn the toe of the left foot inboard so the outside of
the left leg and foot are in contact with the ground. Then bend the right leg and draw it up toward the
body to a comfortable position. Turn the right leg
and foot outboard so the inside of the right boot is in
contact with the ground. Cocking the leg will raise
the diaphragm, making breathing easier. l 
Grasp the rifle butt with the right hand and place the
rifle butt into the right shoulder pocket. Figure 5-32. Right View. -30. Front View.

--- chunk_id: chunk-0139
source_document: MCRP3-01A.pdf
page: 55
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 29
content_hash: e5129ff5ab7c7945
prev_chunk_id: chunk-0138
next_chunk_id: chunk-0140
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-31. Left View.](images/p055_img00.jpeg)
*Figure 5-31. Left View.*

![Figure 5-30](images/p055_img01.jpeg)
*Figure 5-30*

![Figure 5-32. Right View.](images/p055_img02.jpeg)
*Figure 5-32. Right View.*

--- chunk_id: chunk-0140
source_document: MCRP3-01A.pdf
page: 56
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: 4b36748622d81331
prev_chunk_id: chunk-0139
next_chunk_id: chunk-0141
document_type: technical_reference

5-12 _______________________________________________________
l 
Grasp the pistol grip with the right hand. l 
Roll the body to the right while lowering the right
elbow to the ground. The right shoulder is higher
than the left shoulder in the cocked leg position. l 
Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture. l 
Move the left hand to a location under the hand-
guard which provides maximum bone support and
stability for the weapon. 5006. Sitting Position 
There are three variations of the sitting position:
crossed ankle, crossed leg, and open leg. Experiment
with all the variations and select the position that pro-
vides the most stability for firing. Although the sitting position provides an extremely
stable base, it limits lateral movement and maneuver
ability. It has several variations that can be adapted to
the individual Marine. The sitting position provides
greater elevation than the prone position while still
having a fairly low profile. Crossed Ankle Sitting Position with the 
Hasty Sling
The crossed ankle sitting position is an extremely sta-
ble shooting position. This position places most of the
body’s weight behind the weapon and aids in quick
shot recovery. Apply the seven factors to this position
(para. 5003). To assume the crossed ankle sitting posi-
tion with the hasty sling (see figs. 5-33, 5-34, 5-35)—
Crossed Ankle Sitting Position with the Hasty Sling
Figure 5-33. Left View. Figure 5-34. Fro

___________________________________________ MCRP 3-01A
l 
Square the body to the target. l 
Grasp the handguard with the left hand. l 
Bend at knees and break the fall with the right hand. l 
Push backward with the feet to extend the legs and
place the buttocks on the ground. l 
Cross the left ankle over the right ankle. l 
Grasp the pistol grip with the right hand and place
the rifle butt in the right shoulder pocket. l 
Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture. l 
Rotate the left hand up, pinching the handguard be-
tween the thumb and forefinger. l 
Bend forward at the waist and place the flat portion
of the back of the left arm, just above the elbow, on
the left leg just below the knee.

--- chunk_id: chunk-0141
source_document: MCRP3-01A.pdf
page: 56
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 265
content_hash: 8ced580934d129e3
prev_chunk_id: chunk-0140
next_chunk_id: chunk-0142
document_type: technical_reference

l 
Rotate the left hand up, pinching the handguard be-
tween the thumb and forefinger. l 
Bend forward at the waist and place the flat portion
of the back of the left arm, just above the elbow, on
the left leg just below the knee. l 
Place the right elbow on the inside of the right knee. l 
Adjust the position to adjust sling tension. To tight-
en the sling: square the body more to the target, or
move the left elbow out, or draw the feet up slightly
toward the body. l 
Adjust the position of the left hand to allow the
sling to support the weapon and the front sight to be
centered in the rear sight aperture. To adjust for elevation:
l 
Move left hand rearward or forward on handguards
(moving the hand rearward elevates the muzzle). l 
Open or close the “V” of the left hand for small ad-
justments (closing the “V” elevates the muzzle). To adjust for a minor cant in the rifle, rotate the hand-
guard left or right in the “V” formed by the thumb and
forefinger by rotating the pistol grip left or right. Front View. Figure 5-35. Right View.

--- chunk_id: chunk-0142
source_document: MCRP3-01A.pdf
page: 56
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 32
content_hash: d166e7f8467ffa27
prev_chunk_id: chunk-0141
next_chunk_id: chunk-0143
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-33. Left View.](images/p056_img00.jpeg)
*Figure 5-33. Left View.*

![Figure 5-34. Fro](images/p056_img01.jpeg)
*Figure 5-34. Fro*

![Figure 5-35. Right View.](images/p056_img02.jpeg)
*Figure 5-35. Right View.*

--- chunk_id: chunk-0143
source_document: MCRP3-01A.pdf
page: 57
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 492
content_hash: 4e4aa7d995d5136a
prev_chunk_id: chunk-0142
next_chunk_id: chunk-0144
document_type: technical_reference

Rifle Marksmanship______________________________________________________________________________________ 5-13
Crossed Ankle Sitting Position with the 
Loop Sling 
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume crossed ankle sitting
position with the loop sling (see figs. 5-36 and 5-37)—
l Position the body at approximately a 30-degree an-
gle to the target. l Place the left hand under the handguard. l Bend at knees and break the fall with the right hand. l Push backward with the feet to extend the legs and
place the buttocks on the ground. l Cross the left ankle over the right ankle. l Bend forward at the waist and place the left elbow
on the left leg below the knee. l Grasp the rifle butt with the right hand and place the
rifle butt into the right shoulder pocket. l Grasp the pistol grip with the right hand. l Lower right elbow to the inside of the right knee. l Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture. l 
Move the left hand to a location under the hand-
guard, which provides maximum bone support and
stability of the weapon. Crossed Leg Sitting Position with the 
Hasty Sling
The crossed leg sitting position provides a medium
base of support and places some of the body's weight
behind the weapon for quick recovery after each shot. Apply the seven factors to this position (para. 5003). To assume the crossed leg sitting position with the
hasty sling (see figures 5-38, 5-39, and 5-40)—
l 
Square the body to the target. l 
Grasp the handguard with the left hand. l 
Bend at the knees while breaking the fall with the
right hand. l 
Place the buttocks on the ground as close to the feet
as you comfortably can. l 
Cross the left leg over the right leg. l 
Grasp the pistol grip with the right hand and place
the rifle butt in the right shoulder pocket. Figure 5-36. Right View. Figure 5-37. Front View. Crossed Ankle Sitting Position with the Loop Sling
Figure 5-38. Left View. Figure 5-40. Right View. Figure 5-39. Front 
Crossed Leg Sitting Position with the Hasty Sling

--- chunk_id: chunk-0144
source_document: MCRP3-01A.pdf
page: 57
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 53
content_hash: 15595f741f1f917a
prev_chunk_id: chunk-0143
next_chunk_id: chunk-0145
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-36. Right View.](images/p057_img00.jpeg)
*Figure 5-36. Right View.*

![Figure 5-37. Front View.](images/p057_img01.jpeg)
*Figure 5-37. Front View.*

![Figure 5-38. Left View.](images/p057_img02.jpeg)
*Figure 5-38. Left View.*

![Figure 5-40. Right View.](images/p057_img03.jpeg)
*Figure 5-40. Right View.*

![Figure 5-39. Front](images/p057_img04.jpeg)
*Figure 5-39. Front*

--- chunk_id: chunk-0145
source_document: MCRP3-01A.pdf
page: 58
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 518
content_hash: dc9f27d6e18d492b
prev_chunk_id: chunk-0144
next_chunk_id: chunk-0146
document_type: technical_reference

5-14 _______________________________________________________
l 
Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture. l 
Rotate the left hand up, pinching the handguard be-
tween the thumb and forefinger. l 
Bend forward at the waist while placing the left el-
bow into the bend of the knee or placing the flat
portion of the back of the left arm, just above the el-
bow, in front of the knee. l 
Place the right elbow on the inside of the right knee. l 
Adjust the position to adjust sling tension. Squaring
the body more to the target or drawing the feet clos-
er together tightens the sling by forcing the left el-
bow outboard. l 
Adjust the position of the left hand to allow the
sling to support the weapon and the front sight to be
centered in the rear sight aperture. To adjust for elevation:
l 
Move left hand rearward or forward on handguards
(moving the hand rearward elevates the muzzle). l 
Open or close the “V” of the left hand for small ad-
justments (closing the “V” elevates the muzzle). To adjust for a minor cant in the rifle, rotate the hand-
guard left or right in the “V” formed by the thumb and
forefinger by rotating the pistol grip left or right. Crossed Leg Sitting Position with the 
Loop Sling
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume crossed leg sitting posi-
tion with loop sling (see figs. 5-41, 5-42, and 5-43)—
l 
Position body at a 45- to 60-degree angle to target. l 
Place the left hand under the handguard. l 
Cross the left leg over the right leg. Figure 5-41. Left View. Figure 5-42. Fro
Crossed Leg Sitting Position with the Loop Sling

___________________________________________ MCRP 3-01A
l 
Bend at the knees while breaking the fall with the
right hand. l 
Place the buttocks on the ground as close to the
crossed legs as you comfortably can. l 
Bend forward at the waist while placing the left el-
bow on the left leg into the bend of the knee. l 
Grasp the rifle butt with the right hand and place the
rifle butt into the right shoulder pocket. l 
Grasp the pistol grip with the right hand.

--- chunk_id: chunk-0146
source_document: MCRP3-01A.pdf
page: 58
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 324
content_hash: 6ea384b8722e847c
prev_chunk_id: chunk-0145
next_chunk_id: chunk-0147
document_type: technical_reference

l 
Grasp the rifle butt with the right hand and place the
rifle butt into the right shoulder pocket. l 
Grasp the pistol grip with the right hand. l 
Lower right elbow to the inside of the right knee. l 
Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture. l 
Move the left hand to a location under the hand-
guard which provides maximum bone support and
stability of the weapon. Open Leg Sitting Position with the Hasty 
Sling
The open leg sitting position provides a medium base
of support and is most commonly used when firing
from a forward slope. Apply the seven factors to this
position (para. 5003). To assume the open leg sitting
position with the hasty sling (see figs. 5-44, 5-45, and
5-46)—
l 
Square the body to the target. l 
Place the feet approximately shoulder width apart. l 
Grasp the handguard with the left hand. l 
Bend at the knees while breaking the fall with the
right hand. l 
Push backward with the feet to extend the legs and
place the buttocks on the ground. l 
Grasp the pistol grip with the right hand and place
the rifle butt in the right shoulder pocket. l 
Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture. Front View. Figure 5-43. Right View.

--- chunk_id: chunk-0147
source_document: MCRP3-01A.pdf
page: 58
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 32
content_hash: 3acde56c671ba7ba
prev_chunk_id: chunk-0146
next_chunk_id: chunk-0148
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-41. Left View.](images/p058_img00.jpeg)
*Figure 5-41. Left View.*

![Figure 5-42. Fro](images/p058_img01.jpeg)
*Figure 5-42. Fro*

![Figure 5-43. Right View.](images/p058_img02.jpeg)
*Figure 5-43. Right View.*

--- chunk_id: chunk-0148
source_document: MCRP3-01A.pdf
page: 59
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 506
content_hash: 9d34780dd988e3f0
prev_chunk_id: chunk-0147
next_chunk_id: chunk-0149
document_type: technical_reference

Rifle Marksmanship______________________________________________________________________________________ 5-15
l Rotate the left hand up, pinching the handguard be-
tween the thumb and forefinger. l Place the flat portion of the back of the left arm, just
above the elbow, in front of the left knee. l Place the right elbow on the inside of the right knee
or place the flat portion of the back of the right arm,
just above the elbow, in front of the knee. l Adjust the position to adjust sling tension. Widen-
ing the stance tightens the sling by forcing the left
elbow outboard. There must be some controlled
muscular tension in the legs to hold them up and of-
fer resistance to recoil. l The position of the left hand to allow the sling to
support the weapon and the front sight to be cen-
tered in the rear sight aperture. To adjust for elevation:
l Move left hand rearward or forward on handguards
(moving the hand rearward elevates the muzzle). l Open or close the “V” of the left hand for small ad-
justments (closing the “V” elevates the muzzle). To adjust for a minor cant in the rifle, rotate the hand-
guard left or right in the “V” formed by the thumb and
forefinger by rotating the pistol grip left or right. Open Leg Sitting Position with the Loop 
Sling
Apply the three elements and seven factors to this
position (para. 5004). To assume the open leg sitting
position with the loop sling (see figs. 5-47, 5-48, and
5-49 on page 5-16)—
l Position the body at approximately a 30-degree an-
gle to the target. l Place the feet approximately shoulder width apart. l Place the left hand under the handguard. l 
Bend at the knees while breaking the fall with the
right hand. l 
Push backward with the feet to extend the legs and
place the buttocks on the ground. l 
Place the left elbow on the inside of the left knee. l 
Grasp the rifle butt with the right hand and place the
rifle butt into the right shoulder pocket. l 
Lower right elbow to the inside of the right knee. l 
Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture.

--- chunk_id: chunk-0149
source_document: MCRP3-01A.pdf
page: 59
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 282
content_hash: 758dfea2c07cbc57
prev_chunk_id: chunk-0148
next_chunk_id: chunk-0150
document_type: technical_reference

l 
Lower right elbow to the inside of the right knee. l 
Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture. l 
Move the left hand to a location under the hand-
guard which provides maximum bone support and
stability of the weapon. 5007. Kneeling Position
Description
The kneeling position is quick to assume and easy to
maneuver from. It is usually assumed after initial en-
gagement has been made from a standing position. It
can easily be adapted to available cover. A tripod is
formed by the left foot, right foot, and right knee when
the Marine assumes the position, providing a stable
foundation for shooting. The kneeling position also
presents a higher profile to facilitate a better field of
view as compared to the prone and sitting positions. Assuming the Kneeling Position
The kneeling position can be assumed by either mov-
ing forward or dropping back into position, depending
on the combat situation. For example, it may be neces-
sary to drop back into position to avoid crowding cov-
er, or to avoid covering uncleared terrain. Figure 5-44. Left View. Figure 5-46. Right View. Figure 5-45. Front View. Open Leg Sitting Position with the Hasty Sling

--- chunk_id: chunk-0150
source_document: MCRP3-01A.pdf
page: 59
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 34
content_hash: a60317417fb12a82
prev_chunk_id: chunk-0149
next_chunk_id: chunk-0151
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-44. Left View.](images/p059_img00.jpeg)
*Figure 5-44. Left View.*

![Figure 5-46. Right View.](images/p059_img01.jpeg)
*Figure 5-46. Right View.*

![Figure 5-45. Front View.](images/p059_img02.jpeg)
*Figure 5-45. Front View.*

--- chunk_id: chunk-0151
source_document: MCRP3-01A.pdf
page: 60
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 520
content_hash: b40f7f938ac1e6c3
prev_chunk_id: chunk-0150
next_chunk_id: chunk-0152
document_type: technical_reference

5-16 _______________________________________________________
Moving Forward into Position
To move forward into the kneeling position, the
Marine steps forward toward the target with his left
foot and kneels down on his right knee. Dropping Back into Position
To drop back into the kneeling position, the Marine
leaves his left foot in place and steps backward with
his right foot and kneels down on his right knee. High Kneeling Position with the Hasty 
Sling
Apply the seven factors to this position (para. 5003). To assume the high kneeling position with the hasty
sling, either move forward or drop back into position
(see figs. 5-50, 5-51, and 5-52):
l 
Square the body to the target. l 
Keep the right ankle straight, with the toe of the
boot in contact with the ground and curled under by
the weight of the body. Open Leg Sitting Position with the Loop Sling
Figure 5-47. Left View. Figure 5-48. Fro
Figure 5-50. Left View. Figure 5-51. Fro
High Kneeling Position with the Hasty Sling

___________________________________________ MCRP 3-01A
l 
Place the right portion of the buttocks on or over the
right heel. Contact with the heel provides more sta-
bility to the position, however, it is not mandatory
that the buttocks make contact. l 
Place the left foot forward to a point that allows the
shin to be vertically straight. For the shin to be ver-
tical, the heel should be directly under the knee. The
left foot must be flat on the ground. To provide a
wider base of support, slide the right knee and left
foot outboard to form a tripod with the right foot. l 
Grasp the pistol grip with the right hand and place
the rifle butt in the right shoulder pocket. l 
Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture. l 
Rotate the left hand up, pinching the handguard be-
tween the thumb and forefinger. The left hand will
not grasp the slip ring or the magazine. The maga-
zine must be on the inside of the left arm. l 
Place the flat portion of the back of the upper left
arm, just above the elbow, on the left knee or
against the inside of the left knee so it is in firm
Front View. Figure 5-49. Right View.

--- chunk_id: chunk-0152
source_document: MCRP3-01A.pdf
page: 60
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 13
content_hash: 5692e8c94ed73477
prev_chunk_id: chunk-0151
next_chunk_id: chunk-0153
document_type: technical_reference

Figure 5-49. Right View. Front View. Figure 5-52. Right View.

--- chunk_id: chunk-0153
source_document: MCRP3-01A.pdf
page: 60
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 61
content_hash: e10ae3e89de7db3b
prev_chunk_id: chunk-0152
next_chunk_id: chunk-0154
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-47. Left View.](images/p060_img00.jpeg)
*Figure 5-47. Left View.*

![Figure 5-48. Fro](images/p060_img01.jpeg)
*Figure 5-48. Fro*

![Figure 5-50. Left View.](images/p060_img02.jpeg)
*Figure 5-50. Left View.*

![Figure 5-51. Fro](images/p060_img03.jpeg)
*Figure 5-51. Fro*

![Figure 5-49. Right View.](images/p060_img04.jpeg)
*Figure 5-49. Right View.*

![Figure 5-52. Right View.](images/p060_img05.jpeg)
*Figure 5-52. Right View.*

--- chunk_id: chunk-0154
source_document: MCRP3-01A.pdf
page: 61
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: 81d381ef3dd212cb
prev_chunk_id: chunk-0153
next_chunk_id: chunk-0155
document_type: technical_reference

Rifle Marksmanship____________________________________
contact. The upper portion of the triceps or the arm-
pit will not rest on the knee. l Bend the right elbow to provide the least muscular
tension possible, lowering it to a natural position. l Adjust the position to adjust sling tension. Widen-
ing the stance by moving the left foot and knee out-
board will allow the sling to be tightened. l Adjust the position of the left hand to allow the
sling to support the weapon and the front sight to be
centered in the rear sight aperture. To adjust for elevation:
l Move left hand rearward or forward on handguards
(moving the hand rearward elevates the muzzle). l Open or close the “V” of the left hand for small ad-
justments (closing the “V” elevates the muzzle). To adjust for a minor cant in the rifle, rotate the hand-
guard left or right in the “V” formed by the thumb and
forefinger by rotating the pistol grip left or right. High Kneeling Position with the Loop 
Sling
Apply the three elements and seven factors to this po-
sition (para. 5004). To assume the high kneeling posi-
tion with the loop sling, either move forward or drop
back into position (see figs. 5-53, 5-54, and 5-55):
l Position the body at a 45-degree angle to the target. l Place the left hand under the handguard. l Kneel down on right knee so right lower leg is ap-
proximately parallel to the target (45 to 90 degrees). Figure 5-53. Left View. Figure 5-54
High Kneeling Position with the Loop Sling

______________________________________________________ 5-17
r
-
-
e
e
s
-
-
d
-
-
p
-
l 
Keep the right ankle straight, with the toe of the
boot in contact with the ground and curled under by
the weight of the body. l 
Place the right portion of the buttocks on or over the
right heel; contact with the heel provides more sta-
bility to the position. l 
Place the left foot forward to a point that allows the
shin to be vertically straight. For the shin to be ver-
tical, the heel should be directly under the knee. The left foot must be flat on the ground since it will
be supporting the majority of the weight.

--- chunk_id: chunk-0155
source_document: MCRP3-01A.pdf
page: 61
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 320
content_hash: f4e397582fc5797b
prev_chunk_id: chunk-0154
next_chunk_id: chunk-0156
document_type: technical_reference

For the shin to be ver-
tical, the heel should be directly under the knee. The left foot must be flat on the ground since it will
be supporting the majority of the weight. l 
Place the flat portion of the back of upper left arm,
just above the elbow, on the left knee so it is in firm
contact with the flat surface formed on top of the
bent knee. The point of the left elbow will extend
just slightly past the left knee. The upper portion of
the triceps or the armpit will not rest on the knee. l 
Lean slightly forward into the sling for support. l 
Grasp the rifle butt with the right hand and place the
rifle butt into the right shoulder pocket. l 
Grasp the pistol grip with the right hand. l 
Bend the right elbow to provide the least muscular
tension possible and lower it to a natural position. l 
Lower the head and place the cheek firmly against
the stock to allow the aiming eye to look through
the rear sight aperture. l 
Move the left hand to a location under the hand-
guard, which provides maximum bone support and
stability for the weapon. Medium Kneeling Position
This is also referred to as the bootless kneeling posi-
tion. Assume the medium kneeling position in the
same way as the high kneeling position with the ex-
-54. Front View. Figure 5-55. Right View.

--- chunk_id: chunk-0156
source_document: MCRP3-01A.pdf
page: 61
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 29
content_hash: ea14badd569d6ef9
prev_chunk_id: chunk-0155
next_chunk_id: chunk-0157
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-53. Left View.](images/p061_img00.jpeg)
*Figure 5-53. Left View.*

![Figure 5-54](images/p061_img01.jpeg)
*Figure 5-54*

![Figure 5-55. Right View.](images/p061_img02.jpeg)
*Figure 5-55. Right View.*

--- chunk_id: chunk-0157
source_document: MCRP3-01A.pdf
page: 62
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 505
content_hash: d47ea9ff3b4b49c7
prev_chunk_id: chunk-0156
next_chunk_id: chunk-0158
document_type: technical_reference

5-18 _______________________________________________________
ception of the right foot. The right ankle is straight and
the foot is stretched out with the bootlaces in contact
with the ground. The buttocks are in contact with the
heel of the right foot. See figure 5-56. Low Kneeling Position
The low kneeling position is most commonly used
when firing from a forward slope. Assume the low
kneeling position in the same way as the high kneeling
position with the exception of the placement of the
right foot. Turn the right ankle so the outside of the
foot is in contact with the ground and the buttocks are
in contact with the inside of the foot. See figure 5-57. 5008. Standing Position
Description
The standing position is the quickest position to as-
sume and the easiest to maneuver from. It allows
greater mobility than other positions. The standing po-
Figure 5-56. Medium Kneeling Position. Figure 5-57. Low Kneeling Position. ___________________________________________ MCRP 3-01A
sition is often used for immediate combat engagement. The standing position is supported by the shooter’s
legs and feet and provides a small area of contact with
the ground. In addition, the body’s center of gravity is
high above the ground. Therefore, maintaining balance
is critical in this position. Standing Position with the Hasty Sling
Apply the seven factors to this position (para. 5003). To assume the standing position with the hasty sling
(see figs. 5-58, 5-59, and 5-60)—
l 
Square the body to the target. l 
Spread the feet apart to a comfortable distance with
the left foot slightly in front of the right foot. This
distance may be wider than shoulder width. l 
Distribute the weight evenly over both feet and
hips. Balance will shift forward slightly to reduce
recovery time and increase the stability of the hold. The legs should be slightly bent for balance. l 
Grasp the pistol grip with the right hand and place
the rifle butt in the right shoulder pocket. l 
Bring the rifle sights up to eye level instead of low-
ering the head to the sights and place the cheek
firmly against the stock. Ensure the head is erect so
the aiming eye can look through rear sight aperture. l 
Rotate the left hand up, pinching the handguard be-
tween the thumb and forefinger.

--- chunk_id: chunk-0158
source_document: MCRP3-01A.pdf
page: 62
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 276
content_hash: 63cfa5f0bce9b023
prev_chunk_id: chunk-0157
next_chunk_id: chunk-0159
document_type: technical_reference

Ensure the head is erect so
the aiming eye can look through rear sight aperture. l 
Rotate the left hand up, pinching the handguard be-
tween the thumb and forefinger. l 
The left hand will be under the handguard with the
thumb on the outboard side of the handguard.The
left hand will not grasp the slip ring or magazine. The magazine must be on the inside of the left arm. l 
Hold the right elbow in a natural position. l 
Adjust the position of the left hand on the hand-
guard to allow the sling to support the weapon and
front sight to be centered in the rear sight aperture. To adjust for elevation:
l 
Move left hand rearward or forward on handguards
(moving the hand rearward elevates the muzzle). l 
Open or close the “V” of the left hand for small ad-
justments (closing the “V” elevates the muzzle). l 
Adjust the position to adjust sling tension. Moving
the left elbow out or squaring the body more to the
target tightens the sling. To adjust for a minor cant in the rifle, rotate the hand-
guard left or right in the “V” formed by the thumb and
forefinger by rotating the pistol grip left or right.

--- chunk_id: chunk-0159
source_document: MCRP3-01A.pdf
page: 62
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 29
content_hash: d8560f34551b2f3b
prev_chunk_id: chunk-0158
next_chunk_id: chunk-0160
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-56. Medium Kneeling Position.](images/p062_img00.jpeg)
*Figure 5-56. Medium Kneeling Position.*

![Figure 5-57. Low Kneeling Position.](images/p062_img01.jpeg)
*Figure 5-57. Low Kneeling Position.*

--- chunk_id: chunk-0160
source_document: MCRP3-01A.pdf
page: 63
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 321
content_hash: f59c8c1a538baa76
prev_chunk_id: chunk-0159
next_chunk_id: chunk-0161
document_type: technical_reference

Rifle Marksmanship____________________________________
Standing Position with the Parade Sling
The parade sling is used to emphasize marksmanship
fundamentals while firing from the standing position
on KD courses during entry-level training. To achieve
proper positioning of the parade sling, perform the fol-
lowing steps:
l Attach sling to rifle by placing feed end of sling
down through the upper sling swivel. l Place feed end of sling through sling keeper and
lock into place. l Attach J-hook to lower sling swivel. l Pull feed end of sling through sling keeper until
sling is taut. l Move sling keeper down near feed end of sling. l Lock sling keeper into place. Perform the following steps to assume the standing
position with a parade sling (figure 5-61):
l Stand erect. l Face approximately 90 degrees to the right of the
line of fire. l Place feet approximately shoulder width apart. Figure 5-58. Left View. Figure 5-59. F
Standing Position with the Hasty Sling

______________________________________________________ 5-19
p
n
e
-
g
d
l
g
e
l 
Place left hand under handguard. l 
Grasp pistol grip with right hand. l 
Place rifle butt into right shoulder pocket. l 
Invert left elbow across rib cage. l 
Rest left arm naturally against rib cage. l 
Lower right elbow to a natural position. l 
Place cheek firmly against stock to obtain a firm
stock weld. Figure 5-60. Right View. 9. Front View. Figure 5-61. Standing Position with
the Parade Sling.

--- chunk_id: chunk-0161
source_document: MCRP3-01A.pdf
page: 63
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 45
content_hash: a9a0adfc3d72d388
prev_chunk_id: chunk-0160
next_chunk_id: chunk-0162
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 5-58. Left View.](images/p063_img00.jpeg)
*Figure 5-58. Left View.*

![Figure 5-59. F](images/p063_img01.jpeg)
*Figure 5-59. F*

![Figure 5-60. Right View.](images/p063_img02.jpeg)
*Figure 5-60. Right View.*

![Figure 5-61. Standing Position with](images/p063_img03.jpeg)
*Figure 5-61. Standing Position with*

--- chunk_id: chunk-0162
source_document: MCRP3-01A.pdf
page: 64
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: a21959da1bbe5b2c
prev_chunk_id: chunk-0161
next_chunk_id: chunk-0163
section_heading: CHAPTER 6. USE OF COV
document_type: technical_reference

CHAPTER 6. USE OF COV
Note
+The procedures in this manual are written
for right-handed Marines; left-handed
Marines should reverse instructions as
necessary. 6001. Cover and Concealment
In a combat environment, a Marine must be prepared
to fire from any type of cover or concealment. Cover is
anything that protects a Marine from enemy fire. Cov-
er may be an existing hole, a hastily dug shelter, or a
well-prepared fighting position with overhead protec-
tion. Concealment is anything that hides a Marine
from enemy view, but it may not afford protection. Concealment can be obtained from buildings, trees,
crops, and skillful use of ground contours. A Marine
can use any object or terrain feature that protects him
from enemy fire, hides him from enemy view, allows
him to observe the enemy, and provides support for a
firing position. Types of Cover
Frontal Cover
A firing position should have frontal cover that pro-
vides protection from small arms fire and indirect fire
fragments. Ideally, frontal cover should be thick
enough to stop small arms fire, high enough to provide
protection from enemy fire, and wide enough to pro-
vide cover when firing to the left or right edge of a
sector of fire. Ideal Cover
The ideal cover provides:
l Overhead, flank, and rear protection from direct and
indirect fire. l Free use of personal weapons. l Concealment from enemy observation. l A concealed route in and out. l Unobstructed view of the sector of fire. COVER AND CONCEALMENT
d
s
-
a
-
e
,
e
m
s
a
-
e
k
e
-
a
d
Common Cover Materials
Any material that protects a Marine from small arms
fire can be used for cover. Some common materials in-
clude sandbags, trees, logs, and building debris. Table
6-1 presents some common materials and their mini-
mum thickness required for protection from small
arms fire. Table 6-1. Minimum Thickness
for Protection Against Small Arms. Sandbags 
Cover can be improved and positions can be fortified
by filling sandbags with dirt/sand and placing them
around the position. Sandbags should be tightly
packed because bullets can easily penetrate moist or
loosely packed sandbags. Overlapping sandbags in-
crease protection and decrease the bullet’s ability to
penetrate the sandbag. A minimum thickness of three
sandbags is required to stop small arms fire.

--- chunk_id: chunk-0163
source_document: MCRP3-01A.pdf
page: 64
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 198
content_hash: 98093f6988b296f9
prev_chunk_id: chunk-0162
next_chunk_id: chunk-0164
section_heading: CHAPTER 6. USE OF COV
document_type: technical_reference

Overlapping sandbags in-
crease protection and decrease the bullet’s ability to
penetrate the sandbag. A minimum thickness of three
sandbags is required to stop small arms fire. Trees/Logs
Wood is a relatively dense material and offers good
cover and protection. Bullets have a tendency to frag-
ment when they penetrate wood. Live trees have a
greater resistance to bullet penetration than dead trees. Wood that has been treated with creosote, such as tele-
phone poles and railroad ties, offers better protection
from projectiles than untreated wood, but it still does
not ensure protection from small arms fire. Cinder Bocks
Cinderblocks are not impenetrable cover. Although
they are made of a dense material, the composition of
a cinderblock is so brittle that a bullet can shatter the
Material
Minimum 
Thickness
(in inches)
Concrete
7
Broken stone (rubble)
20
Dry sand
24
Wet sand
35
Logs (oak)
40
Earth (packed)
48

--- chunk_id: chunk-0164
source_document: MCRP3-01A.pdf
page: 65
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 476
content_hash: 61449da6a91f843f
prev_chunk_id: chunk-0163
next_chunk_id: chunk-0165
document_type: technical_reference

6-2 ________________________________________________________
block upon impact. This can cause injury to a Marine
by secondary fragmentation. Firing From Specific Types of Cover
Effective cover allows a Marine to engage enemy tar-
gets while protecting himself from enemy fire. Several
types of cover provide support, protection, and con-
cealment and do not interfere with target engagement. A Marine must adapt firing positions to the type of
cover available. Fighting Hole
A Marine should use fighting holes if available. See
figure 6-1. After a Marine enters the fighting hole, he
adds or removes dirt, sandbags or other supports to fit
his height. To assume a firing position, a Marine per-
forms the following steps:
l 
Place the right foot to the rear as a brace. l 
Lean forward until the chest is against the forward
wall of the fighting hole. l 
Extend the left arm and elbow over the forward side
of the fighting hole so the left forearm rests against
the back of the parapet. l 
Place the rifle butt into the pocket of the right shoul-
der and grasp the pistol grip with the right hand. l 
Place the right elbow on solid support using the el-
bow rest of the fighting hole or sandbags placed
around the fighting hole. Rooftop
If possible, a Marine’s entire body should be posi-
tioned behind the apex of the rooftop, using the apex
to support the rifle. See figure 6-2. If the body cannot
be positioned behind the apex, place the left arm over
the apex of the roof to hold the weight of the body. Ex-
pose as little of the head and shoulders as possible. See
figure 6-3. Figure 6-1. Fighting Hole Position. ___________________________________________ MCRP 3-01A
Window
The Marine can establish a supported or unsupported
position from a window. Unsupported. A Marine can establish an unsupported
position back from the opening of the window so that
the muzzle does not protrude and interior shadows
provide concealment so as not to provide a silhouette
to the enemy. See figure 6-4. Figure 6-2. Rooftop Position Behind the Apex. Figure 6-3. Rooftop Position
Supported by the Apex. Figure 6-4. Unsupported Window Position.

--- chunk_id: chunk-0165
source_document: MCRP3-01A.pdf
page: 65
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 66
content_hash: 9a6557c86ed88e3c
prev_chunk_id: chunk-0164
next_chunk_id: chunk-0166
section_heading: Figures
document_type: technical_reference

## Figures

![figure 6-1. After a Marine enters the fighting hole, he](images/p065_img00.jpeg)
*figure 6-1. After a Marine enters the fighting hole, he*

![figure 6-3.](images/p065_img01.jpeg)
*figure 6-3.*

![Figure 6-1. Fighting Hole Position.](images/p065_img02.jpeg)
*Figure 6-1. Fighting Hole Position.*

![Figure 6-2. Rooftop Position Behind the Apex.](images/p065_img03.jpeg)
*Figure 6-2. Rooftop Position Behind the Apex.*

--- chunk_id: chunk-0166
source_document: MCRP3-01A.pdf
page: 66
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 356
content_hash: 3db93b4cfd0c30cc
prev_chunk_id: chunk-0165
next_chunk_id: chunk-0167
document_type: technical_reference

Rifle Marksmanship____________________________________
Supported. When additional stability is needed, a
Marine can establish a supported position by placing
the rifle handguards or his forearm in the “V” formed
by the side and bottom of the windowsill. A drawback
to this technique is that the muzzle of the weapon and
the Marine may be exposed to view. See figures 6-5
and 6-6. Vehicle
In many combat situations, particularly in urban envi-
ronments, a vehicle may be the best form of cover. When using a vehicle for cover, the engine block pro-
vides the most protection from small arms fire. The
Marine should establish a position behind the front
wheel so the engine block is between him and the tar-
get (see figs. 6-7 and 6-8). From this position, the
Marine may fire over, under or around the vehicle. This is a particularly effective position for larger vehi-
cles that are high off the ground. The Marine can establish additional support for the ri-
fle by positioning himself behind the doorjamb (frame
of door) and placing the rifle against the “V” formed
by the open door and doorframe (see figure 6-9). From
this position, the Marine may fire over the hood of the
vehicle while using the engine block for protection. Figure 6-5. Supported Window Position
(Handguards on Support). Figure 6-6. Supported Window Position
(Forearm on Support). ________________________________________________________ 6-3
a
g
d
k
d
5
-
-
e
t
-
e
-
-
e
d
m
e
Figure 6-7. Firing Around Front of Vehicle. Figure 6-8. Firing Over Front of Vehicle. Figure 6-9. Establishing a Supported
Position in a Vehicle.

--- chunk_id: chunk-0167
source_document: MCRP3-01A.pdf
page: 66
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 80
content_hash: 941f6dc7d195ac92
prev_chunk_id: chunk-0166
next_chunk_id: chunk-0168
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 6-5. Supported Window Position](images/p066_img00.jpeg)
*Figure 6-5. Supported Window Position*

![Figure 6-6. Supported Window Position](images/p066_img01.jpeg)
*Figure 6-6. Supported Window Position*

![Figure 6-7. Firing Around Front of Vehicle.](images/p066_img02.jpeg)
*Figure 6-7. Firing Around Front of Vehicle.*

![Figure 6-8. Firing Over Front of Vehicle.](images/p066_img03.jpeg)
*Figure 6-8. Firing Over Front of Vehicle.*

![Figure 6-9. Establishing a Supported](images/p066_img04.jpeg)
*Figure 6-9. Establishing a Supported*

--- chunk_id: chunk-0168
source_document: MCRP3-01A.pdf
page: 67
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 509
content_hash: c09d3486685b18c3
prev_chunk_id: chunk-0167
next_chunk_id: chunk-0169
document_type: technical_reference

6-4 ________________________________________________________
However, this position limits lateral mobility and it is
more difficult to maneuver from. At the back of the vehicle, only the axle and the wheel
provide cover. If the Marine must shoot from the back
of the vehicle, he must position himself directly be-
hind the wheel as much as possible (see fig. 6-10). 6002. Supported Firing Positions
Supports are foundations for positions; positions are
foundations for the rifle. To maximize the support the
position provides, the firing position should be adjusted
to fit or conform to the shape of the cover. Elements of
a sound firing position, such as balance and stability,
must be incorporated and adjusted to fit the situation
and type of cover. A supported firing position should
minimize exposure to the enemy, maximize the stabili-
ty of the rifle, and provide protection from enemy ob-
servation and fires. A Marine can use any available
support (e.g., logs, rocks, sandbags or walls) to stabilize
his firing position. The surrounding combat environ-
ment dictates the type of support and position used. Considerations Using Cover and 
Concealment
Cover and concealment considerations are similar, re-
gardless of the combat environment (e.g., urban,
desert, jungle). Figure 6-10. Using the Back of a Vehicle for Cover. ___________________________________________ MCRP 3-01A
Adjusting the Shooting Position
The type of cover can dictate which shooting position
(e.g., standing, kneeling, sitting, and prone) will be the
most effective. For example, a Marine’s height in rela-
tion to the height of the cover aids in the selection of a
firing position. The firing position selected should be adjusted to fit
the type of cover to:
l 
Provide stability. The position should be adjusted to
stabilize the rifle sights and allow the management
of recoil to recover on target. l 
Permit mobility. The position should be adjusted to
permit lateral engagement of dispersed targets and
movement to other cover. l 
Allow observation of the area/enemy while mini-
mizing exposure to the enemy. The firing position is adjusted to fit the type of cover
by adjusting the seven factors (i.e., left hand, pocket of
shoulder, right elbow, stock weld, grip of right hand)
to support the rifle or the position. Keeping the Entire Body Behind Cover
A Marine should minimize
exposure of any part of his
body to fire.

--- chunk_id: chunk-0169
source_document: MCRP3-01A.pdf
page: 67
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 174
content_hash: 3b2a797dbcfb983a
prev_chunk_id: chunk-0168
next_chunk_id: chunk-0170
document_type: technical_reference

The firing position is adjusted to fit the type of cover
by adjusting the seven factors (i.e., left hand, pocket of
shoulder, right elbow, stock weld, grip of right hand)
to support the rifle or the position. Keeping the Entire Body Behind Cover
A Marine should minimize
exposure of any part of his
body to fire. Be especially
aware of the head, right el-
bow, knees or any other
body part that may extend
beyond the cover. Firing From the Right
or Left Side of Cover
To minimize exposure and
maximize the cover’s pro-
tection, a right-handed Ma-
rine should fire from the
right side of cover and a
left-handed Marine should
fire from the left side, if
possible (see fig. 6-11). Figure 6-11. Firing 
from the Right
Side of Cover.

--- chunk_id: chunk-0170
source_document: MCRP3-01A.pdf
page: 67
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 37
content_hash: c2391e60ec9d369f
prev_chunk_id: chunk-0169
next_chunk_id: chunk-0171
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 6-10. Using the Back of a Vehicle for Cover.](images/p067_img00.jpeg)
*Figure 6-10. Using the Back of a Vehicle for Cover.*

![Figure 6-11. Firing](images/p067_img01.jpeg)
*Figure 6-11. Firing*

--- chunk_id: chunk-0171
source_document: MCRP3-01A.pdf
page: 68
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 325
content_hash: 9d079dad3a3fcd53
prev_chunk_id: chunk-0170
next_chunk_id: chunk-0172
document_type: technical_reference

Rifle Marksmanship________________________________________________________________________________________ 6-5
If, however, a right-handed
Marine must fire from the
left side of cover, he fires
right-handed but adjusts his
position behind cover and
uses the rollout technique
(see para. 6003) to engage
the target. See figure 6-12. Firing Over the Top of Cover
Firing over the top of cover provides a wider field of
view and lateral movement. When firing over the top
of cover, the position may be supported and stabilized
by resting the handguard or the left forearm on the
cover (see fig. 6-13). The Marine should keep as low a
profile as possible; the rifle should be as close to the
top of cover as possible. Maintaining Muzzle Awareness
When firing over the top of cover, a Marine must re-
member that the sights are higher than the barrel and
remain aware of the location of his muzzle. Therefore,
a Marine must maintain a position that ensures the
muzzle is high enough to clear the cover (e.g., window
sill, top of wall) as he obtains sight alignment/sight
picture on the target (see figs. 6-14a and 6-14b). Clearing the Ejection Port
Ensure the cover does not obstruct the ejection port. If
the ejection port is blocked, the obstruction can inter-
fere with the ejection of the spent cartridge case and
cause a stoppage. Figure 6-12. Firing 
from the Left
Side of Cover. Figure 6-13. Firing Over the Top of Cover. Figures 6-14a and 6-14b. Clearing
Cover with the Muzzle.

--- chunk_id: chunk-0172
source_document: MCRP3-01A.pdf
page: 68
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 61
content_hash: 9b025e744fc275bd
prev_chunk_id: chunk-0171
next_chunk_id: chunk-0173
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 6-12. Firing](images/p068_img00.jpeg)
*Figure 6-12. Firing*

![Figure 6-13. Firing Over the Top of Cover.](images/p068_img01.jpeg)
*Figure 6-13. Firing Over the Top of Cover.*

![Figure 6-12. Firing](images/p068_img02.jpeg)
*Figure 6-12. Firing*

![Figure 6-13. Firing Over the Top of Cover.](images/p068_img03.jpeg)
*Figure 6-13. Firing Over the Top of Cover.*

--- chunk_id: chunk-0173
source_document: MCRP3-01A.pdf
page: 69
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 362
content_hash: d9e292fcad13a5dd
prev_chunk_id: chunk-0172
next_chunk_id: chunk-0174
document_type: technical_reference

6-6 ________________________________________________________
Resting the Magazine
The bottom, front or side of the rifle magazine can rest
on or against support to provide additional stability
(see figs. 6-15, 6-16, and 6-17). CAUTION
The back of the magazine should not be
pulled back against support because it can
cause a stoppage by not allowing a round to
feed from the magazine. Seven Factors
The seven factors (left hand, rifle in shoulder pocket,
stock weld, right elbow, grip of the right hand,
breathing, muscular tension) are applied when firing
from cover, however, some may have to be modified
Figure 6-16. Front of Magazine on Support. Figure 6-15. Bottom of M

___________________________________________ MCRP 3-01A
slightly to accommodate the artificial support provid-
ed the rifle and position. Left Hand
The support should be used to help stabilize both the
firing position and the rifle to enable the Marine to
maintain sight alignment and sight picture. The forearm or left hand can contact the support to sta-
bilize the weapon. Rest the forearm or the meaty por-
tion of the bottom of the left hand on the support and
rest the rifle in the “V” formed by the thumb and fore-
finger of the left hand (see fig. 6-18). The rifle’s handguards may rest on the support, but the
barrel may not (see fig. 6-19). Placement of left hand
on the handguard may have to be adjusted forward or
back to accommodate the cover and the additional
support provided by the rifle resting on the cover. If
the handguards are resting on the cover, the left hand
Figure 6-17. Side of Magazine on Support. f Magazine on Support.

--- chunk_id: chunk-0174
source_document: MCRP3-01A.pdf
page: 69
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 53
content_hash: 178710e58ddf455c
prev_chunk_id: chunk-0173
next_chunk_id: chunk-0175
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 6-16. Front of Magazine on Support.](images/p069_img00.jpeg)
*Figure 6-16. Front of Magazine on Support.*

![Figure 6-15. Bottom of M](images/p069_img01.jpeg)
*Figure 6-15. Bottom of M*

![Figure 6-17. Side of Magazine on Support.](images/p069_img02.jpeg)
*Figure 6-17. Side of Magazine on Support.*

--- chunk_id: chunk-0175
source_document: MCRP3-01A.pdf
page: 70
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 368
content_hash: 416a5e339782ccfd
prev_chunk_id: chunk-0174
next_chunk_id: chunk-0176
document_type: technical_reference

Rifle Marksmanship____________________________________
can pull down on the handguards to further stabilize
the weapon. Rifle in Shoulder Pocket
Regardless of the combat situation or the height of the
cover, the rifle butt must remain in the shoulder pocket
to manage the effects of recoil, stabilize the rifle, and
maintain the rifle’s battlesight zero. The firing position
must be adjusted behind cover to enable the rifle to be
placed in the shoulder. Stock Weld
Regardless of the cover, the firing position must be ad-
justed to allow stock weld to be achieved. Proper stock
weld provides quick recovery between shots and keeps
the aiming eye centered in the rear sight aperture. Right Elbow
The right elbow can be placed on or against the sup-
port to stabilize the weapon and the position. Ensure
Figure 6-18. Forearm
Figure 6-19. Handguards Resting on Cover. ________________________________________________________ 6-7
e
e
t
d
n
e
-
k
s
-
e
the elbow is not extended beyond cover revealing the
position to the enemy. Grip of the Right Hand
If rifle handguards, forward hand, or forearm rest on
cover for support, the grip of the right hand should pull
back and down on the pistol grip to further stabilize
the weapon in the shoulder and on the support. Breathing
Breathing does not change when firing from a support-
ed position. Muscular Tension
To create balance and support for the position, the
Marine may shift his body weight into or against the
support (see fig. 6-20). This enables the Marine to use
cover to support his body weight, reducing the need
for muscular tension. rm Resting on Cover. Figure 6-20. Shifting Body Weight into Cover.

--- chunk_id: chunk-0176
source_document: MCRP3-01A.pdf
page: 70
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 45
content_hash: b3b389e7acdec007
prev_chunk_id: chunk-0175
next_chunk_id: chunk-0177
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 6-18. Forearm](images/p070_img00.jpeg)
*Figure 6-18. Forearm*

![Figure 6-19. Handguards Resting on Cover.](images/p070_img01.jpeg)
*Figure 6-19. Handguards Resting on Cover.*

![Figure 6-20. Shifting Body Weight into Cover.](images/p070_img02.jpeg)
*Figure 6-20. Shifting Body Weight into Cover.*

--- chunk_id: chunk-0177
source_document: MCRP3-01A.pdf
page: 71
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 512
content_hash: 245a008b56201537
prev_chunk_id: chunk-0176
next_chunk_id: chunk-0178
document_type: technical_reference

6-8 ________________________________________________________
Types of Supported Positions
Supported Prone
If possible, a Marine should use the supported prone
position when firing from behind cover. This position
is the steadiest, provides the lowest silhouette, and
provides maximum protection from enemy fire. l 
Support the position by placing the handguards, the
forearm, or the magazine on or against support (see
fig. 6-21). l 
The prone position can be assumed behind a tree, a
wall, a log, or almost any type of cover. It is flexible
and allows shooting from all sides of cover and
from cover of various sizes. l 
The body must be adjusted to conform to the cover. For example, if the cover is narrow, keep the legs
together. The body should be in line with the rifle
Figure 6-21. Supported Prone. Figure 6-22. Supported Prone Behind
Narrow Cover—Rear View. ___________________________________________ MCRP 3-01A
and directly behind the rifle (see figs. 6-22 and
6-23). This presents a smaller target to the enemy
and provides more body mass to absorb recoil. Supported Kneeling
When the prone position cannot be used because of the
height of the support, the supported kneeling position
may be appropriate. The kneeling position provides
additional mobility over the prone position. l 
The kneeling position allows shooting from all
sides and from cover of varying sizes. This position
may be altered to maximize the use of cover or sup-
port by assuming a variation of the kneeling posi-
tion (high, medium or low). l 
In the kneeling position, the Marine must not tele-
graph his position behind the cover with his knee. When shooting around the sides of cover, the
Marine should strive to keep his right knee in line
with his left foot so as not to reveal the position to
the enemy. See figure 6-24. l 
Support the position by placing the handguards, the
forearm, or the magazine on or against support. In
addition, the position (e.g., a knee, the side of the
body) may rest against support (see fig. 6-25). l 
If the rifle is resting on support, the Marine may not
need to stabilize the weapon by placing his left el-
bow on his knee (see fig. 6-26). Supported Sitting
A supported sitting position may be used to fire over the
top of cover when mobility is not as critical.

--- chunk_id: chunk-0178
source_document: MCRP3-01A.pdf
page: 71
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 84
content_hash: 5706a51a36e259a3
prev_chunk_id: chunk-0177
next_chunk_id: chunk-0179
document_type: technical_reference

6-26). Supported Sitting
A supported sitting position may be used to fire over the
top of cover when mobility is not as critical. A sitting
position can be comfortably assumed for a longer peri-
od of time than a kneeling position and it can conform
to higher cover when a prone position cannot be used. Figure 6-23. Supported Prone Behind
Narrow Cover—Front View.

--- chunk_id: chunk-0179
source_document: MCRP3-01A.pdf
page: 71
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 32
content_hash: e2b661fe6a97c1d7
prev_chunk_id: chunk-0178
next_chunk_id: chunk-0180
section_heading: Figures
document_type: technical_reference

## Figures

![fig. 6-21).](images/p071_img00.jpeg)
*fig. 6-21).*

![Figure 6-21. Supported Prone.](images/p071_img01.jpeg)
*Figure 6-21. Supported Prone.*

![Figure 6-22. Supported Prone Behind](images/p071_img02.jpeg)
*Figure 6-22. Supported Prone Behind*

--- chunk_id: chunk-0180
source_document: MCRP3-01A.pdf
page: 72
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 220
content_hash: 9dc1b2e4ed69c184
prev_chunk_id: chunk-0179
next_chunk_id: chunk-0181
document_type: technical_reference

Rifle Marksmanship____________________________________
l Support the position by placing the handguards, the
forearm, or the magazine on or against support (see
fig. 6-27). l If the rifle is resting on support, the Marine may not
need to stabilize the weapon by placing his left or
right elbows on his legs (see fig. 6-28). Supported Standing
The supported standing position provides greater mo-
bility than the other positions and usually provides
greater observation of the enemy. The supported
standing position is effectively used behind high cover
(e.g., window, over a wall) or narrow cover (e.g., tree,
telephone pole). l To assume the supported standing position, the
Marine leans his body forward or against support to
stabilize the weapon and the position. Figure 6-25. Supported Kneeling with Body 
Against Support. Figure 6-24. Supported Kneeling. ________________________________________________________ 6-9
e
e
t
r
-
s
d
r
,
e
o
Figure 6-26. Supported Kneeling with
Rifle Resting on Support. Figure 6-27. Supported Sitting. Figure 6-28. Supported Sitting with
Rifle on Support.

--- chunk_id: chunk-0181
source_document: MCRP3-01A.pdf
page: 72
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 58
content_hash: 4225d83c2c5aa5b5
prev_chunk_id: chunk-0180
next_chunk_id: chunk-0182
section_heading: Figures
document_type: technical_reference

## Figures

![fig. 6-27).](images/p072_img00.jpeg)
*fig. 6-27).*

![Figure 6-25. Supported Kneeling with Body](images/p072_img01.jpeg)
*Figure 6-25. Supported Kneeling with Body*

![Figure 6-24. Supported Kneeling.](images/p072_img02.jpeg)
*Figure 6-24. Supported Kneeling.*

![Figure 6-26. Supported Kneeling with](images/p072_img03.jpeg)
*Figure 6-26. Supported Kneeling with*

![Figure 6-27. Supported Sitting.](images/p072_img04.jpeg)
*Figure 6-27. Supported Sitting.*

--- chunk_id: chunk-0182
source_document: MCRP3-01A.pdf
page: 73
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 505
content_hash: af2e4cb81caf7d14
prev_chunk_id: chunk-0181
next_chunk_id: chunk-0183
document_type: technical_reference

6-10 _______________________________________________________
l 
Support the position by placing the handguards, the
forearm, or the magazine on or against support. In
addition, the position (e.g., the side of the body)
may rest against support (see fig. 6-29). 6003. Searching for and Engaging 
Targets From Behind Cover
To locate targets when behind cover or to ensure the
area is clear before moving, the Marine must expose as
little of himself as possible to the enemy. Additionally,
the Marine must be ready to fire if a target is located. Two techniques that can be used to locate and engage
targets from behind cover are: the pie and rollout. These techniques minimize the Marine’s exposure to
enemy fire while placing the Marine in a position to
engage targets or to move to another location if neces-
sary. These techniques are also used to enter a building
or structure. Both techniques are used in the kneeling
and standing positions. To be accurate in engaging tar-
gets using either technique, the seven factors must be
applied. See page 6-6 for a discussion of seven factors. Pie Technique 
To perform the pie technique:
l 
Staying behind cover, move back and away from the
leading edge of the cover. The surroundings and
situation will dictate the distance you should move
back and away from the cover. Generally, the further
back the Marine is from cover, the greater his area of
observation; staying too close to cover decreases the
area of observation. However, if the Marine is too
Figure 6-29. Supported Standing. ___________________________________________ MCRP 3-01A
far back from the leading edge of cover, he may
unknowingly expose himself to the enemy. l 
Assume a firing position and lower the rifle sights
enough to have a clear field of view, orienting the
muzzle on the leading edge of the cover. (In a build-
ing, the baseboards serve as a reference point for
the muzzle of the rifle when searching for targets.)
l 
Taking small side steps, slowly move out from be-
hind the cover, covering the field of view with the
aiming eye and muzzle of the weapon. Wherever
the eyes move, the muzzle should move (eyes, muz-
zle, target). The muzzle should remain on the lead-
ing edge of cover, serving as a pivot point when
moving out.

--- chunk_id: chunk-0183
source_document: MCRP3-01A.pdf
page: 73
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 398
content_hash: b5be0e1300deea78
prev_chunk_id: chunk-0182
next_chunk_id: chunk-0184
document_type: technical_reference

Wherever
the eyes move, the muzzle should move (eyes, muz-
zle, target). The muzzle should remain on the lead-
ing edge of cover, serving as a pivot point when
moving out. l 
Continue taking small side steps and moving out
from cover until a target is identified or the area is
found to be clear. l 
When a target is identified, sweep the safety, place
the finger on the trigger, and engage the target. Rollout Technique
To perform the rollout technique:
l 
Staying behind cover, move back and position the
body so it is in line with the leading edge of the
cover, ensuring that no part of the body extends be-
yond the cover. l 
Assume a firing position and come to the Ready,
ensuring the muzzle is just behind the cover. l 
Canting the head and weapon slightly, roll the up-
per body out to the side just enough to have a clear
field of view and allow the muzzle to clear the cov-
er. Keeping the feet in place, push up on the ball of
one foot to facilitate rolling out. l 
Continue rolling out from cover until a target is
identified or the area is found to be clear. l 
When a target is identified, sweep the safety, place
the finger on the trigger, and engage the target. l 
If a target is identified before moving out from cov-
er, the rifle should be taken off safe before moving
out using the rollout technique. Combining Techniques
In some situations, it may be necessary to combine the
pie and rollout techniques to search an entire area for
targets (e.g., corner of a building, a doorway). Chang-
ing from one technique to another may permit the
Marine to minimize his exposure to enemy observa-
tion and fires.

--- chunk_id: chunk-0184
source_document: MCRP3-01A.pdf
page: 73
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 13
content_hash: d49304e281f6872a
prev_chunk_id: chunk-0183
next_chunk_id: chunk-0185
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 6-29. Supported Standing.](images/p073_img00.jpeg)
*Figure 6-29. Supported Standing.*

--- chunk_id: chunk-0185
source_document: MCRP3-01A.pdf
page: 74
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 169
content_hash: dfbf1e66d5fb141f
prev_chunk_id: chunk-0184
next_chunk_id: chunk-0186
section_heading: 6004. Moving Out From Behind Cover
document_type: technical_reference

Rifle Marksmanship______________________________________________________________________________________ 6-11
6004. Moving Out From Behind Cover
A Marine must be constantly aware of his surround-
ings and available cover, should a threat appear. He
should avoid obvious danger areas and move quickly
through danger areas that cannot be avoided. When moving from cover to cover, the Marine should
select the next covered location and plan his route be-
fore moving from his present position. This is done by
quickly looking from behind cover to ensure the area
is clear, ensuring the head and eyes are exposed for as
short a time as possible. If necessary, the Marine should conduct a Condition 1
reload before moving from cover. Once the Marine is committed to moving, all focus
should be on moving until cover is reassumed.

--- chunk_id: chunk-0186
source_document: MCRP3-01A.pdf
page: 75
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: dc4c9856dfd43df2
prev_chunk_id: chunk-0185
next_chunk_id: chunk-0187
section_heading: CHAPTER 7. RIFLE PRESENTATION
document_type: technical_reference

CHAPTER 7. RIFLE PRESENTATION
Note
+The procedures in this manual are
written for right-handed Marines; left-
handed Marines should reverse instructions
as necessary. 7001. Presentation of the Rifle
In a combat environment, targets may present them-
selves with little or no warning. To maintain an advan-
tage, the Marine carries his weapon in a position
appropriate to the threat level that permits the rifle to
be both easily carried and presented as quickly as pos-
sible. A carry is also established based on the situation
such as moving in a close quarter environment, mov-
ing over or under objects, etc. Presenting the Rifle From the Tactical 
Carry
The Marine uses the Tactical Carry when no immedi-
ate threat is present. This carry permits the rifle to be
easily carried for long periods of time, but it does not
permit the quickest presentation to a target. If the situ-
ation changes and a target presents itself, a Marine
performs the following steps to present the rifle from
the Tactical Carry once a target appears:
l Extend the rifle toward the target keeping the muz-
zle slightly up so the buttstock clears all personal
equipment. Continue
to look at the target. l At the same time,
place the rifle in Con-
dition 1. Two meth-
ods can be used to
place rifle in Condi-
tion 1 if it is in Con-
dition 3:
n  Grip the pistol grip
firmly with the
right hand. Pull the
charging handle
with the left hand
to its rearmost po-
sition and release
(see fig. 7-1). n  Grip the handguards firmly with the left hand. Pull the charging handle with the right hand to its
rearmost position and release (see fig. 7-2). l As the rifle is being presented, take the rifle off safe
and place the trigger finger on the trigger (see figs. 7-3a, 7-3b, and 7-3c on page 7-2). l Level the rifle while pulling it firmly into the pocket
of the shoulder to obtain proper stock weld. Do not
move the head down to meet the stock of the rifle. Note
If the rifle is in the shoulder properly, the
aiming eye will be able to look through the
rear sight as soon as the stock makes
contact with the cheek.

--- chunk_id: chunk-0187
source_document: MCRP3-01A.pdf
page: 75
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 217
content_hash: 1497c61aef871581
prev_chunk_id: chunk-0186
next_chunk_id: chunk-0188
section_heading: CHAPTER 7. RIFLE PRESENTATION
document_type: technical_reference

Do not
move the head down to meet the stock of the rifle. Note
If the rifle is in the shoulder properly, the
aiming eye will be able to look through the
rear sight as soon as the stock makes
contact with the cheek. l As the sights become level with the aiming eye, vi-
sually locate the target through the rear sight aper-
ture. As the rifle sights settle, shift the focus back to
the front sight post to obtain sight alignment, and
place the tip of the post center mass on the target to
obtain sight picture. Presenting the Rifle From the Alert Carry 
and From the Ready Carry
The Marine uses the Alert Carry when enemy contact
is likely. The Alert is also used for moving in close ter-
rain (e.g., urban, jungle). The Marine uses the Ready Carry when enemy contact
is imminent. Figure 7-1. Pulling
Charging Handle
with Left Hand. Figure 7-2. Pulling Charging Handle
with Right Hand.

--- chunk_id: chunk-0188
source_document: MCRP3-01A.pdf
page: 75
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 24
content_hash: 506699260c51de9d
prev_chunk_id: chunk-0187
next_chunk_id: chunk-0189
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 7-1. Pulling](images/p075_img00.jpeg)
*Figure 7-1. Pulling*

![Figure 7-2. Pulling Charging Handle](images/p075_img01.jpeg)
*Figure 7-2. Pulling Charging Handle*

--- chunk_id: chunk-0189
source_document: MCRP3-01A.pdf
page: 76
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: 61f3f89c6e62a6d6
prev_chunk_id: chunk-0188
next_chunk_id: chunk-0190
document_type: technical_reference

7-2 _______________________________________________________________________________________________ MCRP 3-01A
To present the rifle from the Alert and from the Ready,
a Marine performs the following steps once a target
appears:
l While looking at the target, bring the muzzle up by
raising the left hand, allowing the rifle butt to pivot
in the shoulder. At the same time, pull the rifle firm-
ly into the pocket of the shoulder. l As the rifle is being presented, take the rifle off safe
and place the trigger finger on the trigger (see figs. 7-3a, 7-3b, and 7-3c). l As the stock makes contact with the cheek, level the
rifle to obtain proper stock weld. l Do not move the head down to meet rifle stock. Note
If the rifle is in the shoulder properly, the
aiming eye will be able to look through the
rear sight as soon as the stock makes con-
tact with the cheek. l As the sights become level with the aiming eye, vi-
sually locate the target through the rear sight aper-
ture. As the rifle sights settle, shift the focus back to
the front sight post to obtain sight alignment, and
place the tip of the post center mass on the target to
obtain sight picture. Presenting the Rifle From the Strong Side 
Sling Arms Transport
Once a target appears, a Marine performs the follow-
ing to present the rifle from Strong Side Sling Arms:
l While looking at the tar-
get, lean forward slight-
ly to facilitate removal
of the rifle from the
shoulder. l Reach under the right
arm with the left hand
between the sling and
the body and grasp the
handguards. See figure
7-4). At the same time,
pull down on the sling
and raise right elbow
out and parallel to the
deck. l Roll the right shoulder
forward and release the
sling from the right
hand once the hand-
guards have cleared the elbow. At the same time,
pull rifle forward off the shoulder with left hand. l Continue pulling the rifle forward with the left hand
while rotating the rifle parallel to the deck; when
the right arm is free of the sling and the rifle clears
all personal gear, grasp the charging handle with the
right hand (see fig. 7-5) and pull it to its rearmost
position and release.

--- chunk_id: chunk-0190
source_document: MCRP3-01A.pdf
page: 76
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 180
content_hash: e61e6479158f2c5e
prev_chunk_id: chunk-0189
next_chunk_id: chunk-0191
document_type: technical_reference

l Continue pulling the rifle forward with the left hand
while rotating the rifle parallel to the deck; when
the right arm is free of the sling and the rifle clears
all personal gear, grasp the charging handle with the
right hand (see fig. 7-5) and pull it to its rearmost
position and release. l Establish a firing grip with right hand while keeping
the trigger finger straight along the receiver. l Take rifle off safe and place the trigger finger on the
trigger (see figs. 7-3a, 7-3b, and 7-3c). l Level the rifle while pulling it firmly into the pocket
of the shoulder to obtain proper stock weld. Do not
move the head down to meet the stock of the rifle. Figures 7-3a, 7-3b, and 7-3c. Sweeping the Safety. Figure 7-4. Grasping 
the Handguards.

--- chunk_id: chunk-0191
source_document: MCRP3-01A.pdf
page: 76
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 45
content_hash: f101cde902c74a0f
prev_chunk_id: chunk-0190
next_chunk_id: chunk-0192
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 7-4. Grasping](images/p076_img00.jpeg)
*Figure 7-4. Grasping*

![fig. 7-5) and pull it to its rearmost](images/p076_img01.jpeg)
*fig. 7-5) and pull it to its rearmost*

![Figure 7-4. Grasping](images/p076_img02.jpeg)
*Figure 7-4. Grasping*

![Figure from page 76](images/p076_img03.jpeg)

--- chunk_id: chunk-0192
source_document: MCRP3-01A.pdf
page: 77
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 477
content_hash: 9624ef4f12a73431
prev_chunk_id: chunk-0191
next_chunk_id: chunk-0193
document_type: technical_reference

Rifle Marksmanship ________________________________________________________________________________________ 7-3
Note
If the rifle is in the shoulder properly, the
aiming eye will be able to look through the
rear sight as soon as the stock makes
contact with the cheek. l As the sights become level with the aiming eye, vi-
sually locate the target through the rear sight aper-
ture. As the rifle sights settle, shift the focus back to
the front sight post to obtain sight alignment, and
place the tip of the post center mass on the target to
obtain sight picture. Presenting the Rifle From the Weak Side 
Sling Arms Transport
The hasty sling should be maintained while presenting
the rifle from this transport. To present the rifle from
Weak Side Sling Arms, a Marine performs the follow-
ing steps once a target appears:
l While looking at the target, lean forward slightly to
facilitate removal of rifle from the shoulder. l Grasp the sling with the right hand to prevent the
rifle from falling off the shoulder. l Grasp handguards with left hand
(the index finger points toward
the muzzle). See figure 7-6. l Rotate the rifle counterclockwise
while extending the muzzle to-
ward the target. l Continue extending the rifle to-
ward the target to ensure the rifle
clears all personal gear. l Grasp the charging handle with
the right hand and pull it to its
rearmost position and release
(see fig. 7-7). l Establish a firing grip with right
hand while keeping the trigger
finger straight along the receiver. l Take the rifle off safe and place
the trigger finger on the trigger (see figures 7-3a, 7-
3b, and 7-3c). l Level the rifle while pulling it firmly into the pocket
of the shoulder to obtain proper stock weld. Do not
move the head down to meet the stock of the rifle. Note
If the rifle is in the shoulder properly, the
aiming eye will be able to look through the
rear sight as soon as the stock makes
contact with the cheek. Figure 7-5. Clearing Gear and Grasping the 
Charging Handle. Figure 7-6. Grasping the 
Handguards. Figure 7-7. Clearing Gear and Grasping the 
Charging Handle.

--- chunk_id: chunk-0193
source_document: MCRP3-01A.pdf
page: 77
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 45
content_hash: 796141ca883d147a
prev_chunk_id: chunk-0192
next_chunk_id: chunk-0194
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 7-5. Clearing Gear and Grasping the](images/p077_img00.jpeg)
*Figure 7-5. Clearing Gear and Grasping the*

![Figure 7-6.](images/p077_img01.jpeg)
*Figure 7-6.*

![Figure 7-7. Clearing Gear and Grasping the](images/p077_img02.jpeg)
*Figure 7-7. Clearing Gear and Grasping the*

--- chunk_id: chunk-0194
source_document: MCRP3-01A.pdf
page: 78
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: 9fcf1fb1f8002deb
prev_chunk_id: chunk-0193
next_chunk_id: chunk-0195
document_type: technical_reference

7-4 ________________________________________________________
l As the sights become level with the aiming eye, vi-
sually locate the target through the rear sight aper-
ture. As the rifle sights settle, shift the focus back to
the front sight post to obtain sight alignment, and
place the tip of the post center mass on the target to
obtain sight picture. 7002. Search and Assess
After a Marine engages a target, he must immediately
search the area and assess the results of his engage-
ment. Searching and assessing enables the Marine to
avoid tunnel vision that can restrict the focus so that an
indication of other targets is overlooked. Purpose
The Marine searches the area for additional targets or
for cover. The Marine assesses the situation to deter-
mine if he needs to re-engage a target, engage a new
target, take cover, assume a more stable position,
cease engagement, etc. Technique
To search and assess, a Marine performs the following
steps:
l Keeping the buttstock in the shoulder, lower the
muzzle of the rifle slightly to look over the sights. l Place the trigger finger straight along the receiver
(see fig. 7-8). l Search the area and assess the situation/threat by
moving the head, eyes, and rifle left and right (ap-
proximately 45 degrees from center) to cover the
immediate area. The muzzle moves with the head
and eyes in one fluid motion while searching. Keep
both eyes open to increase the field of view. Figure 7-8. Straight Trigger Finger. ___________________________________________ MCRP 3-01A
l Once a Marine determines the area is clear of ene-
my threat, he places the rifle on safe. Searching and Assessing to a Higher 
Profile
Depending on the tactical situation, the Marine may
choose to increase his area of observation by searching
and assessing to a higher profile position. Prone to Kneeling
After searching and assessing at the prone position,
move to a kneeling position by performing the follow-
ing steps:
l While maintaining control of the pistol grip, lower
the rifle butt out of the shoulder. l Drop the left hand to the deck and, bringing it back,
push up off the deck to both knees (see figs. 7-9a
and 7-9b). l Grasp the handguard with the left hand and place
the rifle butt in the pocket of the shoulder.

--- chunk_id: chunk-0195
source_document: MCRP3-01A.pdf
page: 78
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 112
content_hash: a5dd03fe30e1a8eb
prev_chunk_id: chunk-0194
next_chunk_id: chunk-0196
document_type: technical_reference

7-9a
and 7-9b). l Grasp the handguard with the left hand and place
the rifle butt in the pocket of the shoulder. l Assume a kneeling position and search and assess
(see fig. 7-10). Sitting to Kneeling
After searching and assessing at the sitting position,
move to a kneeling position by performing the follow-
ing steps:
l Maintain control of the rifle with the rifle butt in the
pocket of the shoulder. Figures 7-9a and 7-9b. Pushing Up Off 
the Deck to Both Knees.

--- chunk_id: chunk-0196
source_document: MCRP3-01A.pdf
page: 78
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 34
content_hash: d31762441b3061ee
prev_chunk_id: chunk-0195
next_chunk_id: chunk-0197
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 7-8. Straight Trigger Finger.](images/p078_img00.jpeg)
*Figure 7-8. Straight Trigger Finger.*

![Figure 7-8. Straight Trigger Finger.](images/p078_img01.jpeg)
*Figure 7-8. Straight Trigger Finger.*

![fig. 7-10).](images/p078_img02.jpeg)
*fig. 7-10).*

--- chunk_id: chunk-0197
source_document: MCRP3-01A.pdf
page: 79
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 189
content_hash: 433b9c0e2c3a14fd
prev_chunk_id: chunk-0196
next_chunk_id: chunk-0198
document_type: technical_reference

Rifle Marksmanship ________________________________________________________________________________________ 7-5
l Uncross the legs to an open leg position. l Tuck the right foot underneath the left thigh, as
close to the buttocks as possible (see fig. 7-11). l Lean forward and to the right and roll on to the right
knee to a kneeling position and search and assess
(see fig. 7-12). Note
It may be necessary to release the rifle with
the right hand and push off the deck with
the right hand to assist in rolling up to a
kneeling position. Kneeling to Standing
After searching and assessing at the kneeling position,
maintain control of the rifle with the rifle butt in the
pocket of the shoulder, and stand while continuing to
search and assess. Figure 7-12. Rolling Up to a Kneeling Position. Figure 7-11. Tucking the Right Foot. Figure 7-10. Kneeling Search and Assess.

--- chunk_id: chunk-0198
source_document: MCRP3-01A.pdf
page: 79
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 56
content_hash: 4ec1f17fce38e107
prev_chunk_id: chunk-0197
next_chunk_id: chunk-0199
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 7-12. Rolling Up to a Kneeling Position.](images/p079_img00.jpeg)
*Figure 7-12. Rolling Up to a Kneeling Position.*

![Figure 7-11. Tucking the Right Foot.](images/p079_img01.jpeg)
*Figure 7-11. Tucking the Right Foot.*

![Figure 7-10. Kneeling Search and Assess.](images/p079_img02.jpeg)
*Figure 7-10. Kneeling Search and Assess.*

--- chunk_id: chunk-0199
source_document: MCRP3-01A.pdf
page: 80
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 516
content_hash: af3d3859cc85ed57
prev_chunk_id: chunk-0198
next_chunk_id: chunk-0200
section_heading: CHAPTER 8. EFFE
document_type: technical_reference

CHAPTER 8. EFFE
Wind, temperature, and precipitation can
dition, all weather conditions have a 
Marines. Marines must use techniques to
ature, and precipitation (snow, sleet, and
can develop the confidence required to re
fects of weather during combat situations
8001. Physical Effects of Wind on the 
Bullet
Physical Effects
The weather condition that presents the greatest prob-
lem to shooting is the wind. Wind affects a bullet's tra-
jectory. The effect of wind on the bullet as it travels
down range is referred to as deflection. The wind de-
flects the bullet laterally in its flight to the target (see
fig. 8-1). The bullet’s exposure time to the wind determines the
amount the bullet is deflected from its original trajec-
tory. Deflection increases as the distance to the target
increases. There are three factors that affect the
amount of deflection of the bullet: 
l Velocity of the wind—The greater the velocity of
the wind, the more the bullet will be deflected. l Range to the target—As the distance to the target
increases, the speed of the bullet slows allowing the
wind to have a greater effect on shot placement. Figure 8-1. Deflection of a Bullet. FECTS OF WEATHER
can affect the trajectory of the bullet. In ad-
e a physical and psychological effect on
s to offset the effects of wind, light, temper-
and rain). Through proper training, Marines
o reduce the physical and psychological ef-
ons. t
l Velocity of the bullet—A bullet with a high muzzle
velocity will not be affected by the wind as much as
a bullet with a low muzzle velocity. Determining Windage Adjustments to 
Offset Wind Effects 
The velocity and direction of the wind in relationship
to the bullet must be determined to offset the wind’s
effects. If Marines can classify wind values and deter-
mine velocity within 5 mph, they can effectively en-
gage targets in windy conditions. Wind Direction
Determine wind direction by observing direction veg-
etation is moving, by feeling the wind blow against the
body, or by observing direction of a flag (in training). Wind Value Classifications
Winds are classified according to the direction from
which they are blowing in relation to the direction of
fire. The clock system indicates wind direction and
value (see fig. 8-2). Winds can be classified as half
Figure 8-2. Clock System.

--- chunk_id: chunk-0200
source_document: MCRP3-01A.pdf
page: 80
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 24
content_hash: 84ae8eca6b0bc49e
prev_chunk_id: chunk-0199
next_chunk_id: chunk-0201
section_heading: Figures
document_type: technical_reference

## Figures

![fig. 8-1).](images/p080_img00.jpeg)
*fig. 8-1).*

![Figure 8-1. Deflection of a Bullet.](images/p080_img01.jpeg)
*Figure 8-1. Deflection of a Bullet.*

--- chunk_id: chunk-0201
source_document: MCRP3-01A.pdf
page: 81
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 473
content_hash: 2b648647143ca6bb
prev_chunk_id: chunk-0200
next_chunk_id: chunk-0202
document_type: technical_reference

8-2 ________________________________________________________
value, full value, or no value. The target is always lo-
cated at 12 o’clock. Wind Velocity
There are two methods used to determine wind veloci-
ty: observation and flag. The flag method is used as a
training tool on the known distance (KD) range to
learn the observation method. This method teaches
Marines to relate the effect a given wind condition has
on the natural surroundings in order to develop the
base of knowledge used during the observation meth-
od. The observation method is the primary method
used to estimate wind velocity and direction in a tacti-
cal situation. The following are guidelines used during
the observation method:
l Under 3 miles per hour (mph) the wind can hardly
be felt on the face. The presence of a slight wind
can be detected by drifting smoke. l 3 to 5 mph winds can be felt lightly on the face. l 5 to 8 mph winds keep tree leaves in a constant mo-
tion. l 8 to 12 mph winds raise dust and loose paper. l 12 to 15 mph winds cause small trees to sway. l 16 to 25 mph winds cause large trees to sway. Flag Method
The flag method is primary method used on the KD
range. To estimate wind velocity in miles per hour:
Estimate the angle created between the flagpole and
the flag in degrees. l Divide the angle by four to estimate wind velocity
in miles per hour. See figure 8-3. r
b
p
h
b
p
b
Figure 8-3. Flag Method. ___________________________________________ MCRP 3-01A
Note
Information given is based on a dry flag. A
wet flag is heavy and gives a false reading. Windage Adjustments
After identifying wind direction, wind classification,
and wind velocity, windage adjustments needed to en-
able the bullet to strike the target are estimated in the
following ways:
Observation Method. Using the windage chart pro-
vided in figure 8-4, match the wind velocity, wind di-
rection, and range to the target to the information in
the chart to estimate the correct number of clicks to
apply to the windage knob. Flag Method.

--- chunk_id: chunk-0202
source_document: MCRP3-01A.pdf
page: 81
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 342
content_hash: 340f1f152fd37f0d
prev_chunk_id: chunk-0201
next_chunk_id: chunk-0203
document_type: technical_reference

Using the windage chart pro-
vided in figure 8-4, match the wind velocity, wind di-
rection, and range to the target to the information in
the chart to estimate the correct number of clicks to
apply to the windage knob. Flag Method. Using the windage chart provided in
figure 8-5, match the wind velocity, wind direction,
and range to the target to the information in the chart
to determine the correct number of clicks to apply to
the windage knob. Once the number of windage clicks is determined, turn
the windage knob causing the rear sight aperture to
move into the direction of the wind. (See chapter 9.)
8002. Physical Effects of
Temperature and Precipitation
on the Bullet and the Rifle
Temperature
Extreme changes in temperature cause fluctuation in
the rifle’s chamber pressure. This fluctuation is caused
by changes in the propellant’s temperature. In cold
weather, as rifle chamber pressure decreases, the bullet
exits the muzzle at a lower velocity, and the bullet im-
pacts the target below the point of aim. In extreme
heat, the rifle’s chamber pressure increases causing the
bullet to exit the muzzle at a higher velocity and im-
pact the target above the point of aim. Hot air is less
dense than cool air and provides less resistance to the
bullet; this allows the bullet to travel faster and experi-
ence less deflection from the wind. Cold air is dense
and provides the bullet with more resistance; this caus-
es the bullet to travel slower and experience greater
deflection from the wind.

--- chunk_id: chunk-0203
source_document: MCRP3-01A.pdf
page: 81
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 13
content_hash: fc757140b698df8b
prev_chunk_id: chunk-0202
next_chunk_id: chunk-0204
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 8-3. Flag Method.](images/p081_img00.jpeg)
*Figure 8-3. Flag Method.*

--- chunk_id: chunk-0204
source_document: MCRP3-01A.pdf
page: 82
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 538
content_hash: 9eb999ab410a55ba
prev_chunk_id: chunk-0203
next_chunk_id: chunk-0205
document_type: technical_reference

Figure 8-4. Windage Click Chart for the Observation Method. |             | WINDS CAN BEFELT LIGHTLY ON FACE AND LEAVES AREIN CONSTANT   | WINDS CAN BEFELT LIGHTLY ON FACE AND LEAVES AREIN CONSTANT   | WINDS RAISE DUST ANDLOOSE PAPER   | WINDS RAISE DUST ANDLOOSE PAPER   | WINDS CAUSE SMALL TREETO SWAY 12-15MPH   | WINDS CAUSE SMALL TREETO SWAY 12-15MPH   | WINDS CAUSE LARGE TREES TO SWAY   | WINDS CAUSE LARGE TREES TO SWAY   | WINDS CAUSE LARGE TREES TO SWAY   | WINDS CAUSE LARGE TREES TO SWAY   |
|-------------|--------------------------------------------------------------|--------------------------------------------------------------|-----------------------------------|-----------------------------------|------------------------------------------|------------------------------------------|-----------------------------------|-----------------------------------|-----------------------------------|-----------------------------------|
|             | WIND VALUE                                                   | WIND VALUE                                                   | WIND VALUE                        | WIND VALUE                        | WIND VALUE                               | WIND VALUE                               | WINDVALUE                         | WINDVALUE                         | WINDVALUE                         | WINDVALUE                         |
| RANGE YARDS | FULL                                                         | HALF                                                         | FULL                              | HALF                              | FULL                                     | HALF                                     | FULL                              | HALF                              | FULL                              | HALF                              |
| 200         | 2                                                            | 1                                                            | 3                                 | 1                                 | 5                                        | 2                                        | 6                                 |                                   | 8                                 | 4                                 |
| 300         | 3                                                            | 1                                                            | 6                                 |                                   | 10                                       | 5                                        | 13                                | 6                                 | 16                                | 8                                 |
| 400         | 4                                                            | 2                                                            | 9                                 | 4                                 | 13                                       | 6                                        | 18                                | 9                                 | 22                                | 11                                |
| 500         | 6                                                            | 3                                                            | 12                                | 6                                 | 18                                       | 9                                        | 24                                | 12                                | 30                                | 15                                | ![Figure 8-4. Windage Click Chart for the Observation Method.](images/p082_img00.jpeg)
*Figure 8-4. Windage Click Chart for the Observation Method.*

Figure 8-5. Windage Click Chart for the Flag Method. | RANGE FLAG ANGLES   | 5MPH WIND VALUE   | 5MPH WIND VALUE   | 10MPH   | 10MPH   | 15MPH WINDVALUE   | 15MPH WINDVALUE   | 20MPH WINDVALUE   | 20MPH WINDVALUE   |       |       |
|---------------------|-------------------|-------------------|---------|---------|-------------------|-------------------|-------------------|-------------------|-------|-------|
| RANGE YARDS         | FULL              | HALF              | FULL    | HALF    | FULL              | HALF              | FULL              | HALF              | FULL: | HALF. |
| 200                 | 2                 | 1                 | 3       | 1       | 5                 | 2                 | 9                 | 3                 | 8     | 4     |
| 000                 | 3                 | 1                 | 6       | 3       | 10                | 5                 | 13                | 6                 | 16    | 8     |
| 400                 | 4                 | 2                 | 9       | 4       | 13                | 6                 | 18                | 9                 | 22    | 11    |
| 500                 | 6                 | 3                 | 12      |         | 18                | 9                 | 24                | 12                | 30    | 15    |

--- chunk_id: chunk-0205
source_document: MCRP3-01A.pdf
page: 82
quality: 0.99
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 241
content_hash: ef5631010f1998cd
prev_chunk_id: chunk-0204
next_chunk_id: chunk-0206
document_type: technical_reference

Windage Click Chart for the Flag Method. | RANGE FLAG ANGLES   | 5MPH WIND VALUE   | 5MPH WIND VALUE   | 10MPH   | 10MPH   | 15MPH WINDVALUE   | 15MPH WINDVALUE   | 20MPH WINDVALUE   | 20MPH WINDVALUE   |       |       |
|---------------------|-------------------|-------------------|---------|---------|-------------------|-------------------|-------------------|-------------------|-------|-------|
| RANGE YARDS         | FULL              | HALF              | FULL    | HALF    | FULL              | HALF              | FULL              | HALF              | FULL: | HALF. |
| 200                 | 2                 | 1                 | 3       | 1       | 5                 | 2                 | 9                 | 3                 | 8     | 4     |
| 000                 | 3                 | 1                 | 6       | 3       | 10                | 5                 | 13                | 6                 | 16    | 8     |
| 400                 | 4                 | 2                 | 9       | 4       | 13                | 6                 | 18                | 9                 | 22    | 11    |
| 500                 | 6                 | 3                 | 12      |         | 18                | 9                 | 24                | 12                | 30    | 15    | ![Figure 8-5. Windage Click Chart for the Flag Method.](images/p082_img01.jpeg)
*Figure 8-5. Windage Click Chart for the Flag Method.*

<!-- image -->

<!-- image -->

<!-- image -->

--- chunk_id: chunk-0206
source_document: MCRP3-01A.pdf
page: 83
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 497
content_hash: 151502073bf31e3d
prev_chunk_id: chunk-0205
next_chunk_id: chunk-0207
document_type: technical_reference

8-4 _______________________________________________________________________________________________ MCRP 3-01A
Once the rifle is zeroed, a change in temperature of 20
degrees or more can cause the bullet to strike above or
below the point of aim. Therefore, if the temperature
changes 20 degrees or more, a Marine should re-zero
the rifle. If the rifle is exposed to below freezing temperatures,
it should not be brought immediately into a warm lo-
cation. Condensation may form on and in the rifle, and
it may freeze if re-exposed to the cold. Ice that forms
inside the rifle may cause it to malfunction. Ice can
form on the rear sight aperture due to condensation,
making it impossible to acquire sight alignment. Precipitation
Freezing rain and other types of precipitation may
make the rifle difficult to handle, foul the rifle and
cause stoppages, or build up in the barrel or compensa-
tor and cause erratic shots. Care should be taken to
keep the barrel and muzzle free of water. If the rifle
has been submerged, ensure the bore is drained before
firing. To drain the bore, pull the charging handle
slightly to the rear and hold for a few seconds while
the muzzle points down. Once the barrel has been
drained, turn the rifle muzzle up to allow the water to
drain out of the stock. 8003. Physical and Psychological 
Effects of Weather on Marines
Wind
Marines can shoot effectively in windy conditions if
they apply a few basic techniques and develop the
proper mental attitude. The Marine can combat the
wind in a number of ways:
l Make subtle changes to the basic shooting posi-
tions, such as increasing muscular tension, to re-
duce movement of the rifle sights. l Select a more stable firing position. l Seek support to stabilize the rifle. l Hold the shot and apply the fundamentals during a
lull in the wind. Temperature
Extreme Heat
In extreme heat, a Marine may experience rapid fa-
tigue. Heat can cause muscle cramps, heat exhaustion,
heat stroke, blurred vision, and reduced concentration
levels that result in inaccurate shooting. Increased flu-
id intake and good physical condition can offset the ef-
fects of extreme heat. Sweat running into the eyes can
cause irritation and make it difficult to see the sights.

--- chunk_id: chunk-0207
source_document: MCRP3-01A.pdf
page: 83
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 389
content_hash: 547e1a1cd9802800
prev_chunk_id: chunk-0206
next_chunk_id: chunk-0208
document_type: technical_reference

Increased flu-
id intake and good physical condition can offset the ef-
fects of extreme heat. Sweat running into the eyes can
cause irritation and make it difficult to see the sights. Extreme heat also can create ground mirages that
cause a target to appear indistinct and to drift from
side to side. Heat waves or mirages may also distort
the target shape or the appearance of the front sight
post. A mirage created by the heat of the barrel reduc-
es a Marine's ability to see the sight clearly. To over-
come the effects of heat and accurately engage a
target, a Marine should maintain a center of mass hold. Extreme Cold
Extreme cold may affect a Marine’s ability to concen-
trate. If a Marine’s hands are numb, he will have diffi-
culty holding a frigid rifle and executing effective
trigger control. To protect the hands in a cold environ-
ment, a Marine should wear arctic mittens or gloves. To operate the rifle while wearing arctic mittens or
gloves, a Marine depresses the trigger guard plunger to
open the trigger guard. This allows easier access to the
trigger. See figure 8-6. The hasty sling can assist in
holding the hand in place on the hand guards so the
hand does not slip while wearing mittens. Precipitation
Precipitation (rain, snow, hail, sleet) can affect target
engagement, a Marine’s comfort level, and a Marine’s
ability to concentrate. The amount and type of precipi-
tation may obscure or completely hide the target and it
may reduce a Marine's ability to establish an accurate
sight picture. Precipitation collecting on rear sight ap-
erture can make it difficult to establish sight alignment
and sight picture. Protect sights as much as possible
Figure 8-6. Open Trigger Guard.

--- chunk_id: chunk-0208
source_document: MCRP3-01A.pdf
page: 83
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 16
content_hash: 0a12f78a669c1589
prev_chunk_id: chunk-0207
next_chunk_id: chunk-0209
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 8-6. Open Trigger Guard.](images/p083_img00.jpeg)
*Figure 8-6. Open Trigger Guard.*

--- chunk_id: chunk-0209
source_document: MCRP3-01A.pdf
page: 84
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 337
content_hash: 280a22d8f095d536
prev_chunk_id: chunk-0208
next_chunk_id: chunk-0210
document_type: technical_reference

Rifle Marksmanship ________________________________________________________________________________________ 8-5
during periods of precipitation. It is easy to lose con-
centration when wet and uncomfortable. Proper dress
reduces the effects of precipitation on the Marine. Light
Light conditions can change the appearance of a tar-
get. Light affects each Marine differently. Light can
affect range estimation, visual acuity, or the placement
of the tip of the front sight on the target. By maintain-
ing a center of mass hold, the effects of light can be re-
duced. Bright Light
Bright light conditions exist under a clear blue sky
with no fog or haze present to filter the sunlight. Bright light can make a target appear smaller and far-
ther away. As a result, it is easy to overestimate range. Maintaining a center of mass hold, regardless of how
indistinct the target appears, ensures the best chances
for an effective shot. Overcast
An overcast condition exists when a solid layer of
clouds blocks the sun. The amount of available light
changes as the overcast thickens. Overcast conditions
can make a target appear larger and closer. As a result,
it is easy to underestimate range. During a light over-
cast, the target appears very distinct and the rifle sights
appear very distinct, making it easy to establish sight
alignment. As the overcast thickens, it becomes diffi-
cult to identify the target from its surroundings. Haze
Hazy conditions exist when fog, dust, humidity or
smoke is present. Hazy conditions can make a target
appear indistinct making it difficult to establish sight
picture.

--- chunk_id: chunk-0210
source_document: MCRP3-01A.pdf
page: 85
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 420
content_hash: e20324c7398e3e85
prev_chunk_id: chunk-0209
next_chunk_id: chunk-0211
section_heading: CHAPTER 9. ZEROING
document_type: technical_reference

CHAPTER 9. ZEROING
To be combat effective, it is essential for the Marine to know how to zero his rifle. Zeroing is adjusting the sights on the weapon to cause the shots to impact where
the Marine aims. This must be done while compensating for the effects of weather
and the range to the target. It is critical that Marines can zero their rifles and make
the sight adjustments required to engage targets accurately. See the appropriate technical manual for procedures on boresighting and zeroing
with supplemental aiming devices (e.g., laser, night vision devices). Note
+The procedures in this manual are
written for right-handed Marines; left-
handed Marines should reverse instructions
as necessary. 9001. Elements of Zeroing
There are five basic elements involved in zeroing a ri-
fle: line of sight, aiming point, centerline of the bore,
trajectory, and range. See figure 9-1. Line of Sight
The line of sight is a straight line, which begins with
the shooter’s eye, proceeds through the center of the
rear sight aperture, and passes across the tip of the
front sight post to a point of aim on a target. Aiming Point
The aiming point is the precise point where the tip of
the front sight post is placed in relationship to target. Centerline of the Bore
Centerline of the bore is an imaginary straight-line be-
ginning at the chamber end of the barrel, proceeding
out of the muzzle, and continuing indefinitely. Trajectory
In flight, a bullet does not follow a straight line but
travels in a curve or arc, called trajectory. Trajectory is
the path a bullet travels to the target. As the bullet exits
the muzzle, it travels on an upward path, intersecting
the line of sight (because the sights are above the muz-
zle). As the bullet travels farther, it begins to drop and
intersects the line of sight again. Figure 9-1. Elements of Zeroing.

--- chunk_id: chunk-0211
source_document: MCRP3-01A.pdf
page: 85
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 16
content_hash: 91d9a6196607711e
prev_chunk_id: chunk-0210
next_chunk_id: chunk-0212
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 9-1. Elements of Zeroing.](images/p085_img00.jpeg)
*Figure 9-1. Elements of Zeroing.*

--- chunk_id: chunk-0212
source_document: MCRP3-01A.pdf
page: 86
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 501
content_hash: b996a39e5cada57a
prev_chunk_id: chunk-0211
next_chunk_id: chunk-0213
document_type: technical_reference

9-2 _______________________________________________________________________________________________ MCRP 3-01A
Range
Range is the KD from the rifle muzzle to the target. 9002. Types of Zeros
Battlesight Zero (BZO)
A BZO is the elevation and windage settings required
to place a single shot, or the center of a shot group, in a
predesignated location on a target at 300 yards/meters,
under ideal weather conditions (i.e., no wind). A BZO
is the sight settings placed on your rifle for combat. In
combat, your rifle’s BZO setting will enable engage-
ment of point targets from 0–300 yards/meters in a no-
wind condition. Zero
A zero is the elevation and windage settings required
to place a single shot, or the center of a shot group, in a
predesignated location on a target at a specific range,
from a specific firing position, under specific weather
conditions. True Zero
A true zero is the elevation and windage settings re-
quired to place a single shot, or the center of a shot
group, in a predesignated location on a target at a spe-
cific range other than 300 yards/meters, from a specif-
ic firing position, under ideal weather conditions (i.e.,
no wind). 9003. M16A2 Sighting System
The sighting system of the M16A2 service rifle
consists of a front sight post and two rear sight
apertures windage and elevation knob. Scales of the
sighting system may be applied accurately to both yard
and meter measurements. For example, a rear sight
elevation setting of 8/3 may be used for 300 yards/
meters. Front Sight
The front sight post is used to
adjust for elevation. The front
sight consists of a square, ro-
tating sight post with a four-
position, spring-loaded detent
(see fig. 9-2). To adjust for
elevation, use a pointed in-
strument (or the tip of a car-
tridge) to depress the detent
and rotate the front sight post
(see fig. 9-3). To raise the
strike of the bullet, rotate the
post clockwise (in the direc-
tion of the arrow marked UP)
or to the right. To lower the
strike of the bullet, rotate the
post counter-clockwise (in the
opposite direction of the ar-
row) or to the left. Rear Sight
The rear sight consists of two sight apertures, a windage
knob, and an elevation knob. See figure 9-4.

--- chunk_id: chunk-0213
source_document: MCRP3-01A.pdf
page: 86
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 201
content_hash: 447d779c58e3bcf7
prev_chunk_id: chunk-0212
next_chunk_id: chunk-0214
document_type: technical_reference

Rear Sight
The rear sight consists of two sight apertures, a windage
knob, and an elevation knob. See figure 9-4. The large
aperture marked 0-2 is used for target engagement dur-
ing limited visibility, when a greater field of view is de-
sired, or for engagements of targets closer than 200
yards/meters. The unmarked aperture (small aperture) is
used for zeroing and normal firing situations. Elevation Knob
The rear sight elevation knob is used to adjust the sight
for a specific range to the target. The elevation knob is
indexed as shown in figure 9-5. Each number on the
knob represents a distance from the target in 100-yard/
meter increments. To adjust for range to the target, ro-
tate the elevation knob so the desired setting is aligned
with the index on the left side of the receiver. Figure 9-2. Front 
Sight. Figure 9-3. Front 
Sight Adjustment. Figure 9-4. Rear Sight.

--- chunk_id: chunk-0214
source_document: MCRP3-01A.pdf
page: 86
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 29
content_hash: 518a74dc19b5c578
prev_chunk_id: chunk-0213
next_chunk_id: chunk-0215
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 9-2. Front](images/p086_img00.jpeg)
*Figure 9-2. Front*

![Figure 9-3. Front](images/p086_img01.jpeg)
*Figure 9-3. Front*

![Figure 9-4. Rear Sight.](images/p086_img02.jpeg)
*Figure 9-4. Rear Sight.*

--- chunk_id: chunk-0215
source_document: MCRP3-01A.pdf
page: 87
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 524
content_hash: e6bc4d83aa7eae3d
prev_chunk_id: chunk-0214
next_chunk_id: chunk-0216
document_type: technical_reference

Rifle Marksmanship ____________________________________
If the elevation knob is turned so the number 8/3
aligns with the elevation index line, the 3 indicates 300
yards/meters (see fig. 9-6). When the rear sight elevation knob is set on 8/3 for
800 yards/meters, there will be a considerable gap
(about a quarter inch) between the rear sight housing
and the upper receiver (see fig. 9-7). A hasty sight setting is the setting placed on the rear
sight elevation knob to engage targets beyond 300
yards/meters. Hasty sight settings for ranges of 400 to
800 yards/meters are applied by rotating the rear sight
elevation knob to the number that corresponds with the
engagement distance of the enemy. Aligning the num-
Figure 9-5. Elevation Knob. Figure 9-6. Rear Sight Elevation Knob
Set for 300 Yards/Meters. Figure 9-7. Rear Sight Elevation Knob
Set for 800 Yards/Meters. ________________________________________________________ 9-3
r
t
ber 4, 5, 6 or 7 with the elevation index line places the
elevation at 400, 500, 600 or 700 yards/meters, respec-
tively. If a clockwise rotation is continued, the number
8/3 appears for the second time on the elevation index
line and indicates an 800 yard/meter elevation. Windage Knob
The windage knob is used to adjust the strike of the
round right or left. The windage knob is marked with
an arrow and the letter R that shows the direction the
strike of the round is being moved. See figure 9-8. To move the strike of the round to the right, rotate the
windage knob clockwise (in the direction of the arrow
marked R). To move the strike of the round to the left, rotate the
windage knob counterclockwise. 9004. Windage and Elevation Rules
Moving the front sight post, elevation knob or wind-
age knob one graduation or notch is referred to as
moving one “click” on the sight. The windage and ele-
vation rules define how far the strike of the round will
move on the target for each click of front and rear
sight elevation or rear sight windage for each 100
yards/meters of range to the target. Front Sight Elevation Rule
One click of front sight elevation adjustment will move
the strike of the round on target approximately 1.25
inches for every 100 yards of range to the target or 3.5
centimeters for every 100 meters of range to the target. Figure 9-8. Windage Knob.

--- chunk_id: chunk-0216
source_document: MCRP3-01A.pdf
page: 87
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 56
content_hash: 6ea83001d58b7cf3
prev_chunk_id: chunk-0215
next_chunk_id: chunk-0217
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 9-5. Elevation Knob.](images/p087_img00.jpeg)
*Figure 9-5. Elevation Knob.*

![Figure 9-6. Rear Sight Elevation Knob](images/p087_img01.jpeg)
*Figure 9-6. Rear Sight Elevation Knob*

![Figure 9-7. Rear Sight Elevation Knob](images/p087_img02.jpeg)
*Figure 9-7. Rear Sight Elevation Knob*

![Figure 9-8. Windage Knob.](images/p087_img03.jpeg)
*Figure 9-8. Windage Knob.*

--- chunk_id: chunk-0217
source_document: MCRP3-01A.pdf
page: 88
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 496
content_hash: 6196eb9715ee49f8
prev_chunk_id: chunk-0216
next_chunk_id: chunk-0218
document_type: technical_reference

9-4 ________________________________________________________
Rear Sight Elevation Rule
One click of rear sight elevation adjustment will move
the strike of the round on the target approximately 1
inch for every 100 yards of range to the target or 2.5
centimeters for every 100 meters of range to the target. Windage Rule
One click of windage adjustment will move the strike
of the round on the target approximately 0.5 inch for
every 100 yards of range to the target or 1.25 centime-
ters for every 100 meters of range to the target. 9005. Initial Sight Settings
Initial sight settings are those settings that serve as the
starting point for initial zeroing from which all sight
adjustments are made. (If the Marine already has a
BZO established on his rifle, he may begin the zeroing
process by using the previously established BZO sight
settings.) To set the sights to initial sight settings:
Front Sight Post
To set the front sight post to initial sight setting, de-
press the front sight detent and rotate the front sight
post until the base of the front sight post is flush with
the front sight housing. Rear Sight Elevation Knob
To set the elevation knob at the initial sight setting,
perform the following:
l Rotate the rear sight elevation knob counterclock-
wise until the moveable rear sight housing is bot-
tomed out on the upper receiver. See figure 9-9. b
Figure 9-9. Bottoming Out Elevation Knob. ___________________________________________ MCRP 3-01A
Note
Once bottomed out, the rear sight elevation
knob should be three clicks counterclock-
wise from 8/3. If the sight fails to move
three clicks counterclockwise from 8/3, it
must be adjusted by a qualified armorer. l Rotate rear sight elevation knob clockwise until the
number 8/3 aligns with the index mark located on
the left side of the upper receiver. See figure 9-10. Windage Knob
To set the windage knob to initial sight setting, rotate
windage knob until the index line located on the top of
the large rear sight aperture aligns with the centering
on the windage index scale located on the moveable
base of the rear sight assembly. See figure 9-11. 9006. Zeroing Process
During the zeroing process, all elevation adjustments
are made on the front sight post.

--- chunk_id: chunk-0218
source_document: MCRP3-01A.pdf
page: 88
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 80
content_hash: d838b2fff8e9ae24
prev_chunk_id: chunk-0217
next_chunk_id: chunk-0219
section_heading: 9006. Zeroing Process
document_type: technical_reference

9006. Zeroing Process
During the zeroing process, all elevation adjustments
are made on the front sight post. Once a BZO is
established, the front sight post should never be
moved, except when rezeroing the rifle. (The rear
sight elevation knob is used for dialing in the range to
Figure 9-10. Elevation Knob Set at 8/3. Figure 9-11. Aligning Index Line.

--- chunk_id: chunk-0219
source_document: MCRP3-01A.pdf
page: 88
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 50
content_hash: 26c5c835edc00a9b
prev_chunk_id: chunk-0218
next_chunk_id: chunk-0220
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 9-9. Bottoming Out Elevation Knob.](images/p088_img00.jpeg)
*Figure 9-9. Bottoming Out Elevation Knob.*

![Figure 9-10. Elevation Knob Set at 8/3.](images/p088_img01.jpeg)
*Figure 9-10. Elevation Knob Set at 8/3.*

![Figure 9-11. Aligning Index Line.](images/p088_img02.jpeg)
*Figure 9-11. Aligning Index Line.*

--- chunk_id: chunk-0220
source_document: MCRP3-01A.pdf
page: 89
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 357
content_hash: aa1835e3128e15b9
prev_chunk_id: chunk-0219
next_chunk_id: chunk-0221
document_type: technical_reference

Rifle Marksmanship ____________________________________
the target.) Zeroing is conducted at a range of 300
yards/meters. To prepare a rifle for zeroing, the rifle
sights must be adjusted to the initial sight settings as
outlined in paragraph 9005. Perform the following
steps to zero the rifle:
l Fire a 3-shot group. l Triangulate the shot group to find the center. See
figure 9-12. l Determine the vertical distance in inches from the
center of the shot group to the center of the target. l Make elevation adjustments on the front sight post
to move the center of the shot group to the center of
the target. l Determine the horizontal distance from the center
of the shot group to the center of the target. l Make lateral adjustments on the windage knob to
move the center of the shot group to the center of
the target. Figure 9-12. Triangu

________________________________________________________ 9-5
f
l Repeat preceding steps until shot group is centered. l Fire a 4-round shot group to confirm sight setting. Once the sight setting is confirmed, determine the val-
ue and direction of the wind and remove the number of
clicks added to the windage knob (if necessary) to
compensate for current wind conditions. This becomes
the BZO setting for the rifle. 9007. Battlesight Zero
Zeroing is conducted at a range of 300 yards/meters. If
a 300-yard/-meter range is not available, a field expe-
dient BZO can be established at a reduced range of 36
yards/30 meters. When a rifle is zeroed for 300 yards/
meters, the bullet crosses the line of sight twice. It first
ngulating Shot Group.

--- chunk_id: chunk-0221
source_document: MCRP3-01A.pdf
page: 89
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 8
content_hash: 6d76aab4f61c7b51
prev_chunk_id: chunk-0220
next_chunk_id: chunk-0222
section_heading: Figures
document_type: technical_reference

## Figures

![figure 9-12.](images/p089_img00.jpeg)
*figure 9-12.*

--- chunk_id: chunk-0222
source_document: MCRP3-01A.pdf
page: 90
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: 45d8a086129048d4
prev_chunk_id: chunk-0221
next_chunk_id: chunk-0223
document_type: technical_reference

9-6 _______________________________________________________________________________________________ MCRP 3-01A
crosses the line of sight on its upward path of trajecto-
ry at 36 yards/30 meters, and again farther down range
at 300 yards/meters (see fig. 9-13). Therefore a rifle’s
BZO may be established at a distance of 36 yards/30
meters and the same BZO will be effective at 300
yards/meters. To establish a field expedient BZO at 36 yards or 30
meters when a 300-yard/-meter range is not available,
a Marine performs the same steps as the zeroing pro-
cess outlined in paragraph 9006. However, since wind
does not affect the round at 36 yards/30 meters, wind-
age is not added nor is it removed from the windage
knob after confirming the BZO. To be accurate, the
target must be placed exactly 36 yards (or 30 meters)
from the muzzle of the rifle. 9008. Factors Causing a BZO to be 
Reconfirmed
Marines are responsible for maintaining a BZO on
their rifles at all times. Many factors influence the
BZO of a rifle. Atmospheric conditions, humidity, and
temperature can cause BZOs to change on a daily ba-
sis. If operating in a combat environment, Marines
should confirm their BZO as often as possible. To con-
firm a BZO, a Marine may begin the zeroing process
by using the previously established BZO sight settings
rather than placing the sights at initial sight setting. The following factors cause a BZO to be reconfirmed. Maintenance
It is possible for the BZO to change if ordnance per-
sonnel perform maintenance on a rifle. If maintenance
was performed, it is critical that the rifle be rezeroed as
soon as possible. Temperature
An extreme change in temperature (i.e., 20 degrees or
more) will cause the elevation BZO to change. Chang-
es in temperature cause chamber pressure to increase
when hot and decrease when cold. This causes shots to
impact the target high in hot temperatures and low in
cold temperatures. Climate
Changing climates (i.e., moving from a dry climate to
a tropical climate) can mean changes in air density,
moisture content, temperature or barometric pressure. Any of these elements can affect the rifle’s BZO. Ammunition
Inconsistencies in the production of ammunition lots
can change a rifle’s BZO. Ground Elevation
Drastic changes in ground elevation can create chang-
es in air density, moisture content, temperature or
barometric pressure.

--- chunk_id: chunk-0223
source_document: MCRP3-01A.pdf
page: 90
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 153
content_hash: 66da43ef7b56670f
prev_chunk_id: chunk-0222
next_chunk_id: chunk-0224
document_type: technical_reference

Ammunition
Inconsistencies in the production of ammunition lots
can change a rifle’s BZO. Ground Elevation
Drastic changes in ground elevation can create chang-
es in air density, moisture content, temperature or
barometric pressure. Any of these elements can affect
the rifle’s BZO. Uniform
If Marines zero their rifles in utility uniform and fire in
full battle gear, their BZOs will change. The wearing
of full battle gear changes eye relief, placement of the
rifle in the shoulder pocket, and the way the rifle is
supported on the handguard. Marines must establish
their BZOs while wearing the uniform and equipment
they will be wearing while engaging targets. Figure 9-13. Bullet Crossing the Line of Sight Twice.

--- chunk_id: chunk-0224
source_document: MCRP3-01A.pdf
page: 90
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 26
content_hash: 1cbbc2df0cfa6791
prev_chunk_id: chunk-0223
next_chunk_id: chunk-0225
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 9-13. Bullet Crossing the Line of Sight Twice.](images/p090_img00.jpeg)
*Figure 9-13. Bullet Crossing the Line of Sight Twice.*

--- chunk_id: chunk-0225
source_document: MCRP3-01A.pdf
page: 91
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 120
content_hash: 3f0a32a1caf6eefd
prev_chunk_id: chunk-0224
next_chunk_id: chunk-0226
section_heading: 9009. Factors Affecting the Accuracy of
document_type: technical_reference

Rifle Marksmanship ________________________________________________________________________________________ 9-7
9009. Factors Affecting the Accuracy of 
a BZO
Anything the Marine changes from shot to shot affects
the accuracy of his BZO. It further affects the accuracy
of shot placement. The following factors, when ap-
plied inconsistently, diminish the accuracy of a BZO:
l Any of the seven factors (left hand, rifle butt in the
pocket of the shoulder, grip of the right hand, right
elbow, stock weld, breathing, and muscular relax-
ation/tension). l Stability of hold. l Sling tension. l Trigger control. l Sight picture.

--- chunk_id: chunk-0226
source_document: MCRP3-01A.pdf
page: 92
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 481
content_hash: 3b9a490b92dfa8ab
prev_chunk_id: chunk-0225
next_chunk_id: chunk-0227
section_heading: CHAPTER 10. ENGAG
document_type: technical_reference

CHAPTER 10. ENGAG
A Marine must maintain the ability to r
ment—day or night. He must possess a co
fear, or uncertainty of action. A Marine’
the enemy rapidly and focus on the actio
must remember that speed alone does no
He should fire only as fast as he can fire
physical capability to engage a target e
Marine must train to perfect the physical 
senting the weapon and assuming a shoo
tive. A Marine must also employ effect
acquisition and engagement of a variety o
10001. Target Detection
To be proficient, a Marine rifleman must be able to de-
tect targets, determine the range to targets, and accu-
rately engage the targets. There are many variables
affecting a Marine’s ability to detect and determine the
range to combat targets. Enemy targets on the battle-
field may be single or multiple, stationary or moving,
or completely hidden from view. Success in locating
an enemy target will depend upon the observer’s posi-
tion, his skill in searching an area, and his ability to
recognize target indicators. Target Indicators
Most combat targets are detected at close range by
smoke, flash, dust, noise or movement, and are usually
seen only momentarily. Target indicators are anything
that reveals an individual’s position to the enemy. These indicators are grouped into three general areas:
movement, sound, and improper camouflage. Movement
The human eye is attracted to movement, especially
sudden movement. The Marine need not be looking
directly at an object to notice movement. The degree
of difficulty in locating moving targets depends pri-
marily on the speed of movement. A slowly moving
target will be harder to detect than one with quick,
jerky movements. Sound
Sound can also be used to detect an enemy position. Sound may be made by movement, rattling equipment,
or talking. Sound provides only a general location of
the enemy, making it difficult to pinpoint a target by

AGEMENT TECHNIQUES
to react instinctively in a combat environ-
a combat mindset that eliminates hesitation,
ne’s combat mindset allows him to engage
ctions required to fire well-aimed shots. He
s not equate to effective target engagement. fire accurately. He should never exceed his
et effectively.

--- chunk_id: chunk-0227
source_document: MCRP3-01A.pdf
page: 92
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: 5a31b9f321f92cdb
prev_chunk_id: chunk-0226
next_chunk_id: chunk-0228
section_heading: CHAPTER 10. ENGAG
document_type: technical_reference

fire accurately. He should never exceed his
et effectively. To be effective in combat, a
cal skills of target engagement (such as pre-
hooting position) until they become instinc-
fective engagement techniques that enable
ty of targets in diverse combat conditions. sound alone. However, sound can alert the Marine to
the presence of a target and increase his probability of
locating it through other indicators. Improper Camouflage
There are three indicators caused by improper camou-
flage: shine, outline, and contrast with the background. Most targets on the battlefield are detected due to im-
proper camouflage. However, many times an observa-
tion post or enemy firing position will blend almost
perfectly with the natural background. Only through
extremely careful, detailed searching will these posi-
tions be revealed. Shine. Shine is created from reflective objects such as
metal or glass. It may also come from pools of water
and even the natural oils from the skin. Shine acts as a
beacon to the target’s position. Outline. Most enemy soldiers will camouflage them-
selves, their equipment, and their positions. The out-
line of objects such as the body, head and shoulders,
weapons, and web gear are recognizable even from a
distance. The human eye will often pick up a recogniz-
able shape and concentrate on it even if the object can-
not be identified immediately. The reliability of this
indicator depends upon visibility and the experience of
the observer. Contrast With the Background. Indicators in this
category include objects that stand out against (con-
trast with) a background because of differences in col-
or, surface, and shape. For instance, a target wearing a
dark uniform would be clearly visible in an area of
snow or sand. Geometric shapes, such as helmets or ri-
fle barrels, can be easy to detect in a wooded area. Fresh soil around a fighting hole contrasts with the
otherwise unbroken ground surface. While observing

--- chunk_id: chunk-0228
source_document: MCRP3-01A.pdf
page: 93
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 497
content_hash: 88011a949b422277
prev_chunk_id: chunk-0227
next_chunk_id: chunk-0229
document_type: technical_reference

10-2 _______________________________________________________
an area, take note of anything that looks out of place or
unusual and study it in more detail. This will greatly
increase your chances of spotting a hidden enemy. Identifying Target Location
Observation Position
A good position is one that offers maximum visibility
of the area while affording cover and concealment. The optimal observation position should allow the
Marine to scan all the areas of observation and offer
enough concealment to prevent his position from be-
ing detected. The Marine should avoid positions that are obvious or
stand out, such as a lone tree in a field or a pile of
rocks on a hill. These positions may be ideal points for
easy observation, but they will also make it easier for
the enemy to locate the Marine. Methods for Searching an Area
In searching an area, the Marine will be looking for
target indicators. There are two techniques for search-
ing an area: the hasty search and the detailed search. Hasty Search. When a Marine moves into a new area,
he must quickly check for enemy activity that may
pose an immediate danger. This search is known as the
hasty search and should take about 30 seconds, de-
pending on the terrain. Quickly glance at various points throughout the area
rather than sweeping the eyes across the terrain in one
continuous movement. The Marine should search the
p
h
j
 Figure 10-1. Searching the Terr

___________________________________________ MCRP 3-01A
area nearest him first since it poses the greatest poten-
tial for danger. This method of search is effective because it takes ad-
vantage of peripheral vision. Peripheral vision enables
the detection of any movement in a wide area around
the object being observed. For this technique to be ef-
fective, the eyes must be focused briefly on specific
points (i.e., areas that may provide cover or conceal-
ment for the enemy). Detailed Search. A detailed search is a systematic ex-
amination of a specific target indicator or of the entire
observation area. A detailed search should be conduct-
ed immediately on target indicators located during the
hasty search. The detailed search should be made from
top to bottom or side to side, observing the entire ob-
ject in exact detail.

--- chunk_id: chunk-0229
source_document: MCRP3-01A.pdf
page: 93
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 200
content_hash: 1f70afbed3b44e19
prev_chunk_id: chunk-0228
next_chunk_id: chunk-0230
document_type: technical_reference

A detailed search should be conduct-
ed immediately on target indicators located during the
hasty search. The detailed search should be made from
top to bottom or side to side, observing the entire ob-
ject in exact detail. If multiple indicators were ob-
served during the hasty search, the detailed search
should begin with the indicator that appears to pose
the greatest threat. After a thorough search of target indicators, or if no in-
dicators were located during the hasty search, a de-
tailed search should be made of the entire observation
area. The 50-meter overlapping strip method is nor-
mally used. Normally, the area nearest the observer offers the
greatest potential danger and should be searched first. Begin the search at one flank, systematically searching
the terrain at the front in 180-degree arcs, searching
everything in exacting detail, 50 meters in depth. See
figure 10-1. Terrain in Overlapping Strips.

--- chunk_id: chunk-0230
source_document: MCRP3-01A.pdf
page: 93
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 16
content_hash: 7dff8318fdf6bf0b
prev_chunk_id: chunk-0229
next_chunk_id: chunk-0231
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 10-1. Searching the Terr](images/p093_img00.jpeg)
*Figure 10-1. Searching the Terr*

--- chunk_id: chunk-0231
source_document: MCRP3-01A.pdf
page: 94
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 476
content_hash: e1153c8a1f03e121
prev_chunk_id: chunk-0230
next_chunk_id: chunk-0232
document_type: technical_reference

Rifle Marksmanship ____________________________________
After reaching the opposite flank, systematically cover
the area between 40 and 90 meters from your position. The second search of the terrain includes about 10
meters of the area examined during the first search. This technique ensures complete coverage of the area. Continue the overlapping strip search method for as
far as you can see. Maintaining Observation
Method
The combat situation will dictate the method of main-
taining observation of an area. Generally, the observa-
tion method will include a combination of hasty and
detailed searches. Sequence of Observation
Observation is often conducted by a two-man team. One team member should constantly observe the en-
tire area using the hasty search technique and the other
team member should conduct a detailed overlapping
strip search. If you are observing as an individual, de-
vise a plan to ensure that the area of observation is
completely covered. When entering a new area, imme-
diately conduct a hasty search. Since a hasty search
may fail to detect some indicators, periodically con-
duct a detailed search of the area. A detailed search
should also be conducted any time your attention has
been diverted from the search area. Remembering Target Location
Most targets are seen only briefly and most areas con-
tain multiple targets. Once you have located a target
indicator, you will need to remember its location to en-
gage it successfully. To help remember the location of
a target, select a known feature and use it as a refer-
ence point to determine the distance and general direc-
tion to the target. 10002. Range Estimation
To engage targets at unknown distances, a Marine
must determine the distance from his location to a
known point. This is known as range estimation. The
ability to determine range is a skill that must be devel-
oped if a Marine is to successfully engage targets at
unknown distances. Precise range estimation enhances
accuracy, enhances the chance of survival, and deter-

______________________________________________________ 10-3
t
a
t
mines if a target can be effectively engaged using the
rifle’s existing BZO or if a new sight setting or point
of aim is required.

--- chunk_id: chunk-0232
source_document: MCRP3-01A.pdf
page: 94
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 408
content_hash: a998072c1cd69e5b
prev_chunk_id: chunk-0231
next_chunk_id: chunk-0233
document_type: technical_reference

The
ability to determine range is a skill that must be devel-
oped if a Marine is to successfully engage targets at
unknown distances. Precise range estimation enhances
accuracy, enhances the chance of survival, and deter-

______________________________________________________ 10-3
t
a
t
mines if a target can be effectively engaged using the
rifle’s existing BZO or if a new sight setting or point
of aim is required. Range Estimation Methods
Unit of Measure Method
To use this method, a Marine visualizes a distance of
100 meters on the ground, and then estimates how
many of these units will fit between him and the target. This determines the total distance to the target. See
figure 10-2. The greatest limitation of this method is that its accura-
cy is related to the amount of visible terrain. For exam-
ple, if a target appears at a range of 500 meters or more
and only a portion of the ground between a Marine and
the target can be seen, it becomes difficult to use the
unit of measure method to estimate range accurately. A
Marine must practice this method frequently to be pro-
ficient. Whenever possible, a Marine should select an
object, estimate the range, and then verify the actual
range by either pacing or using another accurate mea-
surement. Rifle Front Sight Post Method
The area of the target covered by the rifle’s front sight
post can be used to estimate range to a target. A
Marine notes the appearance of the front sight post on
a known-distance target. A Marine then uses this as a
guide to determine range over an unknown distance. Because the apparent size of the target changes as the
distance to the target changes, the amount of the target
covered by the front sight post varies based on the
Figure 10-2. Unit of Measure Method.

--- chunk_id: chunk-0233
source_document: MCRP3-01A.pdf
page: 94
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 8
content_hash: 0aed69be2dc70c5c
prev_chunk_id: chunk-0232
next_chunk_id: chunk-0234
section_heading: Figures
document_type: technical_reference

## Figures

![figure 10-2.](images/p094_img00.jpeg)
*figure 10-2.*

--- chunk_id: chunk-0234
source_document: MCRP3-01A.pdf
page: 95
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: b92092e4fed4bdae
prev_chunk_id: chunk-0233
next_chunk_id: chunk-0235
document_type: technical_reference

10-4 _______________________________________________________
range. In addition, a Marine’s eye relief and percep-
tion of the front sight post affect the amount of the tar-
get that is visible. To use this method, a Marine must
apply the following guidelines:
l The front sight post covers the width of a man’s
chest or body at approximately 300 meters. l If the target is less than the width of the front sight
post, the target is in excess of 300 meters and the ri-
fle’s BZO cannot be used effectively. l If the target is wider than the front sight post, the
target is less than 300 meters and can be engaged
point of aim/point of impact using the rifle’s BZO. See figure 10-3. Visible Detail Method
The amount of detail seen at various ranges can pro-
vide a Marine with an estimate of the target’s distance. To use this method, a Marine must be familiar with the
size and various details of personnel and equipment at
known distances. Visibility (such as weather, smoke
or darkness) limits the effectiveness of this method. A
Marine should observe a man while he is standing,
kneeling, and in the prone position at known ranges of
100 to 500 meters. He should note the man’s size,
characteristics/size of his uniform and equipment, and
any other pertinent details. The Marine then uses this
as a guide to determine range over an unknown dis-
tance. A Marine also should study the appearance of
other familiar objects such as rifles and vehicles. To
use this method, a Marine applies the following gener-
al guidelines:
l At 100 meters, the target is clearly observed in de-
tail and facial features are distinguished
l At 200 meters, the target is clearly observed. There
is a loss of facial detail. The color of the skin and
equipment are still identifiable. p
b
b
Figure 10-3. Front Sight Post Method. ___________________________________________ MCRP 3-01A
l At 300 meters, the target has a clear body outline,
face color usually remains accurate, but remaining
details are blurred. l At 400 meters, the body outline is clear, but remain-
ing detail is blurred. l At 500 meters, the body shape begins to taper at the
ends, and the head becomes indistinct from the
shoulders. l At 600 meters, the body appears wedge-shaped and
headless.

--- chunk_id: chunk-0235
source_document: MCRP3-01A.pdf
page: 95
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 397
content_hash: 972ef58418a4f882
prev_chunk_id: chunk-0234
next_chunk_id: chunk-0236
document_type: technical_reference

l At 500 meters, the body shape begins to taper at the
ends, and the head becomes indistinct from the
shoulders. l At 600 meters, the body appears wedge-shaped and
headless. Bracketing Method
This method of range estimation estimates the shortest
possible distance and the greatest possible distance to
the target. For example, a Marine estimates that a tar-
get may be as close as 300 meters but it could be as far
away as 500 meters. The estimated distances are aver-
aged to determine the estimated range to the target. For example, the average of 300 meters and 500
meters is 400 meters. Halving Method
To use the halving method, a Marine estimates the dis-
tance halfway between him and the target, then dou-
bles that distance to get the total distance to the target. A Marine must take care when judging the distance to
the halfway point; any error made in judging the half-
way distance is doubled when estimating the total dis-
tance. Combination Method
The methods previously discussed require optimal
conditions with regard to the target, terrain, and visi-
bility in order to obtain an accurate range estimation. A Marine should estimate the range using two meth-
ods and then compare the estimates, or two Marines
can compare their estimates. The average of the two
estimates should be close to the actual range to target. Factors Affecting Range Estimation
The following specific factors will affect the accuracy
of estimation. A Marine must be aware of these factors
and attempt to compensate for their effects. Nature of the Target
l An object with a regular outline such as a steel hel-
met, rifle, or vehicle on a clear day will appear to be
closer than one with an irregular outline such as a
camouflaged object.

--- chunk_id: chunk-0236
source_document: MCRP3-01A.pdf
page: 95
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 18
content_hash: d0910efd033a30b7
prev_chunk_id: chunk-0235
next_chunk_id: chunk-0237
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 10-3. Front Sight Post Method.](images/p095_img00.jpeg)
*Figure 10-3. Front Sight Post Method.*

--- chunk_id: chunk-0237
source_document: MCRP3-01A.pdf
page: 96
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 460
content_hash: 0eb6f9781eec40ed
prev_chunk_id: chunk-0236
next_chunk_id: chunk-0238
document_type: technical_reference

Rifle Marksmanship ____________________________________
l A target that contrasts with its background will
appear to be closer than a target that blends in with
its background. l A partially exposed object will appear to be farther
away than it is. l A target will appear to be farther away if the target
is smaller than the objects surrounding it. Nature of the Terrain
l Terrain that slopes upward gives the illusion of
shorter distance. l Terrain that slopes downward gives the illusion of
greater distance. l Terrain with dead space makes the target appear to
be closer. l Smooth terrain such as sand, water, or snow gives
the illusion of greater distance. Limited Visibility
The position of the light source significantly affects a
Marine’s ability to estimate range. Other factors that
affect range estimation include smoke, fog, rain, an-
gled light, or anything that obscures the battlefield. Generally, when the sun is bright, a target appears fur-
ther away. When the sky is overcast, a target generally
appears closer. Target contrast is another factor to con-
sider when estimating range as well as obstacles locat-
ed between the shooter and the target. If there is
contrast (e.g., color variation) between the target and
the background, the target will appear closer. If there
is little or no contrast between the target and the back-
ground, the target will appear farther away. If there is
an object between the target and the shooter that will
distract the shooter (e.g., a tree), the target will appear
farther away. 10003. Offset Aiming
The conditions of rifle fire in combat may not permit
mechanical adjustments of the sights. To engage a tar-
get during combat, a Marine may be required to aim
his rifle at a point on the target other than center mass. This is known as offset aiming. Offset aiming is used
to compensate for the distance and size of the target,
wind, and speed and angle of a moving target. There
are two primary techniques for offset aiming: point of
aim technique and known strike of the round.

--- chunk_id: chunk-0238
source_document: MCRP3-01A.pdf
page: 96
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 430
content_hash: b0105fc5a526f8c3
prev_chunk_id: chunk-0237
next_chunk_id: chunk-0239
document_type: technical_reference

Offset aiming is used
to compensate for the distance and size of the target,
wind, and speed and angle of a moving target. There
are two primary techniques for offset aiming: point of
aim technique and known strike of the round. ______________________________________________________ 10-5
a
d
t
m
f
Point of Aim Technique
The point of aim technique is the shifting of the point
of aim (sight picture) to a predetermined location on or
off the target to compensate for a known condition
(i.e., wind, distance, and movement). Each predeter-
mined location is known as a point of aim. Figure 10-4
illustrates points of aim for elevation. Elevation
Predetermined points of aim sector the target horizon-
tally. The tip of the front sight post held at shoulder
level is considered one point of aim; the tip of the front
sight post held at the top of the target’s head is consid-
ered two points of aim. A Marine uses these points of
aim to compensate for the elevation required to engage
a target beyond the BZO capability of the rifle or to
engage a small target (e.g., head shot) inside the BZO
of the weapon. Beyond the BZO. To use the point of aim technique
to engage a target beyond the BZO of the rifle, a
Marine must apply the following guidelines:
l When range to the target is estimated to be beyond
300 meters out to 400 meters, hold one point of aim. l When the range to the target is estimated to be be-
yond 400 meters out to 500 meters, hold two points
of aim. Note
It is better to apply a hasty sight setting at
ranges beyond the rifle’s BZO. Points of
aim are only guidelines at these distances
because the front sight will mask the target
when the front sight is held above center
mass, making it difficult to acquire sight
picture. Figure 10-4. Points of Aim for Elevation.

--- chunk_id: chunk-0239
source_document: MCRP3-01A.pdf
page: 96
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 21
content_hash: 0b2144ca5b4ab6b0
prev_chunk_id: chunk-0238
next_chunk_id: chunk-0240
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 10-4. Points of Aim for Elevation.](images/p096_img00.jpeg)
*Figure 10-4. Points of Aim for Elevation.*

--- chunk_id: chunk-0240
source_document: MCRP3-01A.pdf
page: 97
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: 63e5a7f49d5c4033
prev_chunk_id: chunk-0239
next_chunk_id: chunk-0241
document_type: technical_reference

10-6 ______________________________________________________________________________________________ MCRP 3-01A
Inside the BZO. If the rifle is properly zeroed for 300
yards/meters, the trajectory (path of the bullet) will
rise approximately 4.5 inches (11 centimeters) above
the line of sight at a distance of approximately 175
yards (160 meters). At other distances, the strike of the
bullet will be less than 4.5 inches above the point of
aim. Only at 36 yards/30 meters and 300 yards/meters
does the point of impact coincide with the point of
aim. If only a portion of the target is visible (e.g., the
head of an enemy soldier), the trajectory of the bullet
may have to be taken into consideration when firing at
a distance less than 300 yards/meters. If a Marine does
not consider trajectory, he may shoot over the top of
the target if the target is small and at a distance less
than 300 yards/meters. See figure 10-5. Windage
Predetermined points of aim sector the target vertical-
ly (see fig. 10-6). The tip of the front sight post cen-
tered on the edge of the target into the wind is
considered one point of aim; the trailing edge of the
front sight post held on the edge of the target into the
wind is considered two points of aim. The same units
of measure are applied off the target for holds of addi-
tional points of aim. These points of aim are used to
compensate for wind affecting the strike of the round
and when there is no time to adjust the rifle’s sights, or
when a lead is required to engage a moving target
(points of aim for moving targets are discussed in
paragraph 10007). Table 10-1 provides points of aim
for full value winds. Known Strike of the Round
This offset aiming technique shifts the aiming point
(sight picture) to compensate for rounds that strike off
target center. The known strike of the round method is
used if the strike of the round is known. To engage a
target using this method, a Marine aims an equal dis-
tance from center mass opposite the known strike of
the round. For example, if the round strikes high and
left, a Marine aims an equal and opposite distance low
and right. Figure 10-5. Trajectory and Point of Aim/Point of Impact for 300 Yard BZO. Figure 10-6.

--- chunk_id: chunk-0241
source_document: MCRP3-01A.pdf
page: 97
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 21
content_hash: 3bfa64c6f17eb257
prev_chunk_id: chunk-0240
next_chunk_id: chunk-0242
document_type: technical_reference

Trajectory and Point of Aim/Point of Impact for 300 Yard BZO. Figure 10-6. Points of Aim.

--- chunk_id: chunk-0242
source_document: MCRP3-01A.pdf
page: 97
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 50
content_hash: 7b4fdf977ed50f1d
prev_chunk_id: chunk-0241
next_chunk_id: chunk-0243
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 10-5. Trajectory and Point of Aim/Point of Impact for 300 Yard BZO.](images/p097_img00.jpeg)
*Figure 10-5. Trajectory and Point of Aim/Point of Impact for 300 Yard BZO.*

![Figure 10-6. Points of Aim.](images/p097_img01.jpeg)
*Figure 10-6. Points of Aim.*

--- chunk_id: chunk-0243
source_document: MCRP3-01A.pdf
page: 98
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 512
content_hash: c3e5f16760e178ce
prev_chunk_id: chunk-0242
next_chunk_id: chunk-0244
section_heading: 10004. Techniques of Fire
document_type: technical_reference

Rifle Marksmanship ____________________________________
10004. Techniques of Fire
The size and distance to the target should dictate the
technique of fire. Two-Shot Technique
In combat, an effective technique for eliminating a
threat is to rapidly fire more than one shot on the tar-
get. Two shots fired in rapid succession will increase
the trauma (i.e., shock, blood loss) on the target, in-
creasing the Marine’s chances of quickly eliminating
the threat. Firing two shots enables the Marine to
break out of the tunnel vision often associated with fir-
ing in combat and then assess the situation to deter-
mine follow-on action. To execute the two-shot
technique, the Marine acquires sight picture for each
shot fired (each pull of the trigger). Single Shot Technique
If the target is at a long range or if the target is small
(i.e., partially exposed), it can best be engaged with a
single, precision shot. A Marine’s stability of hold and
sight alignment are more critical to accurate engage-
ment of long-range or small targets. To engage a target
with the single shot technique, the Marine must slow
down the application of the fundamentals and place
one well-aimed shot on target. Sustained Rate of Fire
An effective method for delivering suppressive fire is
to fire at the sustained rate of 12 to 15 rounds per
minute. Management of recoil is critical to bring the
sights back on target after the shot is fired. Table 10-1. Points of Aim for Full Value Winds. Wind 
Distance
(yards/meters)
Points 
of 
Aim
Light 
0-300
0
Medium 200-300
1
Strong 
0-200
1
Strong 
200-300
2

______________________________________________________ 10-7
a
t
a
r
Three-Round Burst Technique
When set on burst, the design of the rifle permits three
shots to be fired from a single trigger pull. The rounds
fire as fast as the weapon will function and cause the
muzzle to climb during recoil. The ability to manage
recoil is extremely important when firing the rifle on
burst. To achieve the desired effect (i.e., 3 rounds on
target), the Marine must control the jump angle of the
weapon to maintain the sights on target. At short rang-
es (i.e., 25 meters or less), firing on three-round burst
can be an effective technique to place rounds on a
man-sized target quickly to increase trauma on the tar-
get.

--- chunk_id: chunk-0244
source_document: MCRP3-01A.pdf
page: 98
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 374
content_hash: cd32504eabc78fa0
prev_chunk_id: chunk-0243
next_chunk_id: chunk-0245
section_heading: 10004. Techniques of Fire
document_type: technical_reference

To achieve the desired effect (i.e., 3 rounds on
target), the Marine must control the jump angle of the
weapon to maintain the sights on target. At short rang-
es (i.e., 25 meters or less), firing on three-round burst
can be an effective technique to place rounds on a
man-sized target quickly to increase trauma on the tar-
get. To execute the three-round burst technique, the
Marine places the selector lever on burst, aims center
mass, and acquires sight picture once for the single
trigger pull. 10005. Engaging Immediate Threat 
Targets
Immediate threat target engagement is characterized
by short-range engagement (i.e., less than 50 meters)
with little or no warning that requires an immediate re-
sponse to engage an enemy. This type of engagement
is likely in close terrain (e.g., urban, jungle). If this
type of engagement is likely, the large rear sight aper-
ture (0-2) could be placed up to provide a wider field
of view and detection of targets. Marksmanship skills
include quick presentation and compression of the
fundamentals (i.e., quick acquisition of sight picture,
uninterrupted trigger control). At close ranges, perfect
sight alignment is not as critical to accuracy on target. However, the front sight post must be in the rear sight
aperture; proper sight alignment is always the goal. 10006. Engaging Multiple Targets
When engaging multiple targets, a Marine must priori-
tize each target and carefully plan his shots to ensure
successful target engagement. Mental preparedness
and the ability to make split-second decisions are the
key to successful engagement of multiple targets. The
proper mindset allows a Marine to react instinctively
and to control the pace of the battle rather than just re-
acting to the threat.

--- chunk_id: chunk-0245
source_document: MCRP3-01A.pdf
page: 99
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 478
content_hash: 8b0db1f5de961790
prev_chunk_id: chunk-0244
next_chunk_id: chunk-0246
document_type: technical_reference

10-8 _______________________________________________________
After the first target is engaged, a Marine must imme-
diately engage the next target and continue to engage
targets until they are eliminated. While engaging mul-
tiple targets, a Marine must be aware of his surround-
ings and not fixate on just one target. He must rapidly
prioritize the targets, establish an engagement se-
quence, and engage the targets. A Marine also must
maintain constant awareness and continuously search
the terrain for additional targets. Prioritizing Targets
The combat situation will usually dictate the order of
multiple target engagement. Target priority is based on
factors such as proximity, threat, and opportunity; no
two situations will be the same. The principal method
is to determine the level of threat for each target so all
may be engaged in succession from the most threaten-
ing to the least threatening. The target that poses the
greatest threat (e.g., closest, greatest firepower) should
be engaged first. Prioritizing targets is an ongoing pro-
cess. Changes in threat level, proximity, or the target
itself may cause a Marine to revise his priorities. Therefore, a Marine must remain alert to changes in a
target's threat level and proximity and other target op-
portunities as the battle progresses. Technique of Engagement
To engage multiple targets, the Marine performs the
following steps:
l The first target with two rounds. l The recoil of the rifle can be used to direct the re-
covery of the weapon on to the next target. As the
weapon is coming down in its recovery, the Marine
physically brings the sights onto the desired target. Pressure is maintained on the trigger throughout re-
covery and trigger control is applied at a rate con-
sistent with the Marine’s ability to establish sight
picture on the desired target. l When possible, such as when all targets are of equal
threat, the Marine should engage targets in a direc-
tion that maximizes his ability to support and con-
trol the weapon. l The preceding steps are repeated until all targets
have been engaged. Firing Position
The selection and effective use of a firing position are
critical to the successful engagement of multiple tar-
gets.

--- chunk_id: chunk-0246
source_document: MCRP3-01A.pdf
page: 99
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 478
content_hash: a16a670ae4bd2194
prev_chunk_id: chunk-0245
next_chunk_id: chunk-0247
document_type: technical_reference

l The preceding steps are repeated until all targets
have been engaged. Firing Position
The selection and effective use of a firing position are
critical to the successful engagement of multiple tar-
gets. A Marine should make a quick observation of the
p
p
p

___________________________________________ MCRP 3-01A
terrain and select a firing position that provides good
cover and concealment, as well as the flexibility to en-
gage multiple targets. If enemy targets are widely dis-
persed, the selected position must provide the Marine
with flexibility of movement. The more restrictive the
firing position, the longer it will take a Marine to elim-
inate multiple targets. Prone
The prone position limits left and right lateral move-
ment and is, therefore, not recommended for engaging
short-range dispersed targets. Because the elbows are
firmly placed on the ground in the prone position, up-
per body movement is restricted. Sitting
Like the prone position, the sitting position allows lim-
ited lateral movement. This makes engagement of
widely-dispersed multiple targets difficult. To ease en-
gagement, the forward arm can be moved by pivoting
on the elbow, but this movement disturbs the stability
of the position. Kneeling
The kneeling position provides a wider, lateral range
of motion since only one elbow is used for support. A
Marine moves from one target to another by rotating at
the waist to move the forward arm in the direction of
the target, either right or left. Standing
The standing position allows maximum lateral move-
ment. Multiple targets are engaged by rotating the up-
per body to a position where the sights can be aligned
on the desired target. If severe or radical adjustments
are required to engage widely dispersed targets, a
Marine moves his feet to establish a new position rath-
er than give up maximum stability of the rifle. This
avoids poorly placed shots that can result from an un-
stable position. 10007. Engaging Moving Targets
In combat, it is unlikely that a target will remain sta-
tionary. The enemy will move quickly from cover to
cover, exposing himself for the shortest possible time. Therefore, a Marine must quickly engage a moving
target before it disappears.

--- chunk_id: chunk-0247
source_document: MCRP3-01A.pdf
page: 100
quality: 0.96
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 501
content_hash: e4466ad70cc57fe6
prev_chunk_id: chunk-0246
next_chunk_id: chunk-0248
document_type: technical_reference

Rifle Marksmanship ____________________________________
Types of Moving Targets
There are two types of moving targets: steady moving
targets and stop and go targets. Steady moving targets
move in a consistent manner and remain in a Marine’s
field of vision. A walking or running man is an exam-
ple of a steady moving target. A stop and go target ap-
pears and disappears during its movement. A stop and
go target will present itself for only a short time before
it reestablishes cover. An enemy moving from cover to
cover is an example of a stop and go target. This target
is most vulnerable to fire at the beginning and end of
its movement to new cover because the target must
gain momentum to exit its existing cover and then
slow down to occupy a new position. Leads
When a shot is fired at a moving target, the target con-
tinues to move during the time the bullet is in flight. Therefore, a Marine must aim in front of the target;
otherwise, the shot will fall behind the target. This is
called leading a target. Lead is the distance in advance
of the target that the rifle sights are placed to accurate-
ly engage the target when it is moving. Amount of Lead Required
Factors that affect the amount of lead are the target’s
range, speed, and angle of movement. Range. Lead is determined by the rifle’s distance to
the target. When a shot is fired at a moving target, the
target continues to move during the time the bullet is
in flight. This time of flight could allow a target to
move out of the bullet’s path if the round was fired di-
rectly at the target. Time of flight increases as range to
the target increases. Therefore, the lead must be in-
creased as the distance to the target increases. Speed. If a man is running, a greater lead is required
because the man will move a greater distance than a
walking man will while the bullet is in flight. Angle of Movement. The angle of movement across
the line of sight relative to the flight of the bullet deter-
mines the type (amount) of lead. Three Types of Leads: Full, Half, No
l Full Lead.

--- chunk_id: chunk-0248
source_document: MCRP3-01A.pdf
page: 100
quality: 0.96
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 477
content_hash: ddad5dbcd9c90beb
prev_chunk_id: chunk-0247
next_chunk_id: chunk-0249
document_type: technical_reference

The angle of movement across
the line of sight relative to the flight of the bullet deter-
mines the type (amount) of lead. Three Types of Leads: Full, Half, No
l Full Lead. The target is moving straight across a
Marine's line of sight with only one arm and half
the body visible. This target requires a full lead be-
cause it will move the greatest distance across a
Marine’s line of sight during the flight of the bullet. ______________________________________________________ 10-9
f
t
d
a
a
a
l Half Lead. The target is moving obliquely across a
Marine's line of sight (at a 45-degree angle). One
arm and over half the back or chest are visible. This
target requires half of a full lead because it will
move half as far as a target moving directly across a
Marine’s line of sight during the flight of the bullet. l No Lead. The target is moving directly toward or
away from a Marine and presents a full view of both
arms and the entire back or chest. No lead is re-
quired. A Marine engages this target as if it were a
stationary target because it is not moving across his
line of sight. Point of Aim Technique
Predetermined points of aim sector the target vertical-
ly. The tip of the front sight post centered on the lead-
ing edge of the target is considered one point of aim;
the trailing edge of the front sight post held on the
leading edge of the target is considered two points of
aim. The same units of measure are applied off the tar-
get for holds of additional points of aim. These points
of aim are used to compensate when a lead is required
to engage a moving target. The following guidelines
apply if a Marine uses the point of aim technique to es-
tablish a lead for a moving target at various ranges and
speeds (see fig. 10-7, on page 10-10). These guidelines
do not consider wind or other effects of weather. Body
width in these examples is considered to be 12 inches
(30 centimeters) (side view of the target).

--- chunk_id: chunk-0249
source_document: MCRP3-01A.pdf
page: 100
quality: 0.96
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 237
content_hash: 334cd18ef8e65ef4
prev_chunk_id: chunk-0248
next_chunk_id: chunk-0250
document_type: technical_reference

These guidelines
do not consider wind or other effects of weather. Body
width in these examples is considered to be 12 inches
(30 centimeters) (side view of the target). For a slow walking target (approximately 2 to 2.5
mph/3.2 to 4 kph) moving directly across the line of
sight (full lead)—
l At a range of 200 meters or less, no lead is required. l At a range of 300 meters, hold one point of aim in
the direction the target is moving. For a fast walking target (approximately 4 mph/6.4
kph) moving directly across the line of sight (full
lead)—
l At a range of 200 meters or less, hold one point of
aim in the direction the target is moving. l At a range of 300 meters, hold two points of aim in
the direction the target is moving. For a target running (approximately 6 mph/9.7 kph)
directly across the line of sight (full lead)—
l At a range of 100 meters or less, hold one point of
aim in the direction the target is moving.

--- chunk_id: chunk-0250
source_document: MCRP3-01A.pdf
page: 101
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 504
content_hash: f1a288c3b2539b61
prev_chunk_id: chunk-0249
next_chunk_id: chunk-0251
document_type: technical_reference

10-10 ______________________________________________________
l At a range of 200 meters, hold two points of aim in
the direction the target is moving. For a target moving at a 45-degree angle (an oblique
target) across the line of sight, the lead is one half of
the lead that is required for a target moving directly
across the line of sight. Engagement Methods
Moving targets are the most difficult targets to engage. However, they can be engaged successfully by using
the tracking or the ambush method. The Tracking Method
The tracking method is used for a target that is moving
at a steady pace over a well-determined route. If a
Marine uses the tracking method, he tracks the target
with the rifle’s front sight post while maintaining sight
alignment and a point of aim on or ahead of (leading)
the target until the shot is fired. When establishing a
lead on a moving target, rifle sights will not be cen-
tered on the target and instead will be held on a lead in
front of the target. See figure 10-8. A Marine performs
the following steps to execute the tracking methods:
l Present the rifle to the target. l Swing rifle muzzle through the target (from the rear
of the target to the front) to the desired lead (point
of aim). The point of aim may be on the target or
some point in front of the target depending upon the
target’s range, speed, and angle of movement. l Track and maintain focus on the front sight post
while acquiring the desired sight picture. It may be
necessary to shift the focus between the front sight
W
Figure 10-7. Poi

___________________________________________ MCRP 3-01A
post and the target while acquiring sight picture, but
the focus must be on the tip of the front sight post
when the shot is fired. l Engage the target once sight picture is acquired
while maintaining the proper lead. l Follow-through so the lead is maintained as the bul-
let exits the muzzle. l Continue to track in case a second shot needs to be
fired on the target. The Ambush Method
The ambush method is used when it is difficult to track
the target with the rifle, as in the prone, sitting, or any
supported position.

--- chunk_id: chunk-0251
source_document: MCRP3-01A.pdf
page: 101
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 113
content_hash: 25bc4ba838b0441f
prev_chunk_id: chunk-0250
next_chunk_id: chunk-0252
document_type: technical_reference

l Continue to track in case a second shot needs to be
fired on the target. The Ambush Method
The ambush method is used when it is difficult to track
the target with the rifle, as in the prone, sitting, or any
supported position. The lead required to effectively
engaging the target determines the engagement point. With the sights settled, the target moves into the pre-
determined engagement point and creates the desired
sight picture. See figure 10-9. Points of Aim. Figure 10-8. Tracking Method.

--- chunk_id: chunk-0252
source_document: MCRP3-01A.pdf
page: 101
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 21
content_hash: b8add67bc9e6ffa7
prev_chunk_id: chunk-0251
next_chunk_id: chunk-0253
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 10-7. Poi](images/p101_img00.jpeg)
*Figure 10-7. Poi*

![Figure 10-8. Tracking Method.](images/p101_img01.jpeg)
*Figure 10-8. Tracking Method.*

--- chunk_id: chunk-0253
source_document: MCRP3-01A.pdf
page: 102
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 510
content_hash: 032a0ac8228b0366
prev_chunk_id: chunk-0252
next_chunk_id: chunk-0254
document_type: technical_reference

Rifle Marksmanship ____________________________________
The trigger is pulled simultaneously with the estab-
lishment of sight picture. To execute the ambush
method, a Marine performs the following steps:
l Select an aiming point ahead of the target. l Obtain sight alignment on the aiming point. l Hold sight alignment until the target moves into vi-
sion and the desired sight picture is established. l Engage the target once sight picture is acquired. l Follow-through so the rifle sights are not disturbed
as the bullet exits the muzzle. A variation of the ambush method can be used when
engaging a stop and go target. A Marine should look
for a pattern of exposure (e.g., every 15 seconds). Once a pattern is determined, a Marine establishes a
lead by aiming at a point in front of the area in which
the target is expected to appear, then he fires the shot
at the moment the target appears. Marksmanship Fundamentals
Engaging moving targets requires concentration and
adherence to the fundamentals of marksmanship. The
following modifications to the fundamentals of marks-
manship are critical to engagement of moving targets. Sight Picture
Typically, sight picture is the target’s center of mass. If a Marine engages a moving target, he bases his sight
picture on the target’s range, speed, and angle of
movement, i.e., sight alignment may be established on
a point of aim in front of the target. Figure 10-9. Ambush Method. _____________________________________________________ 10-11
k
a
t
f
Trigger Control
As with any target engagement, trigger control is criti-
cal to the execution of shots. A Marine can apply pres-
sure on the trigger prior to establishing sight picture,
but there should be no rearward movement of the trig-
ger until sight picture is established. Interrupted trig-
ger control is not recommended because the lead will
be lost or have to be adjusted to reassume proper sight
picture. When using the tracking method, continue
tracking as trigger control is applied to ensure the shot
does not impact behind the moving target. Follow-through
If a Marine uses the tracking method to engage mov-
ing targets, he continues to track the target during fol-
low-through so the desired lead is maintained as the
bullet exits the muzzle. Continuous tracking also en-
ables a second shot to be fired on target if necessary.

--- chunk_id: chunk-0254
source_document: MCRP3-01A.pdf
page: 102
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 340
content_hash: db698ed3bd1e27e9
prev_chunk_id: chunk-0253
next_chunk_id: chunk-0255
document_type: technical_reference

Follow-through
If a Marine uses the tracking method to engage mov-
ing targets, he continues to track the target during fol-
low-through so the desired lead is maintained as the
bullet exits the muzzle. Continuous tracking also en-
ables a second shot to be fired on target if necessary. Stable Position
To engage moving targets using the tracking method,
the rifle must be moved smoothly and steadily as the
target moves. A stable position steadies the rifle sights
while tracking. Additional rearward pressure may be
applied to the pistol grip to help steady the rifle during
tracking and trigger control. Elbows may be moved
from the support so the target can be tracked smoothly. 10008. Engaging Targets at Unknown 
Distances
Hasty Sight Setting
While a BZO is considered true for 300 meters, a Ma-
rine must be capable of engaging targets beyond this
distance. The rifle’s sighting system allows sight set-
tings for distances out to 800 meters in 100-meter in-
crements. If a Marine must establish a BZO for
extended ranges, it is referred to a hasty sight setting. To achieve a hasty sight setting, a Marine dials the ap-
propriate range numeral on the rear sight elevation
knob that corresponds to the range to the target. For
example, if the rear sight elevation knob is set at 8/3
and a target appears at 500 meters, rotate the knob to
the 5 setting. Note
Upon completion of firing with a hasty
sight setting for extended ranges, return the
rear sight to the BZO setting.

--- chunk_id: chunk-0255
source_document: MCRP3-01A.pdf
page: 102
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 13
content_hash: 887ae6ec3b8cbe40
prev_chunk_id: chunk-0254
next_chunk_id: chunk-0256
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 10-9. Ambush Method.](images/p102_img00.jpeg)
*Figure 10-9. Ambush Method.*

--- chunk_id: chunk-0256
source_document: MCRP3-01A.pdf
page: 103
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 482
content_hash: e2e7d3bcf43a54c9
prev_chunk_id: chunk-0255
next_chunk_id: chunk-0257
section_heading: 10009. Engaging Targets During Low
document_type: technical_reference

10-12 _____________________________________________________________________________________________ MCRP 3-01A
Point of Aim Technique
If the distance to the target is beyond the BZO capabil-
ity of the rifle and time does not permit adjustment of
the sights, a Marine can use offset aiming techniques
to apply a point of aim for elevation to engage the tar-
get. See paragraph 10003. 10009. Engaging Targets During Low 
Light and Darkness 
Combat targets are frequently engaged during periods
of darkness or under low-light conditions. Although
basic marksmanship fundamentals do not change, the
principles of night vision must be applied and target
detection is applied differently. During periods of
darkness or low light, a Marine’s vision is extremely
limited. A Marine must apply the techniques of night
observation in order to detect potential targets, and he
must develop skills that allow him to engage targets
under these conditions. Night Vision
A Marine can improve his ability to see during periods
of darkness or low light by obtaining and maintaining
night vision. Since adapting to night vision is a slow
and gradual process, steps should be taken to protect
night vision once it is obtained. Obtaining Night Vision
There are two methods used to obtain night vision. The first method is to remain in an area of darkness for
about 30 minutes. This area can be indoors or out-
doors. The major disadvantage of this approach is that
an individual is not able to perform any tasks while ac-
quiring night vision in total darkness. The second
method is to remain in a darkened area under low in-
tensity red light (similar to the light used in a photog-
rapher’s darkroom) for about 20 minutes, followed by
about 10 minutes in darkness without the red light. This method produces almost complete night vision
adaptation while permitting the performance of some
tasks during the adjustment period. Maintaining Night Vision
Because the eyes take a long time to adjust to dark-
ness, it is important to protect night vision once it is
acquired. To maintain night vision—
l Avoid looking at any bright light. Bright light will
eliminate night vision and require readaptation. l Shield eyes from parachute flares, from spotlights
or from headlights.

--- chunk_id: chunk-0257
source_document: MCRP3-01A.pdf
page: 103
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 406
content_hash: 3f4a5abda2e9e743
prev_chunk_id: chunk-0256
next_chunk_id: chunk-0258
section_heading: 10009. Engaging Targets During Low
document_type: technical_reference

Bright light will
eliminate night vision and require readaptation. l Shield eyes from parachute flares, from spotlights
or from headlights. l When using a flashlight to read a map or any other
written material:
n  Put one hand over the glass to limit the area illu-
minated and the intensity of the light. Keeping
one eye shut will reduce the amount of night vi-
sion lost. n  Cover the light with a red filter to help reduce the
loss of night vision. n  Minimize the time spent using a flashlight. Factors Affecting Night Vision
Some physical factors may affect your night vision
and reduce your ability to see as clearly as possible in
low light or darkness. These factors include—
l Fatigue. l Lack of oxygen. l Long exposure to sunlight. l Heavy smoking. l Drugs. l Headaches. l Illness. l Consumption of alcohol within the past 48 hours. l Improper diet. Searching Methods
Once night vision has been acquired, the Marine can
locate targets. Some daylight observation techniques
(e.g., searching for target indicators) also apply during
periods of darkness or low light. Off-center Vision
Off-center vision is the technique of keeping the atten-
tion focused on an object without looking directly at it
(see fig. 10-10). To search for targets using off-center
vision, never look directly at the object you are ob-
serving. You will see the object much better by using
off-center vision. Look slightly to the left, right, above
or below the object. Experiment and practice to find
the best off-center angle for you. For most people, it is
about 6 to 10 degrees away from the object, or about a
fist's width at arm’s length. Note
Staring at a stationary object in the dark
may make it appear to be moving. This oc-
curs because the eye has nothing on which

--- chunk_id: chunk-0258
source_document: MCRP3-01A.pdf
page: 104
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 484
content_hash: 869f5e707250d4ba
prev_chunk_id: chunk-0257
next_chunk_id: chunk-0259
document_type: technical_reference

Rifle Marksmanship _____________________________________________________________________________________ 10-13
to reference the exact position of the object. This illusion can be prevented by visually
aligning the object against something else,
such as a finger at arm’s length. Scanning/Figure Eight Scan
Scanning is the use of off-center vision to observe an
area or object and involves moving the eyes in a series
of separate movements across the objective area. A common method of scanning is to move the eyes in
a figure eight pattern (see fig. 10-11). A Marine moves
the eyes in short, abrupt, irregular movements over
and around the area. Once a target indicator is detect-
ed, focus is concentrated in that area, but not directly
at it. Pause a few seconds at each point of observation
since the eyes cannot focus on a still object while in
motion. Rest the eyes frequently when scanning. While you are observing, there may be periodic black-
outs of night vision due to simple fatigue. This is nor-
mal and is not a cause for alarm. Night vision will
quickly return after the eyes are moved and blinked a
few times. It is more effective to scan from a prone position or a
position closer to the ground than the object being ob-
served. This creates a silhouetted view of the object. When scanning an area, look and listen for the same
target indicators as in daylight: movement, sound, and
improper camouflage. Objects in bright moonlight/starlight cast shadows just
as in sunlight. Sound seems louder at night than during daylight. Types of Illumination
There are two types of illumination that assist engage-
ment during low light or darkness: ambient light and
artificial illumination. Both ambient light and artificial
illumination can affect target perception (distance and
size) and night vision capabilities. l Ambient light is the light produced by natural
means (i.e., the sun, moon, and stars). Variations
occur in ambient light due to the time of day, time
of year, weather conditions, terrain, and vegetation. l Artificial illumination is the light produced by a
process other than natural means. Artificial light
can be used to illuminate an area for target detection
Figure 10-10. Off-center Vision. Figure 10-11. Figure Eight Scan.

--- chunk_id: chunk-0259
source_document: MCRP3-01A.pdf
page: 104
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 26
content_hash: 8af01766ca043137
prev_chunk_id: chunk-0258
next_chunk_id: chunk-0260
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 10-10. Off-center Vision.](images/p104_img00.jpeg)
*Figure 10-10. Off-center Vision.*

![Figure 10-11. Figure Eight Scan.](images/p104_img01.jpeg)
*Figure 10-11. Figure Eight Scan.*

--- chunk_id: chunk-0260
source_document: MCRP3-01A.pdf
page: 105
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 486
content_hash: 168dd7dfeb46a2f9
prev_chunk_id: chunk-0259
next_chunk_id: chunk-0261
document_type: technical_reference

10-14 ______________________________________________________
or to illuminate a specific target to pinpoint its posi-
tion. There are two types of artificial illumination
used in combat: air and ground. Effects of Illumination
In some combat situations, ambient light and artificial
illumination may assist a Marine in locating targets. However, this light can affect perception of the target
and disrupt night vision. The introduction of artificial
light requires the eyes to make a sudden, drastic ad-
justment to the amount of light received. This can
cause a temporary blinding because night vision was
abruptly interrupted. Ambient light also can cause a
blinding effect; e.g., a Marine may experience tempo-
rary blindness or reduced night vision if a bright moon
suddenly appears from behind the clouds. l Light behind a Marine or light between the Marine
and a target illuminates the front of the target and
makes it appear closer than it is. l Light beyond the target displays the target in silhou-
ette and makes it appear farther away than it is. If
the target is silhouetted, it is easier to see and easier
to engage. l Air illumination devices are in constant motion as
they descend to the ground. This movement creates
changing shadows on any illuminated target caus-
ing a stationary target to appear as if it is moving. 10010. Engaging Targets while Wearing 
the Field Protective Mask
While engaging targets in a combat environment, a
Marine is under considerable stress caused by fear, fa-
tigue, and the noise of battle. His stress is further ag-
gravated by the fear and uncertainty associated with a
nuclear, biological, and chemical (NBC) threat. How-
ever, a Marine must be able to operate under any bat-
tlefield condition, including an NBC environment. If a
Marine wears the field protective mask, its bulk and
reduced visibility can affect his firing position which
in turn affects the rifle’s zero and his ability to engage
the target. A Marine must make adjustments to his fir-
ing position and the application of marksmanship fun-
damentals to counter the additional gear worn in an
NBC environment. Therefore, a Marine should prac-
tice wearing his field protective mask when he is not
in a combat environment.

--- chunk_id: chunk-0261
source_document: MCRP3-01A.pdf
page: 105
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 509
content_hash: b4fe3b473bb053d3
prev_chunk_id: chunk-0260
next_chunk_id: chunk-0262
document_type: technical_reference

A Marine must make adjustments to his fir-
ing position and the application of marksmanship fun-
damentals to counter the additional gear worn in an
NBC environment. Therefore, a Marine should prac-
tice wearing his field protective mask when he is not
in a combat environment. This allows him to over-
come any restrictions caused by the mask, develop
confidence in his ability to execute well-aimed shots
h
W
W
p
r
W
r
b
p

___________________________________________ MCRP 3-01A
while wearing the mask, and develop a plan of action. This plan should address how the rifle is presented to
the target, how long the mask is worn, and the likeli-
hood of enemy contact. If a Marine expects to wear the
mask for an extended period and enemy contact is
likely, he should consider adjusting the rifle sights so
that his first rounds are on target. Marksmanship Fundamentals
Wearing the field protective mask requires a Marine to
make modifications to his aiming and breath control
techniques. Aiming
Wearing the field protective mask affects the aiming
process and the ability to locate targets. The bulk of
the mask may require an adjustment to stock weld, eye
relief, head position, and placement of the buttstock in
the shoulder. Breath Control
Wearing the field protective mask affects breath con-
trol because breathing may be more difficult. Tempo-
rary fogging of the lens also may be experienced. If
fogging occurs, a Marine should take a deep breath
and fire while holding a full breath of air (inhaling
clears the fog). Firing Position
A good firing position provides balance, control, and
stability during firing. The field protective mask’s
added bulk and other restrictions may require a Marine
to make changes to his firing position. The adjust-
ments are unique to each Marine and based on his
body size and shape and his ability to adapt to the
mask. Adjustments should be minor. However, all fir-
ing positions will be affected in the following areas:
Stock Weld 
Changing the placement of the cheek on the stock may
affect the rifle’s BZO. Therefore, a Marine should ob-
tain a BZO for the rifle in full mission-oriented protec-
tive posture gear. Stock weld will not be as
comfortable or feel as solid as it does without the field
protective mask.

--- chunk_id: chunk-0262
source_document: MCRP3-01A.pdf
page: 105
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 141
content_hash: 46feecf424f08249
prev_chunk_id: chunk-0261
next_chunk_id: chunk-0263
document_type: technical_reference

Therefore, a Marine should ob-
tain a BZO for the rifle in full mission-oriented protec-
tive posture gear. Stock weld will not be as
comfortable or feel as solid as it does without the field
protective mask. The loss of sensitivity between the
cheek and the stock, due to the mask, may cause the
cheek to be pressed too firmly against the stock. Press-
ing the cheek too firmly against the stock can cause
the seal of the field protective mask to break. If this
occurs, quickly clear the mask and resume a firing po-
sition. If the lens of the field protective mask fogs up

--- chunk_id: chunk-0263
source_document: MCRP3-01A.pdf
page: 106
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 477
content_hash: 44f2a92547facced
prev_chunk_id: chunk-0262
next_chunk_id: chunk-0264
document_type: technical_reference

Rifle Marksmanship _____________________________________________________________________________________ 10-15
while in a firing position, this indicates that the mask’s
seal has been broken. Clear the mask and resume the
firing position. Eye Relief
The added bulk of the field protective mask may in-
crease eye relief because the head is farther back along
the stock. If the eye is too far from the rear sight aper-
ture it may be difficult to acquire the target and to
maintain sight picture; if the eye is too close, the
rear sight can hit the mask, possibly breaking a lens
or its seal. Head Position
The mask’s shape and bulk can make sight alignment
difficult to achieve. The restrictive vision caused by
the mask may force a Marine to roll or tilt his head
over the stock to achieve sight alignment. The Marine
should keep his head as erect as possible while main-
taining sight alignment. Placement of Buttstock in the Shoulder
Placement of the buttstock in the shoulder pocket may
have to be altered due to the mask’s added bulk. If the
rifle is canted, a Marine may place the buttstock of the
rifle just outside the pocket of the shoulder to achieve
sight alignment. Holding the rifle straight is the pre-
ferred method of obtaining sight alignment. However,
if sight alignment cannot be achieved in this position, a
Marine may alter the hold of the rifle to bring the aim-
ing eye in line with the sights. Canting the rifle drasti-
cally affects the rifle’s zero. A Marine should cant the
rifle only as much as is needed to obtain a good stock
weld and proper sight alignment. If the rifle is canted,
the point of impact may not coincide with the point of
aim. For example, when wearing the mask, a right-
handed Marine's point of impact is usually high and to
the left of center mass (for a left-handed Marine, high
and to the right of center mass). Therefore a Marine
has to offset aim an equal and opposite distance low
and to the right. See paragraph 10003 for a discussion
on offset aiming and the known strike of the round
technique.

--- chunk_id: chunk-0264
source_document: MCRP3-01A.pdf
page: 107
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 454
content_hash: 57b62ff1781880dc
prev_chunk_id: chunk-0263
next_chunk_id: chunk-0265
section_heading: Appendix A
document_type: technical_reference

Appendix A
DATA BOOK
Note
The principles for recording data in the data
book are the same for the Entry Level Rifle
(ELR) Program and the Sustainment Level
Rifle (SLR) Program. This appendix pro-
vides generic information for completing
the data book. Specifics pertaining to each
program are contained in the ELR and SLR
lesson plans. 1. Data Book 
Of all the tools that assist the Marine in firing accu-
rately and consistently, the data book, if properly used,
is the most valuable asset. It contains a complete
record of every shot fired and the weather conditions
and their effects on shooting. When used properly it
will assist the Marine in establishing and maintaining
a battlesight zero (BZO). 2. Recording Data Before Firing
Recording information in the data book prior to firing
saves valuable time on the firing line that should be
used to prepare for firing. Some information can be re-
corded before going to the firing line. In the BEFORE
FIRING section of the data book, record the following
(see fig. A-1):
True Zero
Front Elevation
Enter the front sight post setting by recording the num-
ber of clicks up (+) or down (-) under FRONT ELEV. Rear Elevation
Circle the rear sight elevation knob setting under
REAR ELEV for the yard line firing from— 
l 200 yards: 8/3-2
l 300 yards: 8/3
l 500 yards: 5
Note
At 500 yards, the rear sight elevation knob
setting may be plus or minus one or two
clicks off of 5. Wind
Under the WIND column under TRUE ZERO, the R
represents clicks right on the rifle from the initial sight
setting and the L represents clicks left on the rifle. En-
ter the rear sight windage knob setting by recording
the number of clicks right (clockwise) or left (counter-
clockwise) under WIND. Wind
Prior to firing, check the wind. If wind conditions are
present, a sight adjustment will have to be made prior
to firing to ensure shots impact the center of the target. Figure A-1. Recording Data Before Firing.

--- chunk_id: chunk-0265
source_document: MCRP3-01A.pdf
page: 107
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 18
content_hash: 6c934cda74958337
prev_chunk_id: chunk-0264
next_chunk_id: chunk-0266
section_heading: Figures
document_type: technical_reference

## Figures

![Figure A-1. Recording Data Before Firing.](images/p107_img00.jpeg)
*Figure A-1. Recording Data Before Firing.*

--- chunk_id: chunk-0266
source_document: MCRP3-01A.pdf
page: 108
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: dae1a4d2ccaf55f0
prev_chunk_id: chunk-0265
next_chunk_id: chunk-0267
document_type: technical_reference

A-2 ________________________________________________________
Direction
Determine the direction of the wind and draw an arrow
through the clock indicating the direction the wind is
blowing. If the wind is not blowing, a data entry is not
needed. Note
Remember that your position is represented
in the center of the clock and the target is at
12 o’clock. Value
Look at the clock to determine if the wind is full, half,
or no value wind. Under VALUE, circle FULL or
HALF to indicate the wind value. Speed
Observe the flag on the range and circle the appropri-
ate flag indicating the wind's velocity (SPEED). Determining Windage Adjustment
The chart beneath the flag indicates the number of
clicks on the rear sight windage knob to offset the ef-
fects of the wind. Circle the number of clicks where
the wind value and wind speed intersect. Zero
Determine the zero you will place on your rifle to ac-
commodate wind conditions to begin firing. This ZE-
RO will be the TRUE ZERO plus the rear sight
windage setting to compensate for the effects of wind. Front Elev and Rear Elevation
Elevation adjustments are not affected by wind so the
same settings are carried over from TRUE ZERO. Wind
Wind will affect the strike of the round right or left on
the target. Therefore, if wind is a factor, the rear sight
windage knob must be adjusted to compensate for the
effects of wind. If the wind is blowing, add the number of clicks cir-
cled under the flags to the rear sight windage knob set-
ting from TRUE ZERO. Once the windage setting is determined, record it in
the WIND column. p
p
W
j
p
p

___________________________________________ MCRP 3-01A
3. Recording Data During Firing 
Recording Data During Slow Fire Stages
The method for calling and plotting slow fire shots in
the data book is called “the shot behind method.” It al-
lows the Marine to spend less time recording data and
more time firing on the target. This is because all the
calling and plotting is done while the target is in the
pits being marked. This information is recorded in the
DURING FIRING portion of the data book page. The
proper and most efficient method for recording data
during KD slow fire stages is as follows (see fig.

--- chunk_id: chunk-0267
source_document: MCRP3-01A.pdf
page: 108
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 369
content_hash: 7e068661074b2034
prev_chunk_id: chunk-0266
next_chunk_id: chunk-0268
document_type: technical_reference

This information is recorded in the
DURING FIRING portion of the data book page. The
proper and most efficient method for recording data
during KD slow fire stages is as follows (see fig. A-2):
Fire the First Shot
Fire the first shot. Then immediately check the wind
flag to see if the speed or direction of the wind
changed. If the wind direction changed, indicate the
windage adjustment needed to compensate for it in the
WIND row under CALL number 1. This windage ad-
justment will have to be applied to the rifle prior to fir-
ing the second shot. Call the Shot Accurately
As soon as the shot is fired and the target is pulled into
the pits, record the exact location where the tip of the
front sight was on the target at the exact instant the
shot was fired (assuming sight alignment was main-
tained). Plot this location on the target provided under
number 1 in the block marked CALL. Prepare to Fire the Second Shot
As soon as you have recorded the call for the first shot,
prepare to fire the second shot. Look at Where the First Shot Hit
As the target reappears out of the pits, look where the
first shot hit the target. Remember this location so it
can be plotted after firing the second shot. Fire the Second Shot
Fire the second shot. Then check the wind flag to see if
the wind changed speed or direction. Call the Second Shot and
Plot the First Shot
As soon as the second shot is fired and the target is
pulled into the pits, record the call of the second shot.

--- chunk_id: chunk-0268
source_document: MCRP3-01A.pdf
page: 109
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 300
content_hash: 4e74ba1b03cae859
prev_chunk_id: chunk-0267
next_chunk_id: chunk-0269
document_type: technical_reference

Rifle Marksmanship ______________________________________________________________________________________ A-3
Now plot the precise location of the first shot by writ-
ing the numeral 1 on the large target diagram provided
in the block marked PLOT. Prepare to Fire the Third Shot
Repeat steps until all shots have been fired. Indicate
each slow fire shot with the appropriate number (e.g.,
1, 2, 3, 4, 5). Make a Sight Adjustment if Required
Sight adjustments should be made off of a shot group,
not a single shot. Determine if a sight adjustment is
necessary off of the first three shots fired. If the shots
form a group (i.e, a group that fits inside the “A” target
bull's-eye or the center scoring ring of the “D” target),
but are not where they were called, make the necessary
sight adjustment. CAUTION
Generally, major sight adjustments from
established sight settings are caused by
poor application of the fundamentals, in-
consistencies in firing positions, inconsis-
tencies in sight picture at different ranges
and different positions, and inconsistent
tension on the sling. Every effort should be
made to correct shooting errors prior to
making a sight adjustment on the rifle. Note
The plotting targets in the data book for the
KD Course of Fire are in inches, requiring
you to calculate the number of clicks to
center your shot groups. Figure A-2. Recording Slow Fire Data During Firing.

--- chunk_id: chunk-0269
source_document: MCRP3-01A.pdf
page: 109
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 24
content_hash: a4e882111ec2ba59
prev_chunk_id: chunk-0268
next_chunk_id: chunk-0270
section_heading: Figures
document_type: technical_reference

## Figures

![Figure A-2. Recording Slow Fire Data During Firing.](images/p109_img00.jpeg)
*Figure A-2. Recording Slow Fire Data During Firing.*

--- chunk_id: chunk-0270
source_document: MCRP3-01A.pdf
page: 110
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: c94a602cf5a636f9
prev_chunk_id: chunk-0269
next_chunk_id: chunk-0271
document_type: technical_reference

A-4 _______________________________________________________________________________________________ MCRP 3-01A
Elevation. Locate the closest horizontal grid line to
the center of the plotted shot group. Follow the line
across to the numbered vertical scale to determine the
number of inches of elevation the shot group is off of
target center. Calculate the number of clicks on your
front sight post (for 200 and 300 yards) or rear sight
elevation knob (for 500 yards) to bring your shot
group center. Windage. Locate the closest vertical grid line to the
center of the plotted shot group. Follow the line down
to the numbered horizontal scale to determine the
number of inches of windage the shot group is off of
target center. Calculate the number of clicks on your
rear sight windage knob to bring shot group center. Recording Data During Rapid Fire Stages
In the DURING FIRING section of the data book,
record the following (see fig. A-3):
Mentally Call Shots While Firing
While firing the rapid fire string, make a mental note
of any shots called out of the group. Plot the Shot Group
After firing the rapid fire string, and when the target is
marked, plot all visible hits with a dot precisely where
they appear on the large target diagram in the block
marked PLOT. Make a Sight Adjustment if Required
Locate the center of the shot group. If the shots form a
group, make the necessary sight adjustments off of the
center of the group. If shots do not form a group and
do not just contain a poor shot, do not make a sight ad-
justment. Determine the sight adjustment by locating
the center of the shot group and using the grid lines on
the target in the data book. These grid lines represent
the number of inches to bring a shot group center. Looking at the shot group:
Figure A-3. Recording Rapid Fire Data During Firing.

--- chunk_id: chunk-0271
source_document: MCRP3-01A.pdf
page: 110
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 24
content_hash: f2067bd0cfa1f40a
prev_chunk_id: chunk-0270
next_chunk_id: chunk-0272
section_heading: Figures
document_type: technical_reference

## Figures

![Figure A-3. Recording Rapid Fire Data During Firing.](images/p110_img00.jpeg)
*Figure A-3. Recording Rapid Fire Data During Firing.*

--- chunk_id: chunk-0272
source_document: MCRP3-01A.pdf
page: 111
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 512
content_hash: f29515c04110444a
prev_chunk_id: chunk-0271
next_chunk_id: chunk-0273
document_type: technical_reference

Rifle Marksmanship ___________________________________
 CAUTION
Generally, major sight adjustments from
established sight settings are caused by
poor application of the fundamentals, in-
consistencies in firing positions, inconsis-
tencies in sight picture at different ranges
and different positions, and inconsistent
tension on the sling. Every effort should be
made to correct shooting errors prior to
making a sight adjustment on the rifle. Note
The plotting targets in the data book for the
KD Course of Fire are in inches, requiring
you to calculate the number of clicks to
center your shot groups. Elevation. Locate the closest horizontal grid line to
the center of the plotted shot group. Follow the line
across to the numbered vertical scale to determine the
number of inches of elevation the shot group is off of
target center. Calculate the number of clicks on your
front sight post to bring your shot group center. Windage. Locate the closest vertical grid line to the
center of the plotted shot group. Follow the line down
to the numbered horizontal scale to determine the
number of inches of windage the shot group is off of
target center. Calculate the number of clicks on your
rear sight windage knob to bring your shot group cen-
ter. Remarks
After firing a stage, record any data or information that
can be helpful in improving shooting in the future. Anything done or observed should be recorded. These
items will be helpful when analyzing daily shooting
performance. Record this information in the RE-
MARKS column. What the Marine fails to record may
be the information he will need to improve. 4. Recording Data After Firing
In the AFTER FIRING section of the data book,
record the following (see fig. A-4 on page A-6):

_______________________________________________________ A-5
f
r
r
-
Zero
Upon completion of firing, determine the elevation
and windage required to center the shot group (if nec-
essary) and record this sight setting in the ZERO block
of the AFTER FIRING section. If no adjustments are
needed to center the shot group, record the sight set-
tings currently on the rifle. Front Elevation
Under the column FRONT ELEV, record the final ele-
vation setting made on the front sight post. Rear Elevation
Under the column REAR ELEV, record the rear sight
elevation knob setting for the yard line firing from.

--- chunk_id: chunk-0273
source_document: MCRP3-01A.pdf
page: 111
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 232
content_hash: b68ad98faa7fc49e
prev_chunk_id: chunk-0272
next_chunk_id: chunk-0274
document_type: technical_reference

Front Elevation
Under the column FRONT ELEV, record the final ele-
vation setting made on the front sight post. Rear Elevation
Under the column REAR ELEV, record the rear sight
elevation knob setting for the yard line firing from. Note
If firing from 500 yards, record the final el-
evation setting made on the rear sight ele-
vation knob. Wind
Under the column WIND under ZERO, record final
windage setting made on the rear sight windage knob. Wind
Calculate the prevailing wind during the string of fire. Direction
Determine the direction of the wind and draw an arrow
through the clock indicating the direction the wind is
blowing. Note
Remember that your position is represented
in the center of the clock and the target is at
12 o’clock. Value
Look at the clock to determine if the wind is full, half,
or no value wind. Under VALUE, circle FULL or
HALF to indicate the wind value. Speed
Observe the flag on the range and circle the appropri-
ate flag indicating the wind's velocity (SPEED).

--- chunk_id: chunk-0274
source_document: MCRP3-01A.pdf
page: 112
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 313
content_hash: 6ef79e4c75512164
prev_chunk_id: chunk-0273
next_chunk_id: chunk-0275
document_type: technical_reference

A-6 _______________________________________________________________________________________________ MCRP 3-01A
Determine Windage Adjustment
The chart beneath the flag indicates the number of
clicks on the rear sight windage knob to offset the ef-
fects of the wind. Circle the number of clicks where
the wind value and wind speed intersect. True Zero
A true zero is the established zero without the windage
adjustments to compensate for the effects of the string
of fire's wind. A true zero is calculated because, the
next time you fire, the wind conditions will probably
be different. Therefore, the rear sight windage knob
adjustments made to compensate for the string of fire's
wind will not be the correct setting for wind conditions
on other strings of fire or other days of firing. Front Elevation and Rear Elevation
Because elevation adjustments are not affected by
wind, the same settings are carried over from ZERO. Wind
Calculate the windage adjustment to compensate for
the string of fire's wind conditions the same way it was
calculated in the BEFORE FIRING information of the
data book. The only exception is now windage adjust-
ments are being removed from the rifle rather than
added to the rifle. Because the windage setting is being
removed from the rifle, remove the number of clicks
of windage right or left from the ZERO windage set-
ting. Once the windage setting is determined, record it
in the WIND column. Figure A-4. Recording Data After Firing.

--- chunk_id: chunk-0275
source_document: MCRP3-01A.pdf
page: 112
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 18
content_hash: a9008d203a0fb6e2
prev_chunk_id: chunk-0274
next_chunk_id: chunk-0276
section_heading: Figures
document_type: technical_reference

## Figures

![Figure A-4. Recording Data After Firing.](images/p112_img00.jpeg)
*Figure A-4. Recording Data After Firing.*

--- chunk_id: chunk-0276
source_document: MCRP3-01A.pdf
page: 113
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 4
content_hash: 15e9352d3eb4533f
prev_chunk_id: chunk-0275
next_chunk_id: chunk-0277
section_heading: APPENDIX B
document_type: technical_reference

APPENDIX B
GLOSSARY

--- chunk_id: chunk-0277
source_document: MCRP3-01A.pdf
page: 113
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 528
content_hash: 25e75a1a4ed089ac
prev_chunk_id: chunk-0276
next_chunk_id: chunk-0278
section_heading: SECTION I. ACRONYMS
document_type: technical_reference

SECTION I. ACRONYMS
BZO. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . battlesight zero
CLP . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .cleaner, lubricant, and preservative
KD. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . known distance
LAW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .lubricating oil, arctic weapons
NBC. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . nuclear, biological, and chemical
ROE. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .rules of engagement
SOP . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .standing operating procedures
TM. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . technical manual

--- chunk_id: chunk-0278
source_document: MCRP3-01A.pdf
page: 114
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 5
content_hash: b0dfd2930dff6285
prev_chunk_id: chunk-0277
next_chunk_id: chunk-0279
document_type: technical_reference

B-2 _______________________________________________________________________________________________ MCRP 3-01A

--- chunk_id: chunk-0279
source_document: MCRP3-01A.pdf
page: 114
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 381
content_hash: 3c2d009d43af9d4e
prev_chunk_id: chunk-0278
next_chunk_id: chunk-0280
section_heading: SECTION II. DEFINITIONS
document_type: technical_reference

SECTION II. DEFINITIONS
A
aiming point – The aiming point is the precise point where the tip of the front sight
post is placed in relationship to the target. alibi – Any condition caused by the weapon, ammunition, or range operation that caus-
es the shooter not to have an equal opportunity to complete a string of fire as all other
shooters on the range. B
battlesight zero (BZO) – The elevation and windage settings required to engage point
targets from 0-300 yards/meters under ideal weather conditions (i.e., no wind). bone support – The body's skeletal structure supporting the rifle's weight. breath control – Procedure used to fire the rifle at the moment of least movement in
the body and the rifle. C
canting – An angular deviation of the weapon to the left or right from a vertical posi-
tion during firing. center of mass – A point that is horizontally and vertically centered on the target. center of mass hold – The placement of the tip of the front sight on the target center of
mass prior to the shot breaking. centerline of the bore – An imaginary straight line beginning at the chamber end of the
barrel and proceeding out of the muzzle. chamber check – Procedure used to determine a weapon's condition. D
double feed – Attempted simultaneous feeding of two or more rounds from the maga-
zine. dry fire – Cocking, aiming, and squeezing the trigger of an unloaded rifle in order to
practice the fundamentals of marksmanship. detailed search – Method for conducting a systematic search of an area for specific tar-
get indicators. E
eye relief – The distance between from the rear sight aperture to the aiming eye.

--- chunk_id: chunk-0280
source_document: MCRP3-01A.pdf
page: 115
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 369
content_hash: ed6226e098646174
prev_chunk_id: chunk-0279
next_chunk_id: chunk-0281
document_type: technical_reference

Rifle Marksmanship ______________________________________________________________________________________ B-3
F
function check – Procedure used to ensure the selector lever operates properly. flag method – Procedure used to determine wind velocity and direction on a Known
Distance (KD) range. field expedient battlesight zeroing – Process used to zero the rifle at 36 yards or 30
meters when a 300-yard/-meter range is not available. G
gas operated – A self-loading firearm that utilizes the expanding force of the propel-
lant’s gases to operate the action of the weapon. H
hasty search – Method for quickly searching an area for enemy activity. hasty sight setting – A zero established for distances out to 800 yards/meters. I
immediate threat target – A target engaged at a short range (50 meters or less) with
little or no warning. initial sight setting – Sight setting placed on a rifle that serves as the starting point
from which all sight adjustments are made for the initial zeroing process. L
limited technical inspection (LTI) – An inspection performed by an armorer on a
weapon to determine its operational status (safety and function, not accuracy). line of sight – An imaginary line extending from the shooter's eye through the rifle's
sights and onto an aiming point on a target. load – Command/Procedure used to take a weapon from Condition 4 to Condition 3 by
inserting a magazine with rounds. M
magazine – A container that holds ammunition in a position to be chambered. magazine fed – A mechanical, automatic means of supplying a firearm with ammuni-
tion to be chambered. make ready – Command/Procedure used to take a weapon from Condition 3 to Condi-
tion 1 by chambering a round.

--- chunk_id: chunk-0281
source_document: MCRP3-01A.pdf
page: 116
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 434
content_hash: 031ca50bface7f40
prev_chunk_id: chunk-0280
next_chunk_id: chunk-0282
document_type: technical_reference

B-4 _______________________________________________________________________________________________ MCRP 3-01A
muscular relaxation – The state of tension required to properly control the rifle. The
shooter's muscles are in a relaxed state of control—tightened but not tensed. N
natural point of aim – The location at which the rifle's sights settle if bone support and
muscular relaxation are achieved. O
observation method – Procedure used to determine wind velocity and direction in a
tactical situation. P
pie technique – A technique used to locate and engage targets from behind cover,
while minimizing the Marines exposure to enemy fire. R
range – 1. A designated place where live fire weapons training is conducted. 2. The
horizontal distance to which a projectile can be propelled to a specified target. 3. The
horizontal distance between a weapon and target. recoil management – The ability to manage or control the recoil of the rifle for a given
shooting position. rollout – A technique used to locate and engage targets from behind cover, while mini-
mizing the Marines exposure to enemy fire. S
semiautomatic – One full cycle of operation. The firing, extraction, and ejection of the
spent cartridge, the cocking of the weapon and chambering of the succeeding round of
ammunition after the trigger is pulled. shooter error — Any action induced by the shooter that causes the weapon to fail to
operate properly or miss the intended target. sight alignment – The placement of the tip of the front sight post in the center of the
rear sight aperture. sight picture — The placement of the tip of the front sight post in the center of the tar-
get while maintaining sight alignment. sling – When properly attached to the rifle, the sling provides maximum stability for
the weapon and helps reduce the effects of the rifle's recoil. Also used for individual
weapon transport. stability of hold – The ability to acquire a stable position and to hold the rifle steady for
any given rifle position.

--- chunk_id: chunk-0282
source_document: MCRP3-01A.pdf
page: 117
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 396
content_hash: 6d6143abc64a1a87
prev_chunk_id: chunk-0281
next_chunk_id: null
document_type: technical_reference

Rifle Marksmanship ______________________________________________________________________________________ B-5
stock weld – The firm, consistent contact of the cheek with the weapon's buttstock. stoppage – Any condition that causes the rifle to fail to fire. T
target indicators – Anything that reveals the enemy's position. trajectory – The path of a projectile through the air and to a target. triangulation process – Process used to determine the vertical and horizontal sight ad-
justments that must be made to center a shot group. trigger control – The skillful manipulation of the trigger that causes the rifle to fire
without disturbing sight alignment or sight picture. U
unload – Command/Procedure used to take a weapon from any condition to Condi-
tion 4. unload and show clear – Command/Procedure used to take a weapon from any condi-
tion to Condition 4 while requiring a second individual to check the weapon to verify
that no ammunition is present. user serviceability inspection – Procedure used to ensure a weapon is in an acceptable
operating condition, conducted by the shooter. V
velocity – Speed at which the projectile travels. W
weapons carry – Procedure used to effectively handle the rifle while remaining alert to
possible threat levels. weapons condition – Describes a weapon's readiness for live fire. weapons transport – Procedure used to carry the rifle for long periods of time and
when one or both hands are needed for other work. windage and elevation rules – Rules that define how far the strike of the round will
move on the target for each click of front and rear sight elevation or rear sight windage
for each 100 yards/meters of range to the target. Z
zeroing – The process used to adjust the rifle sights that cause it to shoot to point of aim
at a desired range.
