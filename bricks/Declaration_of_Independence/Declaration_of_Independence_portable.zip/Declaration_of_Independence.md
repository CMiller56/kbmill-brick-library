---
kb_id: declaration-of-independence-us-founding-documents
title: Declaration of Independence — US Founding Documents
author: Unknown Author
created_date: 2026-08-05
classification: Internal
confidence_level: High
domain_tags: ["security", "rmf", "ato", "general"]
entity_mentions: ["System of"]
document_type: Technical Reference
primary_subject: Declaration of Independence 1776
sources: [{"filename": "Declaration_of_Independence.md", "path": "docs/library/US_Founding_Documents/Declaration_of_Independence/Declaration_of_Independence.md", "page_count": 1}]
ingest_provenance: {"captured_at": "2026-08-05T18:32:51.555619", "page_count": 1, "extraction_methods": {"txt": 1}, "avg_extraction_quality": 1.0, "docling_triage_pages": 0, "docling_triage_rate": 0.0, "extraction_stats": null}
dark_data_inferred_fields: ["author", "classification", "confidence_level", "created_date", "document_type", "document_type_confidence", "document_type_inferred", "domain_tags", "entity_mentions", "ingest_provenance", "kb_id", "sources"]
brick_role: Public-domain Declaration of Independence (1776). Series: US Founding Documents. Primary charter of independence.
usage_notes: Use for independence, grievances, self-government language. Not legal advice. Pair with US_Constitution and Federalist_Papers on the series shelf.
out_of_scope: ["Modern legal advice or litigation strategy", "Current statutory code or case law holdings", "Copyrighted modern commentary or textbooks"]
series: US Founding Documents
document_type_inferred: True
document_type_confidence: 0.556
kb_name: Declaration_of_Independence
created: 2026-08-05T18:32:51.555711
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 6
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-08-05T18:33:03.722009
  chunk_count: 6
  strict_air_gapped: true
---

--- chunk_id: chunk-0000
source_document: Declaration_of_Independence.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 48
content_hash: 0e02b9762fd63fc9
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: The Declaration of Independence
document_type: technical_reference

# The Declaration of Independence

**Series:** US Founding Documents  
**Instrument:** Declaration of Independence (1776)  
**Provenance:** Public domain text via Project Gutenberg eBook #1 (transcription of the Declaration). **Out of scope:** Modern legal advice; contemporary commentary. ---

--- chunk_id: chunk-0001
source_document: Declaration_of_Independence.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 500
content_hash: 73dba9834828d3d1
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
section_heading: Declaration of Independence
document_type: technical_reference

## Declaration of Independence

IN CONGRESS, July 4, 1776

The unanimous Declaration of the thirteen united States of America

When in the Course of human events, it becomes necessary for one people
to dissolve the political bands which have connected them with another,
and to assume, among the Powers of the earth, the separate and equal
station to which the Laws of Nature and of Nature’s God entitle them,
a decent respect to the opinions of mankind requires that they should
declare the causes which impel them to the separation. We hold these truths to be self-evident, that all men are created
equal, that they are endowed by their Creator with certain unalienable
Rights, that among these are Life, Liberty, and the pursuit of
Happiness. That to secure these rights, Governments are instituted
among Men, deriving their just powers from the consent of the governed,
That whenever any Form of Government becomes destructive of these
ends, it is the Right of the People to alter or to abolish it, and to
institute new Government, laying its foundation on such principles
and organizing its powers in such form, as to them shall seem most
likely to effect their Safety and Happiness. Prudence, indeed, will
dictate that Governments long established should not be changed for
light and transient causes; and accordingly all experience hath shown,
that mankind are more disposed to suffer, while evils are sufferable,
than to right themselves by abolishing the forms to which they are
accustomed. But when a long train of abuses and usurpations, pursuing
invariably the same Object evinces a design to reduce them under
absolute Despotism, it is their right, it is their duty, to throw off
such Government, and to provide new Guards for their future security. --Such has been the patient sufferance of these Colonies; and such is
now the necessity which constrains them to alter their former Systems
of Government. The history of the present King of Great Britain is a
history of repeated injuries and usurpations, all having in direct
object the establishment of an absolute Tyranny over these States. To
prove this, let Facts be submitted to a candid world. He has refused his Assent to Laws, the most wholesome and necessary for
the public good.

--- chunk_id: chunk-0002
source_document: Declaration_of_Independence.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 446
content_hash: a3ce3657677f4a04
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: Declaration of Independence
document_type: technical_reference

To
prove this, let Facts be submitted to a candid world. He has refused his Assent to Laws, the most wholesome and necessary for
the public good. He has forbidden his Governors to pass Laws of immediate and pressing
importance, unless suspended in their operation till his Assent should
be obtained; and when so suspended, he has utterly neglected to attend
to them. He has refused to pass other Laws for the accommodation of large
districts of people, unless those people would relinquish the right
of Representation in the Legislature, a right inestimable to them and
formidable to tyrants only. He has called together legislative bodies at places unusual,
uncomfortable, and distant from the depository of their Public Records,
for the sole purpose of fatiguing them into compliance with his
measures. He has dissolved Representative Houses repeatedly, for opposing with
manly firmness his invasions on the rights of the people. He has refused for a long time, after such dissolutions, to cause
others to be elected; whereby the Legislative Powers, incapable of
Annihilation, have returned to the People at large for their exercise;
the State remaining in the mean time exposed to all the dangers of
invasion from without, and convulsions within. He has endeavoured to prevent the population of these States; for that
purpose obstructing the Laws of Naturalization of Foreigners; refusing
to pass others to encourage their migration hither, and raising the
conditions of new Appropriations of Lands. He has obstructed the Administration of Justice, by refusing his Assent
to Laws for establishing Judiciary Powers. He has made judges dependent on his Will alone, for the tenure of their
offices, and the amount and payment of their salaries. He has erected a multitude of New Offices, and sent hither swarms of
Officers to harass our People, and eat out their substance. He has kept among us, in times of peace, Standing Armies without the
Consent of our legislatures. He has affected to render the Military independent of and superior to
the Civil Power.

--- chunk_id: chunk-0003
source_document: Declaration_of_Independence.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 486
content_hash: 046ff03f7ed8d604
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: Declaration of Independence
document_type: technical_reference

He has kept among us, in times of peace, Standing Armies without the
Consent of our legislatures. He has affected to render the Military independent of and superior to
the Civil Power. He has combined with others to subject us to a jurisdiction foreign to
our constitution, and unacknowledged by our laws; giving his Assent to
their Acts of pretended legislation:

For quartering large bodies of armed troops among us:

For protecting them, by a mock Trial, from Punishment for any Murders
which they should commit on the Inhabitants of these States:

For cutting off our Trade with all parts of the world:

For imposing taxes on us without our Consent:

For depriving us, in many cases, of the benefits of Trial by Jury:

For transporting us beyond Seas to be tried for pretended offences:

For abolishing the free System of English Laws in a neighbouring
Province, establishing therein an Arbitrary government, and enlarging
its Boundaries so as to render it at once an example and fit instrument
for introducing the same absolute rule into these Colonies:

For taking away our Charters, abolishing our most valuable Laws, and
altering fundamentally the Forms of our Governments:

For suspending our own Legislatures, and declaring themselves invested
with Power to legislate for us in all cases whatsoever. He has abdicated Government here, by declaring us out of his Protection
and waging War against us. He has plundered our seas, ravaged our Coasts, burnt our towns, and
destroyed the lives of our people. He is at this time transporting large armies of foreign mercenaries
to compleat the works of death, desolation and tyranny, already begun
with circumstances of Cruelty & perfidy scarcely paralleled in the most
barbarous ages, and totally unworthy of the Head of a civilized nation. He has constrained our fellow Citizens taken Captive on the high Seas
to bear Arms against their Country, to become the executioners of their
friends and Brethren, or to fall themselves by their Hands. He has excited domestic insurrections amongst us, and has endeavoured
to bring on the inhabitants of our frontiers, the merciless Indian
Savages, whose known rule of warfare, is an undistinguished destruction
of all ages, sexes and conditions.

--- chunk_id: chunk-0004
source_document: Declaration_of_Independence.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 489
content_hash: 6545a788cbe0a241
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: Declaration of Independence
document_type: technical_reference

He has constrained our fellow Citizens taken Captive on the high Seas
to bear Arms against their Country, to become the executioners of their
friends and Brethren, or to fall themselves by their Hands. He has excited domestic insurrections amongst us, and has endeavoured
to bring on the inhabitants of our frontiers, the merciless Indian
Savages, whose known rule of warfare, is an undistinguished destruction
of all ages, sexes and conditions. In every stage of these Oppressions We have Petitioned for Redress in
the most humble terms: Our repeated Petitions have been answered only
by repeated injury. A Prince, whose character is thus marked by every
act which may define a Tyrant, is unfit to be the ruler of a free
People. Nor have We been wanting in attention to our British brethren. We have
warned them from time to time of attempts by their legislature to
extend an unwarrantable jurisdiction over us. We have reminded them
of the circumstances of our emigration and settlement here. We have
appealed to their native justice and magnanimity, and we have conjured
them by the ties of our common kindred to disavow these usurpations,
which would inevitably interrupt our connections and correspondence. They too have been deaf to the voice of justice and of consanguinity. We must, therefore, acquiesce in the necessity, which denounces our
Separation, and hold them, as we hold the rest of mankind, Enemies in
War, in Peace Friends. We, therefore, the Representatives of the United States of America,
in General Congress, Assembled, appealing to the Supreme Judge of the
world for the rectitude of our intentions, do, in the Name, and by the
Authority of the good People of these Colonies, solemnly publish and
declare, That these United Colonies are, and of Right ought to be Free
and Independent States; that they are Absolved from all Allegiance to
the British Crown, and that all political connection between them and
the State of Great Britain, is and ought to be totally dissolved; and
that as Free and Independent States, they have full Power to levy War,
conclude Peace, contract Alliances, establish Commerce, and to do all
other Acts and Things which Independent States may of right do.

--- chunk_id: chunk-0005
source_document: Declaration_of_Independence.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 461
content_hash: beb00c886eaecb8c
prev_chunk_id: chunk-0004
next_chunk_id: null
section_heading: Declaration of Independence
document_type: technical_reference

We must, therefore, acquiesce in the necessity, which denounces our
Separation, and hold them, as we hold the rest of mankind, Enemies in
War, in Peace Friends. We, therefore, the Representatives of the United States of America,
in General Congress, Assembled, appealing to the Supreme Judge of the
world for the rectitude of our intentions, do, in the Name, and by the
Authority of the good People of these Colonies, solemnly publish and
declare, That these United Colonies are, and of Right ought to be Free
and Independent States; that they are Absolved from all Allegiance to
the British Crown, and that all political connection between them and
the State of Great Britain, is and ought to be totally dissolved; and
that as Free and Independent States, they have full Power to levy War,
conclude Peace, contract Alliances, establish Commerce, and to do all
other Acts and Things which Independent States may of right do. And for
the support of this Declaration, with a firm reliance on the Protection
of Divine Providence, we mutually pledge to each other our Lives, our
Fortunes and our sacred Honor. *** END OF THE PROJECT GUTENBERG EBOOK THE DECLARATION OF INDEPENDENCE OF THE UNITED STATES OF AMERICA ***


    

Updated editions will replace the previous one—the old editions will
be renamed. Creating the works from print editions not protected by U.S. copyright
law means that no one owns a United States copyright in these works,
so the Foundation (and you!) can copy and distribute it in the United
States without permission and without paying copyright
royalties. Special rules, set forth in the General Terms of Use part
of this license, apply to copying and distributing Project
Gutenberg™ electronic works to protect the PROJECT GUTENBERG™
concept and trademark. Project Gutenberg is a registered trademark,
and may not be used if you charge for an eBook, except by following
the terms of the trademark license, including paying royalties for use
of the Project Gutenberg trademark. If you do not charge anything for
copies of this eBook, complying with the trademark license is ve
