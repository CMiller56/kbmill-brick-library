---
kb_id: hr-9442-introduced-in-house-ih
title: H.R. 9442 Introduced in House (IH)
author: Unknown Author
created_date: 2026-09-16
classification: Internal
confidence_level: High
domain_tags: ["general"]
document_type: Technical Reference
primary_subject: Be it enacted by the Senate and House of Representatives of the
United States of America in Congress assembled,
sources: [{"filename": "BILLS-119hr9442ih.md", "path": "kbs/_ingest_jobs/HR9442_AI_Data_Center_Moratorium_119IH/md_clean/BILLS-119hr9442ih.md", "page_count": 1}]
ingest_provenance: {"captured_at": "2026-09-16T11:19:21.111493", "page_count": 1, "extraction_methods": {"txt": 1}, "avg_extraction_quality": 1.0, "docling_triage_pages": 0, "docling_triage_rate": 0.0, "extraction_stats": null}
dark_data_inferred_fields: ["author", "classification", "confidence_level", "created_date", "document_type", "document_type_confidence", "document_type_inferred", "domain_tags", "ingest_provenance", "kb_id", "primary_subject", "sources", "title"]
kb_name: HR9442_AI_Data_Center_Moratorium_119IH
document_type_inferred: True
document_type_confidence: 0.574
kb_name: HR9442_AI_Data_Center_Moratorium_119IH
created: 2026-09-16T11:19:21.111581
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 10
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-09-16T11:19:26.001415
  chunk_count: 12
  strict_air_gapped: true
---

--- chunk_id: chunk-0000
source_document: BILLS-119hr9442ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 132
content_hash: db276c78d0f056c1
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: H.R. 9442 Introduced in House (IH)
document_type: technical_reference

## H.R. 9442 Introduced in House (IH)

Be it enacted by the Senate and House of Representatives of the
United States of America in Congress assembled,

### SECTION 1. Short Title. This Act may be cited as the ``Artificial Intelligence Data Center
Moratorium Act''. ### SEC. 2. Findings. Congress finds that--
            (1) leading experts and industry leaders have warned about
        catastrophic consequences from unchecked artificial
        intelligence development and deployment, including--
                    (A) Elon Musk, the wealthiest person alive, and
                worth $826,600,000,000 as of the date of introduction
                of this Act, who stated that ``AI and robots will
                replace all jobs.

--- chunk_id: chunk-0001
source_document: BILLS-119hr9442ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 473
content_hash: b722561c14ed2a02
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
section_heading: H.R. 9442 Introduced in House (IH)
document_type: technical_reference

Findings. Congress finds that--
            (1) leading experts and industry leaders have warned about
        catastrophic consequences from unchecked artificial
        intelligence development and deployment, including--
                    (A) Elon Musk, the wealthiest person alive, and
                worth $826,600,000,000 as of the date of introduction
                of this Act, who stated that ``AI and robots will
                replace all jobs. Working will be optional.'' and that
                artificial intelligence is akin to ``summoning the
                demon'';
                    (B) Dario Amodei, the CEO of Anthropic, who
                predicted that ``AI could displace half of all entry-
                level white collar jobs in the next 1 to 5 years.'' and
                that ``humanity is about to be handed almost
                unimaginable power, and it is deeply unclear whether
                our social, political, and technological systems
                possess the maturity to wield it.'';
                    (C) Demis Hassabis, the head of Google's Deepmind,
                who stated that the AI revolution will be 10 times
                bigger than the industrial revolution and 10 times
                faster;
                    (D) Jeff Bezos, the fourth-richest person in the
                world and worth $233,000,000,000 as of the date of
                introduction of this Act, who has reportedly pushed his
                staff for years to think big and envision what it would
                take for Amazon to fully automate its operations with
                plans to replace at least 600,000 warehouse workers
                with robots;
                    (E) Bill Gates, worth $101,000,000,000 as of the
                date of introduction of this Act, who predicted that
                humans ``won't be needed for most things,'' such as
                manufacturing products, delivering packages, or growing
                food over the next decade due to artificial
                intelligence;
                    (F) Mustafa Suleyman, the CEO of Microsoft AI, who
                said that most white-collar work ``will be fully
                automated by an AI within the next 12 to 18 months'';
                    (G) Jim Farley, the CEO of Ford, who predicted that
                artificial intelligence will eliminate ``literally half
                of all white-collar jobs in the U.S.'' within the next
                decade;
                    (H) Larry Ellison, the sixth-richest person in the
                world and worth $203,000,000,000 as of the date of
                introduction of this Act, who said that there will be
                an artificial intelligence-powered surveillance state
                where ``citizens will be on their best behavior,
                because we're constantly recording and reporting
                everything that is going on.'';
                    (I) Dr.

--- chunk_id: chunk-0002
source_document: BILLS-119hr9442ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 654
content_hash: 32a25e539d8b1cd7
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: H.R. 9442 Introduced in House (IH)
document_type: technical_reference

Congress finds that--
            (1) leading experts and industry leaders have warned about
        catastrophic consequences from unchecked artificial
        intelligence development and deployment, including--
                    (A) Elon Musk, the wealthiest person alive, and
                worth $826,600,000,000 as of the date of introduction
                of this Act, who stated that ``AI and robots will
                replace all jobs. Working will be optional.'' and that
                artificial intelligence is akin to ``summoning the
                demon'';
                    (B) Dario Amodei, the CEO of Anthropic, who
                predicted that ``AI could displace half of all entry-
                level white collar jobs in the next 1 to 5 years.'' and
                that ``humanity is about to be handed almost
                unimaginable power, and it is deeply unclear whether
                our social, political, and technological systems
                possess the maturity to wield it.'';
                    (C) Demis Hassabis, the head of Google's Deepmind,
                who stated that the AI revolution will be 10 times
                bigger than the industrial revolution and 10 times
                faster;
                    (D) Jeff Bezos, the fourth-richest person in the
                world and worth $233,000,000,000 as of the date of
                introduction of this Act, who has reportedly pushed his
                staff for years to think big and envision what it would
                take for Amazon to fully automate its operations with
                plans to replace at least 600,000 warehouse workers
                with robots;
                    (E) Bill Gates, worth $101,000,000,000 as of the
                date of introduction of this Act, who predicted that
                humans ``won't be needed for most things,'' such as
                manufacturing products, delivering packages, or growing
                food over the next decade due to artificial
                intelligence;
                    (F) Mustafa Suleyman, the CEO of Microsoft AI, who
                said that most white-collar work ``will be fully
                automated by an AI within the next 12 to 18 months'';
                    (G) Jim Farley, the CEO of Ford, who predicted that
                artificial intelligence will eliminate ``literally half
                of all white-collar jobs in the U.S.'' within the next
                decade;
                    (H) Larry Ellison, the sixth-richest person in the
                world and worth $203,000,000,000 as of the date of
                introduction of this Act, who said that there will be
                an artificial intelligence-powered surveillance state
                where ``citizens will be on their best behavior,
                because we're constantly recording and reporting
                everything that is going on.'';
                    (I) Dr. Geoffrey Hinton, considered to be the
                ``godfather'' of artificial intelligence, who stated
                that he believes there is a ``10 to 20 percent chance
                [for artificial intelligence] to wipe us out.''; and
                    (J) Mark Zuckerberg, the fifth-richest person in
                the world and worth $214,000,000,000 as of the date of
                introduction of this Act, is building a data center in
                the State of Louisiana that is the size of Manhattan
                and will use 3 times the quantity of electricity that
                the entire city of New Orleans uses every year; and
            (2) leading experts and the heads of the major artificial
        intelligence companies have called for regulation and
        reasonable pauses to the development of artificial intelligence
        to ensure the safety of humanity, including--
                    (A) Elon Musk, the head of xAI, who stated--
                            (i) in 2018 the following: ``Mark my words.

--- chunk_id: chunk-0003
source_document: BILLS-119hr9442ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 596
content_hash: 9fd95250d9418d01
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: H.R. 9442 Introduced in House (IH)
document_type: technical_reference

Working will be optional.'' and that
                artificial intelligence is akin to ``summoning the
                demon'';
                    (B) Dario Amodei, the CEO of Anthropic, who
                predicted that ``AI could displace half of all entry-
                level white collar jobs in the next 1 to 5 years.'' and
                that ``humanity is about to be handed almost
                unimaginable power, and it is deeply unclear whether
                our social, political, and technological systems
                possess the maturity to wield it.'';
                    (C) Demis Hassabis, the head of Google's Deepmind,
                who stated that the AI revolution will be 10 times
                bigger than the industrial revolution and 10 times
                faster;
                    (D) Jeff Bezos, the fourth-richest person in the
                world and worth $233,000,000,000 as of the date of
                introduction of this Act, who has reportedly pushed his
                staff for years to think big and envision what it would
                take for Amazon to fully automate its operations with
                plans to replace at least 600,000 warehouse workers
                with robots;
                    (E) Bill Gates, worth $101,000,000,000 as of the
                date of introduction of this Act, who predicted that
                humans ``won't be needed for most things,'' such as
                manufacturing products, delivering packages, or growing
                food over the next decade due to artificial
                intelligence;
                    (F) Mustafa Suleyman, the CEO of Microsoft AI, who
                said that most white-collar work ``will be fully
                automated by an AI within the next 12 to 18 months'';
                    (G) Jim Farley, the CEO of Ford, who predicted that
                artificial intelligence will eliminate ``literally half
                of all white-collar jobs in the U.S.'' within the next
                decade;
                    (H) Larry Ellison, the sixth-richest person in the
                world and worth $203,000,000,000 as of the date of
                introduction of this Act, who said that there will be
                an artificial intelligence-powered surveillance state
                where ``citizens will be on their best behavior,
                because we're constantly recording and reporting
                everything that is going on.'';
                    (I) Dr. Geoffrey Hinton, considered to be the
                ``godfather'' of artificial intelligence, who stated
                that he believes there is a ``10 to 20 percent chance
                [for artificial intelligence] to wipe us out.''; and
                    (J) Mark Zuckerberg, the fifth-richest person in
                the world and worth $214,000,000,000 as of the date of
                introduction of this Act, is building a data center in
                the State of Louisiana that is the size of Manhattan
                and will use 3 times the quantity of electricity that
                the entire city of New Orleans uses every year; and
            (2) leading experts and the heads of the major artificial
        intelligence companies have called for regulation and
        reasonable pauses to the development of artificial intelligence
        to ensure the safety of humanity, including--
                    (A) Elon Musk, the head of xAI, who stated--
                            (i) in 2018 the following: ``Mark my words. AI is far more dangerous than nukes.

--- chunk_id: chunk-0004
source_document: BILLS-119hr9442ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: d67b27a24691157e
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: H.R. 9442 Introduced in House (IH)
document_type: technical_reference

Geoffrey Hinton, considered to be the
                ``godfather'' of artificial intelligence, who stated
                that he believes there is a ``10 to 20 percent chance
                [for artificial intelligence] to wipe us out.''; and
                    (J) Mark Zuckerberg, the fifth-richest person in
                the world and worth $214,000,000,000 as of the date of
                introduction of this Act, is building a data center in
                the State of Louisiana that is the size of Manhattan
                and will use 3 times the quantity of electricity that
                the entire city of New Orleans uses every year; and
            (2) leading experts and the heads of the major artificial
        intelligence companies have called for regulation and
        reasonable pauses to the development of artificial intelligence
        to ensure the safety of humanity, including--
                    (A) Elon Musk, the head of xAI, who stated--
                            (i) in 2018 the following: ``Mark my words. AI is far more dangerous than nukes. So why do
                        we have no regulatory oversight? This is
                        insane.''; and
                            (ii) in 2025 that he had ``a lot of AI
                        nightmares'' and would ``certainly slow down AI
                        and robotics'' if he could;
                    (B) Demis Hassabis, the head of Google's Deepmind,
                who said in 2026 that he would support an AI pause if
                he knew other countries and companies also paused
                development;
                    (C) Dario Amodei, the head of Anthropic, who said
                in 2026 that he would be ``absolutely in favor of
                trying'' to slow down AI development if other countries
                also slowed down;
                    (D) Sam Altman, the head of OpenAI, who, in 2023,
                wrote that ``we need some degree of coordination among
                the leading development efforts to ensure that the
                development of superintelligence occurs in a manner
                that allows us to both maintain safety and help smooth
                integration of these systems with society'' and that
                ``an effective global regulatory framework including
                democratic governance'' is needed;
                    (E) more than 1,000 business leaders in the Big
                Tech industry, prominent scientists, and artificial
                intelligence researchers and academics, including Elon
                Musk, Steve Wozniak (co-founder of Apple), and Evan
                Sharp (co-founder of Pinterest), who, in March 2023,
                cosigned an open letter entitled ``Pause Giant AI
                Experiments'' which stated the following: ``We must ask
                ourselves: Should we let machines flood our information
                channels with propaganda and untruth? Should we
                automate away all the jobs, including the fulfilling
                ones?

--- chunk_id: chunk-0005
source_document: BILLS-119hr9442ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 474
content_hash: 3552ecda6907c124
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
section_heading: H.R. 9442 Introduced in House (IH)
document_type: technical_reference

This is
                        insane.''; and
                            (ii) in 2025 that he had ``a lot of AI
                        nightmares'' and would ``certainly slow down AI
                        and robotics'' if he could;
                    (B) Demis Hassabis, the head of Google's Deepmind,
                who said in 2026 that he would support an AI pause if
                he knew other countries and companies also paused
                development;
                    (C) Dario Amodei, the head of Anthropic, who said
                in 2026 that he would be ``absolutely in favor of
                trying'' to slow down AI development if other countries
                also slowed down;
                    (D) Sam Altman, the head of OpenAI, who, in 2023,
                wrote that ``we need some degree of coordination among
                the leading development efforts to ensure that the
                development of superintelligence occurs in a manner
                that allows us to both maintain safety and help smooth
                integration of these systems with society'' and that
                ``an effective global regulatory framework including
                democratic governance'' is needed;
                    (E) more than 1,000 business leaders in the Big
                Tech industry, prominent scientists, and artificial
                intelligence researchers and academics, including Elon
                Musk, Steve Wozniak (co-founder of Apple), and Evan
                Sharp (co-founder of Pinterest), who, in March 2023,
                cosigned an open letter entitled ``Pause Giant AI
                Experiments'' which stated the following: ``We must ask
                ourselves: Should we let machines flood our information
                channels with propaganda and untruth? Should we
                automate away all the jobs, including the fulfilling
                ones? Should we develop nonhuman minds that might
                eventually outnumber, outsmart, obsolete and replace
                us? Should we risk loss of control of our civilization? Such decisions must not be delegated to unelected tech
                leaders. . .Therefore, we call on all AI labs to
                immediately pause for at least 6 months the training of
                AI systems more powerful than GPT-4. This pause should
                be public and verifiable, and include all key actors. If such a pause cannot be enacted quickly, governments
                should step in and institute a moratorium.''; and
                    (F) artificial intelligence pioneers Geoffrey
                Hinton and Yoshua Bengio and other technology leaders,
                who have called for ``a prohibition on the development
                of superintelligence, not lifted before there is broad
                scientific consensus that it will be done safely and
                controllably, and strong public buy-in''.

--- chunk_id: chunk-0006
source_document: BILLS-119hr9442ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 224
content_hash: 488c9f12aeefd522
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: SEC. 3. Moratorium On Construction Of New Artificial Intelligence Data Centers.
document_type: technical_reference

## SEC. 3. Moratorium On Construction Of New Artificial Intelligence Data Centers. (a) Definition of Artificial Intelligence Data Center.--In this
section, the term ``artificial intelligence data center'' means all the
buildings, equipment, structures, and other stationary items, such as
server racks, that--
            (1) are located on a single site or on contiguous,
        adjacent, or otherwise connected sites;
            (2) are owned or operated by the same entity or by any
        entity that controls, is controlled by, or is under the common
        control of that entity, regardless of whether the site is a
        single-occupant or multi-occupant facility; and
            (3)(A) are used for the development or operation of
        artificial intelligence models at scale; or
            (B)(i) have a maximum rated power capacity or total peak
        power load in excess of 20 megawatts; and
            (ii) are designed or equipped--
                    (I) to deliver 20 kilowatts or more of electrical
                power to a single server rack; or
                    (II) to utilize cooling systems that circulate
                liquid to individual hardware components or submerge
                electronic hardware in liquid.

--- chunk_id: chunk-0007
source_document: BILLS-119hr9442ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 608
content_hash: 449935fb4a1ecfbb
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: SEC. 3. Moratorium On Construction Of New Artificial Intelligence Data Centers.
document_type: technical_reference

Moratorium On Construction Of New Artificial Intelligence Data Centers. (a) Definition of Artificial Intelligence Data Center.--In this
section, the term ``artificial intelligence data center'' means all the
buildings, equipment, structures, and other stationary items, such as
server racks, that--
            (1) are located on a single site or on contiguous,
        adjacent, or otherwise connected sites;
            (2) are owned or operated by the same entity or by any
        entity that controls, is controlled by, or is under the common
        control of that entity, regardless of whether the site is a
        single-occupant or multi-occupant facility; and
            (3)(A) are used for the development or operation of
        artificial intelligence models at scale; or
            (B)(i) have a maximum rated power capacity or total peak
        power load in excess of 20 megawatts; and
            (ii) are designed or equipped--
                    (I) to deliver 20 kilowatts or more of electrical
                power to a single server rack; or
                    (II) to utilize cooling systems that circulate
                liquid to individual hardware components or submerge
                electronic hardware in liquid. (b) Moratorium.--Beginning on the date of enactment of this Act,
the construction or upgrading of new or existing artificial
intelligence data centers may not commence or proceed until--
            (1) 1 or more laws are enacted that ensure that--
                    (A) the Federal Government shall review and approve
                artificial intelligence products before those products
                are released, for the purpose of ensuring that those
                products are safe and effective and do not threaten the
                health and well-being of working families, privacy and
                civil rights, and the future of humanity;
                    (B) the economic gains of artificial intelligence
                and robotics will benefit workers, not just the wealthy
                owners of Big Tech companies, including by--
                            (i) putting policies in place to prevent
                        job displacement due to artificial
                        intelligence; and
                            (ii) ensuring the wealth generated by those
                        companies is shared with the people of the
                        United States; and
                    (C) with respect to any artificial intelligence
                data center built or upgraded after the termination of
                the moratorium under this subsection--
                            (i) the artificial intelligence data center
                        does not increase utility or electricity bills
                        of consumers;
                            (ii) the artificial intelligence data
                        center does not exacerbate the threat of
                        climate change or harm the environment;
                            (iii) communities that would be affected by
                        the artificial intelligence data center are
                        empowered to approve or reject the construction
                        or upgrading of that artificial intelligence
                        data center;
                            (iv) no government subsidy is provided for
                        the construction, upgrading, or operation of
                        that artificial intelligence data center; and
                            (v) the artificial intelligence data center
                        creates union jobs with strong labor standards,
                        including payment of prevailing wages and use
                        of registered apprenticeship programs and
                        project labor agreements; and
            (2) a provision in the 1 or more laws described in
        paragraph (1) expressly terminates the moratorium under this
        subsection.

--- chunk_id: chunk-0008
source_document: BILLS-119hr9442ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 644
content_hash: 43bf18c39b7c6cf1
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: SEC. 3. Moratorium On Construction Of New Artificial Intelligence Data Centers.
document_type: technical_reference

(a) Definition of Artificial Intelligence Data Center.--In this
section, the term ``artificial intelligence data center'' means all the
buildings, equipment, structures, and other stationary items, such as
server racks, that--
            (1) are located on a single site or on contiguous,
        adjacent, or otherwise connected sites;
            (2) are owned or operated by the same entity or by any
        entity that controls, is controlled by, or is under the common
        control of that entity, regardless of whether the site is a
        single-occupant or multi-occupant facility; and
            (3)(A) are used for the development or operation of
        artificial intelligence models at scale; or
            (B)(i) have a maximum rated power capacity or total peak
        power load in excess of 20 megawatts; and
            (ii) are designed or equipped--
                    (I) to deliver 20 kilowatts or more of electrical
                power to a single server rack; or
                    (II) to utilize cooling systems that circulate
                liquid to individual hardware components or submerge
                electronic hardware in liquid. (b) Moratorium.--Beginning on the date of enactment of this Act,
the construction or upgrading of new or existing artificial
intelligence data centers may not commence or proceed until--
            (1) 1 or more laws are enacted that ensure that--
                    (A) the Federal Government shall review and approve
                artificial intelligence products before those products
                are released, for the purpose of ensuring that those
                products are safe and effective and do not threaten the
                health and well-being of working families, privacy and
                civil rights, and the future of humanity;
                    (B) the economic gains of artificial intelligence
                and robotics will benefit workers, not just the wealthy
                owners of Big Tech companies, including by--
                            (i) putting policies in place to prevent
                        job displacement due to artificial
                        intelligence; and
                            (ii) ensuring the wealth generated by those
                        companies is shared with the people of the
                        United States; and
                    (C) with respect to any artificial intelligence
                data center built or upgraded after the termination of
                the moratorium under this subsection--
                            (i) the artificial intelligence data center
                        does not increase utility or electricity bills
                        of consumers;
                            (ii) the artificial intelligence data
                        center does not exacerbate the threat of
                        climate change or harm the environment;
                            (iii) communities that would be affected by
                        the artificial intelligence data center are
                        empowered to approve or reject the construction
                        or upgrading of that artificial intelligence
                        data center;
                            (iv) no government subsidy is provided for
                        the construction, upgrading, or operation of
                        that artificial intelligence data center; and
                            (v) the artificial intelligence data center
                        creates union jobs with strong labor standards,
                        including payment of prevailing wages and use
                        of registered apprenticeship programs and
                        project labor agreements; and
            (2) a provision in the 1 or more laws described in
        paragraph (1) expressly terminates the moratorium under this
        subsection. (c) Reports.--
            (1) In general.--The Secretary of Energy shall--
                    (A) submit to Congress quarterly reports on
                artificial intelligence data centers; and
                    (B) make those quarterly reports publicly available
                on the website of the Department of Energy.

--- chunk_id: chunk-0009
source_document: BILLS-119hr9442ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 696
content_hash: fd6e464bf22cd2f8
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
section_heading: SEC. 3. Moratorium On Construction Of New Artificial Intelligence Data Centers.
document_type: technical_reference

(b) Moratorium.--Beginning on the date of enactment of this Act,
the construction or upgrading of new or existing artificial
intelligence data centers may not commence or proceed until--
            (1) 1 or more laws are enacted that ensure that--
                    (A) the Federal Government shall review and approve
                artificial intelligence products before those products
                are released, for the purpose of ensuring that those
                products are safe and effective and do not threaten the
                health and well-being of working families, privacy and
                civil rights, and the future of humanity;
                    (B) the economic gains of artificial intelligence
                and robotics will benefit workers, not just the wealthy
                owners of Big Tech companies, including by--
                            (i) putting policies in place to prevent
                        job displacement due to artificial
                        intelligence; and
                            (ii) ensuring the wealth generated by those
                        companies is shared with the people of the
                        United States; and
                    (C) with respect to any artificial intelligence
                data center built or upgraded after the termination of
                the moratorium under this subsection--
                            (i) the artificial intelligence data center
                        does not increase utility or electricity bills
                        of consumers;
                            (ii) the artificial intelligence data
                        center does not exacerbate the threat of
                        climate change or harm the environment;
                            (iii) communities that would be affected by
                        the artificial intelligence data center are
                        empowered to approve or reject the construction
                        or upgrading of that artificial intelligence
                        data center;
                            (iv) no government subsidy is provided for
                        the construction, upgrading, or operation of
                        that artificial intelligence data center; and
                            (v) the artificial intelligence data center
                        creates union jobs with strong labor standards,
                        including payment of prevailing wages and use
                        of registered apprenticeship programs and
                        project labor agreements; and
            (2) a provision in the 1 or more laws described in
        paragraph (1) expressly terminates the moratorium under this
        subsection. (c) Reports.--
            (1) In general.--The Secretary of Energy shall--
                    (A) submit to Congress quarterly reports on
                artificial intelligence data centers; and
                    (B) make those quarterly reports publicly available
                on the website of the Department of Energy. (2) Contents.--A report submitted by the Secretary of
        Energy under paragraph (1) shall include, at a minimum, for the
        period covered by the report and with respect to each
        artificial intelligence data center--
                    (A) all financial vehicles involved in the
                operation of the artificial intelligence data center;
                    (B) the water usage of the artificial intelligence
                data center;
                    (C) the energy usage and infrastructure needs of
                the artificial intelligence data center;
                    (D) the on- and off-site greenhouse gas emissions
                of the artificial intelligence data center, including
                the results of fenceline air quality monitoring;
                    (E) the wastewater discharge and thermal outputs of
                the artificial intelligence data center;
                    (F) the cooling chemicals used at the artificial
                intelligence data center;
                    (G) the noise levels at the artificial intelligence
                data center;
                    (H) information on wages and benefits provided to
                workers at the artificial intelligence data center;
                    (I) the number of temporary and permanent jobs
                created at the artificial intelligence data center;
                    (J) agreements entered into by the artificial
                intelligence data center relating to land acquisitions,
                utilities, or government entities, if any; and
                    (K) a certification that the artificial
                intelligence data center has not utilized any Federal,
                State, or local subsidies.

--- chunk_id: chunk-0010
source_document: BILLS-119hr9442ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 369
content_hash: 408e0f407423d6a2
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
section_heading: SEC. 3. Moratorium On Construction Of New Artificial Intelligence Data Centers.
document_type: technical_reference

(c) Reports.--
            (1) In general.--The Secretary of Energy shall--
                    (A) submit to Congress quarterly reports on
                artificial intelligence data centers; and
                    (B) make those quarterly reports publicly available
                on the website of the Department of Energy. (2) Contents.--A report submitted by the Secretary of
        Energy under paragraph (1) shall include, at a minimum, for the
        period covered by the report and with respect to each
        artificial intelligence data center--
                    (A) all financial vehicles involved in the
                operation of the artificial intelligence data center;
                    (B) the water usage of the artificial intelligence
                data center;
                    (C) the energy usage and infrastructure needs of
                the artificial intelligence data center;
                    (D) the on- and off-site greenhouse gas emissions
                of the artificial intelligence data center, including
                the results of fenceline air quality monitoring;
                    (E) the wastewater discharge and thermal outputs of
                the artificial intelligence data center;
                    (F) the cooling chemicals used at the artificial
                intelligence data center;
                    (G) the noise levels at the artificial intelligence
                data center;
                    (H) information on wages and benefits provided to
                workers at the artificial intelligence data center;
                    (I) the number of temporary and permanent jobs
                created at the artificial intelligence data center;
                    (J) agreements entered into by the artificial
                intelligence data center relating to land acquisitions,
                utilities, or government entities, if any; and
                    (K) a certification that the artificial
                intelligence data center has not utilized any Federal,
                State, or local subsidies. (3) Verification.--The Secretary of Energy may obtain and
        verify information relating to the moratorium under subsection
        (b) and reporting requirements described in paragraph (2),
        including by--
                    (A) issuing subpoenas;
                    (B) requiring written interrogatories;
                    (C) conducting inspections; and
                    (D) conditioning future permitting on compliance
                with this section.

--- chunk_id: chunk-0011
source_document: BILLS-119hr9442ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 232
content_hash: f057405b960f0247
prev_chunk_id: chunk-0010
next_chunk_id: null
section_heading: SEC. 4. Export Controls On Computing Infrastructure Hardware.
document_type: technical_reference

## SEC. 4. Export Controls On Computing Infrastructure Hardware. (a) Definitions.--In this section:
            (1) Computing infrastructure hardware.--The term
        ``computing infrastructure hardware'' means semiconductors,
        integrated circuits, and products containing integrated
        circuits, including computers, networking equipment, and data
        storage systems. (2) Export; in-country transfer; reexport.--The terms
        ``export'', ``in-country transfer'', and ``reexport'' have the
        meanings given those terms in section 1742 of the Export
        Control Reform Act of 2018 (50 U.S.C. 4801). (b) Export Controls.--On and after the date of the enactment of
this Act, the Secretary of Commerce shall prohibit the export,
reexport, or in-country transfer of computing infrastructure hardware
for an end-use described in subsection (c)--
            (1) to or in any country that does not have in effect
        statutes or regulations that are comparable to the laws
        described in section 3(b)(1); or
            (2) to any person in a country described in paragraph (1). (c) End-Uses Described.--An end-use referred to in subsection (b)
is use--
            (1) in an artificial intelligence data center; or
            (2) otherwise in the training or deployment of artificial
        intelligence models at scale.
