---
kb_id: dronecan-protocol-dsdl-ap-periph-tools
title: DroneCAN — Protocol, DSDL, AP_Periph & Tools
author: Unknown Author
created_date: 2026-07-18
classification: Internal
confidence_level: High
domain_tags: ["dronecan", "uavcan", "can", "ap_periph", "sensors", "ardupilot"]
document_type: Technical Reference
primary_subject: DroneCAN (UAVCAN v0 for drones): specification, implementations, GUI, simple sensor node, ArduPilot AP_Periph
intended_audience: UAV integrators, sensor/peripheral developers, ArduPilot CAN users
sources: [{"filename": "Contact__index.md", "path": "docs/corpus/dronecan/structured_md/Contact__index.md", "page_count": 1}, {"filename": "Examples__Simple_sensor_node__index.md", "path": "docs/corpus/dronecan/structured_md/Examples__Simple_sensor_node__index.md", "page_count": 1}, {"filename": "Examples__index.md", "path": "docs/corpus/dronecan/structured_md/Examples__index.md", "page_count": 1}, {"filename": "GUI_Tool__Examples__index.md", "path": "docs/corpus/dronecan/structured_md/GUI_Tool__Examples__index.md", "page_count": 1}, {"filename": "GUI_Tool__Overview.md", "path": "docs/corpus/dronecan/structured_md/GUI_Tool__Overview.md", "page_count": 1}, {"filename": "GUI_Tool__User_guide.md", "path": "docs/corpus/dronecan/structured_md/GUI_Tool__User_guide.md", "page_count": 1}, {"filename": "Implementations__AP_Periph__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__AP_Periph__index.md", "page_count": 1}, {"filename": "Implementations__Libcanard__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libcanard__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__FAQ__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__FAQ__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Platforms__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Platforms__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Tutorials__1._Library_build_configuration__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Tutorials__1._Library_build_configuration__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Tutorials__10._Dynamic_node_ID_allocation__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Tutorials__10._Dynamic_node_ID_allocation__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Tutorials__11._Firmware_update__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Tutorials__11._Firmware_update__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Tutorials__12._Multithreading__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Tutorials__12._Multithreading__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Tutorials__13._CAN_acceptance_filters__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Tutorials__13._CAN_acceptance_filters__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Tutorials__2._Node_initialization_and_startup__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Tutorials__2._Node_initialization_and_startup__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Tutorials__3._Publishers_and_subscribers__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Tutorials__3._Publishers_and_subscribers__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Tutorials__4._Services__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Tutorials__4._Services__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Tutorials__5._Timers__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Tutorials__5._Timers__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Tutorials__6._Time_synchronization__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Tutorials__6._Time_synchronization__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Tutorials__7._Remote_node_reconfiguration__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Tutorials__7._Remote_node_reconfiguration__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Tutorials__8._Custom_data_types__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Tutorials__8._Custom_data_types__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Tutorials__9._Node_discovery__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Tutorials__9._Node_discovery__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__Tutorials__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__Tutorials__index.md", "page_count": 1}, {"filename": "Implementations__Libuavcan__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Libuavcan__index.md", "page_count": 1}, {"filename": "Implementations__Pydronecan__Examples__Automated_ESC_enumeration__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Pydronecan__Examples__Automated_ESC_enumeration__index.md", "page_count": 1}, {"filename": "Implementations__Pydronecan__Examples__Dump_All_Messages__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Pydronecan__Examples__Dump_All_Messages__index.md", "page_count": 1}, {"filename": "Implementations__Pydronecan__Examples__ESC_throttle_control__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Pydronecan__Examples__ESC_throttle_control__index.md", "page_count": 1}, {"filename": "Implementations__Pydronecan__Examples__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Pydronecan__Examples__index.md", "page_count": 1}, {"filename": "Implementations__Pydronecan__Tutorials__1._Setup__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Pydronecan__Tutorials__1._Setup__index.md", "page_count": 1}, {"filename": "Implementations__Pydronecan__Tutorials__2._Basic_usage__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Pydronecan__Tutorials__2._Basic_usage__index.md", "page_count": 1}, {"filename": "Implementations__Pydronecan__Tutorials__3._Advanced_usage__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Pydronecan__Tutorials__3._Advanced_usage__index.md", "page_count": 1}, {"filename": "Implementations__Pydronecan__Tutorials__4._Parsing_DSDL_definitions__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Pydronecan__Tutorials__4._Parsing_DSDL_definitions__index.md", "page_count": 1}, {"filename": "Implementations__Pydronecan__Tutorials__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Pydronecan__Tutorials__index.md", "page_count": 1}, {"filename": "Implementations__Pydronecan__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__Pydronecan__index.md", "page_count": 1}, {"filename": "Implementations__dronecan_dsdlc__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__dronecan_dsdlc__index.md", "page_count": 1}, {"filename": "Implementations__index.md", "path": "docs/corpus/dronecan/structured_md/Implementations__index.md", "page_count": 1}, {"filename": "Specification__1._Introduction.md", "path": "docs/corpus/dronecan/structured_md/Specification__1._Introduction.md", "page_count": 1}, {"filename": "Specification__2._Basic_concepts.md", "path": "docs/corpus/dronecan/structured_md/Specification__2._Basic_concepts.md", "page_count": 1}, {"filename": "Specification__3._Data_structure_description_language.md", "path": "docs/corpus/dronecan/structured_md/Specification__3._Data_structure_description_language.md", "page_count": 1}, {"filename": "Specification__4.1_CAN_bus_transport_layer.md", "path": "docs/corpus/dronecan/structured_md/Specification__4.1_CAN_bus_transport_layer.md", "page_count": 1}, {"filename": "Specification__4.2_UDP_bus_transport_layer.md", "path": "docs/corpus/dronecan/structured_md/Specification__4.2_UDP_bus_transport_layer.md", "page_count": 1}, {"filename": "Specification__4.3_MAVLink_bus_transport_layer.md", "path": "docs/corpus/dronecan/structured_md/Specification__4.3_MAVLink_bus_transport_layer.md", "page_count": 1}, {"filename": "Specification__4.4_CANFD_bus_transport_layer.md", "path": "docs/corpus/dronecan/structured_md/Specification__4.4_CANFD_bus_transport_layer.md", "page_count": 1}, {"filename": "Specification__5._Application_level_conventions.md", "path": "docs/corpus/dronecan/structured_md/Specification__5._Application_level_conventions.md", "page_count": 1}, {"filename": "Specification__6._Application_level_functions.md", "path": "docs/corpus/dronecan/structured_md/Specification__6._Application_level_functions.md", "page_count": 1}, {"filename": "Specification__7._List_of_standard_data_types.md", "path": "docs/corpus/dronecan/structured_md/Specification__7._List_of_standard_data_types.md", "page_count": 1}, {"filename": "Specification__8._Hardware_design_recommendations.md", "path": "docs/corpus/dronecan/structured_md/Specification__8._Hardware_design_recommendations.md", "page_count": 1}, {"filename": "index.md", "path": "docs/corpus/dronecan/structured_md/index.md", "page_count": 1}]
ingest_provenance: {"captured_at": "2026-07-18T18:03:16.632561", "page_count": 49, "extraction_methods": {"txt": 49}, "avg_extraction_quality": 1.0, "docling_triage_pages": 0, "docling_triage_rate": 0.0, "extraction_stats": null}
dark_data_inferred_fields: ["author", "confidence_level", "created_date", "ingest_provenance", "kb_id", "sources"]
brick_role: dronecan_protocol
out_of_scope: ["live CAN bus control on vehicle", "full modern Cyphal/OpenCyphal v1 stack (related but separate)", "Plane flight mode doctrine (ArduPilot_Plane)", "MAVLink serial GCS protocol (ArduPilot_MAVLink)", "vendor-specific sensor datasheets (future sensor bricks)"]
usage_notes: Offline snapshot of https://dronecan.github.io/ (github.com/dronecan/dronecan.github.io). Use with ArduPilot common-uavcan/canbus pages and future sensor bricks.
routing_policy: DroneCAN types, bus, GUI tool, AP_Periph, libuavcan/libcanard tutorials → this brick. Vehicle setup in MP/ArduPilot wiki → MissionPlanner/ops. Historic cvra/libuavcan stack notes → UAVCAN_cvra (related lineage).
adjacent_bricks: [{"brick_id": "ArduPilot_Plane", "role": "ops_doctrine", "when_to_use": ["vehicle ops"], "status": "built"}, {"brick_id": "ArduPilot_MissionPlanner", "role": "gcs_mission_planner", "when_to_use": ["GCS / ArduPilot UAVCAN setup pages"], "status": "built"}, {"brick_id": "ArduPilot_MAVLink", "role": "mavlink_protocol", "when_to_use": ["serial MAVLink (not CAN)"], "status": "built"}, {"brick_id": "UAVCAN_cvra", "role": "uavcan_protocol", "when_to_use": ["legacy libuavcan C++ / DSDL submodule notes"], "status": "built"}, {"brick_id": "ArduPilot_Plane_Params", "role": "params_reference", "when_to_use": ["CAN/UAVCAN related parameters"], "status": "built"}]
kb_name: DroneCAN
created: 2026-07-18T18:03:16.635288
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 185
template: technical_reference
domain: general
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-07-18T18:03:33.494097
  chunk_count: 185
  strict_air_gapped: true
---

--- chunk_id: chunk-0000
source_document: Contact__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 8
content_hash: b1111e4384231fba
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: Contact
document_type: technical_reference

# Contact

{% include contact.html %}

--- chunk_id: chunk-0001
source_document: Examples__Simple_sensor_node__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 30
content_hash: 8cfeda7e2ef7f992
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
section_heading: Simple sensor node
document_type: technical_reference

# Simple sensor node

This example is not based on any existing DroneCAN implementation -
it is completely standalone featuring zero third-party dependencies.

--- chunk_id: chunk-0002
source_document: Examples__Simple_sensor_node__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 49
content_hash: 68ce9b2036e3d97d
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: Source code
document_type: technical_reference

## Source code ```c
{% include_relative simple_sensor_node.c %}
``` ### Testing against libuavcan
The following code can be used to test the node against the reference implementation of the DroneCAN stack. ```cpp
{% include_relative libuavcan_airspeed_subscriber.cpp %}
```

--- chunk_id: chunk-0003
source_document: Examples__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 85
content_hash: 2950b5e7ee7e1222
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: Examples
document_type: technical_reference

# Examples

This section contains examples that are designed to aid understanding of important concepts of DroneCAN. The examples are not based on any existing DroneCAN implementation, but are completely standalone featuring
zero third-party dependencies. Examples for the existing implementations can be found in the relevant parts of the documentation. Unless explicitly noted otherwise, all example code in this section is in public domain.

--- chunk_id: chunk-0004
source_document: GUI_Tool__Examples__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 69
content_hash: d47939b1aeedf86f
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: Examples
document_type: technical_reference

# Examples

This page collects some interesting or instructional use cases of the DroneCAN GUI Tool. Since the GUI Tool is built on top of PyDroneCAN,
you should also [check out its examples](/Implementations/PyDroneCAN/Examples/) -
they are mostly compatible with the GUI Tool's embedded IPython console,
although some minor modifications may be required.

--- chunk_id: chunk-0005
source_document: GUI_Tool__Examples__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 108
content_hash: 3e456f0915efecdc
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
section_heading: Generating audiovisual feedback
document_type: technical_reference

## Generating audiovisual feedback

Some nodes support DroneCAN messages from the namespace `uavcan.indication.*`
that allow one to generate arbitrary indications on remote DroneCAN nodes. Here’s how this feature can be invoked from the interactive console of the DroneCAN GUI Tool: ```python
# Beeping at 1kHz for 0.1 seconds
broadcast(uavcan.equipment.indication.BeepCommand(frequency=1000, duration=0.1))

# Beeping at 1kHz for 0.1 seconds every 0.5 seconds for 5 seconds
broadcast(uavcan.equipment.indication.BeepCommand(frequency=1000, duration=0.1), interval=0.5, duration=5)

# Turning all RGB LEDs of index 0 magenta
broadcast(uavcan.equipment.indication.LightsCommand(commands=[
    uavcan.equipment.indication.SingleLightCommand(color=uavcan.equipment.indication.RGB565(red=31,
                                                                                            green=0,
                                                                                            blue=31))]))
```

--- chunk_id: chunk-0006
source_document: GUI_Tool__Overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 166
content_hash: 158d722ba55ca905
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: DroneCAN GUI Tool
document_type: technical_reference

# DroneCAN GUI Tool

{% include lightbox.html url="/GUI_Tool/figures/screenshot.png" title="DroneCAN GUI Tool" thumbnail="true" %}

{% include lightbox.html url="/GUI_Tool/figures/demo_sin_cos_setpoint.png" title="Using the embedded IPython console" thumbnail="true" %}

{% include lightbox.html url="/GUI_Tool/figures/demo_node_configuration.png" title="Remote node reconfiguration" thumbnail="true" %}

DroneCAN GUI Tool is a cross-platform free open source application for DroneCAN bus management and diagnostics. It runs on Windows, Linux, and OSX. * Real time monitoring of CAN bus and DroneCAN transfer dissection. * Plotting values in real time. * Remote node reconfiguration (`uavcan.protocol.param`). * Firmware update on remote nodes. * Python scripting from the embedded IPython console. * Different CAN adapter backends supported:
  * ArduPilot
    [SLCAN on USB](https://ardupilot.org/copter/docs/common-slcan-f7h7.html)
    using the 2nd USB endpoint on F7 and H7 flight controllers
  * SLCAN (aka LAWICEL) adapters, e.g. [Zubax Babel](https://zubax.com/products/babel). * Linux [SocketCAN](https://en.wikipedia.org/wiki/SocketCAN).

--- chunk_id: chunk-0007
source_document: GUI_Tool__Overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 124
content_hash: 086b57e1407be77a
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: Installation
document_type: technical_reference

## Installation
### Windows

Download and install the latest MSI package from <https://firmware.ardupilot.org/Tools/CAN_GUI/>. ### Linux

Note that if you're using a USB SLCAN adapter, it may be necessary to
[configure serial port access permissions](https://kb.zubax.com/x/N4Ah). #### Ubuntu, Mint, and other Debian-based distros ```bash

sudo apt-get install -y python3-pip python3-setuptools python3-wheel
sudo apt-get install -y python3-numpy python3-pyqt5 python3-pyqt5.qtsvg git-core
sudo pip3 install dronecan
sudo pip3 install git+https://github.com/DroneCAN/gui_tool@master
``` #### Other distributions

Please refer to the README file in the source repository: <https://github.com/DroneCAN/gui_tool>. ### OSX

Please refer to the README file in the source repository: <https://github.com/DroneCAN/gui_tool>.

--- chunk_id: chunk-0008
source_document: GUI_Tool__Overview.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 32
content_hash: 65c50572ab94df01
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: Feedback
document_type: technical_reference

## Feedback

Direct your questions and feedback to the [discussion area](/Contact). Pull requests and bug reports are welcome at the GitHub repository at <https://github.com/DroneCAN/gui_tool>.

--- chunk_id: chunk-0009
source_document: GUI_Tool__User_guide.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 24
content_hash: d53ea08ceb611943
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
section_heading: User guide
document_type: technical_reference

# User guide

This article provides a brief overview of the main capabilities of the DroneCAN GUI Tool.

--- chunk_id: chunk-0010
source_document: GUI_Tool__User_guide.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 176
content_hash: ef33e8c0eead88de
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
section_heading: Supported CAN adapters
document_type: technical_reference

## Supported CAN adapters

DroneCAN GUI Tool is based on PyDroneCAN, which at the moment supports at least the following hardware backends. ### SLCAN (LAWICEL) compatible adapters

This backend is available on all systems. All adapters that implement the SLCAN (aka LAWICEL) protocol are supported. The following adapters have been tested so far and are guaranteed to work:

* [Zubax Babel](https://zubax.com/products/babel) (recommended)
* Thiemar muCAN
* VSCOM USB-CAN

Any other SLCAN adapter should also work with DroneCAN GUI Tool without issues. ### Linux SocketCAN

[SocketCAN](https://en.wikipedia.org/wiki/SocketCAN) backend is available only on Linux systems. It has been tested with the following adapters:

* 8devices USB2CAN
* PEAK System PCAN-USB
* [Zubax Babel](https://zubax.com/products/babel) (via SLCAN bridge)
* Virtual CAN interface

Any other adapter supported by SocketCAN should also work with DroneCAN GUI Tool without issues.

--- chunk_id: chunk-0011
source_document: GUI_Tool__User_guide.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 482
content_hash: fca82b5fe68b977c
prev_chunk_id: chunk-0010
next_chunk_id: chunk-0012
section_heading: Using Vendor-Specific DSDL Definitions
document_type: technical_reference

## Using Vendor-Specific DSDL Definitions

The DroneCAN GUI Tool is based on PyDroneCAN,
which will automatically scan the directory `~/uavcan_vendor_specific_types` for vendor-specific data types,
where `~` stands for the home directory of the current user, e.g. `/home/joe` or `C:\Users\Joe`. Consider the following directory layout: ```
~
└── uavcan_vendor_specific_types
    └── sirius_cybernetics_corporation
        ├── 100.Foo.uavcan
        ├── 42.Bar.uavcan
        └── Baz.uavcan
``` The above layout defines the following custom data types:

* `sirius_cybernetics_corporation.Foo` with the default data type ID 100. * `sirius_cybernetics_corporation.Bar` with the default data type ID 42. * `sirius_cybernetics_corporation.Baz` where the default data type ID is not set. ### Interactive Console
The application embeds an IPython console (running Python 3.4 or newer)
that provides the user with access to the application's own DroneCAN node. As the application is built on [PyDroneCAN](/Implementations/PyDroneCAN),
all features of the library are avaiable to the user via the interactive shell. The application exposes a few convenience functions and objects, which are listed at the top of the console
when it is started. In order to get more information about any function or object, execute `help(object_name)`. Autocompletion can be invoked by pressing the **Tab** key. ### Programming tips

**Never invoke blocking functions, such as `time.sleep()`, from the console.**
Instead, apply the practices of asynchronous programming;
the functions `defer()`, `periodic()`, and `stop()` should be of great help here. See examples below. Wrong: ```python
i = 470
t = -1

while i > 20:
    i *= 0.99
    c = int(i) + (1000 if t < 0 else 0)
    t = -t
    print ('command', c)
    broadcast(uavcan.equipment.hardpoint.Command(hardpoint_id=1, command=c))
    time.sleep(0.3)     # THIS IS WRONG
``` Same logic as above, implemented correctly: ```python
i = 470
t = -1

def run_once():
    global i, t
    i *= 0.99
    c = int(i) + (1000 if t < 0 else 0)
    t = -t
    print('command', c)
    broadcast(uavcan.equipment.hardpoint.Command(hardpoint_id=1, command=c))
    if i > 20:
        node.defer(0.3, run_once)       # Note: not blocking

node.defer(0, run_once)
``` Another example of a periodic process: ```python
import math, time

def publish_throttle_setpoint():
    sp_sin = int(512 * (math.sin(time.time()) + 2))
    sp_cos = int(512 * (math.cos(time.time()) + 2))
    message = uavcan.equipment.esc.RawCommand(cmd=[sp_sin, sp_cos, sp_sin, sp_cos])
    broadcast(message)

periodic(0.05, publish_throttle_setpoint)
``` All periodic processes, along with all subscriptions, can be stopped by executing `stop()`.

--- chunk_id: chunk-0012
source_document: GUI_Tool__User_guide.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 50
content_hash: eb85acc1265106bc
prev_chunk_id: chunk-0011
next_chunk_id: chunk-0013
section_heading: Bus Monitor, Plotter, etc
document_type: technical_reference

## Bus Monitor, Plotter, etc

DroneCAN GUI Tool provides a bunch of other features,
which are considered self-documenting and therefore not described here. If you find that not true, please [file a ticket](https://github.com/DroneCAN/gui_tool)
or [contribute to this documentation](https://github.com/DroneCAN/dronecan.github.io).

--- chunk_id: chunk-0013
source_document: Implementations__AP_Periph__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 122
content_hash: b6f1ebcbd5649780
prev_chunk_id: chunk-0012
next_chunk_id: chunk-0014
section_heading: AP_Periph
document_type: technical_reference

# AP_Periph

AP_Periph is a toolkit for creating DroneCAN peripheral nodes based on
the ArduPilot libraries. For detailed information see the
[AP_Periph documentation](https://ardupilot.org/dev/docs/ap-peripheral-landing-page.html) and [source code](https://github.com/ArduPilot/ardupilot/tree/master/Tools/AP_Periph)

With AP_Periph you can quickly go from a schematic to a working
DroneCAN nodes with the following features:

 - support for creating GPS, barometer, magnetometer, rangefinder, ESC
 gateway, PWM gateway, MSP peripheral, airspeed sensor, ADSB
 peripheral
 - DNA support for dynamic node IDs
 - robust CRC and board type checking
 - watchdog support
 - DroneCAN bootloader update
 - DroneCAN firmware update
 - diagnostics
 - Lua scripting

--- chunk_id: chunk-0014
source_document: Implementations__Libcanard__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 85
content_hash: 132ad2806255dc24
prev_chunk_id: chunk-0013
next_chunk_id: chunk-0015
section_heading: Libcanard
document_type: technical_reference

# Libcanard

Libcanard is a minimal implementation of DroneCAN in C, suitable for deeply embedded systems and
resource constrained applications. It is primarily targeted for low-end microcontrollers, starting from 8 KB ROM and 6 KB RAM. The documentation and the usage examples are contained right in the
[source repository on Github](https://github.com/DroneCAN/libcanard). Please proceed to read it there. In particular please see the [example firmwares](https://github.com/dronecan/libcanard/tree/master/examples).

--- chunk_id: chunk-0015
source_document: Implementations__Libcanard__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 30
content_hash: 224262df6d3a2aac
prev_chunk_id: chunk-0014
next_chunk_id: chunk-0016
section_heading: Libcanard C++ interface
document_type: technical_reference

## Libcanard C++ interface

Libcanard now also includes a C++ interface providing a clean, light
weight implementation supporting the full DroneCAN feature set.

--- chunk_id: chunk-0016
source_document: Implementations__Libuavcan__FAQ__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: 8d930159a52d5e80
prev_chunk_id: chunk-0015
next_chunk_id: chunk-0017
section_heading: Frequently asked questions
document_type: technical_reference

# Frequently asked questions
### Node is emitting incomplete transfers or losing frames

Possible causes are listed below. Also
[refer to the first tutorial for more info on troubleshooting](/Implementations/Libuavcan/Tutorials/1._Library_build_configuration/#debugging-and-troubleshooting). #### Memory pool is too small

This may prevent the node from allocating enough memory for the TX queue. Try to increase the pool, and make sure that it is not getting exhausted. #### Node is not spinning regularly

This may cause the frames scheduled for transmission to time out before even reaching the CAN driver. Make sure that the spin method is being invoked regularly. #### CAN frames lose arbitration

This could happen if the bus is too congested with higher-priority traffic. Try to increase either or both:

- Transmission timeout. - Transfer priority (if appropriate). Both are explained in the relevant tutorials. ### Build is failing because of missing header files

This issue typically manifests itself with a message like that: ```
libuavcan/include/uavcan/time.hpp:12:32: fatal error: uavcan/Timestamp.hpp: No such file or directory
``` This could be caused by failing DSDL compilation - see below. ### DSDL compiler is failing

Make sure you have Python installed. Inspect the build logs for error messages from the DSDL compiler. They should be descriptive enough to help you understand the nature of the problem. If you're facing the following error message: ```
  File "dsdl_compiler/libuavcan_dsdlc", line 59, in <module>
    from libuavcan_dsdl_compiler import run as dsdlc_run
  File "/home/XXXXX/libuavcan/libuavcan/dsdl_compiler/libuavcan_dsdl_compiler/__init__.py", line 17, in <module>
    from dronecan import dsdl
ImportError: No module named dronecan
``` Make sure that all git submodules are checked out and updated - use `git submodule update --init --recursive --force`. ### SocketCAN does not work reliably with an SLCAN adapter

Sometimes `slcand` may be losing outgoing frames because TX queue is not large enough. TX queue of an interface can be resized as follows: ```bash
ifconfig slcan0 txqueuelen 1000
``` The example above makes TX queue of `slcan0` 1000 frames deep.

--- chunk_id: chunk-0017
source_document: Implementations__Libuavcan__Platforms__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 96
content_hash: d89227e779bb3126
prev_chunk_id: chunk-0016
next_chunk_id: chunk-0018
section_heading: Libuavcan platforms
document_type: technical_reference

# Libuavcan platforms

In the context of Libuavcan, a *platform* is a particular hardware platform or an operating system that can
execute libuavcan-based DroneCAN nodes. For example, the STM32 microcontroller family and the GNU/Linux OS are some of the officially supported
libuavcan platforms. A *platform driver* is a set of platform-specific C++ classes that implement the thin layer of
glue logic needed to make libuavcan function with the particular platform at hand.

--- chunk_id: chunk-0018
source_document: Implementations__Libuavcan__Platforms__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 302
content_hash: 40d2365ea96d8bb7
prev_chunk_id: chunk-0017
next_chunk_id: chunk-0019
section_heading: Adding support for a new platform
document_type: technical_reference

## Adding support for a new platform

Implementing a platform driver for libuavcan is generally a quite straightforward task,
especially if the driver is targeted for a certain application and need not to be generic. Essentially, a libuavcan driver is a set of C++ classes implementing the following C++ interfaces:

* `uavcan::ICanDriver`
* `uavcan::ICanIface`
* `uavcan::ISystemClock`

The interfaces listed above are defined in
[`libuavcan/include/uavcan/driver/`](https://github.com/DroneCAN/libuavcan/blob/master/libuavcan/include/uavcan/driver). Note that the library core already includes a non-blocking prioritized TX queue, so normally a driver should not
implement a software TX queue itself. If the driver does not need to support redundant CAN bus interfaces,
then the first two C++ interfaces can be implemented in the same C++ class. Some features can be left unimplemented:

* **IO flags** - needed for dynamic node ID allocation and time synchronization master. * **TX timestamping** - needed for clock synchronization master. * **Hardware CAN filters configuration** -
not necessary if there is enough computational power to delegate filtering to the library software. There are two extreme examples of the driver complexity level that can give a basic idea of the development effort required:

* LPC11C24 driver - only necessary functionality, no redundant interface support, no TX timestamping - 600 LoC. * Linux driver - complete full-featured driver with hardware timestamping and redundant interfaces - 1200 LoC. Contributions adding support for new platforms are always welcome.

--- chunk_id: chunk-0019
source_document: Implementations__Libuavcan__Platforms__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 225
content_hash: 648dd44250e41d7b
prev_chunk_id: chunk-0018
next_chunk_id: chunk-0020
section_heading: Officially supported platforms
document_type: technical_reference

## Officially supported platforms

Official platform drivers are located in dedicated repositories here:
[github.com/DroneCAN](https://github.com/DroneCAN). Contributions adding support for new platforms are always welcome. Please refer to the platform driver source repositories for relevant documentation:

* [STM32](https://github.com/DroneCAN/libuavcan_stm32)
* [GNU/Linux](https://github.com/DroneCAN/libuavcan_linux)
* [NXP LPC11C24](https://github.com/DroneCAN/libuavcan_lpc11c24)

### POSIX helpers
This is not a complete driver,
but rather a set of C++ classes that implement certain libuavcan interfaces in a cross-platform way,
so that they can be used on any POSIX-compliant operating system,
e.g. Linux or NuttX. The libuavcan tutorials available in an adjacent section cover how to use these classes among other things. The driver is implemented as a header-only C++ library. The sources can be found in the main libuavcan source repository. At least the following classes are implemented in the POSIX driver:

* Firmware version checker - implements a simple firmware version checking strategy for firmware update servers. * File server backend - implements file system I/O for UAVCAN file management services. * File system backends for dynamic node ID allocation servers.

--- chunk_id: chunk-0020
source_document: Implementations__Libuavcan__Tutorials__1._Library_build_configuration__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 186
content_hash: 8cf8fd69130b76a9
prev_chunk_id: chunk-0019
next_chunk_id: chunk-0021
section_heading: Library build configuration
document_type: technical_reference

# Library build configuration

Library build can be configured via C++ preprocessor definitions. All configuration options are listed and documented in the header file
[`libuavcan/include/uavcan/build_config.hpp`](https://github.com/DroneCAN/libuavcan/blob/master/libuavcan/include/uavcan/build_config.hpp). Note that all configuration options have either safe default values or autodetect settings;
so, in most cases, it's not necessary to change them. Applications and the library should use exactly the same build configuration,
meaning that if the library is built separately from the application, e.g. as a static library,
the sets of preprocessor symbols used for the library configuration in both builds should match exactly. Hence, if the library is built separately from the application,
it is highly recommended to use the default build configuration
(the defaults are smart enough to fit virtually any use case). For instance, the static library build for Linux uses (and will always use) only the default build configuration.

--- chunk_id: chunk-0021
source_document: Implementations__Libuavcan__Tutorials__1._Library_build_configuration__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: e520656af8688999
prev_chunk_id: chunk-0020
next_chunk_id: chunk-0022
section_heading: Library version number
document_type: technical_reference

## Library version number

The following definitions are guaranteed to be present in all future versions of the library:

* `UAVCAN_VERSION_MAJOR` - major library version number
* `UAVCAN_VERSION_MINOR` - minor library version number

These values can be used to work-around the API differences in different versions of the library. ### Build configuration options
Note that this chapter doesn't list some of the advanced options that are unlikely to be needed
in most use cases. If you want to see the full list of configuration options, please refer to the header file `build_config.hpp`. ### `UAVCAN_CPP_VERSION`

This macro encodes whether the features that were introduced with newer versions of the C++ standard are supported. It expands to the year number after which the standard was named:

* 2003 for C++03
* 2011 for C++11

Also, there are helper macros:

* `UAVCAN_CPP11` - expands to `2011`
* `UAVCAN_CPP03` - expands to `2003`

This option is automatically set according to the actual C++ standard used by the compiler,
which is detected via the standard symbol `__cplusplus`. Sometimes, the user may want to force the library to use C++03 mode,
in which case this symbol can be overridden manually via compiler flags
(e.g. for GCC: `-DUAVCAN_CPP_VERSION=UAVCAN_CPP03`). Learn more about the differences between standard versions on the [libuavcan page](/Implementations/Libuavcan). ### `UAVCAN_EXCEPTIONS`

This option defines how libuavcan handles fatal errors, e.g. range check error, unexpected null pointer, etc. If this option is nonzero, libuavcan will throw a standard exception inherited from
`std::exception` every time it encounters a fatal error. Possible exception types include `std::runtime_error` and `std::out_of_range`. An exception description string (accessible via the method `what()`) indicates where the exception was thrown from. If this option is zero, then in case of a fatal error libuavcan will perform the following steps in order:

1. Execute a zero assertion, so debug builds will abort here. 2. If possible, attempt to work around the error;
a possible case for such behavior is an out-of-bounds array access wherein the closest valid index is used
instead of the requested index. 3. If the previous step was not possible, the application will be terminated via `std::abort()`. The default value will be 1 if the values of compiler-specific preprocessor symbols that indicate
whether exception handling is available are nonzero, e.g. `__EXCEPTIONS` or `_HAS_EXCEPTIONS`. Otherwise, this option  defaults to 0.

--- chunk_id: chunk-0022
source_document: Implementations__Libuavcan__Tutorials__1._Library_build_configuration__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 493
content_hash: 71ea04d3beaf3d95
prev_chunk_id: chunk-0021
next_chunk_id: chunk-0023
section_heading: Library version number
document_type: technical_reference

`__EXCEPTIONS` or `_HAS_EXCEPTIONS`. Otherwise, this option  defaults to 0. ### `UAVCAN_EXPORT`

This symbol is inserted before every symbol exported by the library. It is empty by default. Possible use case, e.g. for GCC: ```cpp
#define UAVCAN_EXPORT    __attribute__((visibility ("default")))
``` ### `UAVCAN_TINY`

This option is intended for very resource-constrained microcontrollers (<32 KB ROM or <8 KB RAM). It removes some auxiliary library features in order to reduce memory footprint. The default value is always zero (disabled). Some of the important features affected in tiny mode:

* Transport layer self-diagnostics removed
* Logging removed
* The following services are not supported by default:
  * `uavcan.protocol.RestartNode`
  * `uavcan.protocol.GetDataTypeInfo`
  * `uavcan.protocol.GetTransportStats`

### `UAVCAN_TOSTRING`

If nonzero, this option adds a convenience string-conversion method, `std::string toString() const`,
to most of the library classes. The default value is 0, unless any of the preprocessor symbols listed below is nonzero:

* `__linux__`
* `__linux`
* `__APPLE__`
* `_WIN64`
* `_WIN32`
* Possibly some else, refer to the implementation for the complete list

Note that this option is guaranteed to be disabled by default on deeply embedded systems. ### `UAVCAN_IMPLEMENT_PLACEMENT_NEW`

Set this option to nonzero if your C++ implementation does not implement the placement new operator. The default value is zero. ### `UAVCAN_USE_EXTERNAL_SNPRINTF`

If this macro is nonzero, libuavcan will not define (but only declare) the function `uavcan::snprintf()`. In this case the application will need to provide a custom implementation of this function,
otherwise it will fail to link. If this macro is zero, `uavcan::snprintf()` will simply wrap `vsnprintf()` from the standard library. This feature is useful for memory-constrained embedded systems,
where the standard `snprintf()` implementation is too large to fit in the memory. The default value is zero. ### `UAVCAN_USE_EXTERNAL_FLOAT16_CONVERSION`

If this macro is nonzero, libuavcan will not define the functions that perform conversions between
the native `float` data type and the `float16` type used in DSDL,
allowing the application to link custom conversion routines, possibly taking advantage of
hardware support for floating point conversions (e.g. instructions `VCVTB` and `VCVTT` on ARM Cortex). For more info refer to the file `libuavcan/src/marshal/uc_float_spec.cpp` or grep the sources. If this macro is zero, the library will use generic conversion routines that are fully portable and hardware-agnostic. The default value is zero.

--- chunk_id: chunk-0023
source_document: Implementations__Libuavcan__Tutorials__1._Library_build_configuration__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: 757138c29c5e33b0
prev_chunk_id: chunk-0022
next_chunk_id: chunk-0024
section_heading: Library version number
document_type: technical_reference

If this macro is zero, the library will use generic conversion routines that are fully portable and hardware-agnostic. The default value is zero. ### `UAVCAN_ASSERT(x)`

This function-like preprocessor macro is used to perform run-time checks in debug builds;
it works in the same way as the standard `assert()` macro. It is mapped to the standard `assert()` macro by default. If the symbol `UAVCAN_NO_ASSERTIONS` is set to a nonzero value,
this macro expands to an empty statement instead. This allows to save sometimes up to 10 KB of ROM on some platforms and reduce CPU usage. ### `UAVCAN_MEM_POOL_BLOCK_SIZE`

Libuavcan uses a deterministic, fixed-size block allocator to store dynamic data. This option allows to override the default block size to use a lower value,
which sometimes helps to reduce memory usage on platforms with a small pointer size (32 bits or less). The memory pool block size must be a multiple of the biggest possible alignment on the target platform
(which is often the size of the largest primitive type, e.g., `long double`). With some compilers (e.g., GCC), the library can adjust this value completely automatically using
the preprocessor symbol `__BIGGEST_ALIGNMENT__` so that the library user doesn't need to care. In case automatic adjustment can't be performed, it defaults to a safe value, 64 bytes, which fits any platform. If the block size is set too small for the current platform, the library will intentionally fail to compile. ### `UAVCAN_NO_GLOBAL_DATA_TYPE_REGISTRY`

This option will disable the global data type registry maintained by the library. *Use of this feature is strongly discouraged*, unless you have a deep understanding of the library,
your application is extremely ROM and RAM limited, and you really know what you're doing. If this option is enabled, the library will not be able to maintain the set of used DSDL data type
definitions automatically, so the developer will have to register every used data type manually
(this procedure is covered in one of the later tutorials). Pros:

* Slightly lower ROM and RAM footprints of the library. * The library will contain no singletons, and no static initialization will take place at start up. * Inclusion of the data type definition headers will not affect the ROM footprint. Cons:

* The developer will be responsible for registration of the DSDL data types needed by the application.

--- chunk_id: chunk-0024
source_document: Implementations__Libuavcan__Tutorials__1._Library_build_configuration__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 422
content_hash: 90c765b887586363
prev_chunk_id: chunk-0023
next_chunk_id: chunk-0025
section_heading: Debugging and troubleshooting
document_type: technical_reference

## Debugging and troubleshooting

The library facilitates debugging and troubleshooting through perfcounters and debug output. ### Perfcounters
#### `getFailureCount()`

Objects of the following types provide a method that allows the application to query the number of transport
layer failures detected by the protocol stack for the given service or message. * `uavcan::Subscriber`
* `uavcan::ServiceServer`
* `uavcan::ServiceClient`

The signature of the method is `std::uint32_t getFailureCount() const`. Detectable error types include:

* Transfer CRC failures
* Data type signature mismatch
* Data type layout mismatch
* Framing errors

#### `TransferPerfCounter`

Libuavcan maintains a set of performance counters that indicate the number of transfers processed,
as well as the number of common errors detected in the transport layer. The performance counters can be accessed as follows: ```cpp
const uavcan::TransferPerfCounter& perf = node.getDispatcher().getTransferPerfCounter();

std::cout << perf.getErrorCount()      << std::endl;
std::cout << perf.getTxTransferCount() << std::endl;
std::cout << perf.getRxTransferCount() << std::endl;
``` The example above assumes that the node object is named `node`. #### `CanIfacePerfCounters`

Libuavcan maintains the counters of CAN frames exchanged by the CAN controller and the number of
bus errors detected by the CAN hardware. ```cpp
const uavcan::CanIOManager& canio = node.getDispatcher().getCanIOManager();
for (std::uint8_t i = 0; i < canio.getNumIfaces(); i++)
{
    const uavcan::CanIfacePerfCounters can_perf = canio.getIfacePerfCounters(i);
    std::cout << can_perf.errors    << std::endl;
    std::cout << can_perf.frames_tx << std::endl;
    std::cout << can_perf.frames_rx << std::endl;
}
``` The example above assumes that the node object is named `node`. ### Memory pool usage statistics

Use the following methods to check whether the memory pool is getting exhausted: ```cpp
std::cout << node.getAllocator().getNumBlocks() << std::endl;           // Capacity
std::cout << node.getAllocator().getNumUsedBlocks() << std::endl;       // Currently used
std::cout << node.getAllocator().getPeakNumUsedBlocks() << std::endl;   // Peak usage
``` The example above assumes that the node object is named `node`. ### Debug output

The library will print extensive debug information into stdout via `std::printf()`
if the macro `UAVCAN_DEBUG` is assigned a non-zero value. Note that this feature requires C++ I/O streams and `UAVCAN_TOSTRING`.

--- chunk_id: chunk-0025
source_document: Implementations__Libuavcan__Tutorials__10._Dynamic_node_ID_allocation__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 46
content_hash: ddf87ce426a7db6a
prev_chunk_id: chunk-0024
next_chunk_id: chunk-0026
section_heading: Dynamic node ID allocation
document_type: technical_reference

# Dynamic node ID allocation

This advanced-level tutorial demonstrates how to implement dynamic node ID allocation using libuavcan. The reader must be familiar with the corresponding section of the specification, since the content of this

--- chunk_id: chunk-0026
source_document: Implementations__Libuavcan__Tutorials__10._Dynamic_node_ID_allocation__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 125
content_hash: ea81a003a3a888db
prev_chunk_id: chunk-0025
next_chunk_id: chunk-0027
section_heading: chapter heavily relies on principles and concepts introduced there.
document_type: technical_reference

chapter heavily relies on principles and concepts introduced there. In this tutorial, three applications will be implemented:

* **Allocatee** - a generic application that requests a dynamic node ID. It does not implement any specific application-level logic. * **Centralized allocator** - one of two possible types of allocators. * **Distributed allocator** - the other type of allocators, that can operate in a highly reliable redundant cluster. Note that the Linux platform driver contains an implementation of a distributed dynamic node ID allocator -
learn more on the chapter dedicated to the Linux platform driver.

--- chunk_id: chunk-0027
source_document: Implementations__Libuavcan__Tutorials__10._Dynamic_node_ID_allocation__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 285
content_hash: d819b6839e2476ff
prev_chunk_id: chunk-0026
next_chunk_id: chunk-0028
section_heading: Allocatee
document_type: technical_reference

## Allocatee

Use this example as a guideline when implementing dynamic node ID allocation feature in your application. ```cpp
{% include_relative allocatee.cpp %}
``` Possible output: ```
No preference for a node ID value.
To assign a preferred node ID, pass it as a command line argument:
        ./allocatee <preferred-node-id>
major: 0
minor: 0
unique_id: [68, 192, 139, 99, 94, 5, 244, 188, 76, 138, 148, 82, 94, 146, 130, 178]
certificate_of_authenticity: ""
Allocation is in progress...................................................
Dynamic node ID 125 has been allocated by the allocator with node ID 1
``` ### Centralized allocator ```cpp
{% include_relative centralized_allocator.cpp %}
``` ### Distributed allocator
The size of the cluster can be configured via a command line argument. Once a majority of the nodes participating in the cluster are up,
the cluster can serve allocation requests. For example, a three-node cluster can be started as follows (execute each command in a different terminal): ```
# Terminal 1
$ ./distributed_allocator 1 3
# Terminal 2
$ ./distributed_allocator 2 3
# Terminal 3
$ ./distributed_allocator 3 3
``` Also, a distributed allocator can work in a non-redundant configuration,
in which case it behaves the same way as a centralized allocator: ```
$ ./distributed_allocator 1 1
``` The source code is provided below. ```cpp
{% include_relative distributed_allocator.cpp %}
```

--- chunk_id: chunk-0028
source_document: Implementations__Libuavcan__Tutorials__10._Dynamic_node_ID_allocation__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 24
content_hash: 89e05cb94ad5a6c5
prev_chunk_id: chunk-0027
next_chunk_id: chunk-0029
section_heading: Running on Linux
document_type: technical_reference

## Running on Linux

Build the applications using the following CMake script: ```cmake
{% include_relative CMakeLists.txt %}
```

--- chunk_id: chunk-0029
source_document: Implementations__Libuavcan__Tutorials__11._Firmware_update__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 214
content_hash: 4e6ab99da491914c
prev_chunk_id: chunk-0028
next_chunk_id: chunk-0030
section_heading: Firmware update
document_type: technical_reference

# Firmware update

This advanced-level tutorial shows how to implement firmware update over UAVCAN using libuavcan. The reader must be familiar with the corresponding section of the specification. Two applications will be implemented:

* Updater - this application runs an active node monitor (this topic has been covered in one of the previous tutorials),
and when a remote node responds to `uavcan.protocol.GetNodeInfo` request, the application checks if it has a newer
firmware image than the node is currently running. If this is the case, the application sends a request of type
`uavcan.protocol.file.BeginFirmwareUpdate` to the node. This application also implements a file server, which is
another mandatory component of the firmware update process. * Updatee - this application demonstrates how to handle requests of type `uavcan.protocol.file.BeginFirmwareUpdate`,
and how to download a file using the service `uavcan.protocol.file.Read`. Launch instructions are provided after the source code below. It is advised to refer to a real production-used cross-platform UAVCAN bootloader implemented by
[PX4 development team](http://px4.io).

--- chunk_id: chunk-0030
source_document: Implementations__Libuavcan__Tutorials__11._Firmware_update__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 417
content_hash: 91813f02c6ddcac5
prev_chunk_id: chunk-0029
next_chunk_id: chunk-0031
section_heading: Updater
document_type: technical_reference

## Updater ```cpp
{% include_relative updater.cpp %}
``` ### Updatee ```cpp
{% include_relative updatee.cpp %}
``` ### Running on Linux
Build the applications using the following CMake script: ```cmake
{% include_relative CMakeLists.txt %}
``` If the applications are started as-is, nothing interesting would happen,
because updater needs firmware files in order to issue update requests;
otherwise it will be ignoring nodes with a comment like `No firmware files found for this node`. In order to make something happen, create a file named `org.uavcan.tutorial.updatee-1.0-5.0.0.uavcan.bin`
(naming format is explained in the source code), fill it with some data and then start both nodes. In this case, updater will request updatee to update its firmware, because the provided firmware file
is declared to have higher firmware version number than updatee reports. While firmware is being loaded, updatee will set its operating mode to `SOFTWARE_UPDATE`,
as can be seen using UAVCAN monitor application for Linux
(refer to the Linux platform driver documentation to learn more about available applications):

{% include lightbox.html url="/Implementations/Libuavcan/Tutorials/11._Firmware_update/monitor_software_update.png" title="Sample" %}

Possible output of updater: ```
$ ./updater 1
Started successfully
Checking firmware version of node 2; node info:
status:
  uptime_sec: 0
  health: 0
  mode: 0
  sub_mode: 0
  vendor_specific_status_code: 0
software_version:
  major: 1
  minor: 0
  optional_field_flags: 0
  vcs_commit: 0
  image_crc: 0
hardware_version:
  major: 1
  minor: 0
  unique_id: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  certificate_of_authenticity: ""
name: "org.uavcan.tutorial.updatee"
Matching firmware files:
        org.uavcan.tutorial.updatee-1.0-5.0.0.uavcan.bin
status:
  uptime_sec: 0
  health: 0
  mode: 0
  sub_mode: 0
  vendor_specific_status_code: 0
software_version:
  major: 5
  minor: 0
  optional_field_flags: 1
  vcs_commit: 0
  image_crc: 0
hardware_version:
  major: 1
  minor: 0
  unique_id: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  certificate_of_authenticity: ""
name: "org.uavcan.tutorial.updatee"
Preferred firmware: org.uavcan.tutorial.updatee-1.0-5.0.0.uavcan.bin
Firmware file symlink: 93osmbx05mzk.bin
Node 2 has confirmed the update request; response was:
error: 0
optional_error_message: ""
``` Possible output of updatee:

--- chunk_id: chunk-0031
source_document: Implementations__Libuavcan__Tutorials__11._Firmware_update__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 1542
content_hash: b17f87bf46660c59
prev_chunk_id: chunk-0030
next_chunk_id: chunk-0032
section_heading: Updater
document_type: technical_reference

$ ./updatee 2
Firmware update request:
# Received struct ts_m=9534.001067 ts_utc=1443463579.015996 snid=1
source_node_id: 1
image_file_remote_path:
  path: "93osmbx05mzk.bin"
Response:
error: 0
optional_error_message: ""
Firmware download succeeded [881 bytes]
00000000  54 68 65 20 74 72 61 67  65 64 79 20 6f 66 20 68   The tragedy of h
00000010  75 6d 61 6e 20 6c 69 66  65 2c 20 69 74 20 69 73   uman life, it is
00000020  20 6f 66 74 65 6e 20 74  68 6f 75 67 68 74 2c 20    often thought,
00000030  69 73 20 74 68 61 74 20  6f 75 72 20 6d 6f 72 74   is that our mort
00000040  61 6c 69 74 79 20 6d 65  61 6e 73 20 74 68 61 74   ality means that
00000050  20 64 65 61 74 68 20 69  73 20 74 68 65 20 6f 6e    death is the on
00000060  6c 79 20 74 68 69 6e 67  20 74 68 61 74 20 77 65   ly thing that we
00000070  20 6b 6e 6f 77 0a 66 6f  72 20 73 75 72 65 20 61    know.for sure a
00000080  77 61 69 74 73 20 75 73  2e 20 54 68 65 20 73 74   waits us. The st
00000090  6f 72 79 20 6f 66 20 56  69 74 61 6c 69 61 20 74   ory of Vitalia t
000000a0  75 72 6e 73 20 74 68 69  73 20 63 6f 6e 76 65 6e   urns this conven
000000b0  74 69 6f 6e 61 6c 20 77  69 73 64 6f 6d 20 6f 6e   tional wisdom on
000000c0  20 69 74 73 20 68 65 61  64 20 61 6e 64 20 73 75    its head and su
000000d0  67 67 65 73 74 73 20 74  68 61 74 20 69 6d 6d 6f   ggests that immo
000000e0  72 74 61 6c 69 74 79 0a  77 6f 75 6c 64 20 62 65   rtality.would be
000000f0  20 61 20 63 75 72 73 65  2e 20 57 65 20 6e 65 65    a curse. We nee
00000100  64 20 64 65 61 74 68 20  74 6f 20 67 69 76 65 20   d death to give
00000110  73 68 61 70 65 20 61 6e  64 20 6d 65 61 6e 69 6e   shape and meanin
00000120  67 20 74 6f 20 6c 69 66  65 2e 20 57 69 74 68 6f   g to life. Witho
00000130  75 74 20 69 74 2c 20 77  65 20 77 6f 75 6c 64 20   ut it, we would
00000140  66 69 6e 64 20 6c 69 66  65 20 70 6f 69 6e 74 6c   find life pointl
00000150  65 73 73 2e 20 4f 6e 20  74 68 69 73 0a 76 69 65   ess. On this.vie
00000160  77 2c 20 69 66 20 68 65  6c 6c 20 69 73 20 65 74   w, if hell is et
00000170  65 72 6e 61 6c 20 64 61  6d 6e 61 74 69 6f 6e 2c   ernal damnation,
00000180  20 74 68 65 20 65 74 65  72 6e 69 74 79 20 6f 66    the eternity of
00000190  20 6c 69 66 65 20 69 6e  20 48 61 64 65 73 20 77    life in Hades w
000001a0  6f 75 6c 64 20 62 65 20  65 6e 6f 75 67 68 20 74   ould be enough t
000001b0  6f 20 6d 61 6b 65 20 69  74 20 61 20 70 6c 61 63   o make it a plac
000001c0  65 20 6f 66 20 70 75 6e  69 73 68 6d 65 6e 74 2e   e of punishment.
000001d0  0a 0a 49 74 20 69 73 20  73 75 72 70 72 69 73 69   ..It is surprisi
000001e0  6e 67 20 68 6f 77 20 66  65 77 20 70 65 6f 70 6c   ng how few peopl
000001f0  65 20 77 68 6f 20 74 68  69 6e 6b 20 65 74 65 72   e who think eter
00000200  6e 61 6c 20 6c 69 66 65  20 77 6f 75 6c 64 20 62   nal life would b
00000210  65 20 64 65 73 69 72 61  62 6c 65 20 74 68 69 6e   e desirable thin
00000220  6b 20 68 61 72 64 20 61  62 6f 75 74 20 77 68 61   k hard about wha
00000230  74 20 69 74 20 77 6f 75  6c 64 20 65 6e 74 61 69   t it would entai
00000240  6c 2e 20 54 68 61 74 0a  69 73 20 75 6e 64 65 72   l. That.is under
00000250  73 74 61 6e 64 61 62 6c  65 2e 20 57 68 61 74 20   standable. What
00000260  77 65 20 70 72 69 6d 61  72 69 6c 79 20 77 61 6e   we primarily wan
00000270  74 20 69 73 20 73 69 6d  70 6c 79 20 6d 6f 72 65   t is simply more
00000280  20 6c 69 66 65 2e 20 54  68 65 20 65 78 61 63 74    life. The exact
00000290  20 64 75 72 61 74 69 6f  6e 20 6f 66 20 74 68 65    duration of the
000002a0  20 65 78 74 72 61 20 6c  65 61 73 65 20 69 73 20    extra lease is
000002b0  6e 6f 74 20 6f 75 72 20  70 72 69 6d 65 0a 63 6f   not our prime.co
000002c0  6e 63 65 72 6e 2e 20 49  74 20 64 6f 65 73 20 73   ncern. It does s
000002d0  65 65 6d 20 74 68 61 74  20 73 65 76 65 6e 74 79   eem that seventy
000002e0  20 79 65 61 72 73 2c 20  69 66 20 77 65 e2 80 99    years, if we...
000002f0  72 65 20 6c 75 63 6b 79  2c 20 69 73 6e e2 80 99   re lucky, isn...
00000300  74 20 6c 6f 6e 67 20 65  6e 6f 75 67 68 2e 20 54   t long enough. T
00000310  68 65 72 65 20 61 72 65  20 73 6f 20 6d 61 6e 79   here are so many
00000320  20 70 6c 61 63 65 73 20  74 6f 20 73 65 65 2c 20    places to see,
00000330  73 6f 20 6d 75 63 68 0a  74 6f 20 64 6f 20 61 6e   so much.to do an
00000340  64 20 65 78 70 65 72 69  65 6e 63 65 2e 20 49 66   d experience. If
00000350  20 6f 6e 6c 79 20 77 65  20 68 61 64 20 6d 6f 72    only we had mor
00000360  65 20 74 69 6d 65 20 74  6f 20 64 6f 20 69 74 21   e time to do it!
00000370  0a                                                 .

--- chunk_id: chunk-0032
source_document: Implementations__Libuavcan__Tutorials__12._Multithreading__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 56
content_hash: 6f899c2ef7fe7380
prev_chunk_id: chunk-0031
next_chunk_id: chunk-0033
section_heading: Multithreading
document_type: technical_reference

# Multithreading

This advanced-level tutorial explains the concept of multithreaded node in the context of libuavcan,
and shows an example application that runs a multithreaded node. The reader must be familiar with the specification, particularly with the specification of the transport layer.

--- chunk_id: chunk-0033
source_document: Implementations__Libuavcan__Tutorials__12._Multithreading__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 176
content_hash: bc7cbaabc79f4671
prev_chunk_id: chunk-0032
next_chunk_id: chunk-0034
section_heading: Motivation
document_type: technical_reference

## Motivation

An application that runs a DroneCAN node is often required to run hard real-time UAVCAN-related processes
side by side with less time-critical ones. Making both co-exist in the same execution thread can be challenging because of radically different requirements
and constraints. For example, part of the application that controls actuators over UAVCAN may require very low latency,
whereas a non-realtime component (e.g. a firmware update trigger) does not require real-time priority,
but in turn may have to perform long blocking I/O operations, such as file system access, etc. A radical solution to this problem is to run the node in two (or more) execution threads or processes. This enables the designer to put hard real-time tasks in a dedicated thread, while running all low-priority and/or
blocking processes in lower-priority threads.

--- chunk_id: chunk-0034
source_document: Implementations__Libuavcan__Tutorials__12._Multithreading__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 265
content_hash: 5980d9a62be8474a
prev_chunk_id: chunk-0033
next_chunk_id: chunk-0035
section_heading: Architecture
document_type: technical_reference

## Architecture

{% include lightbox.html url="/Implementations/Libuavcan/Tutorials/12._Multithreading/multithreading.svg" title="Multithreading with Libuavcan" thumbnail=true %}

Libuavcan allows to add low-priority threads by means of adding *sub-nodes*,
decoupled from the *main node* via a *virtual CAN driver*. In this tutorial we'll be reviewing a use case with just one sub-node,
but the approach can be scaled to more sub-nodes if necessary by means of daisy-chaining them together
with extra virtual drivers. A virtual CAN driver is a class that implements `uavcan::ICanDriver` (see libuavcan porting guide for details). An object of this class is fed to the sub-node in place of a real CAN driver. ### Transmission

The sub-node emits its outgoing (TX) CAN frames into the virtual driver,
where they get enqueued in a synchronized prioritized queue. The main node periodically unloads the enqueued TX frames from the virtual driver into its own
prioritized TX queue, which then gets flushed into the CAN driver, thus completing the pipeline. Injection of TX frames from sub-node to the main node's queue is done via `uavcan::INode::injectTxFrame(..)`. ### Reception

The main node simply duplicates all incoming (RX) CAN frames to the virtual CAN driver. This is done via the interface `uavcan::IRxFrameListener`,
which is installed via the method `uavcan::INode::installRxFrameListener(uavcan::IRxFrameListener*)`.

--- chunk_id: chunk-0035
source_document: Implementations__Libuavcan__Tutorials__12._Multithreading__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 345
content_hash: 7edbde5c4516745a
prev_chunk_id: chunk-0034
next_chunk_id: chunk-0036
section_heading: Multiprocessing
document_type: technical_reference

## Multiprocessing

{% include lightbox.html url="/Implementations/Libuavcan/Tutorials/12._Multithreading/multiprocessing.svg" title="Multiprocessing with Libuavcan" thumbnail=true %}

A node may be implemented not only in multiple threads, but in multiple processes as well
(with isolated address spaces). In this case, every sub-node will be accessing the CAN hardware as an independent node,
but it will be using the same node ID in all communications, therefore all sub-nodes and the main node
will appear on the bus as the same network participant. We introduce a new term here - *compound node* - which refers to either a multithreaded or a multiprocessed node. ### Limitations
A curious reader could have noticed that the above proposed approaches are in conflict
with requirements of the transport layer specification. Indeed, there is one corner case that has to be kept in mind when working with compound nodes. The transport layer specification introduces the concept of *transfer ID map*,
which is mandatory in order to assign proper transfer ID values to outgoing transfers. The main node and its sub-nodes cannot use a shared transfer ID map, therefore
*multiple sub-nodes must not simultaneously publish transfers with identical descriptors*. This point can be expressed in higher-level terms:

* Every sub-node of a compound node may receive any incoming transfers without limitations. * Only one sub-node can implement a certain publisher or service server. Note that the class `uavcan::SubNode` does not publish `uavcan.protocol.NodeStatus` and
does not provide service `uavcan.protocol.GetNodeInfo` and such (actually it doesn't implement any
publishers or servers or such at all), because this functionality is already provided by the main node class.

--- chunk_id: chunk-0036
source_document: Implementations__Libuavcan__Tutorials__12._Multithreading__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 529
content_hash: 37310d13915c13f0
prev_chunk_id: chunk-0035
next_chunk_id: chunk-0037
section_heading: Example
document_type: technical_reference

## Example
### Virtual CAN driver ```cpp
{% include_relative uavcan_virtual_driver.hpp %}
``` ### Demo application

This demo also shows how to use a thread-safe heap-based shared block memory allocator. This allocator enables lower memory footprint for compound nodes than the default one. ```cpp
{% include_relative node.cpp %}
``` Possible output: ```
uavcan_virtual_iface::Driver: Total memory blocks: 468, blocks per queue: 468
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1001557f   05 00 00 00 00 00 00 c5  '........' ts_m=120912.553326 ts_utc=1443574957.568273 iface=0
uavcan_virtual_iface::Iface: TX injection [iface_index=0]: <volat> 0x1e01ff81   c0  '.'
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   18 ef 05 00 00 00 00 80  '........' ts_m=120912.594184 ts_utc=1443574957.609083 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   00 00 00 00 00 00 00 20  '....... ' ts_m=120912.594188 ts_utc=1443574957.609096 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   00 00 00 00 00 00 00 00  '........' ts_m=120912.594189 ts_utc=1443574957.609102 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   00 00 00 00 00 00 00 20  '....... ' ts_m=120912.594189 ts_utc=1443574957.609110 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   00 00 00 00 00 00 00 00  '........' ts_m=120912.594190 ts_utc=1443574957.609116 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   00 00 00 00 00 00 00 20  '....... ' ts_m=120912.594191 ts_utc=1443574957.609121 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   00 6f 72 67 2e 75 61 00  '.org.ua.' ts_m=120912.594192 ts_utc=1443574957.609128 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   76 63 61 6e 2e 6c 69 20  'vcan.li ' ts_m=120912.594193 ts_utc=1443574957.609131 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   6e 75 78 5f 61 70 70 00  'nux_app.' ts_m=120912.594194 ts_utc=1443574957.609135 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   2e 6e 6f 64 65 74 6f 20  '.nodeto ' ts_m=120912.594195 ts_utc=1443574957.609139 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   6f 6c 40                 'ol@' ts_m=120912.594195 ts_utc=1443574957.609143 iface=0
Node info for 127:
status:
  uptime_sec: 5
  health: 0
  mode: 0
  sub_mode: 0
  vendor_specific_status_code: 0
software_version:
  major: 0
  minor: 0
  optional_field_flags: 0
  vcs_commit: 0
  image_crc: 0
hardware_version:
  major: 0
  minor: 0
  unique_id: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  certificate_of_authenticity: ""
name: "org.uavcan.linux_app.nodetool"
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1001557f   06 00 00 00 00 00 00 c6  '........' ts_m=120913.553339 ts_utc=1443574958.568299 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1001557f   07 00 00 00 00 00 00 c7  '........' ts_m=120914.553385 ts_utc=1443574959.568286 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1001557f   08 00 00 00 00 00 00 c8  '........' ts_m=120915.553300 ts_utc=1443574960.568262 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1001557f   09 00 00 00 00 00 00 c9  '........' ts_m=120916.553426 ts_utc=1443574961.568343 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1001557f   0a 00 00 00 00 00 00 ca  '........' ts_m=120917.553359 ts_utc=1443574962.568282 iface=0
Node 127 went offline
```

--- chunk_id: chunk-0037
source_document: Implementations__Libuavcan__Tutorials__12._Multithreading__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 489
content_hash: f9cbf2ae6abace13
prev_chunk_id: chunk-0036
next_chunk_id: chunk-0038
section_heading: Example
document_type: technical_reference

Possible output: ```
uavcan_virtual_iface::Driver: Total memory blocks: 468, blocks per queue: 468
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1001557f   05 00 00 00 00 00 00 c5  '........' ts_m=120912.553326 ts_utc=1443574957.568273 iface=0
uavcan_virtual_iface::Iface: TX injection [iface_index=0]: <volat> 0x1e01ff81   c0  '.'
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   18 ef 05 00 00 00 00 80  '........' ts_m=120912.594184 ts_utc=1443574957.609083 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   00 00 00 00 00 00 00 20  '....... ' ts_m=120912.594188 ts_utc=1443574957.609096 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   00 00 00 00 00 00 00 00  '........' ts_m=120912.594189 ts_utc=1443574957.609102 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   00 00 00 00 00 00 00 20  '....... ' ts_m=120912.594189 ts_utc=1443574957.609110 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   00 00 00 00 00 00 00 00  '........' ts_m=120912.594190 ts_utc=1443574957.609116 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   00 00 00 00 00 00 00 20  '....... ' ts_m=120912.594191 ts_utc=1443574957.609121 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   00 6f 72 67 2e 75 61 00  '.org.ua.' ts_m=120912.594192 ts_utc=1443574957.609128 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   76 63 61 6e 2e 6c 69 20  'vcan.li ' ts_m=120912.594193 ts_utc=1443574957.609131 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   6e 75 78 5f 61 70 70 00  'nux_app.' ts_m=120912.594194 ts_utc=1443574957.609135 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   2e 6e 6f 64 65 74 6f 20  '.nodeto ' ts_m=120912.594195 ts_utc=1443574957.609139 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1e0101ff   6f 6c 40                 'ol@' ts_m=120912.594195 ts_utc=1443574957.609143 iface=0
Node info for 127:
status:
  uptime_sec: 5
  health: 0
  mode: 0
  sub_mode: 0
  vendor_specific_status_code: 0
software_version:
  major: 0
  minor: 0
  optional_field_flags: 0
  vcs_commit: 0
  image_crc: 0
hardware_version:
  major: 0
  minor: 0
  unique_id: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  certificate_of_authenticity: ""
name: "org.uavcan.linux_app.nodetool"
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1001557f   06 00 00 00 00 00 00 c6  '........' ts_m=120913.553339 ts_utc=1443574958.568299 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1001557f   07 00 00 00 00 00 00 c7  '........' ts_m=120914.553385 ts_utc=1443574959.568286 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1001557f   08 00 00 00 00 00 00 c8  '........' ts_m=120915.553300 ts_utc=1443574960.568262 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1001557f   09 00 00 00 00 00 00 c9  '........' ts_m=120916.553426 ts_utc=1443574961.568343 iface=0
uavcan_virtual_iface::Driver: RX [flags=0]: 0x1001557f   0a 00 00 00 00 00 00 ca  '........' ts_m=120917.553359 ts_utc=1443574962.568282 iface=0
Node 127 went offline
``` ### Running on Linux

Build the application using the following CMake script: ```cmake
{% include_relative CMakeLists.txt %}
```

--- chunk_id: chunk-0038
source_document: Implementations__Libuavcan__Tutorials__13._CAN_acceptance_filters__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 85
content_hash: 5090e6e46159b23d
prev_chunk_id: chunk-0037
next_chunk_id: chunk-0039
section_heading: CAN acceptance filters
document_type: technical_reference

# CAN acceptance filters

One of the most significant features of a CAN protocol controller is the acceptance filtering capability. Most of CAN 
implementations provide some hardware acceptance filters to relieve the microcontroller from the task of filtering 
those messages which are needed from those which are not of interest. You can read more about CAN hardware acceptance filters in
[this article](http://www.inp.nsk.su/~kozak/canbus/canimpl.pdf), page 25-28.

--- chunk_id: chunk-0039
source_document: Implementations__Libuavcan__Tutorials__13._CAN_acceptance_filters__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 156
content_hash: cd6354ea29335c36
prev_chunk_id: chunk-0038
next_chunk_id: chunk-0040
section_heading: Operation principle
document_type: technical_reference

## Operation principle

Diagram below shows how hardware acceptance filters work within CAN protocol:

{% include lightbox.html url="/Implementations/Libuavcan/Tutorials/13._CAN_acceptance_filters/acceptance_filters_scheme.png" title="CAN acceptance filtering" %}

### Example
### Publisher/Client node

This application will be constantly sending messages and service requests to the subscriber/server node (below). It will help to better understand how hardware acceptance filters work and how to properly configure them using
libuavcan. Put the following code into `publisher_client.cpp`: ```cpp
{% include_relative publisher_client.cpp %}
``` ### Subscriber/Server node

This application demonstrates how to configure hardware acceptance filters with libuavcan. Put the following code into `subscriber_server.cpp`: ```cpp
{% include_relative subscriber_server.cpp %}
``` ### Running on Linux
Build the applications using the following CMake script: ```cmake
{% include_relative CMakeLists.txt %}
```

--- chunk_id: chunk-0040
source_document: Implementations__Libuavcan__Tutorials__2._Node_initialization_and_startup__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 25
content_hash: 7108fb81e12f092c
prev_chunk_id: chunk-0039
next_chunk_id: chunk-0041
section_heading: Node initialization and startup
document_type: technical_reference

# Node initialization and startup

In this tutorial we'll create a simple node that doesn't do anything useful yet.

--- chunk_id: chunk-0041
source_document: Implementations__Libuavcan__Tutorials__2._Node_initialization_and_startup__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 760
content_hash: a623acb41af0e5fb
prev_chunk_id: chunk-0040
next_chunk_id: chunk-0042
section_heading: Abstract
document_type: technical_reference

## Abstract

In order to add UAVCAN functionality into an application, we'll have to create a node object of class `uavcan::Node`,
which is the cornerstone of the library's API.
The class requires access to the CAN driver and the system clock, which are platform-specific components,
therefore they are isolated from the library through the following interfaces:

* `uavcan::ICanDriver`
* `uavcan::ICanIface`
* `uavcan::ISystemClock`

Classes that implement above interfaces are provided by libuavcan platform drivers.
Applications that are using libuavcan can be easily ported between platforms by means of swapping the implementations
of these interfaces.

### Memory management

Libuavcan does not use heap.

#### Dynamic memory

Dynamic memory allocations are managed by constant-time determenistic fragmentation-free block memory allocator.
The size of the memory pool that is dedicated to block allocation should be defined compile-time through a template
argument of the node class `uavcan::Node`.
If the template argument is not provided, the node will expect the application to provide a reference to a custom
allocator to the constructor (custom allocators are explained below).

The library uses dynamic memory for the following tasks:

* Allocation of temporary buffers for reception of multi-frame transfers;
* Keeping receiver states (refer to the transport layer specification for more info);
* Keeping transfer ID map (refer to the transport layer specification for more info);
* Prioritized TX queue;
* Some high-level logic.

Typically, the size of the memory pool will be between 4 KB (for a simple node) and 512 KB (for a very complex node).
The minimum safe size of the memory pool can be evaluated as a double of the sum of the following values:

* For every incoming data type, multiply its maximum serialized length to the number of nodes that may publish it and
add up the results.
* Sum the maximum serialized length of all outgoing data types and multiply to the number of CAN interfaces available
to the node plus one.

It is recommended to round the result up to 64-byte boundary.

##### Memory pool sizing example

Consider the following example:

Property                                            | Value
----------------------------------------------------|------------------------------------------------------------------
Number of CAN interfaces                            | 2
Number of publishers of the data type A             | 3
Maximum serialized length of the data type A        | 100 bytes
Number of publishers of the data type B             | 32
Maximum serialized length of the data type B        | 24 bytes
Maximum serialized length of the data type X        | 256 bytes
Maximum serialized length of the data type Z        | 10 bytes

A node that is interested in receiving data types A and B, and in publishing data types X and Y,
will require at least the following amount of memory for the memory pool:

    2 * ((3 * 100 + 32 * 24) + (2 + 1) * (256 + 10)) = 3732 bytes
    Round up to 64: 3776 bytes.

##### Memory gauge

The library allows to query current memory use as well as peak (worst case) memory use with the following methods of
the class `PoolAllocator<>`:

* `uint16_t getNumUsedBlocks() const` - returns the number of blocks that are currently in use.
* `uint16_t getNumFreeBlocks() const` - returns the number of blocks that are currently free.
* `uint16_t getPeakNumUsedBlocks() const` - returns the peak number of blocks allocated, i.e. worst case pool usage.

The methods above can be accessed as follows: ```cpp
std::cout << node.getAllocator().getNumUsedBlocks()     << std::endl;
std::cout << node.getAllocator().getNumFreeBlocks()     << std::endl;
std::cout << node.getAllocator().getPeakNumUsedBlocks() << std::endl;
```

--- chunk_id: chunk-0042
source_document: Implementations__Libuavcan__Tutorials__2._Node_initialization_and_startup__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 774
content_hash: 4bf126189178c9ca
prev_chunk_id: chunk-0041
next_chunk_id: chunk-0043
section_heading: Abstract
document_type: technical_reference

## Abstract

In order to add UAVCAN functionality into an application, we'll have to create a node object of class `uavcan::Node`,
which is the cornerstone of the library's API.
The class requires access to the CAN driver and the system clock, which are platform-specific components,
therefore they are isolated from the library through the following interfaces:

* `uavcan::ICanDriver`
* `uavcan::ICanIface`
* `uavcan::ISystemClock`

Classes that implement above interfaces are provided by libuavcan platform drivers.
Applications that are using libuavcan can be easily ported between platforms by means of swapping the implementations
of these interfaces.

### Memory management

Libuavcan does not use heap.

#### Dynamic memory

Dynamic memory allocations are managed by constant-time determenistic fragmentation-free block memory allocator.
The size of the memory pool that is dedicated to block allocation should be defined compile-time through a template
argument of the node class `uavcan::Node`.
If the template argument is not provided, the node will expect the application to provide a reference to a custom
allocator to the constructor (custom allocators are explained below).

The library uses dynamic memory for the following tasks:

* Allocation of temporary buffers for reception of multi-frame transfers;
* Keeping receiver states (refer to the transport layer specification for more info);
* Keeping transfer ID map (refer to the transport layer specification for more info);
* Prioritized TX queue;
* Some high-level logic.

Typically, the size of the memory pool will be between 4 KB (for a simple node) and 512 KB (for a very complex node).
The minimum safe size of the memory pool can be evaluated as a double of the sum of the following values:

* For every incoming data type, multiply its maximum serialized length to the number of nodes that may publish it and
add up the results.
* Sum the maximum serialized length of all outgoing data types and multiply to the number of CAN interfaces available
to the node plus one.

It is recommended to round the result up to 64-byte boundary.

##### Memory pool sizing example

Consider the following example:

Property                                            | Value
----------------------------------------------------|------------------------------------------------------------------
Number of CAN interfaces                            | 2
Number of publishers of the data type A             | 3
Maximum serialized length of the data type A        | 100 bytes
Number of publishers of the data type B             | 32
Maximum serialized length of the data type B        | 24 bytes
Maximum serialized length of the data type X        | 256 bytes
Maximum serialized length of the data type Z        | 10 bytes

A node that is interested in receiving data types A and B, and in publishing data types X and Y,
will require at least the following amount of memory for the memory pool:

    2 * ((3 * 100 + 32 * 24) + (2 + 1) * (256 + 10)) = 3732 bytes
    Round up to 64: 3776 bytes.

##### Memory gauge

The library allows to query current memory use as well as peak (worst case) memory use with the following methods of
the class `PoolAllocator<>`:

* `uint16_t getNumUsedBlocks() const` - returns the number of blocks that are currently in use.
* `uint16_t getNumFreeBlocks() const` - returns the number of blocks that are currently free.
* `uint16_t getPeakNumUsedBlocks() const` - returns the peak number of blocks allocated, i.e. worst case pool usage.

The methods above can be accessed as follows: ```cpp
std::cout << node.getAllocator().getNumUsedBlocks()     << std::endl;
std::cout << node.getAllocator().getNumFreeBlocks()     << std::endl;
std::cout << node.getAllocator().getPeakNumUsedBlocks() << std::endl;
``` The example above assumes that the node object is named `node`.

--- chunk_id: chunk-0043
source_document: Implementations__Libuavcan__Tutorials__2._Node_initialization_and_startup__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 520
content_hash: d6fde60d70a2a494
prev_chunk_id: chunk-0042
next_chunk_id: chunk-0044
section_heading: Abstract
document_type: technical_reference

```cpp
std::cout << node.getAllocator().getNumUsedBlocks()     << std::endl;
std::cout << node.getAllocator().getNumFreeBlocks()     << std::endl;
std::cout << node.getAllocator().getPeakNumUsedBlocks() << std::endl;
``` The example above assumes that the node object is named `node`. ##### Custom allocators

The node classes can accept a custom allocator provided by the application instead of using a default one. In order to use a custom allocator, omit the template argument to the node class, and provide a reference to
`uavcan::IPoolAllocator` to the node class constructor. The library implements an alternative allocator that uses heap memory instead of a statically allocated pool. It can be found under `uavcan/helpers/heap_based_pool_allocator.hpp`. Please read the class documentation for more info. The tutorial dedicated to multithreading also covers the topic of custom allocators. #### Stack allocation

Deserialized message and service objects are allocated on the stack. Therefore, the size of the stack available to the thread must account for the largest used message or service object. This also implies that any reference to a message or service object passed to the application via a callback will be
invalidated once the callback returns control back to the library. Typically, minimum safe size of the stack would be about 1.5 KB. ### Threading

From the standpoint of threading, the following configurations are available:

* Single-threaded - the library runs entirely in a single thread. * Multi-threaded - the library runs in two threads:
  * Primary thread, which is suitable for hard real time, low-latency communications;
  * Secondary threads, which are suitable for blocking, I/O-intensive, or CPU-intensive tasks, but not for
real-time tasks. #### Single-threaded configuration

In a single-threaded configuration, the library's thread should either always block inside `Node<>::spin()`, or
invoke `Node<>::spin()` or `Node<>::spinOnce()` periodically. ##### Blocking inside `spin()`

This is the most typical use-case: ```cpp
for (;;)
{
    const int error = node.spin(uavcan::MonotonicDuration::fromMSec(100));
    if (error < 0)
    {
        std::cerr << "Transient error: " << error << std::endl; // Handle the transient error...
    }
}
``` Some background processing can be performed between the calls to `spin()`: ```cpp
for (;;)
{
    const int error = node.spin(uavcan::MonotonicDuration::fromMSec(100));
    if (error < 0)
    {
        std::cerr << "Transient error: " << error << std::endl; // Handle the transient error...
    }

    performBackgroundProcessing();  // Will be invoked between spin() calls, at 10 Hz in this example
}
``` In the latter example, the function `performBackgroundProcessing()` will be invoked at 10 Hz between calls to
`Node<>::spin()`.

--- chunk_id: chunk-0044
source_document: Implementations__Libuavcan__Tutorials__2._Node_initialization_and_startup__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 390
content_hash: 5678e8748b9fc2ae
prev_chunk_id: chunk-0043
next_chunk_id: chunk-0045
section_heading: Abstract
document_type: technical_reference

```cpp
for (;;)
{
    const int error = node.spin(uavcan::MonotonicDuration::fromMSec(100));
    if (error < 0)
    {
        std::cerr << "Transient error: " << error << std::endl; // Handle the transient error...
    }

    performBackgroundProcessing();  // Will be invoked between spin() calls, at 10 Hz in this example
}
``` In the latter example, the function `performBackgroundProcessing()` will be invoked at 10 Hz between calls to
`Node<>::spin()`. The same effect can be achieved with libuavcan's timer objects, which will be covered in the following tutorials. ##### Blocking outside of `spin()`

This is a more involved use case. This approach can be useful if the application needs to poll various I/O operations in the same thread
with libuavcan. In this case, the application will have to obtain the *file descriptor* from the UAVCAN's CAN driver object,
and add it to the set of file descriptors it is polling on. Whenever the CAN driver's file descriptor reports an event, the application will call either
`Node<>::spin()` or `Node<>::spinOnce()`. Also, the spin method must be invoked periodically; the recommended maximum period is 10 milliseconds. The difference between `Node<>::spin()` and `Node<>::spinOnce()` is as follows:

* `spin()` - blocks until the timeout has expired, then returns, even if some of the CAN frames or timer events
are still pending processing. * `spinOnce()` - instead of blocking,
it returns immediately once all available CAN frames and timer events are processed. #### Multi-threaded configuration

This configuration is covered later in a dedicated tutorial. In short, it splits the node into multiple node objects,
where each node object is being maintained in a separate thread. The same concepts concerning the spin methods apply as for the single-threaded configuration (see above). Typically, the separated node objects communicate with each other by means of a *virtual CAN driver interface*.

--- chunk_id: chunk-0045
source_document: Implementations__Libuavcan__Tutorials__2._Node_initialization_and_startup__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 510
content_hash: bbe68ba5c07f57f0
prev_chunk_id: chunk-0044
next_chunk_id: chunk-0046
section_heading: The code
document_type: technical_reference

## The code

Put the following code into `node.cpp`: ```cpp
{% include_relative node.cpp %}
``` ### Running on Linux
We need to implement the platform-specific functions declared in the beginning of the example code above,
write a build script, and then build the application. For the sake of simplicity, it is assumed that there's a single CAN interface named `vcan0`. Libuavcan must be installed on the system in order for the build to succeed. Also take a look at the CLI tools that come with the libuavcan Linux platform driver -
they will be helpful when learning from the tutorials. ### Implementing the platform-specific functions

Put the following code into `platform_linux.cpp`: ```cpp
{% include_relative platform_linux.cpp %}
``` ### Writing the build script

We're going to use [CMake](http://cmake.org/), but other build systems will work just as well. Put the following code into `CMakeLists.txt`: ```cmake
{% include_relative CMakeLists.txt %}
``` #### Building

The building is quite standard for CMake: ```sh
mkdir build
cd build
cmake ..
make -j4
``` When these steps are executed, the application can be launched. ### Using virtual CAN interface

It is convenient to test CAN applications against virtual CAN interfaces. In order to add a virtual CAN interface, execute the following: ```sh
IFACE="vcan0"

modprobe can
modprobe can_raw
modprobe can_bcm
modprobe vcan

ip link add dev $IFACE type vcan
ip link set up $IFACE

ifconfig $IFACE up
``` Libuavcan also includes utility `uavcan_add_vcan` that automates the procedure. For example: ```bash
uavcan_add_vcan vcan0
``` Execute `uavcan_add_vcan --help` to get usage info. ### Using SLCAN (tunneling CAN over serial port)

Libuavcan includes an utility named `uavcan_add_slcan` that allows to easily configure an SLCAN interface. For example: ```bash
uavcan_add_slcan /dev/ttyACM0
``` Execute `uavcan_add_slcan --help` to get full usage info. Note that SLCAN support requires that the package `can-utils` is installed on the system. On a Debian/Ubuntu-based system the package can be installed from APT: `apt-get install can-utils`. If this package is not available for your Linux distribution, you can
[build it from sources](http://elinux.org/Can-utils). In certain cases SLCAN adapters may be losing TX frames due to insufficient capacity of the interface's TX queue. This can be easily solved by means of providing larger TX queue for the interface: ```sh
ifconfig slcan0 txqueuelen 100     # Where 'slcan0' is the interface and '100' is queue depth
```

--- chunk_id: chunk-0046
source_document: Implementations__Libuavcan__Tutorials__2._Node_initialization_and_startup__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 178
content_hash: 0adbbc1769f8383e
prev_chunk_id: chunk-0045
next_chunk_id: chunk-0047
section_heading: The code
document_type: technical_reference

This can be easily solved by means of providing larger TX queue for the interface: ```sh
ifconfig slcan0 txqueuelen 100     # Where 'slcan0' is the interface and '100' is queue depth
``` ### Using `candump`

`candump` is a tool from the package `can-utils` that can be used to monitor CAN bus traffic. ```sh
candump -caeta vcan0
``` You can always combine it with `grep` and other standard tools for advanced data processing, for example: ```sh
# Ignore status messages of node 121:
candump -caetz slcan0 | grep -v '\S\S015579'
# Print only messages from node 10 except its status messages:
candump -caetz slcan0 | grep '\S\S\S\S\S\S0A' | grep -v '\S\S01550A'
# Dump exchange to a file for later analysis:
candump -caetz slcan0 > can_`date -Iseconds`.dump
``` Learn how to grep from the
[grep manual](https://www.gnu.org/software/findutils/manual/html_node/find_html/grep-regular-expression-syntax.html).

--- chunk_id: chunk-0047
source_document: Implementations__Libuavcan__Tutorials__2._Node_initialization_and_startup__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 85
content_hash: 3fd0f09a5351c284
prev_chunk_id: chunk-0046
next_chunk_id: chunk-0048
section_heading: Running on STM32
document_type: technical_reference

## Running on STM32

The platform-specific functions can be implemented as follows: ```cpp
{% include_relative platform_stm32.cpp %}
``` For the rest, please refer to the STM32 test application provided in the repository. ### Running on LPC11C24
The platform-specific functions can be implemented as follows: ```cpp
{% include_relative platform_lpc11c24.cpp %}
``` For the rest, please refer to the LPC11C24 test application provided in the repository.

--- chunk_id: chunk-0048
source_document: Implementations__Libuavcan__Tutorials__3._Publishers_and_subscribers__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 90
content_hash: 5db406fde82871c1
prev_chunk_id: chunk-0047
next_chunk_id: chunk-0049
section_heading: Publishers and subscribers
document_type: technical_reference

# Publishers and subscribers

This tutorial presents two applications:

* Publisher, which broadcasts messages of type `uavcan.protocol.debug.KeyValue` once a second with random values. * Subscriber, which subscribes to messages of types `uavcan.protocol.debug.KeyValue` and
`uavcan.protocol.debug.LogMessage`, and prints them to stdout in the [YAML](https://en.wikipedia.org/wiki/YAML) format. Note that the presented publisher will not publish messages of type `uavcan.protocol.debug.LogMessage`. The reader is advised to extend it with this functionality on their own.

--- chunk_id: chunk-0049
source_document: Implementations__Libuavcan__Tutorials__3._Publishers_and_subscribers__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 101
content_hash: 2e8d6eec09ee9db9
prev_chunk_id: chunk-0048
next_chunk_id: chunk-0050
section_heading: Publisher
document_type: technical_reference

## Publisher ```cpp
{% include_relative publisher.cpp %}
``` ### Subscriber ```cpp
{% include_relative subscriber.cpp %}
``` ### Compatibility with older C++ standards

The following code demonstrates how to work-around the lack of important features in older C++ standards (prior C++11). ```cpp
{% include_relative subscriber_cpp03.cpp %}
``` ### Running on Linux
Build the applications using the following CMake script: ```cmake
{% include_relative CMakeLists.txt %}
``` This build script assumes that the platform-specific functions are defined in
`../2._Node_initialization_and_startup/platform_linux.cpp`.

--- chunk_id: chunk-0050
source_document: Implementations__Libuavcan__Tutorials__4._Services__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 53
content_hash: cc68c15c56a259a1
prev_chunk_id: chunk-0049
next_chunk_id: chunk-0051
section_heading: Services
document_type: technical_reference

# Services

This tutorial presents two applications:

* Server - provides a service of type `uavcan.protocol.file.BeginFirmwareUpdate`. * Client - calls the same service type on a specified node. Server's node ID is provided to the application as a command-line argument.

--- chunk_id: chunk-0051
source_document: Implementations__Libuavcan__Tutorials__4._Services__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 85
content_hash: 4b6390aaf6499134
prev_chunk_id: chunk-0050
next_chunk_id: chunk-0052
section_heading: Server
document_type: technical_reference

## Server ```cpp
{% include_relative server.cpp %}
``` ### Client ```cpp
{% include_relative client.cpp %}
``` ### Compatibility with older C++ standards

The following code demonstrates how to work-around the lack of important features in older C++ standards (prior C++11). ```cpp
{% include_relative client_cpp03.cpp %}
``` ### Running on Linux
Build the applications using the following CMake script: ```cmake
{% include_relative CMakeLists.txt %}
```

--- chunk_id: chunk-0052
source_document: Implementations__Libuavcan__Tutorials__5._Timers__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 13
content_hash: 69daf08b7c172022
prev_chunk_id: chunk-0051
next_chunk_id: chunk-0053
section_heading: Timers
document_type: technical_reference

# Timers

This application demonstrates how to use software timers.

--- chunk_id: chunk-0053
source_document: Implementations__Libuavcan__Tutorials__5._Timers__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 96
content_hash: 03245863e258d7e4
prev_chunk_id: chunk-0052
next_chunk_id: chunk-0054
section_heading: The code
document_type: technical_reference

## The code
### C++11

This is the recommended example. It requires C++11 or a newer version of the C++ standard. ```cpp
{% include_relative node_cpp11.cpp %}
``` ### C++03

This example shows how to work-around the lack of lambdas and `std::function<>` in C++03. ```cpp
{% include_relative node_cpp03.cpp %}
``` ### Running on Linux
Both versions of the application can be built with the following CMake script: ```cmake
{% include_relative CMakeLists.txt %}
```

--- chunk_id: chunk-0054
source_document: Implementations__Libuavcan__Tutorials__6._Time_synchronization__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 282
content_hash: 78451fe3b69e7643
prev_chunk_id: chunk-0053
next_chunk_id: chunk-0055
section_heading: Time synchronization
document_type: technical_reference

# Time synchronization

This advanced-level tutorial shows how to implement network-wide time synchronization with libuavcan. Two applications are implemented:

* Time synchronization slave - a very simple application that synchronizes the local clock with the network time. * Time synchronization master - a full-featured master that can work with other redundant masters in the same network. Note that in real applications the master's logic can be more complex, for instance,
if the local time source is not always available (e.g. like in GNSS receivers). The reader is highly encouraged to build these example applications and experiment a little:

1. Start a master and some slaves and see how the slaves synchronize with the master. 2. Start more than one master (redundant masters) and see how they interact with each other and how the nodes
converge to the same master. Please note that UAVCAN does not explicitly define algorithms used for clock frequency and phase adjustments,
which are implementation defined. For instance, the Linux platform driver relies on the kernel function `adjtime()` to perform clock adjustments;
other platform drivers may implement a simple PLL. This tutorial assumes that you have completed the previous tutorials and have a solid understanding
of the time synchronization algorithm defined in the relevant part of the UAVCAN specification.

--- chunk_id: chunk-0055
source_document: Implementations__Libuavcan__Tutorials__6._Time_synchronization__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 64
content_hash: cde8aa4409120552
prev_chunk_id: chunk-0054
next_chunk_id: chunk-0056
section_heading: Slave
document_type: technical_reference

## Slave

This application implements a time synchronization slave. ```cpp
{% include_relative slave.cpp %}
``` ### Master
This application implements a time synchronization master. ```cpp
{% include_relative master.cpp %}
``` ### Running on Linux
Build the applications using the following CMake script: ```cmake
{% include_relative CMakeLists.txt %}
```

--- chunk_id: chunk-0056
source_document: Implementations__Libuavcan__Tutorials__7._Remote_node_reconfiguration__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 122
content_hash: 7bfd14de43e05099
prev_chunk_id: chunk-0055
next_chunk_id: chunk-0057
section_heading: Remote node reconfiguration
document_type: technical_reference

# Remote node reconfiguration

This advanced-level tutorial shows how to do the following:

* Add support for standard configuration services to a node. * Get, set, save, or erase configuration parameters on a remote node via UAVCAN. These are the standard configuration services defined by the UAVCAN specification:

* `uavcan.protocol.param.GetSet`
* `uavcan.protocol.param.ExecuteOpcode`

Please read the specification for more info. Two applications are implemented in this tutorial:

* Configurator - the node that can alter configuration parameters of a remote node via UAVCAN. * Remote node - the node that supports remote reconfiguration.

--- chunk_id: chunk-0057
source_document: Implementations__Libuavcan__Tutorials__7._Remote_node_reconfiguration__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 134
content_hash: f203c36cb25688bd
prev_chunk_id: chunk-0056
next_chunk_id: chunk-0058
section_heading: Configurator
document_type: technical_reference

## Configurator

Once started, this node performs the following:

* Reads all configuration parameters from a remote node (the user must enter the node ID of the remote node). * Sets all parameters to their maximum values. * Resets all parameters back to their default values. * Restarts the remote node. * Exits. ```cpp
{% include_relative configurator.cpp %}
``` ### Remote node
This node doesn't do anything on its own; it merely provides the standard configuration services. ```cpp
{% include_relative remote_node.cpp %}
``` ### Running on Linux
Build the applications using the following CMake script: ```cmake
{% include_relative CMakeLists.txt %}
```

--- chunk_id: chunk-0058
source_document: Implementations__Libuavcan__Tutorials__8._Custom_data_types__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 149
content_hash: 1582dd87de911127
prev_chunk_id: chunk-0057
next_chunk_id: chunk-0059
section_heading: Custom data types
document_type: technical_reference

# Custom data types

This tutorial covers how to define and use vendor-specific data types (DSDL definitions). The following topics are explained:

* How to define a vendor-specific data type. * How to allow the end user to assign/override a data type ID for a certain type. * How to invoke the DSDL compiler to generate C++ headers for custom data types. Two applications are implemented in this tutorial:

* Server - the node that provides two vendor-specific services. * Client - the node that calls the vendor-specific services provided by the server. This tutorial requires the reader to be familiar with UAVCAN specification and
to have completed all the basic tutorials.

--- chunk_id: chunk-0059
source_document: Implementations__Libuavcan__Tutorials__8._Custom_data_types__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 510
content_hash: 9735ff6fc459e9fe
prev_chunk_id: chunk-0058
next_chunk_id: chunk-0060
section_heading: Defining data types
document_type: technical_reference

## Defining data types
### Abstract

Suppose we have a vendor named "Sirius Cybernetics Corporation" for whom
we need to define the following vendor-specific data types:

* `sirius_cybernetics_corporation.GetCurrentTime` - returns the current time on the server. The default data type ID for this service is 242. * `sirius_cybernetics_corporation.PerformLinearLeastSquaresFit` -
accepts a set of 2D coordinates and returns the coefficients for the best-fit linear function. This service does not have a default data type ID. Note that both data types are located in the namespace `sirius_cybernetics_corporation`,
which unambiguously indicates that these types are defined by Sirius Cybernetics Corporation and
allows to avoid name clashing if similarly named data types from different vendors are used in the same application. Note that, according to the naming requirements, name of a DSDL namespace must start with an alphabetic character;
therefore, a company whose name starts with a digit will have to resort to a mangled name
(e.g., "42 Computing" &rarr; `fourtytwo_computing`, or `computing42`, etc.). Even though this tutorial deals with service types,
the same concepts and procedures are also applicable to message types. The reader is encouraged to extend this tutorial with at least one vendor-specific message data type. ### The procedure

As explained in the specification, a namespace for DSDL definitions is just a directory,
so we need to create a directory named `sirius_cybernetics_corporation`. This directory can be placed anywhere; normally you'd probably want to put it in your project's root directory,
as we'll do in this tutorial. You should not create it inside the libuavcan's DSDL directory (`libuavcan/dsdl/...`)
in order to not pollute the libuavcan's source tree with your custom data types. In the newly created directory, place the following DSDL definition in a file named `242.GetCurrentTime.uavcan`: ```python
{% include_relative sirius_cybernetics_corporation/242.GetCurrentTime.uavcan %}
``` Note that the filename starts with the number 242 followed by a dot,
which tells the DSDL compiler that the default data type ID for this type is 242. You can learn more about naming in the relevant part of the specification. In the same directory, place the following DSDL definition in a file named `PerformLinearLeastSquaresFit.uavcan`: ```python
{% include_relative sirius_cybernetics_corporation/PerformLinearLeastSquaresFit.uavcan %}
``` Now, observe that the definition above refers to the data type `PointXY`. Let's define it - place the following in a file named `PointXY.uavcan`: ```python
{% include_relative sirius_cybernetics_corporation/PointXY.uavcan %}
```

--- chunk_id: chunk-0060
source_document: Implementations__Libuavcan__Tutorials__8._Custom_data_types__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 212
content_hash: 9dcf2d6dd4934ddb
prev_chunk_id: chunk-0059
next_chunk_id: chunk-0061
section_heading: Defining data types
document_type: technical_reference

Let's define it - place the following in a file named `PointXY.uavcan`: ```python
{% include_relative sirius_cybernetics_corporation/PointXY.uavcan %}
``` ### Compiling

Normally, the compilation should be performed by the build system, which is explained later in this tutorial. For the sake of a demonstration, let's compile the data types defined above by manually invoking the DSDL compiler. If the host OS is Linux and libuavcan is installed, the following command can be used:

    $ libuavcan_dsdlc ./sirius_cybernetics_corporation -I/usr/local/share/uavcan/dsdl/uavcan

Alternatively, if the library is not installed, use relative paths
(the command invocation example below assumes that the libuavcan directory and
our vendor-specific namespace directory are both located in the project's root):

    $ libuavcan/libuavcan/dsdl_compiler/libuavcan_dsdlc ./sirius_cybernetics_corporation -Iuavcan/dsdl/uavcan/

Note that if the output directory is not specified explicitly via the command line option `--outdir` or `-O`,
the default will be used, which is `./dsdlc_generated`. It is recommended to exclude the output directory from version control,
e.g. for git, add `dsdlc_generated` to the `.gitignore` config file.

--- chunk_id: chunk-0061
source_document: Implementations__Libuavcan__Tutorials__8._Custom_data_types__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 338
content_hash: d9c12e74296e8553
prev_chunk_id: chunk-0060
next_chunk_id: chunk-0062
section_heading: The code
document_type: technical_reference

## The code
### Server ```cpp
{% include_relative server.cpp %}
``` ### Client ```cpp
{% include_relative client.cpp %}
``` ### Building
This example shows how to build the above applications and compile the vendor-specific data types using CMake. It's quite easy to adapt it to other platforms and build systems - use the
[existing projects](https://www.google.com/?q=site%3Agithub.com%20%2B%22uavcan%22%20%22Makefile%22) as a reference. It is assumed that the libuavcan directory and our vendor-specific namespace directory are both located
in the project's root, although it is not necessary. `CMakeLists.txt`: ```cmake
{% include_relative CMakeLists.txt %}
``` ### Running
These instructions assume a Linux environment. First, make sure that the system has at least one CAN interface. You may want to refer to the first tutorials to learn how to add a virtual CAN interface on Linux. Running the server with node ID 111:

    $ ./server 111

The server just sits there waiting for requests, not doing anything on its own. Start another terminal and execute the client with node ID 112:

    $ ./client 112 111

The client should print something like this: ```
# Service call result [sirius_cybernetics_corporation.GetCurrentTime] OK server_node_id=111 tid=0
# Received struct ts_m=25935.913686 ts_utc=1442844327.400572 snid=111
time:
  usec: 1442844327400560
# Service call result [sirius_cybernetics_corporation.PerformLinearLeastSquaresFit] OK server_node_id=111 tid=0
# Received struct ts_m=25935.913891 ts_utc=1442844327.400725 snid=111
slope: 0.4
y_intercept: -4

``` Now, execute the client providing a non-existent server Node ID and see what happens: ```
$ ./client 112 1
# Service call result [sirius_cybernetics_corporation.GetCurrentTime] FAILURE server_node_id=1 tid=0
# (no data)
# Service call result [sirius_cybernetics_corporation.PerformLinearLeastSquaresFit] FAILURE server_node_id=1 tid=0
# (no data)
```

--- chunk_id: chunk-0062
source_document: Implementations__Libuavcan__Tutorials__9._Node_discovery__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 214
content_hash: cd20bc5c66cc48f4
prev_chunk_id: chunk-0061
next_chunk_id: chunk-0063
section_heading: Node discovery
document_type: technical_reference

# Node discovery

This tutorial demonstrates how to discover other nodes in the network and retrieve information about each node. Two applications are implemented in this tutorial:

* Passive network monitor - a small application that simply listens to messages of type `uavcan.protocol.NodeStatus`,
which allows it to obtain the following minimal information about each node:
  * Node ID
  * Operating mode (Initialization, Operational, Maintenance, etc.)
  * Health code (OK, Warning, Error, Critical)
  * Uptime
* Active network monitor - an application that extends the passive monitor so that it actively requests
`uavcan.protocol.GetNodeInfo` whenever a node appears in the network or restarts. This allows the monitor to obtain the following information about each node:
  * All information from the passive monitor (see above)
  * Node name
  * Software version information
  * Hardware version information, including the globally unique ID and the certificate of authenticity

Refer to the applications provided with the Linux platform drivers to see some
real-world examples of network monitoring.

--- chunk_id: chunk-0063
source_document: Implementations__Libuavcan__Tutorials__9._Node_discovery__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 65
content_hash: 566ef4b0d7571557
prev_chunk_id: chunk-0062
next_chunk_id: chunk-0064
section_heading: Passive monitor
document_type: technical_reference

## Passive monitor ```cpp
{% include_relative passive.cpp %}
``` ### Active monitor ```cpp
{% include_relative active.cpp %}
``` The output may look like this:

{% include lightbox.html url="/Implementations/Libuavcan/Tutorials/9._Node_discovery/output.png" title="Sample output" %}

### Running on Linux
Build the applications using the following CMake script: ```cmake
{% include_relative CMakeLists.txt %}
```

--- chunk_id: chunk-0064
source_document: Implementations__Libuavcan__Tutorials__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 68
content_hash: 52c04a723c72f605
prev_chunk_id: chunk-0063
next_chunk_id: chunk-0065
section_heading: Libuavcan tutorials
document_type: technical_reference

# Libuavcan tutorials

Tutorials are arranged in ascending order of difficulty and descending order of importance. All tutorials are written in C++11 in a cross-platform way,
so they can be applied to any supported platform with minimal changes. The code can be easily adapted to earlier standards of C++ if needed.

--- chunk_id: chunk-0065
source_document: Implementations__Libuavcan__Tutorials__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 49
content_hash: 180de6b72c6d77bb
prev_chunk_id: chunk-0064
next_chunk_id: chunk-0066
section_heading: Prerequisite skills and knowledge
document_type: technical_reference

## Prerequisite skills and knowledge

* Familiarity with UAVCAN specification
* Intermediate C++ skills

### License
Unless expressly stated otherwise,
all code samples contained in the tutorials are distributed under the terms of
[CC0 (public domain dedication)](https://creativecommons.org/publicdomain/zero/1.0/).

--- chunk_id: chunk-0066
source_document: Implementations__Libuavcan__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 474
content_hash: 82d017791ceeb705
prev_chunk_id: chunk-0065
next_chunk_id: chunk-0067
section_heading: Libuavcan
document_type: technical_reference

# Libuavcan

{% include lightbox.html url="figures/libuavcan_data_flow.png" title="Libuavcan data flow" thumbnail=true %}

NOTE: Libuavcan is not recommended for new implementations. Please use
libcanard with the new canard C++ interface. Using libcanard results
in a much lighter weight implementaion, reducing flash usage, memory
and CPU

Libuavcan is a portable, cross-platform library written in C++ with minimal dependency on the C++ standard library. It can be compiled by virtually any standard-compliant C++ compiler and can be used on virtually any architecture/OS. Libuavcan is free to use for anyone under the terms of the MIT open source license. Libuavcan is implemented in two components:

* Cross-platform **core**. This is the largest component that implements the entire DroneCAN stack in a platform-independent way. * Platform-specific **drivers**. These are thin layers that adapt the core for a particular OS/architecture. Drivers are separated from the core by a few C++ interface classes. There are default drivers available for some popular platforms (e.g., Linux, STM32, LPC11C24). The libuavcan core can be compiled in either C++03 or C++11 mode. In the latter case, some extra features are enabled (e.g., callbacks will be implemented through `std::function`
instead of through raw function pointers). In C++03 mode, the implementation has almost zero dependency on the C++ standard library,
which allows to use the library on platforms with very limited C++ support. C++11 mode though requires many parts of the standard library (e.g., `<functional>`). The library can detect the actual C++ standard in use at compile time,
but this can be overridden to force the older C++ standard if desired
(e.g., if the application is compiled in C++11 mode but the full standard library is not available). The library supports a few compile-time configuration options via preprocessor symbols that allow to fine-tune
the implementation for a particular platform/application; in most cases though, it's not required because
there's either a safe default value or an auto-detect setting provided for each configuration option. The implementation also features the following properties that render the library suitable
for deeply embedded and real-time systems:

* Zero use of the heap
(a custom built-in block memory allocator is implemented, which is deterministic and fragmentation free).

--- chunk_id: chunk-0067
source_document: Implementations__Libuavcan__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 205
content_hash: 075f40a5cb11e95d
prev_chunk_id: chunk-0066
next_chunk_id: chunk-0068
section_heading: Libuavcan
document_type: technical_reference

The library supports a few compile-time configuration options via preprocessor symbols that allow to fine-tune
the implementation for a particular platform/application; in most cases though, it's not required because
there's either a safe default value or an auto-detect setting provided for each configuration option. The implementation also features the following properties that render the library suitable
for deeply embedded and real-time systems:

* Zero use of the heap
(a custom built-in block memory allocator is implemented, which is deterministic and fragmentation free). * No C++ exceptions are used by default, but the library can be configured via preprocessor symbols to throw
exceptions if a fatal error occurs (e.g., unexpected null pointer, boundary check failure, etc.). * No run-time type identification (RTTI) is used. * The source code is partially compliant with MISRA C++ 2008. * The code is unit tested and validated using strong static analysis tools. **The source code is available here: <https://github.com/DroneCAN/libuavcan>.**

--- chunk_id: chunk-0068
source_document: Implementations__Libuavcan__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 225
content_hash: 2e0887c23f9c913b
prev_chunk_id: chunk-0067
next_chunk_id: chunk-0069
section_heading: Build dependencies
document_type: technical_reference

## Build dependencies

The following software must be installed on the host computer in order to build the library:

* Either [Python 2.7 or Python 3.x](https://www.python.org) - needed for the DSDL compiler. * A suitable C++ compiler (see below). * Additional dependencies, if any, depending on the environment. Please read the documentation related to your platform (refer to subsections) for more information. ### C++ compiler requirements
#### C++11

* IEEE754 floating point
* At least the following headers of the C++ standard library must be available:
  * `cassert`
  * `climits`
  * `cmath`
  * `cstddef`
  * `cstdio`
  * `cstdlib`
  * `cstring`
  * `cstdint`
  * `cfloat`
  * `cerrno`
  * `functional`

#### C++03

* IEEE754 floating point
* `long long` and `unsigned long long` integer types
* At least the following headers of the C++ standard library must be available:
  * `cassert`
  * `climits`
  * `cmath`
  * `cstddef`
  * `cstdio`
  * `cstdlib`
  * `cstring`
* The following headers of the C standard library must be available:
  * `float.h`
  * `stdint.h`
  * `stdio.h`

--- chunk_id: chunk-0069
source_document: Implementations__Libuavcan__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 153
content_hash: e6d29b65570c83dc
prev_chunk_id: chunk-0068
next_chunk_id: chunk-0070
section_heading: DSDL compiler
document_type: technical_reference

## DSDL compiler

Libuavcan has a DSDL compiler that converts DSDL definitions into libuavcan-compatible header files (`*.hpp`). The compiler is titled `libuavcan_dsdlc`, and it is invoked as follows: ```sh
libuavcan_dsdlc source_dir
``` Where `source_dir` is the root namespace directory containing the data type definitions to be compiled,
e.g. `dsdl/uavcan`. Please use `libuavcan_dsdlc --help` to obtain more detailed usage information. You must invoke the DSDL compiler during your build process before compiling your application and/or the library. For example, if you are using Make, a possible way to invoke the DSDL compiler is as follows: ```make
$(info $(shell $(LIBUAVCAN_DSDLC) $(UAVCAN_DSDL_DIR)))
UINCDIR += dsdlc_generated
``` For more information, refer to the examples specific to your target platform.

--- chunk_id: chunk-0070
source_document: Implementations__Pydronecan__Examples__Automated_ESC_enumeration__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 46
content_hash: eafba72c13e85a73
prev_chunk_id: chunk-0069
next_chunk_id: chunk-0071
section_heading: Automated ESC enumeration
document_type: technical_reference

# Automated ESC enumeration

In this example we'll demonstrate how the automated ESC enumeration feature works from the inside. Please read the UAVCAN specification if the concept of automated enumeration is not familiar to you.

--- chunk_id: chunk-0071
source_document: Implementations__Pydronecan__Examples__Automated_ESC_enumeration__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 226
content_hash: d9c97e8859a659d4
prev_chunk_id: chunk-0070
next_chunk_id: chunk-0072
section_heading: Writing the script
document_type: technical_reference

## Writing the script ```python
{% include_relative automated_esc_enumeration.py %}
``` ### Running the code
Connect ESC to the CAN bus
(it's better to use multiple ESC, otherwise the auto-enumeration procedure becomes rather pointless),
start the script, and follow its instructions. For each ESC you will see the output similar to this: ```
=== PROVIDE ENUMERATION FEEDBACK ON ESC INDEX 0 NOW ===
=== e.g. turn the motor, press the button, etc, depending on your equipment ===
### Message from 124 to All  ts_mono=94836.894482  ts_real=1470647890.850445
value:
  empty:
    {}
parameter_name: 'esc_index' # [101, 115, 99, 95, 105, 110, 100, 101, 120]
Indication received from node 124
Stopping enumeration on node 124
Setting config param 'esc_index' to 0...
### Response from 124 to 10  ts_mono=94837.077415  ts_real=1470647891.033378
value:
  integer_value: 0
default_value:
  integer_value: 0
max_value:
  integer_value: 15
min_value:
  integer_value: 0
name: 'esc_index' # [101, 115, 99, 95, 105, 110, 100, 101, 120]
### Response from 124 to 10  ts_mono=94837.122424  ts_real=1470647891.078387
argument: 0
ok: true
Node 124 assigned ESC index 0
Enumerated so far: [124]
```

--- chunk_id: chunk-0072
source_document: Implementations__Pydronecan__Examples__Automated_ESC_enumeration__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 54
content_hash: a73e5fd2b7b63118
prev_chunk_id: chunk-0071
next_chunk_id: chunk-0073
section_heading: A relevant video
document_type: technical_reference

## A relevant video

The following video demonstrates how the automated enumeration works on the user level. Although it was not performed with the script shown in this example, the core principles remain the same. <iframe width="560" height="315" src="https://www.youtube.com/embed/4nSa8tvpbgQ" frameborder="0" allowfullscreen></iframe>

--- chunk_id: chunk-0073
source_document: Implementations__Pydronecan__Examples__Dump_All_Messages__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 22
content_hash: 9982fae91af7f58b
prev_chunk_id: chunk-0072
next_chunk_id: chunk-0074
section_heading: Dump All Messages
document_type: technical_reference

# Dump All Messages

This example script shows how to dump all messages in human readable form

--- chunk_id: chunk-0074
source_document: Implementations__Pydronecan__Examples__Dump_All_Messages__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 53
content_hash: b6ae9e0507daa11f
prev_chunk_id: chunk-0073
next_chunk_id: chunk-0075
section_heading: Writing the script
document_type: technical_reference

## Writing the script

One code sample is worth 1024 words: ```python
{% include_relative dump_all.py %}
``` ### Running the script
Save the above code somewhere and run it. It will print all messages
on the bus in YAML format

--- chunk_id: chunk-0075
source_document: Implementations__Pydronecan__Examples__ESC_throttle_control__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 48
content_hash: b1b47fba7992c88a
prev_chunk_id: chunk-0074
next_chunk_id: chunk-0076
section_heading: ESC throttle control
document_type: technical_reference

# ESC throttle control

This example script demonstrates how to control ESC throttle setpoint using the PyDroneCAN library. Before running the script, make sure that no other node on the bus issues contradictory ESC commands concurrently.

--- chunk_id: chunk-0076
source_document: Implementations__Pydronecan__Examples__ESC_throttle_control__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 225
content_hash: 025f0436c2af1862
prev_chunk_id: chunk-0075
next_chunk_id: chunk-0077
section_heading: Writing the script
document_type: technical_reference

## Writing the script

One code sample is worth 1024 words: ```python
{% include_relative sine_throttle_output.py %}
``` ### Running the script
Save the above code somewhere and run it. The connected ESC will be changing their RPM in a sine pattern, slowly accelerating and decelerating. The script will periodically print output similar to this: ```
### Message from 124 to All  ts_mono=19376.645693  ts_real=1470440665.872391
error_count: 0
voltage: 13.2812
current: 1.3379
temperature: 313.15
rpm: 1514
power_rating_pct: 13
esc_index: 3
``` ### Using the DroneCAN GUI Tool
It is also possible to run the above script (with minor modifications)
directly from the interactive console of the [DroneCAN GUI Tool](/GUI_Tool),
because the DroneCAN GUI Tool is built on top of PyDroneCAN. In that case you won’t need to create a new node yourself in the script - just use the application’s own node,
it is accessible from the interactive console. For details, please read the documentation of the DroneCAN GUI Tool. {% include lightbox.html url="/Implementations/PyDroneCAN/Examples/ESC_throttle_control/uavcan_gui_tool.png" title="DroneCAN GUI Tool running this example script" %}

--- chunk_id: chunk-0077
source_document: Implementations__Pydronecan__Examples__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 42
content_hash: e0becf8cecf11c2e
prev_chunk_id: chunk-0076
next_chunk_id: chunk-0078
section_heading: PyDroneCAN examples
document_type: technical_reference

# PyDroneCAN examples

This directory contains a collection of hands-on examples of applications and scripts that employ PyDroneCAN. All examples should be run with Python 3.5 or newer, unless specifically noted otherwise.

--- chunk_id: chunk-0078
source_document: Implementations__Pydronecan__Examples__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 45
content_hash: 53dedf4d10aa82f1
prev_chunk_id: chunk-0077
next_chunk_id: chunk-0079
section_heading: Prerequisites
document_type: technical_reference

## Prerequisites

* Familiarity with UAVCAN specification. * Intermediate Python skills. ### License
Unless expressly stated otherwise,
all code samples contained in this directory are distributed under the terms of
[CC0](https://creativecommons.org/publicdomain/zero/1.0/) (public domain dedication).

--- chunk_id: chunk-0079
source_document: Implementations__Pydronecan__Tutorials__1._Setup__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 53
content_hash: 4dd4fdef5ab4288f
prev_chunk_id: chunk-0078
next_chunk_id: chunk-0080
section_heading: Setup
document_type: technical_reference

# Setup

This tutorial covers the basic setup of PyDroneCAN. PyDroneCAN is designed to be as platform-independent as possible. It has been successfully tested under Linux, Windows, and OSX,
but its portability should not be restricted only to these platforms.

--- chunk_id: chunk-0080
source_document: Implementations__Pydronecan__Tutorials__1._Setup__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: 95c8851708c38f64
prev_chunk_id: chunk-0079
next_chunk_id: chunk-0081
section_heading: Installation
document_type: technical_reference

## Installation

It is recommended to use PIP to install PyDroneCAN: ```bash
pip install dronecan
``` If your operating system has both Python 2.7 and Python 3,
you probably should use `pip3` instead of `pip` in the example above. Sometimes the PIP executable is not available at all,
in which case you should resort to the below command: ```bash
python -m pip install dronecan
``` PyDroneCAN requires no external dependencies, except for PySerial if SLCAN support is required (more on this below). ### CAN hardware backends
Supported hardware backends are documented in this section. ### SLCAN (aka LAWICEL)

This backend is available under all supported operating systems. In order to use it, you should also install PySerial: ```bash
pip install pyserial
``` SLCAN is a simple quasi-standard protocol that allows to transfer CAN frames and
CAN adapter commands and status information via a serial port link
(most often it's USB CDC ACM virtual serial port). Many different vendors manufacture SLCAN-compatible CAN adapters. PyDroneCAN has been successfully tested at least with the following models:

* [Zubax Babel](https://zubax.com/products/babel)
* Thiemar muCAN
* VSCOM USB-CAN

Since SLCAN works over a serial port link, USB SLCAN adapters will be detected on the host
<abbr title="Operating System">OS</abbr> as a virtual serial port device. Depending on your OS, serial ports can be accessed as follows:

* On Linux, all devices are represented as files; serial ports can be referred to using the following files:
    * `/dev/serial/by-id/*`, where `*` is a string descriptor of the connected device, e.g. `/dev/serial/by-id/usb-Zubax_Robotics_Zubax_Babel_380032000D5732413336392000000000-if00`;
this is the recommended way of accessing serial ports on Linux,
because each connected device has a persistent name with <abbr title="Unique ID">UID</abbr>
that is invariant to the order in which devices are connected. * `/dev/ttyACM*` or `/dev/ttyUSB*`, where `*` is a number. Files in this directory are symlinked to from `/dev/serial/` described above. * On OSX, look for the following files:
    * `/dev/tty.usbmodem*`, where `*` is a number. * On Windows, connected serial devices will be detected as COM ports. ### SocketCAN

The SocketCAN backend is available only under Linux. For SocketCAN adapter configuration, please refer to the documentation that
came with your adapter. Once you have configured the adapter, it will be
available via a specific network interface name, e.g. `can0`. It is also possible to use PyDroneCAN with virtual CAN interfaces.

--- chunk_id: chunk-0081
source_document: Implementations__Pydronecan__Tutorials__1._Setup__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 100
content_hash: aa7507d4d87c4ab0
prev_chunk_id: chunk-0080
next_chunk_id: chunk-0082
section_heading: Installation
document_type: technical_reference

`can0`. It is also possible to use PyDroneCAN with virtual CAN interfaces. A virtual SocketCAN interface can be brought up using the following commands as root: ```bash
modprobe can
modprobe can_raw
modprobe can_bcm
modprobe vcan
ip link add dev vcan0 type vcan
ip link set up vcan0
ifconfig vcan0 up
``` The following devices have been tested successfully with the SocketCAN backend:

* 8devices USB2CAN
* PEAK-System PCAN-USB
* SLCAN adapters via the SLCAN bridge

--- chunk_id: chunk-0082
source_document: Implementations__Pydronecan__Tutorials__2._Basic_usage__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 132
content_hash: 3f37309dac7f3a89
prev_chunk_id: chunk-0081
next_chunk_id: chunk-0083
section_heading: Basic usage
document_type: technical_reference

# Basic usage

This tutorial will walk you through the basic usage of PyDroneCAN. It is intended for execution in an interactive shell of Python 3.4 or newer. While PyDroneCAN supports Python 2.7, its use is strongly discouraged. It is recommended to keep a running instance of the [DroneCAN GUI Tool](/GUI_Tool) on the same bus
while trying the examples below. If you're working on Linux, consider using a virtual CAN interface for experimenting. This guide is not an extensive list of all capabilities of the library. For that, use the Python's help system (function `help()`), or read the code.

--- chunk_id: chunk-0083
source_document: Implementations__Pydronecan__Tutorials__2._Basic_usage__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 496
content_hash: 0ca6eadb8c014c19
prev_chunk_id: chunk-0082
next_chunk_id: chunk-0084
section_heading: Node initialization
document_type: technical_reference

## Node initialization

Start a Python 3 shell and run this: ```python
import dronecan
node = dronecan.make_node('/dev/ttyACM0')
``` This will create a node connected to the SLCAN interface `/dev/ttyACM0`,
where all options are initialized to default values. The library will select the correct backend automatically by looking at the name of the interface. That is, if the interface is named like `COM3` or like above, the library will choose the SLCAN backend;
if the interface is named in the form of `can0`, the library will select SocketCAN. A more useful node instantiation example is shown below: ```python
import dronecan

# Instantiating an instance of standard service type uavcan.protocol.GetNodeInfo
# Here we need the response data structure, which is why we use the factory Response()
node_info = uavcan.protocol.GetNodeInfo.Response()
node_info.name = 'org.uavcan.pydronecan_demo'
node_info.software_version.major = 1
node_info.hardware_version.unique_id = b'12345' # Setting first 5 bytes; rest will be kept zero
# Fill other fields as necessary...

node = dronecan.make_node('vcan0',
                        node_id=123,          # Setting the node ID 123
                        node_info=node_info)  # Setting node info

# Alternatively, node ID can be set after initialization,
# but only if it hasn't been set before:
node.node_id = 123
``` While the node is running, it is possible to change its mode, health, and vendor specific status code
as follows: ```python
node.mode = uavcan.protocol.NodeStatus().MODE_OPERATIONAL
node.health = uavcan.protocol.NodeStatus().HEALTH_WARNING
node.vendor_specific_status_code = 12345
``` The library expects that it nearly always has a thread of execution blocked inside the
`spin()` method of the node class. It is allowed to deviate from this requirement if the application does not have strict
real-time requirements by temporarily dispatching control to other tasks,
or by invoking the spin method periodically (at least 100 times per second) in a non-blocking way
with zero timeout. Thus, the application should always keep one thread in the node's `spin()` function. ```python
while True:
    try:
        node.spin()             # Spin forever or until an exception is thrown
    except UAVCANException as ex:
        print('Node error:', ex)
``` Another popular use case: ```python
while True:
    try:
        node.spin(1)            # Spin for 1 second or until an exception is thrown
        perform_other_tasks()
        # time.sleep(0.1)       # Never do this!
    except UAVCANException as ex:
        print('Node error:', ex)
``` In general, if the application needs to perform other blocking tasks,
a separate thread should be spawned.

--- chunk_id: chunk-0084
source_document: Implementations__Pydronecan__Tutorials__2._Basic_usage__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 160
content_hash: 8bb53a5afa2d4860
prev_chunk_id: chunk-0083
next_chunk_id: chunk-0085
section_heading: Node initialization
document_type: technical_reference

while True:
    try:
        node.spin(1)            # Spin for 1 second or until an exception is thrown
        perform_other_tasks()
        # time.sleep(0.1)       # Never do this!
    except UAVCANException as ex:
        print('Node error:', ex)
``` In general, if the application needs to perform other blocking tasks,
a separate thread should be spawned. In the next section we'll learn how to run non-blocking parallel tasks from the node thread
by using the callback scheduler embedded in the node. When you're finished with the node, don't forget to call `close()` on it; better yet, use contextlib: ```python
from contextlib import closing
with closing(dronecan.driver.make_node('/dev/ttyACM0', bitrate=1000000)) as node:
    # Do some work here...
# When control reaches the end of the with block, the node will be properly finalized

--- chunk_id: chunk-0085
source_document: Implementations__Pydronecan__Tutorials__2._Basic_usage__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 294
content_hash: 948f7c3dd84e0aa6
prev_chunk_id: chunk-0084
next_chunk_id: chunk-0086
section_heading: Invoking callbacks from the node thread
document_type: technical_reference

## Invoking callbacks from the node thread

{% include lightbox.html url="/Implementations/PyDroneCAN/Tutorials/2._Basic_usage/gui_tool_node_info.png" title="Test node as seen from GUI Tool" thumbnail=true %}

In order to keep the node running in the background while having the shell available for
input, let's spawn a thread and dispatch it into the `spin()` method. This approach works fine for experimenting, however,
it must never be used in production because the library is not thread safe. ```python
import threading
threading.Thread(target=node.spin, daemon=True).start()
``` It is recommended to launch the DroneCAN GUI tool now to make sure that the node can be seen online. Now we'll see how to invoke callbacks once or periodically from the node thread: ```python
def periodic_callback_1hz():
    print('Periodic')

def deferred_call():
    print('Deferred call')

# Invoking a function every second.
periodic_handle = node.periodic(1, periodic_callback_1hz)

# Invoking a function once after a 0.5 second delay expires.
deferred_handle = node.defer(0.5, deferred_call)

# When we no longer want a callback to fire, the associated task can be removed.
periodic_handle.remove()

# Deferred calls get removed automatically once they were invoked.
# Removing a deferred call before its invocation can be used to cancel
# pending deferred calls if they are no longer needed.
deferred_handle.remove()
``` Note that all exceptions thrown from all kinds of callbacks from the node
are propagated through and thrown from the `spin()` method. Make sure to catch them.

--- chunk_id: chunk-0086
source_document: Implementations__Pydronecan__Tutorials__2._Basic_usage__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 202
content_hash: acc37c54d6c90564
prev_chunk_id: chunk-0085
next_chunk_id: chunk-0087
section_heading: Loading DSDL definitions
document_type: technical_reference

## Loading DSDL definitions

The library automatically loads definitions of all standard DSDL definitions
(from the namespace `uavcan.*`) immediately once the module is imported. Additional definitions, such as vendor-specific definitions,
can be added later by invoking `uavcan.load_dsdl()` with a list of lookup paths provided in the first argument. Refer to the function documentation for more info. Standard definitions can be reached directly from the module namespace, e.g. `uavcan.protocol.NodeStatus`. Vendor-specific definitions can be accessed via the pseudo-module `uavcan.thirdparty`. Both standard and vendor-specific types are also accessible via the global dictionaries
`uavcan.DATATYPES` and `uavcan.TYPENAMES`. When instantiating a message type, its type name should be treated as a class name,
e.g. `msg = uavcan.protocol.NodeStatus()`. When instantiating a service request or response structure,
its type name need to be appended with either `Request()` or `Response()`
specifier, e.g. `uavcan.protocol.GetNodeInfo.Request()`, `uavcan.protocol.GetNodeInfo.Response()`. Direct instantiation of services is not defined by the specification,
and will lead to a runtime error.

--- chunk_id: chunk-0087
source_document: Implementations__Pydronecan__Tutorials__2._Basic_usage__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 293
content_hash: 3eede1b09295656c
prev_chunk_id: chunk-0086
next_chunk_id: chunk-0088
section_heading: Receiving messages from the bus
document_type: technical_reference

## Receiving messages from the bus ```python
def node_status_callback(event):
    print('NodeStatus message from node', event.transfer.source_node_id)
    print('Node uptime:', event.message.uptime_sec, 'seconds')
    # Messages, service requests, service responses, and entire events
    # can be converted into YAML formatted data structure using to_yaml():
    print(dronecan.to_yaml(event))

# Subscribing to messages uavcan.protocol.NodeStatus
handle = node.add_handler(uavcan.protocol.NodeStatus, node_status_callback)

# When we no longer need them, we can remove the handler
handle.remove()
``` ### Timestamping

It should be noted that PyDroneCAN goes at great lengths to obtain precise timestamps
of the received CAN frames, and, by extension, UAVCAN transfers (both messages and services). The exact method of timestamp estimation depends on the backend,
so the most valid information can be obtained by looking at the source code of the backend of interest. For SLCAN, if the CAN adapter provides timestamps,
the library will convert them from the adapter's clock domain
into the monotonic and real time domains of the local computer using the Olson
passive time synchronization algorithm. If timestamps are not provided by the adapter,
the library will use naive timestamping, which is imprecise. For SocketCAN, the library retrieves the timestamping information
from the Linux kernel. Refer to the code for more information. The computed precise timestamps will be stored in the fields
`event.transfer.ts_monotonic` and `event.transfer.ts_real` for time in
the local monotonic (see `time.monotonic()`) and real (see `time.time()`) domains, respectively.

--- chunk_id: chunk-0088
source_document: Implementations__Pydronecan__Tutorials__2._Basic_usage__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 149
content_hash: fa3d1ceffac064cd
prev_chunk_id: chunk-0087
next_chunk_id: chunk-0089
section_heading: Publishing messages to the bus
document_type: technical_reference

## Publishing messages to the bus

PyDroneCAN supports different of ways to assign values to fields of DSDL data structures. Using the type constructors:

* `uavcan.protocol.debug.KeyValue(key='this is key', value=123.456)`
* `uavcan.protocol.param.GetSet.Request(name='foobar')`
* `uavcan.protocol.param.GetSet.Response(value=uavcan.protocol.param.Value(integer_value=123))`

{% include lightbox.html url="/Implementations/PyDroneCAN/Tutorials/2._Basic_usage/gui_tool_bus_monitor_publishing.png" title="Broadcasts as seen from GUI Tool" thumbnail=true %}

Values that are not specified in the constructor are zero initialized by default. Using direct assignment: ```python
s = uavcan.protocol.debug.KeyValue()
s.key = 'this is key'
s.value = 123.456
``` Messages can be broadcast using the method `broadcast()`: ```python
def do_publish():
    msg = uavcan.protocol.debug.KeyValue(key='this is key', value=123.456)
    # The priority argument can be omitted, in which case default will be used
    node.broadcast(msg, priority=uavcan.TRANSFER_PRIORITY_LOWEST)

handle = node.periodic(1, do_publish)
```

--- chunk_id: chunk-0089
source_document: Implementations__Pydronecan__Tutorials__2._Basic_usage__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 185
content_hash: e600688f23e7e086
prev_chunk_id: chunk-0088
next_chunk_id: chunk-0090
section_heading: Invoking services
document_type: technical_reference

## Invoking services ```python
# The callback will be invoked ALWAYS, even if the request has timed out.
# In the case of a timeout, the argument will be None.
def response_callback(event):
    if event:
        print('Service response from server', event.transfer.source_node_id)
        print(uavcan.to_yaml(event.response))
    else:
        print('SERVICE REQUEST HAS TIMED OUT')

# The priority argument can be omitted, in which case default will be used
node.request(uavcan.protocol.GetNodeInfo.Request(), 127, response_callback,
             priority=uavcan.TRANSFER_PRIORITY_LOWEST)
node.request(uavcan.protocol.GetNodeInfo.Request(), 126, response_callback)
``` ### Responding to services
{% include lightbox.html url="/Implementations/PyDroneCAN/Tutorials/2._Basic_usage/gui_tool_restart.png" title="Sending restart requests from GUI Tool" thumbnail=true %} ```python
def handle_node_restart_request(event):
    print('Request from client', event.transfer.source_node_id)
    # Rejecting the request if the magic number is incorrect
    if event.request.magic_number != event.request.MAGIC_NUMBER:
        return uavcan.protocol.RestartNode.Response(ok=False)
    print('Restart request accepted')
    # Ha ha, just kidding; actual reboot in a demo application is hardly a good idea
    import os
    print('Reboot result:', os.system('reboot'))
    # Returning confirmation
    return uavcan.protocol.RestartNode.Response(ok=True)

node.add_handler(uavcan.protocol.RestartNode, handle_node_restart_request)
```

--- chunk_id: chunk-0090
source_document: Implementations__Pydronecan__Tutorials__2._Basic_usage__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 116
content_hash: 374bce6a76aa27fe
prev_chunk_id: chunk-0089
next_chunk_id: chunk-0091
section_heading: Using Vendor-Specific DSDL Definitions
document_type: technical_reference

## Using Vendor-Specific DSDL Definitions

PyDroneCAN will automatically scan the directory `~/dronecan_vendor_specific_types` for vendor-specific data types,
where `~` stands for the home directory of the current user, e.g. `/home/joe` or `C:\Users\Joe`. Consider the following directory layout: ```
~
└── uavcan_vendor_specific_types
    └── sirius_cybernetics_corporation
        ├── 100.Foo.uavcan
        ├── 42.Bar.uavcan
        └── Baz.uavcan
``` The above layout defines the following custom data types:

* `sirius_cybernetics_corporation.Foo` with the default data type ID 100. * `sirius_cybernetics_corporation.Bar` with the default data type ID 42. * `sirius_cybernetics_corporation.Baz` where the default data type ID is not set.

--- chunk_id: chunk-0091
source_document: Implementations__Pydronecan__Tutorials__3._Advanced_usage__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 92
content_hash: ed4117244b727bdf
prev_chunk_id: chunk-0090
next_chunk_id: chunk-0092
section_heading: Advanced usage
document_type: technical_reference

# Advanced usage

This article provides a brief overview of some of the more advanced features of PyDroneCAN. It does not aim to provide an exhaustive user guide; for that you should refer to the
Python's help system (the function `help()`) and to the source code,
particularly to the sub-package `dronecan.app`. The examples below assume that the local node instance is bound to the variable `node`,
unless stated otherwise.

--- chunk_id: chunk-0092
source_document: Implementations__Pydronecan__Tutorials__3._Advanced_usage__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 298
content_hash: a27066331bc5f7d4
prev_chunk_id: chunk-0091
next_chunk_id: chunk-0093
section_heading: Bus monitoring
document_type: technical_reference

## Bus monitoring

IO hooks allow the application to monitor all incoming and outgoing CAN frames. The Bus Monitor feature of the GUI Tool is based on this capability of PyDroneCAN. ```python
def frame_hook(direction, frame):
    if direction == 'rx':
        print('<', frame)
    elif direction == 'tx':
        print('>', frame)
    else:
        raise Exception('Invalid direction specification: %r' % direction)

handle = node.can_driver.add_io_hook(frame_hook)

# The hook can be removed like that:
handle.remove()
``` ### File server
File server can be used to perform firmware update on remote nodes,
as well as for general purpose file exchange. ```python
import dronecan

# File server need to be provided with file lookup pathes.
# These can be directories or files.
file_server = dronecan.app.file_server.FileServer(node, ['/home/pavel'])
file_server.lookup_paths.append('/etc/fstab')

print(file_server.lookup_paths)
print(file_server.path_hit_counters)

# The file server will be running in the background, requiring no additional attention
# When it is no longer needed, it should be finalized by calling close():
file_server.close()
``` You can test the file server using the following command in the Interactive Console of the GUI Tool: ```python
request(uavcan.protocol.file.Read.Request(path=uavcan.protocol.file.Path(path='/etc/fstab')), 123)
``` The file server uses the following logic for relative file path resolution (simplified). It can be seen that locations specified earlier in the lookup path list take precedence. ```python
# This is simplified
def _try_resolve_relative_path(lookup_paths, rel_path):
    for p in lookup_paths:
        if p.endswith(rel_path) and os.path.isfile(p):
            return p
        if os.path.isfile(os.path.join(p, rel_path)):
            return os.path.join(p, rel_path)
```

--- chunk_id: chunk-0093
source_document: Implementations__Pydronecan__Tutorials__3._Advanced_usage__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 145
content_hash: 1d32944e5c30af96
prev_chunk_id: chunk-0092
next_chunk_id: chunk-0094
section_heading: Dynamic node ID allocation
document_type: technical_reference

## Dynamic node ID allocation

The logic pertaining to the dynamic node ID allocation feature is located in the module
`dronecan.app.dynamic_node_id`. The code below demonstrates how to run an instance of a centralized node ID allocator. ```python
node_monitor = dronecan.app.node_monitor.NodeMonitor(node)
# It is NOT necessary to specify the database storage.
# If it is not specified, the allocation table will be kept in memory, thus it will not be persistent.
allocator = dronecan.app.dynamic_node_id.CentralizedServer(node, node_monitor,
                                                         database_storage='/home/pavel/allocation_table.db')

# The allocator and the node monitor will be running in the background, requiring no additional attention
# When they are no longer needed, they should be finalized by calling close():
allocator.close()
node_monitor.close()
```

--- chunk_id: chunk-0094
source_document: Implementations__Pydronecan__Tutorials__4._Parsing_DSDL_definitions__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 460
content_hash: 903a77d2d5d36333
prev_chunk_id: chunk-0093
next_chunk_id: chunk-0095
section_heading: Parsing DSDL definitions
document_type: technical_reference

# Parsing DSDL definitions

Create a file named `namespace_a/Foo.uavcan` with the following content: ```python
uavcan.Timestamp timestamp
uint8 MY_FAVORITE_CHAR = '\x42'
``` Create another file named `namespace_b/Bar.uavcan` with the following content: ```python
float16 x
float16[<8] y
---
uint6 JUST_ENOUGH = 42
float64 answer
namespace_a.Foo foo
``` Place the standard DSDL definitions into the directory `dsdl/`
(just clone or symlink the DSDL repository into the current directory). The resulting directory structure should look like this: ```python
namespace_a/
    Foo.uavcan
namespace_b/
    Bar.uavcan
dsdl/
    uavcan/
        ...
...
``` Put this code into a file in the current directory: ```python
#
# PyDroneCAN DSDL parser demo.
# Read the package docstrings for details.
#

# pydronecan supports Python 2.7 and Python 3.x
from __future__ import print_function
from dronecan import dsdl

# Root namespace directories:
NAMESPACE_DIRS = ['namespace_a/', 'namespace_b/']

# Where to look for the referenced types (standard UAVCAN types):
SEARCH_DIRS = ['dsdl/uavcan']

# Run the DSDL parser:
types = dsdl.parse_namespaces(NAMESPACE_DIRS, SEARCH_DIRS)

# Print what we got
ATTRIBUTE_INDENT = ' ' * 3

def print_attributes(fields, constants):
    for a in fields:
        print(ATTRIBUTE_INDENT, a.type.full_name, a.name, end='  # ')
        # Add a bit of relevant information for this type:
        if a.type.category == a.type.CATEGORY_COMPOUND:
            print('DSDL signature: 0x%08X' % a.type.get_dsdl_signature())
        if a.type.category == a.type.CATEGORY_ARRAY:
            print('Max array size: %d' % a.type.max_size)
        if a.type.category == a.type.CATEGORY_PRIMITIVE:
            print('Bit length: %d' % a.type.bitlen)
    for a in constants:
        print(ATTRIBUTE_INDENT, a.type.full_name, a.name, '=', a.value, '#', a.init_expression)

for t in types:
    print(t.full_name)
    if t.kind == t.KIND_MESSAGE:
        print_attributes(t.fields, t.constants)
    elif t.kind == t.KIND_SERVICE:
        print_attributes(t.request_fields, t.request_constants)
        print(ATTRIBUTE_INDENT, '---')
        print_attributes(t.response_fields, t.response_constants)
``` Make sure the PyDroneCAN package is installed, then run the script. The output should look like this: ```
namespace_a.Foo
    uavcan.Timestamp timestamp  # DSDL signature: 0xF776DD8697A8DB73
    saturated uint8 MY_FAVORITE_CHAR = 66 # '\x42'
namespace_b.Bar
    saturated float16 x  # Bit length: 16
    saturated float16[<=7] y  # Max array size: 7
    ---
    saturated float64 answer  # Bit length: 64
    namespace_a.Foo foo  # DSDL signature: 0xFE327FCBE8C6F7D
    saturated uint6 JUST_ENOUGH = 42 # 42
``` For a real world usage example it's recommended to refer to Libuavcan,
which implements a DSDL compiler based on the DSDL parsing module from PyDroneCAN.

--- chunk_id: chunk-0095
source_document: Implementations__Pydronecan__Tutorials__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 50
content_hash: 2e11c1dc327601b9
prev_chunk_id: chunk-0094
next_chunk_id: chunk-0096
section_heading: PyDroneCAN tutorials
document_type: technical_reference

# PyDroneCAN tutorials

Tutorials are arranged in ascending order of difficulty and descending order of importance. Besides these tutorials, it is also recommended to refer to the sources of the
[DroneCAN GUI Tool](/GUI_Tool), which is based on PyDroneCAN.

--- chunk_id: chunk-0096
source_document: Implementations__Pydronecan__Tutorials__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 69
content_hash: 24fb31100d768265
prev_chunk_id: chunk-0095
next_chunk_id: chunk-0097
section_heading: Prerequisites
document_type: technical_reference

## Prerequisites

* Familiarity with UAVCAN specification. * Intermediate Python skills. * A supported USB to CAN adapter. ### Installation
Install pydronecan via pip: ```sh
pip install dronecan
``` ### License
Unless expressly stated otherwise,
all code samples contained in the tutorials are distributed under the terms of
[CC0](https://creativecommons.org/publicdomain/zero/1.0/) (public domain dedication).

--- chunk_id: chunk-0097
source_document: Implementations__Pydronecan__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 108
content_hash: 1d2b38001f55ff52
prev_chunk_id: chunk-0096
next_chunk_id: chunk-0098
section_heading: PyDroneCAN
document_type: technical_reference

# PyDroneCAN

PyDroneCAN is an implementation of DroneCAN stack in [Python](http://python.org), supporting SLCAN and SocketCAN adapters. It is compatible with Python **2.7** (legacy) and **3.3+** (recommended). We strongly recommend to use Python 3, because support for Python 2.7 may be dropped in the future. The latest version of pydronecan can be installed using pip: ```sh
pip install dronecan
``` Please visit the [GitHub page](https://github.com/DroneCAN/pydronecan)
for more information about contributing to pydronecan, or view the
[examples](https://github.com/dronecan/pydronecan/tree/master/examples)
and [tools](https://github.com/dronecan/pydronecan/tree/master/tools)
for useful example programs.

--- chunk_id: chunk-0098
source_document: Implementations__dronecan_dsdlc__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 41
content_hash: 50303a79657b039b
prev_chunk_id: chunk-0097
next_chunk_id: chunk-0099
section_heading: dronecan_dsdlc
document_type: technical_reference

# dronecan_dsdlc

dronecan_dsdlc is a compiler for DSDL files that generates C
headers. It is the compiler used by the ArduPilot AP_Periph DroneCAN toolkit. For detailed information see the
[github repository](https://github.com/dronecan/dronecan_dsdlc)

--- chunk_id: chunk-0099
source_document: Implementations__index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 93
content_hash: a959530caf358b2b
prev_chunk_id: chunk-0098
next_chunk_id: chunk-0100
section_heading: Implementations
document_type: technical_reference

# Implementations

This section contains documentation for existing reference implementations of DroneCAN. * [PyDroneCAN](/Implementations/PyDroneCAN) - UAVCAN protocol stack and DSDL parser implemented in pure Python. * [Libcanard](/Implementations/Libcanard) - minimal implementation in C suitable for deeply embedded systems and
resource constrained applications. * [AP_Periph](/Implementations/AP_Periph) - A DroneCAN peripheral node toolkit
* [DroneCAN dsdlc](/Implementations/dronecan_dsdlc) - A DroneCAN DSDL compiler
* [Libuavcan](/Implementations/Libuavcan) - (DEPRECATED) reference implementation in C++ for embedded systems and Linux.

--- chunk_id: chunk-0100
source_document: Specification__1._Introduction.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 57
content_hash: 61c7e25c23a89f5b
prev_chunk_id: chunk-0099
next_chunk_id: chunk-0101
section_heading: Introduction
document_type: specification

# Introduction

This section covers the basic concepts that govern development and maintenance of the specification. The actual specification is contained in the following sections. The reader should have a solid understanding of the main concepts and operating principles of the [CAN bus](https://en.wikipedia.org/wiki/CAN_bus).

--- chunk_id: chunk-0101
source_document: Specification__1._Introduction.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 358
content_hash: 9031bc4fb180fb13
prev_chunk_id: chunk-0100
next_chunk_id: chunk-0102
section_heading: Core design goals
document_type: specification

## Core design goals

The core design goals listed below help explain the basic DroneCAN concepts and the motivation behind them. * **Democratic network** - There should be no master node. All nodes in the network should have the same communication rights so that there is no single point of failure. * **Nodes can exchange long payloads** - Nodes must be provided with a simple way to exchange large data structures that cannot fit into a single CAN frame (such as GNSS solutions, 3D vectors, etc.). DroneCAN should perform automatic transfer decomposition and reassembly at the protocol level, hiding the related complexity from the application. * **Support for redundant interfaces and redundant nodes** - This is a common requirement for
safety-concerned applications. * **High throughput, low latency communication** - Applications that are dependent on high-frequency,
hard real-time control loops, require a low-latency, high-throughput communication method. * **Simple logic, low computational requirements** - DroneCAN targets a wide variety of embedded systems,
from high-performance embedded on-board computers for intensive data processing
(e.g., a high-performance Linux-powered machine) to extremely resource-constrained microcontrollers. The latter imposes severe restrictions on the amount of logic needed to implement the protocol. * **Common high-level functions should be clearly defined** - DroneCAN defines standard services and messages
for common high-level functions, such as network discovery, node configuration, node firmware update,
node status monitoring (which naturally grows into a vehicle-wide health monitoring),
network-wide time synchronization, dynamic node ID allocation (a.k.a. plug-and-play), etc. * **Open specification and reference implementations** - The DroneCAN specification is open and freely available; the reference implementations are distributed under the terms of the
[MIT License](http://en.wikipedia.org/wiki/MIT_License).

--- chunk_id: chunk-0102
source_document: Specification__1._Introduction.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 264
content_hash: 26045279755e4f24
prev_chunk_id: chunk-0101
next_chunk_id: chunk-0103
section_heading: Specification update and approval process
document_type: specification

## Specification update and approval process

The DroneCAN development team is charged with advancing the specification based on input from adopters. This feedback is gathered via the [mailing list](/Contact), which is open to everyone. The set of standard data definitions is one of the cornerstone concepts of the specification (see [*data structure description language* (DSDL)](/Specification/3._Data_structure_description_language)). Within the same major version, the specification can be extended only in the following ways:

* A new data type can be added, possibly with default data type ID, as long as the default data type ID doesn't
conflict with one of the existing data types. * An existing data type can be modified, as long as the modification doesn't break backward compatibility. * An existing data type can be declared deprecated. * Once declared deprecated, the data type will be maintained for at least two more years. After this period its default data type ID may be reused for an incompatible data type. * Deprecation will be announced via the mailing list, and indicated in the form of a comment within the DSDL definition. Link to the repository containing the set of default DSDL definitions can be found on the
[contacts page](/Contact).

--- chunk_id: chunk-0103
source_document: Specification__1._Introduction.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 176
content_hash: eead6bf80dd0b6f3
prev_chunk_id: chunk-0102
next_chunk_id: chunk-0104
section_heading: Referenced sources
document_type: specification

## Referenced sources

The DroneCAN specification contains references to the following sources:

* CiA 801 - Application note - Automatic bit rate detection. * CiA 103 - Intrinsically safe capable physical layer. * CiA 303 - Recommendation - Part 1: Cabling and connector pin assignment. * IEEE 754 - Standard for binary floating-point arithmetic. * ISO 11898-1 - Controller area network (CAN) - Part 1: Data link layer and physical signaling. * ISO 11898-2 - Controller area network (CAN) - Part 2: High-speed medium access unit. * ISO/IEC 10646:2014 - Universal Coded Character Set (UCS). * ISO/IEC 14882:2014(E) - Programming Language C++. * "Implementing a Distributed High-Resolution Real-Time Clock using the CAN-Bus", M. Gergeleit and H. Streich. * "In Search of an Understandable Consensus Algorithm (Extended Version)", Diego Ongaro and John Ousterhout.

--- chunk_id: chunk-0104
source_document: Specification__2._Basic_concepts.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: d221ebeba077e999
prev_chunk_id: chunk-0103
next_chunk_id: chunk-0105
section_heading: Basic concepts
document_type: specification

# Basic concepts

{% include lightbox.html url="/Specification/figures/architecture.png" title="DroneCAN architecture" thumbnail=true maxwidth="40%" %}

DroneCAN is a lightweight protocol designed to provide a highly reliable communication method for aerospace and robotic
applications via the [CAN bus](https://en.wikipedia.org/wiki/CAN_bus). The DroneCAN network is a decentralized peer network, where each peer (node) has a unique numeric identifier -
*node ID*. The nodes of the DroneCAN network can communicate using any of the following communication methods:

* Message broadcasting - The primary method of data exchange with publish/subscribe semantics. * Service invocation - The communication method for peer-to-peer request/response interactions. For each type of communication, a predefined set of data structures is used, where each data structure has a unique
identifier - the *data type ID* (DTID). Some data structures are standard and defined by the protocol specification; others may be specific to a particular
application or vendor. Since every published message type has its own unique data type ID, and each node of the network has its own unique
node ID, a pair of data type ID and node ID can be used to support redundant nodes with identical functionality
inside the same network. Message and service data structures are defined using the
[*data structure description language* (DSDL)](/Specification/3._Data_structure_description_language). The DSDL description is used to generate the serialization/deserialization code for a given data structure in each target
programming language. The DSDL approach allows compilers to determine the data structure size statically, thus helping to optimize the protocol
implementations in terms of memory consumption and performance. This feature is important for deeply embedded systems, where the memory footprint is critical and dynamic memory
allocation may not be acceptable. On top of the standard data types, DroneCAN defines a set of standard high-level functions including: node health monitoring,
network discovery, time synchronization, firmware update, and more. For more information see the part of the specification dedicated to
the [standard data types and application level functions](/Specification/6._Application_level_functions).

--- chunk_id: chunk-0105
source_document: Specification__2._Basic_concepts.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 109
content_hash: 87d42d8d3cca857a
prev_chunk_id: chunk-0104
next_chunk_id: chunk-0106
section_heading: Basic concepts
document_type: specification

On top of the standard data types, DroneCAN defines a set of standard high-level functions including: node health monitoring,
network discovery, time synchronization, firmware update, and more. For more information see the part of the specification dedicated to
the [standard data types and application level functions](/Specification/6._Application_level_functions). Serialized message and service data structures are exchanged by means of the
[CAN bus transport layer](/Specification/4.1_CAN_bus_transport_layer), which implements automatic decomposition of long
transfers into several CAN frames, allowing nodes to exchange data structures of arbitrary size.

--- chunk_id: chunk-0106
source_document: Specification__2._Basic_concepts.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 230
content_hash: da2ad8a0609fae75
prev_chunk_id: chunk-0105
next_chunk_id: chunk-0107
section_heading: Message broadcasting
document_type: specification

## Message broadcasting

Message broadcasting refers to the transmission of a serialized data structure over the CAN bus to other nodes. This is the primary DroneCAN data exchange mechanism.
Typical use cases may include transfer of the following kinds of data (either cyclically or on an adhoc basis): sensor measurements,
actuator commands, or equipment status information.

A broadcast message includes the following information:

Field                   | Content
------------------------|----------------------------------------------------------------------------------------------
Payload                 | The serialized data structure
Data type ID            | Numerical identifier that indicates how the data structure should be interpreted
Source node ID          | The node ID of the transmitting node
Transfer ID             | A small overflowing integer that increments with every transfer of this type of message from a given node

### Anonymous message broadcasting

Nodes that don't have a unique node ID can publish *anonymous messages*.
An anonymous message is different from a regular message in that it doesn't contain source node ID.
This kind of data exchange is useful during initial configuration of the node, particularly during dynamic node ID
allocation procedure.

--- chunk_id: chunk-0107
source_document: Specification__2._Basic_concepts.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 266
content_hash: d8fd535af03d9ecc
prev_chunk_id: chunk-0106
next_chunk_id: chunk-0108
section_heading: Service invocation
document_type: specification

## Service invocation

Service invocation is a two-step data exchange between exactly two nodes: a client and a server. The steps are:

1. The client sends a service request to the server.
2. The server takes appropriate actions and sends a response to the client.

Typical use cases for this type of communication include: node configuration parameter update,
firmware update, adhoc action request, file transfer, and other service tasks.

Both service requests and service responses include the following data:

Field                   | Content
------------------------|----------------------------------------------------------------------------------------------
Payload                 | The serialized data structure
Data type ID            | Numerical identifier that indicates how the data structure should be interpreted
Client node ID          | Source node ID during request transfer, destination node ID during response transfer
Server node ID          | Destination node ID during request transfer, source node ID during response transfer
Transfer ID             | A small overflowing integer that increments with every call to this service from a given node

Both request and response contain exactly the same values for all fields except payload, where the content is application defined.
Clients can match the response with a corresponding request using the following fields: data type ID, client node ID,
server node ID, and transfer ID.

--- chunk_id: chunk-0108
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 73
content_hash: 48f17916d752d7a8
prev_chunk_id: chunk-0107
next_chunk_id: chunk-0109
section_heading: Data structure description language
document_type: specification

# Data structure description language

The Data Structure Description Language (DSDL) is used to define data structures for exchange via the CAN bus. The DSDL definitions are used to automatically generate the message serialization/deserialization code for a certain
programming language. The tool that generates source code from DSDL definition files is called the *DSDL compiler*.

--- chunk_id: chunk-0109
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 417
content_hash: 7259b36efdee2319
prev_chunk_id: chunk-0108
next_chunk_id: chunk-0110
section_heading: File hierarchy
document_type: specification

## File hierarchy

Each DSDL definition file specifies exactly one data structure that can be used for message broadcasting or a pair of structures that can be used for service invocation data exchange. The DSDL source file must be named using the *data type name* and *default data type ID* (if needed) as shown below:

    [default data type ID.]<data type name>.uavcan

A defined data structure must be contained in a namespace, which may in turn be *nested* within another namespace. A namespace that is not nested in another namespace is called a *root namespace*. For example, all standard data types are contained in the root namespace `uavcan`, which contains nested namespaces: `equipment`, `protocol`, etc. The namespace hierarchy is mapped directly to the file-system directory structure, as shown in the example below: ```
+ uavcan                        <-- Root namespace
    + equipment                 <-- Nested namespace
        + ...
    + protocol                  <-- Nested namespace
        + 341.NodeStatus.uavcan <-- Definition of data type "uavcan.protocol.NodeStatus" with default data type ID 341
        + ...
    + Timestamp.uavcan          <-- Definition of data type "uavcan.Timestamp", default data type ID is not assigned
``` Notes:

* It is not necessary to explicitly define a default data type ID for non-standard data types
(i.e., for vendor-specific or application-specific data types). * If the default data type ID is not defined by the DSDL definition, it will need to be assigned by the application at
run time. * All standard data types have default data type ID values defined. * Data type names are case sensitive, i.e., names `foo.Bar` and `foo.bar` are considered different. Names that differ only in case should be avoided, because it may cause problems on file systems that are not case-sensitive. * Data types may contain nested data structures. * Some data structures may be designed for such nesting only, in which case they are not required to have a dedicated
    data type ID.

--- chunk_id: chunk-0110
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 230
content_hash: ad082ed2ebb2ab8b
prev_chunk_id: chunk-0109
next_chunk_id: chunk-0111
section_heading: File hierarchy
document_type: specification

* Data types may contain nested data structures. * Some data structures may be designed for such nesting only, in which case they are not required to have a dedicated
    data type ID. * *Full data type name* is a unique identifier of a data type constructed from the root namespace,
  all nested namespaces (if any), and the data type name itself, joined via the dot symbol (`.`),
   e.g., `uavcan.protocol.file.Read`. * The length of the Full data type name must not exceed 80 characters. * Refer to the naming rules below for the limitations imposed on the character set. ### Service data structure

Since a service invocation consists of two network exchange operations, the DSDL definition for a service must define two structures:

* Request part - for request transfer (client to server). * Response part - for response transfer (server to client). Both request and response structures are contained within the same DSDL definition file,
separated by a special statement (see the syntax chapter below). Service invocation data structures cannot be nested.

--- chunk_id: chunk-0111
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 454
content_hash: 186a8897280bfa1c
prev_chunk_id: chunk-0110
next_chunk_id: chunk-0112
section_heading: Syntax
document_type: specification

## Syntax

A data structure definition consists of *attributes* and *directives*. Any line of the definition file may contain at most one attribute definition or at most one directive. The same line cannot contain an attribute definition and a directive at the same time. Lines should be separated with the ASCII line feed character (`\n`, code 10);
vendor-specific data type definitions are allowed to use any other line ending convention. An attribute can be either of the following:

* *Field* - a variable that can be modified by the application and exchanged via the network. * *Constant* - an immutable value that does not participate in network exchange. A directive is a statement that provides instructions to the DSDL compiler. Aside from attributes and directives, a DSDL definition may contain the following entities:

* Comments
* Service response marker

The details are explained below. A DSDL definition for a message data type may contain only the following:

* Attribute definitions (zero or more)
* Directives (zero or more)
* Comments (optional)

A DSDL definition for a service data type may contain only the following:

* Request part attribute definitions (zero or more)
* Response part attribute definitions (zero or more)
* Directives (zero or more)
* Comments (optional)
* Service response marker (exactly one)

### Attribute definition

Field definition patterns:

1. `cast_mode field_type field_name`
2. `cast_mode field_type[X] field_name`
3. `cast_mode field_type[<X] field_name`
4. `cast_mode field_type[<=X] field_name`
5. `void_type`

Constant definition pattern:

1. `cast_mode constant_type constant_name = constant_initializer`

Each component is discussed below. #### Field type

The field type can be either a primitive data type (primitive data types are defined below) or a nested data structure. A primitive data type can be referred simply by name, e.g., `float16`, `bool`. A nested data structure can be referred by either of these two:

* Short name, e.g., `NodeStatus`, if both the referred and the referring data types are located in the same namespace. For example, it is possible to access `ns1.ns2.Type1` from `ns1.ns2.Type2` using a short name, but not from
`ns1.ns2.ns3.Type3` or `ns1.ns4.Type4`.

--- chunk_id: chunk-0112
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 209
content_hash: 029a14854df79f02
prev_chunk_id: chunk-0111
next_chunk_id: chunk-0113
section_heading: Syntax
document_type: specification

A nested data structure can be referred by either of these two:

* Short name, e.g., `NodeStatus`, if both the referred and the referring data types are located in the same namespace. For example, it is possible to access `ns1.ns2.Type1` from `ns1.ns2.Type2` using a short name, but not from
`ns1.ns2.ns3.Type3` or `ns1.ns4.Type4`. * Full name, e.g., `uavcan.protocol.NodeStatus`. A full name allows access to the data type from any namespace. A field type name can be appended with a statement in square brackets to define an array:

* Syntax `[X]` is used to define a static array of size exactly X items. * Syntax `[<X]` is used to define a dynamic array of size from 0 to X-1 items, inclusively. * Syntax `[<=X]` is used to define a dynamic array of size from 0 to X items, inclusively. In the array definition statements above, X must be a valid integer literal according to the rules defined in the

--- chunk_id: chunk-0113
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 454
content_hash: 5411c1de5b951861
prev_chunk_id: chunk-0112
next_chunk_id: chunk-0114
section_heading: section dedicated to constant definitions.
document_type: specification

section dedicated to constant definitions. Arrays of maximum size with less than one item are not allowed. Multidimensional arrays are not allowed. #### Field name and constant name

For a message data type, all attributes must have a unique name within the data type. For a service data type, all attributes must have a unique name within the same part (request/response)
of the data type. In other words, service-type attributes can have the same name as long as they are separated by the service
response marker. #### Cast mode

Cast mode defines the rules of conversion from the native value of a certain programming language to the serialized
field value. Cast mode may be left undefined, in which case the default will be used. Possible cast modes are defined below. * `saturated` - This is the default cast mode, which will be used if the attribute definition does not specify
the cast mode explicitly. For integers, it prevents an integer overflow - for example, attempting to write 0x44 to a 4-bit field will result
in a bitfield value of 0x0F. For floating point values, it prevents overflow when casting to a lower precision floating point representation -
for example, 65536.0 will be converted to a `float16` as 65504.0; infinity will be preserved. * `truncated` - For integers, it discards the excess most significant bits - for example, attempting to write
0x44 to a 4-bit field will produce 0x04. For floating point values, overflow during downcasting will produce an infinity. #### Constant definition

A constant must be a primitive scalar type (i.e., arrays and nested data structures are not allowed as constant types). A constant must be assigned with a constant initializer, which must be one of the following:

* Integer zero (0). * Integer literal in base 10, starting with a non-zero character. E.g., 123, -12. * Integer literal in base 16 prefixed with `0x`. E.g., 0x123, -0x12, +0x123. * Integer literal in base 2 prefixed with `0b`. E.g., 0b1101, -0b101101, +0b101101. * Integer literal in base 8 prefixed with `0o`.

--- chunk_id: chunk-0114
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 450
content_hash: 9552fe6bc3341bf8
prev_chunk_id: chunk-0113
next_chunk_id: chunk-0115
section_heading: section dedicated to constant definitions.
document_type: specification

E.g., 0b1101, -0b101101, +0b101101. * Integer literal in base 8 prefixed with `0o`. E.g., 0o123, -0o777, +0o777. * Floating point literal. Fractional part with an optional exponent part, e.g.,
`15.75`, `1.575E1`, `1575e-2`, `-2.5e-3`, `+25E-4`. Not-a-number (NaN), positive infinity, and negative infinity are intentionally not supported in order to maximize cross-platform compatibility. * Boolean `true` or `false`. * Single ASCII character, ASCII escape sequence, or ASCII hex literal in single quotes. E.g., `'a'`, `'\x61'`, `'\n'`. The DSDL compiler must implicitly convert the type of an initializer expression to the constant type if
the target type can allocate the value with no data loss. If a data loss occurs (e.g., integer overflow, floating point number decays to infinity), the DSDL compiler
should refuse to compile such data type. Note that constants do not affect the serialized data layout as they are never exchanged via the network. #### Void type

Void type is a special field type that is intended for data alignment purposes. The specification defines 64 distinct void types as follows:

* `void1` - 1 padding bit;
* `void2` - 2 padding bits;
* ... * `void63` - 63 padding bits;
* `void64` - 64 padding bits. A field of type void does not have a name and its cast mode cannot be specified. During message serialization, all void fields must be populated with zero bits;
during deserialization, contents of the void fields should be ignored. ### Directives

A directive is a single case-sensitive word starting with an "at sign" (`@`),
possibly followed by space-separated arguments:

* `@directive`
* `@directive arg1 arg2`

All valid directives are documented below. #### Union

Keyword: `@union`. This directive instructs the DSDL compiler that the current message or the current part of
a service data type (request or response) is a tagged union. A tagged union is a data structure that may encode either of its fields at a time. Such a data structure contains one implicit field, a *union tag* that indicates what particular field the
data structure is holding at the moment.

--- chunk_id: chunk-0115
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 185
content_hash: cc76803b92175feb
prev_chunk_id: chunk-0114
next_chunk_id: chunk-0116
section_heading: section dedicated to constant definitions.
document_type: specification

A tagged union is a data structure that may encode either of its fields at a time. Such a data structure contains one implicit field, a *union tag* that indicates what particular field the
data structure is holding at the moment. Unions are required to have at least two fields. This directive must be placed before the first attribute definition. The encoding rules for tagged unions are defined in the following chapters. ### Comments

A DSDL description may contain comments starting from a number sign `#` up to the end of the line. Comments must be ignored by the DSDL compiler. ### Service response marker

A service response marker separates the request and response parts of a service data type definition. The marker consists of three minus symbols (`-`) in a row on a dedicated line: ```
---
```

--- chunk_id: chunk-0116
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 274
content_hash: 335a1aed50cc3d8c
prev_chunk_id: chunk-0115
next_chunk_id: chunk-0117
section_heading: Primitive data types
document_type: specification

## Primitive data types

These types are assumed to be built-in. They can be directly referenced from any data type of any namespace. The DSDL compiler should implement these types using the native types of the target programming language. Example mapping to native types is given for C/C++. There is also a set of special built-in types `voidX`, where `X` is the number of bits, 1 to 64 inclusive;
e.g. `void7`. They are used for data alignment purposes. Name | Bit length           | Possible representation in C/C++              | Value range                                       | Binary representation
---------- |----------------------|-----------------------------------------------|---------------------------------------------------| -----------------------
bool | 1                    | `bool` *(can be optimized for bit arrays)*    | {0, 1}                                            | One bit
int**X** | 2 &le; **X** &le; 64 | `int8_t`, `int16_t`, `int32_t`, `int64_t`     | [-(2<sup>**X**</sup>)/2, 2<sup>**X**</sup>/2 - 1] | [Two's complement](http://en.wikipedia.org/wiki/Two's_complement)
uint**X** | 2 &le; **X** &le; 64 | `uint8_t`, `uint16_t`, `uint32_t`, `uint64_t` | [0, 2<sup>**X**</sup> - 1]                        | float16 | 16                   | `float`                                       | &plusmn;65504                                     | [IEEE754](http://en.wikipedia.org/wiki/IEEE_754) binary16
float32 | 32                   | `float`                                       | Approx. &plusmn;10<sup>39</sup>                   | [IEEE754](http://en.wikipedia.org/wiki/IEEE_754) binary32
float64 | 64                   | `double`                                      | Approx. &plusmn;10<sup>308</sup>                  | [IEEE754](http://en.wikipedia.org/wiki/IEEE_754) binary64
void**X** | 1 &le; **X** &le; 64 | N/A                                           | N/A                                               | **X** zero bits (set to zero when encoding, ignore when decoding)

--- chunk_id: chunk-0117
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 274
content_hash: 9989ccbff37e14ac
prev_chunk_id: chunk-0116
next_chunk_id: chunk-0118
section_heading: Naming rules
document_type: specification

## Naming rules
### Mandatory

Field names, constant names, and type names must contain only ASCII alphanumeric characters and underscores
(`[A-Za-z0-9_]`), and must begin with an ASCII alphabetic character (`[A-Za-z]`). Violation of this rule must be detected by the DSDL compiler and treated as a fatal error. ### Optional

The following rules are recommended only (DSDL compilers are not required to enforce them):

* Field and namespace names should be all-lowercase words separated with underscores, and may include numbers, (e.g.: `field_name`, `my_namespace_7`). * Constant names should be all-uppercase words separated with underscores, and may include  numbers (e.g.: `CONSTANT_NAME`). * Data type names should be in camel case (first letter of all words in uppercase) and may include numbers (e.g.: `TypeName`, `TypeName2`). ### Advisory

The following rules should be considered by the application designer, but should not be enforced:

* Message names should be nouns or adjectives; service names should be verbs. * The name of a message that carries a command should end with the word "Command";
the name of a message that carries state information should end with the word "Status". * The name of a service that is designed to obtain or to store data should begin with the word "Get" or "Set",
respectively.

--- chunk_id: chunk-0118
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 549
content_hash: ed3267b2d008a1ad
prev_chunk_id: chunk-0117
next_chunk_id: chunk-0119
section_heading: Data type compatibility
document_type: specification

## Data type compatibility
### The concept of data type compatibility

It is vital that all nodes exchanging some particular data structure use compatible DSDL definitions of it. Different DSDL definitions are considered compatible if they share the aspects listed below. #### Binary layout

Encoded binary representation must be interpreted by different nodes in the same way. This implies that compatible data structures must have the same field types in the same order. First definition:

    uint8 a
    uint8 b

Second definition:

    uint12 a
    uint4 b

Even though the bit length of the data structures above is the same, the binary layout is clearly not compatible. #### Field name and order

Encoded binary representation must be interpreted by different nodes in the same way. This implies that compatible data structures must have the same field types and names in the same order. First definition:

    uint8 a
    uint8 b

Second definition:

    uint8 b
    uint8 a

Even though the first and the second definitions share the same binary layout (two fields of type `uint8`),
they feature different field names and therefore are semantically incompatible. #### Constant definitions

Despite the fact that different constant values may render the different representations of the same data structure
semantically incompatible, DroneCAN does not consider constant definitions in signature computation, because fixing
constant definitions renders data types not extensible, i.e., any modification of a constant would break backward
compatibility. ### Signature

Incompatible data types may break the data exchange and cause unpredictable system behavior. In order to ensure type compatibility the concept of a *data type signature* is introduced. This section explains both the data type signature and a number of associated/auxiliary concepts. Signature *usage* is discussed in the topic: [CAN bus transport layer](/Specification/4.1_CAN_bus_transport_layer/). #### Signature hash function

The data type signature is based on CRC-64-WE:

* Name: CRC-64-WE
* Description: http://reveng.sourceforge.net/crc-catalogue/17plus.htm#crc.cat-bits.64
* Initial value: 0xFFFFFFFFFFFFFFFF
* Poly: 0x42F0E1EBA9EA3693
* Reverse: no
* Output XOR: 0xFFFFFFFFFFFFFFFF
* Check: 0x62EC59E3F1A4F00A

Source code in Python: ```python
# License: CC0, no copyright reserved
class Signature:
    MASK64 = 0xFFFFFFFFFFFFFFFF
    POLY = 0x42F0E1EBA9EA3693

    def __init__(self, extend_from=None):
        if extend_from is not None:
            self._crc = (int(extend_from) & Signature.MASK64) ^ Signature.MASK64
        else:
            self._crc = Signature.MASK64

    def add(self, data_bytes):
        if isinstance(data_bytes, str):
            data_bytes = map(ord, data_bytes)
        for b in data_bytes:
            self._crc ^= (b << 56) & Signature.MASK64
            for _ in range(8):
                if self._crc & (1 << 63):
                    self._crc = ((self._crc << 1) & Signature.MASK64) ^ Signature.POLY
                else:
                    self._crc <<= 1

    def get_value(self):
        return (self._crc & Signature.MASK64) ^ Signature.MASK64
```

--- chunk_id: chunk-0119
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 504
content_hash: 7a493006abfed72b
prev_chunk_id: chunk-0118
next_chunk_id: chunk-0120
section_heading: Data type compatibility
document_type: specification

#### Signature hash function

The data type signature is based on CRC-64-WE:

* Name: CRC-64-WE
* Description: http://reveng.sourceforge.net/crc-catalogue/17plus.htm#crc.cat-bits.64
* Initial value: 0xFFFFFFFFFFFFFFFF
* Poly: 0x42F0E1EBA9EA3693
* Reverse: no
* Output XOR: 0xFFFFFFFFFFFFFFFF
* Check: 0x62EC59E3F1A4F00A

Source code in Python: ```python
# License: CC0, no copyright reserved
class Signature:
    MASK64 = 0xFFFFFFFFFFFFFFFF
    POLY = 0x42F0E1EBA9EA3693

    def __init__(self, extend_from=None):
        if extend_from is not None:
            self._crc = (int(extend_from) & Signature.MASK64) ^ Signature.MASK64
        else:
            self._crc = Signature.MASK64

    def add(self, data_bytes):
        if isinstance(data_bytes, str):
            data_bytes = map(ord, data_bytes)
        for b in data_bytes:
            self._crc ^= (b << 56) & Signature.MASK64
            for _ in range(8):
                if self._crc & (1 << 63):
                    self._crc = ((self._crc << 1) & Signature.MASK64) ^ Signature.POLY
                else:
                    self._crc <<= 1

    def get_value(self):
        return (self._crc & Signature.MASK64) ^ Signature.MASK64
``` #### Normalized data type definition

Some traits of a data type are important to ensure compatibility and some are not. A normalized data type definition is a definition that does not have such unimportant traits. To obtain a normalized definition of a given data type, the following actions must be performed on its definition:

1. Remove comments. 2. Remove all constant definitions. 3. Ensure that all cast specifiers are explicitly defined; if not, add default cast specifiers. 4. For dynamic arrays, replace the max length specifier in the form `[<X]` to the form `[<=Y]`. 5. For nested data structures, replace all short names with full names. 6. Remove unimportant whitespace (empty lines, leading whitespace, trailing whitespace,
more than one whitespace between tokens). 7. Prepend the DSDL definition with the full data type name on a separate line. 8. Replace newline characters with the ASCII line-feed character (code: 0x0A; escape sequence: `\n`). Example for message type `A` in the namespace `root`: ```
#
# A header comment.
# Note that the formatting is broken deliberately.
#

@union

float16 foo

float16 BAR    = 12.34  # This is BAR
truncated uint8    bar

int32  FOO =   - 42
``` Normalized definition:

    root.A
    @union
    saturated float16 foo
    truncated uint8 bar

Example for service type `A` in the namespace `root`: ```
#
# A header comment.
# Note that the formatting is broken deliberately.
#

B foobar
float16 foo
float16 BAR    = 12.34  # This is BAR
---

truncated uint8    foo
int32  BAR =   -42
root.ns1.B baz
```

--- chunk_id: chunk-0120
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 442
content_hash: b6e88f8533a00146
prev_chunk_id: chunk-0119
next_chunk_id: chunk-0121
section_heading: Data type compatibility
document_type: specification

Normalized definition:

    root.A
    @union
    saturated float16 foo
    truncated uint8 bar

Example for service type `A` in the namespace `root`: ```
#
# A header comment.
# Note that the formatting is broken deliberately.
#

B foobar
float16 foo
float16 BAR    = 12.34  # This is BAR
---

truncated uint8    foo
int32  BAR =   -42
root.ns1.B baz
``` Normalized definition:

    root.A
    root.B foobar
    saturated float16 foo
    ---
    truncated uint8 foo
    root.ns1.B baz

#### DSDL signature

DSDL signature is the product of the application of the *signature hash function*
to a *normalized data type definition*. It is important to understand that DSDL signature is not the same as data type signature (because the data type may reference definitions stored in several files). #### Data type signature

Data type signature is a 64-bit integer value that is *guaranteed to be equal for compatible data types*. Hence, it is said that *data types are compatible if their names and signatures are equal*. The following is the data type signature computation algorithm for a given data type,
where *hash* is the signature hash function described earlier:

1. Initialize the hash value with the DSDL signature of the given type. 2. Starting from the top of the DSDL definition, do the following for each nested data structure:
    1. Extend the current hash value with the data type signature of the nested data structure. 3. The resulting hash value will be the data type signature. The hash extension algorithm:

1. Save the current hash value. 2. Feed the value the hash needs to be extended with to the hash function, byte by byte, LSB first. 3. Feed the saved hash value to the hash function, byte by byte, LSB first. The data type signature computation algorithm has the following properties:

* Data type signature and DSDL signature of the same type are equal if the data type does not contain nested data structures. * Data type signature is guaranteed to match only if all nested data structures are compatible.

--- chunk_id: chunk-0121
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 374
content_hash: c3ff380d227f1226
prev_chunk_id: chunk-0120
next_chunk_id: chunk-0122
section_heading: Data type compatibility
document_type: specification

The data type signature computation algorithm has the following properties:

* Data type signature and DSDL signature of the same type are equal if the data type does not contain nested data structures. * Data type signature is guaranteed to match only if all nested data structures are compatible. The implementation of the algorithm explained above can be found in one of the existing implementations. #### Aggregate signature

Aggregate data type signature is a signature computed for a set of data types. Aggregate data type signature is useful for checking the compatibility between two sets of data types. Two sets of data types **X** and **Y** are compatible if each data type in **X** has exactly one compatible data type
in **Y** and both sets are of equal size. One possible way to ensure compatibility between **X** and **Y** is to directly check the compatibility of each element
from **X** against each element from **Y**. DroneCAN, however, defines a computationally less expensive algorithm based on data type signature extension
(as defined above). The algorithm that computes the aggregate signature for the set of data types **A** is defined as follows,
where *hash* is the signature hash function described earlier:

1. Sort **A** by full data type name lexicographically in descending order (encoding is ASCII, order is A to Z). 2. Initialize the hash value with the data type signature of the first data type from **A**. 3. For each data type **a** from **A**, starting from the second, do the following:
  1. Extend the current hash value with the data type signature of **a**. Then, *two sets of data types are considered to be compatible if their aggregate signatures are equal*.

--- chunk_id: chunk-0122
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 285
content_hash: 120f833afa804fc5
prev_chunk_id: chunk-0121
next_chunk_id: chunk-0123
section_heading: Data type ID
document_type: specification

## Data type ID

The set of possible data type ID values is limited, so devices from different vendors may occasionally reuse the
same data type ID for different purposes. A part of the data type ID space is reserved for standard data types. Since all DroneCAN nodes should share the
same configuration for standard data types, collisions are unlikely to occur in that range. Another part of the data type ID space is dedicated for vendor-specific (or application-specific) IDs,
and this range of IDs is always collision prone. In order to allow the nodes from different vendors to be used in the same application,
*the end user must be able to change the ID of any non-standard data type on each node*. Vendors are advised to provide the end user with an option to change the ID of any standard message type as
well. Notes:
* The reserved ID ranges listed in the [Application level conventions](/Specification/5._Application_level_conventions/#id-distribution). * Message types and service types do not share the same set of possible data ID values (i.e., a message type and a service type can share the same data type ID with no conflict). You can learn more about this in the [CAN bus transport layer specification](/Specification/4.1_CAN_bus_transport_layer). * Changing ID does not affect data type compatibility.

--- chunk_id: chunk-0123
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 450
content_hash: 6a7b12b2b4998062
prev_chunk_id: chunk-0122
next_chunk_id: chunk-0124
section_heading: Data serialization
document_type: specification

## Data serialization
### Serialized data format

Serialized data are an ordered sequence of bit fields; no header or footer is provided, and fields are
not implicitly aligned. DSDL authors are advised (but not required) to manually align fields at byte boundaries using the void data type, in order to simplify data layouts and improve the performance of serialization and deserialization routines. The rules of encoding of different data types are defined below. #### Primitive types

Type | Bit length    | Binary representation
---------- |---------------| --------------------------------------------------------------------------------------------
int**X** | **X**         | [Two's complement](http://en.wikipedia.org/wiki/Two's_complement) signed integer
uint**X** | **X**         | Plain bits
bool | 1             | Single bit
float16 | 16            | [IEEE754](http://en.wikipedia.org/wiki/IEEE754) binary16
float32 | 32            | [IEEE754](http://en.wikipedia.org/wiki/IEEE754) binary32
float64 | 64            | [IEEE754](http://en.wikipedia.org/wiki/IEEE754) binary64
void**X** | **X**         | **X** zero bits; ignore when decoding

#### Nested data structures

Nested data structures are encoded in much the same way as if they were standalone top-level data structures,
with one exception for *tail array optimization*, as defined below. #### Fixed size arrays

Fixed-size arrays are encoded as a plain sequence of items, with each item encoded independently in place,
with no alignment. No extra data is added. Essentially, a fixed-size array of size **X** will be encoded exactly in the same way as a sequence of
**X** fields of the same type in a row. Hence, the following data type:

    AnyType[3] array

will have the same binary layout as:

    AnyType array_0
    AnyType array_1
    AnyType array_2

The only difference is the representation in the target programming language. #### Dynamic arrays

Dynamic array encoding rules are sophisticated; hence it is recommended to review the existing implementations for a
deeper understanding. There is no difference between the following two array definitions other than text representation for the human benefit:

    AnyType[<42]  a # Max size 41
    AnyType[<=41] b # Max size 41

Both forms are equivalent in terms of the data serialization. Array items can be of variable length
(for example, if the item's type is a data structure that itself contains dynamic arrays).

--- chunk_id: chunk-0124
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 444
content_hash: ed936a502491e413
prev_chunk_id: chunk-0123
next_chunk_id: chunk-0125
section_heading: Data serialization
document_type: specification

There is no difference between the following two array definitions other than text representation for the human benefit:

    AnyType[<42]  a # Max size 41
    AnyType[<=41] b # Max size 41

Both forms are equivalent in terms of the data serialization. Array items can be of variable length
(for example, if the item's type is a data structure that itself contains dynamic arrays). As a result, array maximum and minimum size may not not always be the same. Normally, a dynamic array will be encoded as a sequence of encoded items, prepended with an unsigned integer field
representing the number of contained items - the *length field*. The bit width of the length field is a function of the maximum number of items in the array:
`⌈log2(X + 1)⌉`, where X is the maximum number of items in the array. For example, if the maximum number of items is 251, the length field bit width must be 8 bits,
or if the maximum number of items is 1, the length field bit width will be just a single bit. The transport layer provides a data length for every received data transfer (with an 8-bit resolution);
thus, in some cases, the array length information would be redundant as it can be inferred from the overall transfer
length reported by the transport layer. Elimination of the dynamic array length field is called *tail array optimization*,
and it can be done if all the conditions below are satisfied:

1. The minimum bit length of an item type is not less than 8 bits - because the transport layer reports the transfer length with an 8-bit resolution. 2. The array is the last field in the top-level data structure - because, otherwise, a much more complicated logic would be required to derive the length. The second condition means that tail array optimization would be possible only if there are no other fields in the
output bit stream after the dynamic array. Only one array can be tail optimized.

--- chunk_id: chunk-0125
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 461
content_hash: 0f6a3860cbe37610
prev_chunk_id: chunk-0124
next_chunk_id: chunk-0126
section_heading: Data serialization
document_type: specification

The second condition means that tail array optimization would be possible only if there are no other fields in the
output bit stream after the dynamic array. Only one array can be tail optimized. Below are some examples that illustrate when a tail array optimization is possible and when it is not. ```
# Type root.A
uint8 foo
# Tail array optimization is possible here
# It will be encoded just like a fixed-size array
# The number of elements will be inferred from the transfer length
uint8[<9] array

# Type root.B
float16 foo
# Tail array optimization will not be possible because item length is less than 8 bits
uint7[<=8] array

# Type root.C
# Tail array optimization will not be possible because the array is not the last field
uint8[<=8] array
float16 bar

# Type root.D
# Tail array optimization will not be possible because item length is less than 8 bits
bool[<=42] array

# Type root.E
# Tail array optimization will not be possible because the minimum item length is zero
root.D[<=42] array     # Refer to root.D definition above
``` The same rules are applied to more sophisticated cases, for example when multiple nested types with dynamic arrays are used. Such structure may produce very complex binary layouts, but the same array encoding rules are still applicable. ```
# Type root.Z
# Refer to root.A definition above
# This array will be tail optimized
# Arrays inside root.A will not be tail optimized
root.A[<=2] array

# Type root.Y
# This array will NOT be tail optimized
# Arrays inside root.A will NOT be tail optimized
root.A[<=2] array
# The last field here effectively disables any arrays from being tail optimized
float16 baz

# Type root.Q
int4 fooz
# Just an array that can be tail optimized, no nested types
float64[<=64] array

# Type root.X
# This array will NOT be tail optimized
# Because the minimum bit length of root.Q is 4 bits (less than 8 bits)
# However, the last array in the last item will be tail optimized
root.Q[<=12] array
```

--- chunk_id: chunk-0126
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 452
content_hash: 1a25a39c7d9288e3
prev_chunk_id: chunk-0125
next_chunk_id: chunk-0127
section_heading: Data serialization
document_type: specification

Such structure may produce very complex binary layouts, but the same array encoding rules are still applicable. ```
# Type root.Z
# Refer to root.A definition above
# This array will be tail optimized
# Arrays inside root.A will not be tail optimized
root.A[<=2] array

# Type root.Y
# This array will NOT be tail optimized
# Arrays inside root.A will NOT be tail optimized
root.A[<=2] array
# The last field here effectively disables any arrays from being tail optimized
float16 baz

# Type root.Q
int4 fooz
# Just an array that can be tail optimized, no nested types
float64[<=64] array

# Type root.X
# This array will NOT be tail optimized
# Because the minimum bit length of root.Q is 4 bits (less than 8 bits)
# However, the last array in the last item will be tail optimized
root.Q[<=12] array
``` Application designers are advised to keep in mind the tail array optimization rules when designing custom data types. #### Unions

Unions are encoded as two subsequent entities:

1. The union tag;
2. The selected field. The union tag is an unsigned integer, whose bit length is a function of the number of fields in the union:
`⌈log2(N)⌉`, where N is the number of fields in the union. The value encoded in the union tag is the index of the selected field. Field indexes are assigned according to the order in which they are defined, starting from zero;
i.e. the first defined field gets index 0, second defined field gets index 1, and so on. Consider the following example: ```
#
# This is a union.
#

@union                  # In this case, the union tag requires 2 bits

uint16 FOO = 42         # A regular constant attribute

uint16 a                # Index 0
uint8 b                 # Index 1
float64 c               # Index 2

uint32 BAR = 42         # Another regular constant
``` In order to encode the value `b`, which, according to the definition, has the data type `uint8`, the union
tag should be assigned the value 1.

--- chunk_id: chunk-0127
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 318
content_hash: 3ab45ffc8a0dd652
prev_chunk_id: chunk-0126
next_chunk_id: chunk-0128
section_heading: Data serialization
document_type: specification

```
#
# This is a union.
#

@union                  # In this case, the union tag requires 2 bits

uint16 FOO = 42         # A regular constant attribute

uint16 a                # Index 0
uint8 b                 # Index 1
float64 c               # Index 2

uint32 BAR = 42         # Another regular constant
``` In order to encode the value `b`, which, according to the definition, has the data type `uint8`, the union
tag should be assigned the value 1. The following structure will have identical layout: ```
uint2 tag
uint8 b
``` By way of an example, if the value of `b` was 7, the resulting encoded byte sequence would be (in binary):

    01000001 11000000

### Byte order and bit order

Byte order: least significant byte (LSB) first, also known as little-endian. Bit order: bits are filled from the most significant to the least significant,
i.e., the most significant bit has index 0. The resulting bit sequence must be aligned to 1 byte; pad bits must be set to zero. For the purpose of example, the following data will be encoded according to the defined order:

1. 0xbeda of bit length 12
2. -1 of bit length 3
3. -5 of bit length 4
4. -1 of bit length 2
5. 0x88 of bit length 4

The resulting byte sequence is shown on the following diagram:

{% include lightbox.html url="/Specification/figures/bit_encoding.png" title="Encoding rules" %}

We recommend you review the existing implementations.

--- chunk_id: chunk-0128
source_document: Specification__3._Data_structure_description_language.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 317
content_hash: ae0ff3ef7f980e7f
prev_chunk_id: chunk-0127
next_chunk_id: chunk-0129
section_heading: Standard data types
document_type: specification

## Standard data types

The DSDL definitions of the standard data structures are available in the DSDL repository,
which is linked [here](/Contact), and in a later section of the specification. Information concerning development and maintenance of the standard DSDL definitions is available
[here](/Specification/1._Introduction). ### Vendor-specific data types
Vendors must define their specific data types in a separate namespace, which should typically be named to match their company name. Separation of the vendor's definitions into a dedicated namespace ensures that no name conflicts will occur in
systems that utilize vendor-specific data types from different providers. Note that, according to the naming requirements, the name of a DSDL namespace must start with an alphabetic character;
therefore, a company whose name starts with a digit will have to resort to a mangled name, e.g. by moving the
digits towards the end of the name, or by spelling the digits in English (e.g. 42 - `fortytwo`). Defining vendor-specific data types within the standard namespace `uavcan` is explicitly prohibited. The standard namespace will always be used only for standard definitions. Generally speaking it is desirable for "generic" data types to be included into the standard set. Vendors should strive to design their data types as generic and as independent of their specific use cases as possible. The SI system of measurement units should be preferred, as data type definitions that make unnecessary deviations from SI will not be accepted into the standard set.

--- chunk_id: chunk-0129
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 21
content_hash: 725c9f9c1e0c57ea
prev_chunk_id: chunk-0128
next_chunk_id: chunk-0130
section_heading: CAN bus transport layer
document_type: specification

# CAN bus transport layer

This chapter defines the CAN bus based transport layer of DroneCAN.

--- chunk_id: chunk-0130
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 990
content_hash: 7f96563e3649bf37
prev_chunk_id: chunk-0129
next_chunk_id: chunk-0131
section_heading: The concept of transfer
document_type: specification

## The concept of transfer

A *Transfer* is an act of data transmission between nodes.
A transfer that is addressed to all nodes except the source node is a *broadcast transfer*.
A transfer that is addressed to one particular node is a *unicast transfer*.
DroneCAN defines the following types of transfers:

* Message transfer - a broadcast transfer that contains a serialized message.
* Service transfer - a unicast transfer that contains either a service request or a service response.

Both message and service transfers can be further distinguished between:

* Single-frame transfer - a transfer that is entirely contained in a single CAN frame.
* Multi-frame transfer - a transfer that has its payload distributed over multiple CAN frames.

The following properties are common to all types of transfer:

Property        | Description
----------------|------------------------------------------------------------------------------------------------------
Payload         | The serialized data structure
Data type ID    | An identifier that indicates how the data structure should be interpreted
Priority        | A positive integer value that defines the message urgency (0 is the highest priority). Higher priority transfers can delay transmission of lower priority transfers.
Transfer ID     | An integer value that allows receiving nodes to distinguish this transfer from all others

### Message broadcasting

A broadcast message is carried by a single message transfer that contains the serialized message.
A broadcast message has the following properties:

Property        | Description
----------------|------------------------------------------------------------------------------------------------------
Payload         | The serialized message
Data type ID    | An identifier that indicates how the message should be interpreted
Source node ID  | Node ID of the node that has transmitted the transfer
Priority        | See above
Transfer ID     | See above

In order to broadcast a message, the broadcasting node must have a node ID that is unique within the network.
An exception is applied to *anonymous message broadcasts*.

#### Anonymous message broadcasting

An anonymous message is a transfer that originates from a node that does not have a node ID.
This sort of message transfer is useful for *dynamic node ID allocation* (a high-level concept that
will be explained in [the chapter 6 of the specification](/Specification/6._Application_level_functions/)).

A node that does not have a node ID is said to be in *passive mode*.

An anonymous message has the same properties as a regular message, except for source node ID.

An anonymous transfer can only be a single-frame transfer. Multi-frame anonymous messages are not allowed.

Note that anonymous messages require specific arbitration rules and have restrictions on the acceptable
data type ID values.
The details are explained in the following chapters.

#### Timing

Message transmission should be aborted if it cannot be completed in 1 second.

### Service invocation

A service invocation consists of two service transfers:

1. *Service request transfer* - from the node that invokes the service, known as *client*, to the node that provides
the service, known as *server*.
2. *Service response transfer* - once the server node receives the service request and processes it, it sends a
response transfer back to the client.

A *service request transfer* has the following properties:

Property                | Description
------------------------|------------------------------------------------------------------------------------------------------
Payload                 | The serialized request structure
Data type ID            | An identifier that indicates how the request should be interpreted
Source node ID          | Node ID of the client
Destination node ID     | Node ID of the server
Priority                | See above
Transfer ID             | An integer value that: <br>1. allows the server to distinguish this request from other requests from the same client<br>2. allows the client to match the response with its request

A *service response transfer* has the following properties:

Property                | Description
------------------------|------------------------------------------------------------------------------------------------------
Payload                 | The serialized response structure
Data type ID            | Must be the same value as in the request transfer
Source node ID          | Node ID of the server
Destination node ID     | Node ID of the client
Priority                | Should be the same value as in the request transfer
Transfer ID             | Must be the same value as in the request transfer

Both client and server must have node ID values that are unique within the network.

#### Timing

The following timings should be used, unless the application strongly requires different values:

* Service transfer transmission should be aborted if does not complete in 1 second.
* The client should stop waiting for a response from the server if one has not arrived within 1 second.
* The server should be able to process any request in under 0.5 seconds.

If different values are used, they must be explicitly documented.

--- chunk_id: chunk-0131
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 420
content_hash: 5dcbf772e3fb1662
prev_chunk_id: chunk-0130
next_chunk_id: chunk-0132
section_heading: Transmission
document_type: specification

## Transmission
### Transfer ID computation

The *Transfer ID* is a small unsigned integer value that is added to every outgoing transfer
(it is used by receiving nodes to distinguish between individual transfers). For *message transfers* and *service request transfers* the ID value should be computed as described below. For *service response transfers* this value must be directly copied from the corresponding service request
transfer. The logic to compute the *Transfer ID* relies on the concept of *transfer descriptor*. A transfer descriptor is a set of properties that identify a particular set of transfers that originate from
the same node, share the same data type ID and the same type. The properties that constitute a transfer descriptor are listed below:

* Transfer type (message broadcast, service request, etc.)
* Data type ID
* Source node ID
* Destination node ID (only for unicast transfers)

Every node that needs to publish a transfer must maintain the mapping from transfer descriptors to transfer ID. This mapping is referred to as the *transfer ID map*. Whenever a node needs to emit a transfer, it will query its transfer ID map for the appropriate transfer descriptor. If the map does not contain such entry, a new entry will be created with transfer ID initialized to zero. The node will use the current value of transfer ID from the map for the transfer, and then the value stored in the map
will be incremented by one. When the stored transfer ID exceeds its maximum value, it will roll over to zero. It is expected that some nodes will need to publish certain transfers aperiodically or on an ad-hoc basis, thereby creating
unused entries in the transfer ID map. In order to avoid keeping unused entries in the map, the nodes are allowed, but not required,
to remove entries from the map that were not used for at least 2 seconds.

--- chunk_id: chunk-0132
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 444
content_hash: 56ea008e5b64d7e8
prev_chunk_id: chunk-0131
next_chunk_id: chunk-0133
section_heading: Transmission
document_type: specification

It is expected that some nodes will need to publish certain transfers aperiodically or on an ad-hoc basis, thereby creating
unused entries in the transfer ID map. In order to avoid keeping unused entries in the map, the nodes are allowed, but not required,
to remove entries from the map that were not used for at least 2 seconds. Therefore, it is possible that a node may publish a transfer with an out-of-order transfer ID value, if previous
transfer of the same descriptor has been published more than 2 seconds previously. ### Payload decomposition
#### Single frame transfer

If the size of the entire transfer payload does not exceed the space available for payload in a single CAN frame,
the whole transfer will be contained in one CAN frame. Such transfer is called a *single-frame transfer*. Single frame transfers are more efficient than multi-frame transfers in terms of throughput and latency,
therefore it is advised to avoid the latter where possible. #### Multi-frame transfer

*Multi-frame transfers* are used when the size of the transfer payload exceeds the space available for payload in a
single CAN frame. Two new concepts are introduced in the context of multi-frame transfers, both of which are reviewed below in detail:

* Transfer CRC
* Toggle bit

In order to make a multi-frame transfer, the node must first compute a CRC for the transfer payload. The node prepends the CRC value to the transfer payload, and emits this data in chunks as a sequence of CAN frames (i.e. the first CAN frame contains the CRC and the first bytes of the payload). The data field of all CAN frames of a multi-frame transfer, except the last one, must be filled/fully utilized. All frames of a multi-frame transfer should be pushed to the bus at once, in the proper order from the first
frame to the last frame. ##### Transfer CRC

The *Transfer CRC* is computed from the transfer payload, prepended with a data type signature, in little-endian byte order.

--- chunk_id: chunk-0133
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 436
content_hash: 757b754619cb584d
prev_chunk_id: chunk-0132
next_chunk_id: chunk-0134
section_heading: Transmission
document_type: specification

All frames of a multi-frame transfer should be pushed to the bus at once, in the proper order from the first
frame to the last frame. ##### Transfer CRC

The *Transfer CRC* is computed from the transfer payload, prepended with a data type signature, in little-endian byte order. The diagram below illustrates the input of the transfer CRC function:

{% include lightbox.html url="/Specification/figures/transfer_crc_input.png" title="Transfer CRC input" %}

The transfer CRC algorithm is specified as follows:

* Name: CRC-16-CCITT-FALSE
* Description: <http://reveng.sourceforge.net/crc-catalogue/16.htm#crc.cat.crc-16-ccitt-false>
* Initial value: 0xFFFF
* Poly: 0x1021
* Reverse: no
* Output XOR: 0
* Check: 0x29B1

The following code provides an implementation of the transfer CRC algorithm in C++: ```cpp
/*
 * License: CC0, no copyright reserved.
 */

#include <iostream>
#include <cstdint>
#include <cassert>

class TransferCRC
{
    std::uint16_t value_;

public:
    TransferCRC()
        : value_(0xFFFFU)
    { }

    void add(std::uint8_t byte)
    {
        value_ ^= static_cast<std::uint16_t>(byte) << 8;
        for (std::uint8_t bit = 8; bit > 0; --bit)
        {
            if (value_ & 0x8000U)
            {
                value_ = (value_ << 1) ^ 0x1021U;
            }
            else
            {
                value_ = (value_ << 1);
            }
        }
    }

    void add(const std::uint8_t* bytes, unsigned len)
    {
        assert(bytes);
        while (len--)
        {
            add(*bytes++);
        }
    }

    std::uint16_t get() const { return value_; }
};

int main()
{
    TransferCRC crc;
    crc.add(reinterpret_cast<const std::uint8_t*>("123456789"), 9);
    std::cout << std::hex << "0x" << crc.get() << std::endl;
}
``` ##### Toggle bit

The *Toggle bit* is a property defined at the CAN frame level. Its purpose is to detect and avoid CAN frame duplication errors. The toggle bit of the first CAN frame of a multi-frame transfer must be set to zero. The toggle bits of the following CAN frames of the transfer must alternate,
i.e. the toggle bit of the second CAN frame will be one, the toggle bit of the third CAN frame will be zero,
and so on. ### Redundant interface support

In configurations with redundant CAN bus interfaces, nodes are required to transmit every outgoing transfer via
all available redundant interfaces simultaneously.

--- chunk_id: chunk-0134
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 132
content_hash: bf5eb93543340e80
prev_chunk_id: chunk-0133
next_chunk_id: chunk-0135
section_heading: Transmission
document_type: specification

the toggle bit of the second CAN frame will be one, the toggle bit of the third CAN frame will be zero,
and so on. ### Redundant interface support

In configurations with redundant CAN bus interfaces, nodes are required to transmit every outgoing transfer via
all available redundant interfaces simultaneously. An exception to the above rule is applicable if the payload of the transfer depends on some properties of the
interface through which the transfer is emitted. An example of such a special case is the time-synchronization algorithm leveraged by DroneCAN
(documented in [the chapter 6 of the specification](/Specification/6._Application_level_functions/)).

--- chunk_id: chunk-0135
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 410
content_hash: 586c67fce2ecb0a3
prev_chunk_id: chunk-0134
next_chunk_id: chunk-0136
section_heading: CAN frame format
document_type: specification

## CAN frame format

DroneCAN uses only CAN 2.0B frame format (29-bit identifiers). DroneCAN can share the same bus with other protocols based on CAN 2.0A (11-bit identifiers). ### ID field

{% include lightbox.html url="/Specification/figures/can_id_format.png" title="CAN ID format" %}

Contents of the CAN ID field depend on the transfer type. In the case of a message broadcast transfer, the CAN ID field of every frame of the transfer will contain
the following fields:

Field | Bits | Allowed values | Description
-------------------------------- |------|----------------| --------------------------------------------------------------
Priority | 5    | Any            | Message type ID | 16   | Any            | Data type ID of the encoded message
Service not message | 1    | 0              | Always zero
Source node ID | 7    | 1...127        | See below

In the case of an anonymous message transfer, the CAN ID will contain the following fields:

Field | Bits | Allowed values | Description
-------------------------------- |------|----------------| --------------------------------------------------------------
Priority | 5    | Any            | Discriminator | 14   | Any            | See below
Lower bits of message type ID | 2    | Any            | Data type ID of the encoded message
Service not message | 1    | 0              | Always zero
Source node ID | 7    | 0              | Always zero

In the case of a service transfer, the CAN ID field of every frame of the transfer will contain the following fields:

Field | Bits | Allowed values | Description
-------------------------------- |------|----------------| --------------------------------------------------------------
Priority | 5    | Any            | Service type ID | 8    | Any            | Data type ID of the encoded service request or response
Request not response | 1    | Any            | Values: 1 - service request transfer, 0 - service response transfer
Destination node ID | 7    | 1...127        | See below
Service not message | 1    | 1              | Always one
Source node ID | 7    | 1...127        |

--- chunk_id: chunk-0136
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 697
content_hash: aeb6cc98ced673b2
prev_chunk_id: chunk-0135
next_chunk_id: chunk-0137
section_heading: CAN frame format
document_type: specification

See below

#### Priority

Valid values for priority range from 0 to 31, inclusively, where 0 corresponds to highest priority (and 31 corresponds to lowest priority).

In multi-frame transfers, the value of the *priority* field must be identical for all frames of the transfer.

#### Message type ID

Valid values of message type ID range from 0 to 65535, inclusively.

Valid values of message type ID range for *anonymous message transfers* range from 0 to 3, inclusively.
This limitation is due to the fact that only 2 lower bits of the message type ID are available in this case.

#### Service type ID

Valid values of service type ID range from 0 to 255, inclusively.

#### Node ID

Valid values of Node ID range from 1 to 127, inclusively.

Note that Node ID is represented by a 7-bit unsigned integer value and that zero is reserved,
to represent either an unknown node or all nodes, depending on the context.

#### Discriminator

CAN bus does not allow different nodes to transmit CAN frames with different data field values under the same CAN ID.
Owing to the fact that the CAN ID field includes the node ID value of the transmitting node,
this restriction is met by regular DroneCAN transfers.
However, anonymous message transfers violate this restriction, because they all share the same node ID of zero.

In order to work-around this problem, DroneCAN adds a discriminator to the CAN ID field of anonymous message
transfers, and defines special logic for handling CAN bus errors during transmission of anonymous frames.

The discriminator field must be filled with random data whenever a node transmits an anonymous message transfer.
The source of the random data must be likely to produce different discriminator values for different data field values.
A possible way of initializing the discriminator value is to apply the transfer CRC function (as defined above)
to the contents of the anonymous message, and then use any 14 bits of the result.
Nodes that adopt this approach will be using the same discriminator value for identical messages,
which is acceptable since this will not trigger an error on the bus.

Since the discriminator is only 14 bits long, the probability of having multiple nodes that are emitting CAN frames
with the same CAN ID but different data is higher than 0.006% (which is significant).
Therefore, the protocol must account for possible errors on the CAN bus triggered by CAN ID collisions.
In order to comply with this requirement,
DroneCAN requires all nodes to immediately abort transmission of all anonymous transfers once an error on the CAN bus is
detected.
This measure allows to prevent the bus deadlock that may occur if the automatic retransmission on bus error
is not suppressed.

### Payload

{% include lightbox.html url="/Specification/figures/can_payload_format.png" title="CAN payload format" %}

The Data field of the CAN frame is shared between the following fields:

Field                   | Description
------------------------|----------------------------------------------------------------------------------------------
Transfer payload        | Actual payload of the transfer
Tail byte               | The last byte of the CAN frame data field, which contains auxiliary transport layer fields

The tail byte contains the following fields, starting from the most significant bit:

Field

--- chunk_id: chunk-0137
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 701
content_hash: bd91243739a25ff3
prev_chunk_id: chunk-0136
next_chunk_id: chunk-0138
section_heading: CAN frame format
document_type: specification

See below

#### Priority

Valid values for priority range from 0 to 31, inclusively, where 0 corresponds to highest priority (and 31 corresponds to lowest priority).

In multi-frame transfers, the value of the *priority* field must be identical for all frames of the transfer.

#### Message type ID

Valid values of message type ID range from 0 to 65535, inclusively.

Valid values of message type ID range for *anonymous message transfers* range from 0 to 3, inclusively.
This limitation is due to the fact that only 2 lower bits of the message type ID are available in this case.

#### Service type ID

Valid values of service type ID range from 0 to 255, inclusively.

#### Node ID

Valid values of Node ID range from 1 to 127, inclusively.

Note that Node ID is represented by a 7-bit unsigned integer value and that zero is reserved,
to represent either an unknown node or all nodes, depending on the context.

#### Discriminator

CAN bus does not allow different nodes to transmit CAN frames with different data field values under the same CAN ID.
Owing to the fact that the CAN ID field includes the node ID value of the transmitting node,
this restriction is met by regular DroneCAN transfers.
However, anonymous message transfers violate this restriction, because they all share the same node ID of zero.

In order to work-around this problem, DroneCAN adds a discriminator to the CAN ID field of anonymous message
transfers, and defines special logic for handling CAN bus errors during transmission of anonymous frames.

The discriminator field must be filled with random data whenever a node transmits an anonymous message transfer.
The source of the random data must be likely to produce different discriminator values for different data field values.
A possible way of initializing the discriminator value is to apply the transfer CRC function (as defined above)
to the contents of the anonymous message, and then use any 14 bits of the result.
Nodes that adopt this approach will be using the same discriminator value for identical messages,
which is acceptable since this will not trigger an error on the bus.

Since the discriminator is only 14 bits long, the probability of having multiple nodes that are emitting CAN frames
with the same CAN ID but different data is higher than 0.006% (which is significant).
Therefore, the protocol must account for possible errors on the CAN bus triggered by CAN ID collisions.
In order to comply with this requirement,
DroneCAN requires all nodes to immediately abort transmission of all anonymous transfers once an error on the CAN bus is
detected.
This measure allows to prevent the bus deadlock that may occur if the automatic retransmission on bus error
is not suppressed.

### Payload

{% include lightbox.html url="/Specification/figures/can_payload_format.png" title="CAN payload format" %}

The Data field of the CAN frame is shared between the following fields:

Field                   | Description
------------------------|----------------------------------------------------------------------------------------------
Transfer payload        | Actual payload of the transfer
Tail byte               | The last byte of the CAN frame data field, which contains auxiliary transport layer fields

The tail byte contains the following fields, starting from the most significant bit:

Field | Bits  |

--- chunk_id: chunk-0138
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 704
content_hash: 55318f7281510600
prev_chunk_id: chunk-0137
next_chunk_id: chunk-0139
section_heading: CAN frame format
document_type: specification

See below

#### Priority

Valid values for priority range from 0 to 31, inclusively, where 0 corresponds to highest priority (and 31 corresponds to lowest priority).

In multi-frame transfers, the value of the *priority* field must be identical for all frames of the transfer.

#### Message type ID

Valid values of message type ID range from 0 to 65535, inclusively.

Valid values of message type ID range for *anonymous message transfers* range from 0 to 3, inclusively.
This limitation is due to the fact that only 2 lower bits of the message type ID are available in this case.

#### Service type ID

Valid values of service type ID range from 0 to 255, inclusively.

#### Node ID

Valid values of Node ID range from 1 to 127, inclusively.

Note that Node ID is represented by a 7-bit unsigned integer value and that zero is reserved,
to represent either an unknown node or all nodes, depending on the context.

#### Discriminator

CAN bus does not allow different nodes to transmit CAN frames with different data field values under the same CAN ID.
Owing to the fact that the CAN ID field includes the node ID value of the transmitting node,
this restriction is met by regular DroneCAN transfers.
However, anonymous message transfers violate this restriction, because they all share the same node ID of zero.

In order to work-around this problem, DroneCAN adds a discriminator to the CAN ID field of anonymous message
transfers, and defines special logic for handling CAN bus errors during transmission of anonymous frames.

The discriminator field must be filled with random data whenever a node transmits an anonymous message transfer.
The source of the random data must be likely to produce different discriminator values for different data field values.
A possible way of initializing the discriminator value is to apply the transfer CRC function (as defined above)
to the contents of the anonymous message, and then use any 14 bits of the result.
Nodes that adopt this approach will be using the same discriminator value for identical messages,
which is acceptable since this will not trigger an error on the bus.

Since the discriminator is only 14 bits long, the probability of having multiple nodes that are emitting CAN frames
with the same CAN ID but different data is higher than 0.006% (which is significant).
Therefore, the protocol must account for possible errors on the CAN bus triggered by CAN ID collisions.
In order to comply with this requirement,
DroneCAN requires all nodes to immediately abort transmission of all anonymous transfers once an error on the CAN bus is
detected.
This measure allows to prevent the bus deadlock that may occur if the automatic retransmission on bus error
is not suppressed.

### Payload

{% include lightbox.html url="/Specification/figures/can_payload_format.png" title="CAN payload format" %}

The Data field of the CAN frame is shared between the following fields:

Field                   | Description
------------------------|----------------------------------------------------------------------------------------------
Transfer payload        | Actual payload of the transfer
Tail byte               | The last byte of the CAN frame data field, which contains auxiliary transport layer fields

The tail byte contains the following fields, starting from the most significant bit:

Field | Bits  | Description
------------------------

--- chunk_id: chunk-0139
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 312
content_hash: 340f43f064c1c97e
prev_chunk_id: chunk-0138
next_chunk_id: chunk-0140
section_heading: CAN frame format
document_type: specification

| Bits  | Description
------------------------ |-------| --------------------------------------------------------------------------------------
Start of transfer | 1     | See below
End of transfer | 1     | See below
Toggle bit | 1     | See below
Transfer ID | 5     | The transfer ID value

The following figure summarizes the data field format for a single-frame transfer:

{% include lightbox.html url="/Specification/figures/single_frame_transfer.png" title="Single frame transfer" %}

The following figure summarizes the data field format for a multi-frame transfer:

{% include lightbox.html url="/Specification/figures/multi_frame_transfer.png" title="Multi frame transfer" %}

#### Start of transfer

For single-frame transfers, the value of this field is always 1. For multi-frame transfers, the value of this field is 1 if the current frame is the first frame of the transfer,
and 0 otherwise. #### End of transfer

For single-frame transfers, the value of this field is always 1. For multi-frame transfers, the value of this field is 1 if the current frame is the last frame of the transfer,
and 0 otherwise. #### Toggle bit

For single-frame transfers, the value of this field is always 0. For multi-frame transfers, this field contains the value of the toggle bit. As specified above this will alternate value between frames, starting at 0 for the first frame. #### Transfer ID

This field contains the transfer ID value of the current transfer (for all types of transfers). The value is 5 bits wide, therefore the allowed values range from 0 to 31, inclusively.

--- chunk_id: chunk-0140
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 300
content_hash: 7e5a2294f48d4bba
prev_chunk_id: chunk-0139
next_chunk_id: chunk-0141
section_heading: Reception
document_type: specification

## Reception
### Transfer ID comparison

The following explanation relies on the concept of *transfer ID forward distance*. Transfer ID forward distance is a function of two transfer ID values, A and B,
that defines the number of increment operations that need to be applied to A so that A' equals B. Consider an example:

* A = 0, B = 0 &rArr; forward distance 0
* A = 0, B = 5 &rArr; forward distance 5
* A = 31, B = 30 &rArr; forward distance 31 (overflow)
* A = 31, B = 0 &rArr; forward distance 1 (overflow)

The following code sample provides an implementation of the transfer ID comparison algorithm in C++: ```cpp
/*
 * License: CC0, no copyright reserved.
 */

#include <cstdint>
#include <iostream>
#include <cassert>

constexpr std::uint8_t TransferIDBitLength = 5;

std::int8_t computeForwardDistance(std::uint8_t a, std::uint8_t b)
{
    constexpr std::uint8_t MaxValue = (1U << TransferIDBitLength) - 1U;
    assert((a <= MaxValue) && (b <= MaxValue));

    std::int16_t d = static_cast<std::int16_t>(b) - static_cast<std::int16_t>(a);
    if (d < 0)
    {
        d += 1U << TransferIDBitLength;
    }

    assert((d <= MaxValue) && (d >= -MaxValue));
    assert(((a + d) & MaxValue) == b);
    return static_cast<std::int8_t>(d);
}

int main()
{
    assert(0  == computeForwardDistance(0, 0));
    assert(1  == computeForwardDistance(0, 1));
    assert(7  == computeForwardDistance(0, 7));
    assert(0  == computeForwardDistance(7, 7));
    assert(31 == computeForwardDistance(31, 30)); // overflow
    assert(1  == computeForwardDistance(31, 0));  // overflow
}
```

--- chunk_id: chunk-0141
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 736
content_hash: d38817861ad3572a
prev_chunk_id: chunk-0140
next_chunk_id: chunk-0142
section_heading: Reception
document_type: specification

*Half range* of transfer ID is 16.

### State variables

A node that can receive a transfer must keep a certain set of state variables for each transfer descriptor.
The set of state variables will be referred to as *receiver state*.
For the purposes of specification, it is assumed that the node will maintain a mapping from
transfer descriptors to receiver states, which is referred to as the *receiver map*.

The receiver state should include at least the following variables:

State                           | Description
--------------------------------|--------------------------------------------------------------------------------------
Transfer payload                | Actual payload of the transfer
Transfer ID                     | Transfer ID value
Next toggle bit                 | Expected value of the toggle bit in the next frame of the transfer
Transfer timestamp              | The local time when the first frame of the transfer arrived
Interface index                 | Only applicable for a redundant interface configuration

The following operations are defined for the receiver state:

* Add data to the payload - this operation adds new data to the current transfer's payload state.
* Reinitialize - this operation resets the state variables to match the parameters of a new transfer.
Reinitialization includes at least the following:
  * Clearing the transfer payload;
  * Updating the transfer ID value with the actual value from the new transfer;
  * Clearing the toggle bit;
  * Initializing the transfer timestamp;
  * Initializing the interface index, if applicable.

The following conditions are defined for the receiver state:

* *Uninitialized* - this is a default condition, which indicates that the receiver has not yet seen any transfers.
* *Transfer ID timeout* - last matching transfer was seen more than 2 seconds ago.
* *Interface switch allowed* - this condition is only applicable for configurations with redundant CAN bus interfaces.
It means that the node is allowed to receive the next transfer from an interface that is not the same as the one the
previous transfer was received from. The condition will be reached if the last matching transfer has been successfully
received more than *T<sub>switch</sub>* seconds ago. The value of *T<sub>switch</sub>* must not exceed 2 seconds.
The actual value of *T<sub>switch</sub>* can be either a constant chosen by the designer according to the application
requirements (e.g., maximum recovery time in an event of an interface failure), or the protocol stack
may estimate the value automatically by means of analysing the transfer intervals.

Whenever a node receives a transfer, it will query its receiver map for the matching transfer descriptor.
If the matching state does not exist, the node will add a new uninitialized receiver state to the map.
The node then will proceed with the procedure of *receiver state update*, which is defined below.

It is expected that some transfers will be aperiodic or ad-hoc, which implies that the receiver map may accumulate
receiver states that are no longer used over time. Therefore, nodes are allowed, but not required, to remove any
receiver state from the receiver map, once the state reaches the transfer ID timeout condition.

Receiver state can only be modified when a new CAN frame of a matching transfer is received.
This guarantee simplifies implementation, as it implies that the receiver states will not require any background
maintenance processes.

### State update in a redundant interface configuration

The following pseudocode demonstrates the transfer reception process for
a configuration with redundant CAN bus interfaces.

--- chunk_id: chunk-0142
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: b9e0e85d90a71ae5
prev_chunk_id: chunk-0141
next_chunk_id: chunk-0143
section_heading: Reception
document_type: specification

// Constants:
tid_timeout := 2 seconds;
tid_half_range := 16;
iface_switch_delay := UserDefinedConstant; // Or autodetect

// State variables:
initialized := 0;
payload;
this_transfer_timestamp;
current_transfer_id;
iface_index;
toggle;

function receiveFrame(frame)
{
    // Resolving the state flags:
    tid_timed_out := (frame.timestamp - this_transfer_timestamp) > tid_timeout;
    same_iface := frame.iface_index == iface_index;
    first_frame := frame.start_of_transfer;
    non_wrapped_tid := computeForwardDistance(current_transfer_id, frame.transfer_id) < tid_half_range;
    not_previous_tid := computeForwardDistance(frame.transfer_id, current_transfer_id) > 1;
    iface_switch_allowed := (frame.timestamp - this_transfer_timestamp) > iface_switch_delay;

    // Using the state flags from above, deciding whether we need to reset:
    need_restart :=
        (!initialized) or
        (tid_timed_out) or
        (same_iface and first_frame and not_previous_tid) or
        (iface_switch_allowed and first_frame and non_wrapped_tid);

    if (need_restart)
    {
        initialized := 1;
        iface_index := frame.iface_index;
        current_transfer_id := frame.transfer_id;
        payload.clear();
        toggle := 0;
        if (!first_frame)
        {
            current_transfer_id.increment();
            return;                       // Ignore this frame, since the start of the transfer has already been missed
        }
    }

    if (frame.iface_index != iface_index)
    {
        return;  // Wrong interface, ignore
    }

    if (frame.toggle != toggle)
    {
        return;  // Unexpected toggle bit, ignore
    }

    if (frame.transfer_id != current_transfer_id)
    {
        return;  // Unexpected transfer ID, ignore
    }

    if (first_frame)
    {
        this_transfer_timestamp := frame.timestamp;
    }

    toggle := !toggle;
    payload.append(frame.data);

    if (frame.last_frame)
    {
        // CRC validation for multi-frame transfers is intentionally omitted for brevity
        processTransfer(payload, ...);

        current_transfer_id.increment();
        toggle := 0;
        payload.clear();
    }
}
``` ### State update in a non-redundant interface configuration

The following pseudocode demonstrates the transfer reception process for
a configuration with a non-redundant CAN bus interface. ```cpp
// Constants:
tid_timeout := 2 seconds;

// State variables:
initialized := 0;
payload;
this_transfer_timestamp;
current_transfer_id;
toggle;

function receiveFrame(frame)
{
    // Resolving the state flags:
    tid_timed_out := (frame.timestamp - this_transfer_timestamp) > tid_timeout;
    first_frame := frame.start_of_transfer;
    not_previous_tid := computeForwardDistance(frame.transfer_id, current_transfer_id) > 1;

    // Using the state flags from above, deciding whether we need to reset:
    need_restart :=
        (!initialized) or
        (tid_timed_out) or
        (first_frame and not_previous_tid);

    if (need_restart)
    {
        initialized := 1;
        current_transfer_id := frame.transfer_id;
        payload.clear();
        toggle := 0;
        if (!first_frame)
        {
            current_transfer_id.increment();
            return;                       // Ignore this frame, since the start of the transfer has already been missed
        }
    }

    if (frame.toggle != toggle)
    {
        return;  // Unexpected toggle bit, ignore
    }

    if (frame.transfer_id != current_transfer_id)
    {
        return;  // Unexpected transfer ID, ignore
    }

    if (first_frame)
    {
        this_transfer_timestamp := frame.timestamp;
    }

    toggle := !toggle;
    payload.append(frame.data);

    if (frame.last_frame)
    {
        // CRC validation for multi-frame transfers is intentionally omitted for brevity
        processTransfer(payload, ...);

        current_transfer_id.increment();
        toggle := 0;
        payload.clear();
    }
}

--- chunk_id: chunk-0143
source_document: Specification__4.1_CAN_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 152
content_hash: 17fdf352315fac58
prev_chunk_id: chunk-0142
next_chunk_id: chunk-0144
section_heading: CAN bus requirements
document_type: specification

## CAN bus requirements

The chapter dedicated to [hardware design recommendations](/Specification/8._Hardware_design_recommendations) contains
important information concerning CAN bus bit rate, connectors, and other properties of the physical layer
of the protocol. ### CAN controller driver software

Multi-frame transfers use identical CAN ID for all frames of the transfer, and
DroneCAN requires that all frames of a multi-frame transfer should be transmitted in order. Therefore, the CAN controller driver software must ensure that
*CAN frames with identical CAN ID must be transmitted in their order of appearance in the TX queue*. Some hardware will not meet this requirement by default, so the designer must take special care to
ensure correct behavior, and apply workarounds if necessary.

--- chunk_id: chunk-0144
source_document: Specification__4.2_UDP_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 21
content_hash: 523389833e2c4f42
prev_chunk_id: chunk-0143
next_chunk_id: chunk-0145
section_heading: UDP bus transport layer
document_type: specification

# UDP bus transport layer

This chapter defines the UDP bus based transport layer of DroneCAN.

--- chunk_id: chunk-0145
source_document: Specification__4.2_UDP_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 145
content_hash: 0c3decf1aa53c876
prev_chunk_id: chunk-0144
next_chunk_id: chunk-0146
section_heading: Ports and IP addresses
document_type: specification

## Ports and IP addresses

DroneCAN is carried over UDP using multicast packets. The default
multicast IP is 239.65.82.B where B is the DroneCAN bus number, where
0 is used for the first system bus. The default multicast port is 57732. ### Packet format
The packet format is: ```
   - MAGIC 0x2934 16 bit
   - 16 bit CRC CRC-16-CCITT (over all bytes after CRC)
   - 16 bit flags
   - 32 bit message ID
   - data[]
``` All data is little endian. ### URIs
In tools where the transport is enumerated the URI is "mcast:B" where
B is the bus number. This means "mcast:0" is 239.65.82.0 on UDP port
57732.

--- chunk_id: chunk-0146
source_document: Specification__4.3_MAVLink_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 21
content_hash: 144d5b57f321ee3a
prev_chunk_id: chunk-0145
next_chunk_id: chunk-0147
section_heading: MAVLink bus transport layer
document_type: specification

# MAVLink bus transport layer

This chapter defines the MAVLink bus based transport layer of DroneCAN.

--- chunk_id: chunk-0147
source_document: Specification__4.3_MAVLink_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 96
content_hash: aa833bdd253c2c9f
prev_chunk_id: chunk-0146
next_chunk_id: chunk-0148
section_heading: DroneCAN on MAVLink
document_type: specification

## DroneCAN on MAVLink

DroneCAN packets can be carried over MAVLink2 using either CAN_FRAME
or CAN_FRAME or CANFD_FRAME messages. Data in CAN_FRAME messages is
identical to the data in a bxCAN transport packet. Data in a
CANFD_FRAME message is identical to the data in a CANFD transport
packet. ### URI
When referring to a DroneCAN on MAVLink connection the prefix
"mavcan:" should be used in URIs followed by a standard MAVLink URI.

--- chunk_id: chunk-0148
source_document: Specification__4.4_CANFD_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 21
content_hash: 45d8544010336a2b
prev_chunk_id: chunk-0147
next_chunk_id: chunk-0149
section_heading: CANFD bus transport layer
document_type: specification

# CANFD bus transport layer

This chapter defines the CANFD bus based transport layer of DroneCAN.

--- chunk_id: chunk-0149
source_document: Specification__4.4_CANFD_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 197
content_hash: a204bc7f9735a1d0
prev_chunk_id: chunk-0148
next_chunk_id: chunk-0150
section_heading: DroneCAN on CANFD
document_type: specification

## DroneCAN on CANFD

DroneCAN operates on CANFD with a small number of changes from
operation on bxCAN. The changes are:

 - frames can be up to 64 bytes in length, as opposed to 8 byte frames
   for bxCAN
 - the TAO (tail array optimisation) technique is never used in the
   encoding at any level
 - the DLC is quantised as described below

### Bus rates
CANFD implementations will usually use bit rate switching (BRS) with a
nominal bit rate of 1MBps, with payload switching to 1, 2, 4, 5 or 8
MBit depending on hardware capabilities

### DLC Encoding
To accomodate the limited range of the DLC field a mapping is used for
data lengths of over 8 bytes. The mapping is ```
  # Data Length Code      9  10  11  12  13  14  15
  # Number of data bytes 12  16  20  24  32  48  64
```

--- chunk_id: chunk-0150
source_document: Specification__4.4_CANFD_bus_transport_layer.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 38
content_hash: f388b6612c2e4ac1
prev_chunk_id: chunk-0149
next_chunk_id: chunk-0151
section_heading: Compiler support
document_type: specification

## Compiler support

It is highly recommended that implementors use the dronecan_dsdlc
compiler for building compliant C and C++ bindings for DroneCAN that
work with both bxCAN and CANFD

--- chunk_id: chunk-0151
source_document: Specification__5._Application_level_conventions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 200
content_hash: 8b2c12640c5dddb0
prev_chunk_id: chunk-0150
next_chunk_id: chunk-0152
section_heading: ID distribution
document_type: specification

## ID distribution

*Application-level conventions*


### Message type ID

The valid range for *message type ID* is from 0 to 65535, inclusive (see [CAN bus transport layer specification](/Specification/4.1_CAN_bus_transport_layer)).
The range is segmented as follows:

ID range        | Purpose
----------------|--------------------------------------------------------------
[0, 20000)      | Standard message types
[20000, 21000)  | Vendor-specific message types
[21000, 65536)  | Reserved for future use

### Service type ID

The valid range for *service type ID* is from 0 to 255, inclusive (see [CAN bus transport layer specification](/Specification/4.1_CAN_bus_transport_layer)).
The range is segmented as follows:

ID range        | Purpose
----------------|--------------------------------------------------------------
[0, 100)        | Standard service types
[100, 200)      | Reserved for future use
[200, 256)      | Vendor-specific service types

### Node ID

The valid range for *node ID* is from 1 to 127, inclusive (see [CAN bus transport layer specification](/Specification/4.1_CAN_bus_transport_layer)).

The values 126 and 127 are reserved for debugging tools and should not be used for real nodes.

--- chunk_id: chunk-0152
source_document: Specification__5._Application_level_conventions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 405
content_hash: 9ed8e6696761311f
prev_chunk_id: chunk-0151
next_chunk_id: chunk-0153
section_heading: Coordinate frames and rotation representation
document_type: specification

## Coordinate frames and rotation representation

{% include lightbox.html url="/Specification/figures/rpy_angles_of_airplanes.png" title="Coordinate frames" thumbnail=true %}

DroneCAN follows the conventions that are widely accepted in various aerospace applications. All systems are right handed. In relation to a body, the standard is as follows:

* X forward
* Y right
* Z down

In the case of cameras, the following convention should be preferred:

* Z forward
* X right
* Y down

For world frames, the [North-East-Down (NED)](https://en.wikipedia.org/wiki/North_east_down) notation should be preferred. The default rotation representation is quaternion. The coefficients are ordered as follows: X, Y, Z, W. Angular velocities should be represented in fixed axis roll (about X), pitch (about Y), and yaw (about Z). ### Matrix representation
Matrices should be represented as flat arrays in row-major order. There are some standard ways to represent an N-by-N square matrix in a one-dimensional array:

* An empty array represents a zero matrix. * An array of one element represents a scalar matrix. * An array of N elements represents a diagonal matrix,
where each array member A<sub>i</sub> equals the matrix element M<sub>i,i</sub>. * An array of ((1+N)*N)/2 elements represents a symmetric matrix,
where array members represent elements of the upper-right triangle arranged in row-major order. For example, a 3-by-3 symmetric matrix can be represented as a flat array containing 6 matrix elements
in the following order:
[M<sub>1,1</sub>, M<sub>1,2</sub>, M<sub>1,3</sub>, M<sub>2,2</sub>, M<sub>2,3</sub>, M<sub>3,3</sub>]. * An array of size N<sup>2</sup> elements represents a full square matrix. ### Covariance matrix

A zero covariance matrix represents an unknown covariance. Positive infinity in variance means that the associated value is undefined. Alternatively, in some cases, the value itself can be set to NAN (not-a-number float constant) to indicate that
the parameter value is not defined. Note though that it is recommended to avoid NAN and infinities whenever possible for portability reasons.

--- chunk_id: chunk-0153
source_document: Specification__5._Application_level_conventions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 101
content_hash: 893c6b0dee273ce5
prev_chunk_id: chunk-0152
next_chunk_id: chunk-0154
section_heading: Engineering units
document_type: specification

## Engineering units

All units are [SI units](http://en.wikipedia.org/wiki/International_System_of_Units), unless explicitly noted otherwise. The following field naming convention is used:

* Fields that contain values not in SI units must be suffixed with the unit name, e.g.,
`battery_capacity_wh` ("wh" is for "Watt-hours" in this example). * Fields that contain values in SI units are not suffixed, e.g., `voltage` (implying that the units are Volts). If an application designer chooses to deviate, such decision should be properly documented.

--- chunk_id: chunk-0154
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 30
content_hash: 4b67d850ff2e74e2
prev_chunk_id: chunk-0153
next_chunk_id: chunk-0155
section_heading: Application-level functions
document_type: specification

# Application-level functions

{% include lightbox.html url="/Specification/figures/architecture.png" title="DroneCAN architecture" thumbnail=true maxwidth="40%" %}

The higher level concepts of DroneCAN are described in this section.

--- chunk_id: chunk-0155
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 181
content_hash: fb6562b73c49beff
prev_chunk_id: chunk-0154
next_chunk_id: chunk-0156
section_heading: Node initialization
document_type: specification

## Node initialization

DroneCAN does not require that nodes undergo any specific initialization upon connecting to the bus -
a node is free to begin functioning immediately once it is powered up. The only application-level function that every DroneCAN node must support is the periodic broadcasting of the
node status message, which is documented next. ### Node status reporting
Every DroneCAN node must report its status and presence by broadcasting messages of type
`uavcan.protocol.NodeStatus`. This is the only data structure that DroneCAN nodes are required to support. All other application-level functions are considered optional. Note that the ID of this message contains a long sequence
of alternating 0 and 1 values when represented in binary, which facilitates automatic CAN bus bit rate detection. The definition of the message is provided below. {% include dsdl.md prefix='uavcan.protocol.NodeStatus' %}

--- chunk_id: chunk-0156
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: 96a5475460601fcd
prev_chunk_id: chunk-0155
next_chunk_id: chunk-0157
section_heading: Node discovery
document_type: specification

## Node discovery

DroneCAN provides mechanisms to obtain the list of all nodes present in the network
as well as detailed information about each node:

- Lists of all nodes that are connected to the bus can be created and maintained
by listening for node status messages `uavcan.protocol.NodeStatus`. - Extended information about each node can be requested using the services documented below. Note that **it is highly recommended to support the service `uavcan.protocol.GetNodeInfo` in every node**,
as it is vital for node discovery and identification. {% include dsdl.md prefix='uavcan.protocol.GetNodeInfo' %}

{% include dsdl.md prefix='uavcan.protocol.GetDataTypeInfo' %}

### Time synchronization
DroneCAN supports network-wide precise time synchronization with a resolution of up to 1 CAN bus bit period
(i.e., 1 microsecond for 1 Mbps CAN bit rate), assuming that CAN frame timestamping is supported by the hardware. The algorithm can also function in the absence of hardware support for timestamping, although its performance will be
degraded. The time synchronization approach is based on the work
"Implementing a Distributed High-Resolution Real-Time Clock using the CAN-Bus" (M. Gergeleit and H. Streich). The general idea of the algorithm is to have one or more nodes that periodically broadcast a message of type
`uavcan.protocol.GlobalTimeSync` (definition is provided below) containing the exact timestamp of the previous
transmission of this message. A node that performs a periodic broadcast of this message is referred to as a *time synchronization master*,
whereas a node that synchronizes its time with the master is referred to as a *time synchronization slave*. Note that this algorithm only allows to precisely estimate the phase difference between the given slave and
the master it is synchronized with. DroneCAN does not define the algorithm for clock speed/phase adjustment, which is entirely implementation defined. The following constants are defined for the time synchronization algorithm:

* *T<sub>max</sub>* - maximum broadcast interval for a given master. * *T<sub>min</sub>* - minimum broadcast interval for a given master.

--- chunk_id: chunk-0157
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 546
content_hash: 9605a79b1e8f9b47
prev_chunk_id: chunk-0156
next_chunk_id: chunk-0158
section_heading: Node discovery
document_type: specification

The following constants are defined for the time synchronization algorithm:

* *T<sub>max</sub>* - maximum broadcast interval for a given master. * *T<sub>min</sub>* - minimum broadcast interval for a given master. * *T<sub>timeout</sub>* - if the master was not broadcasting the time synchronization message for this amount of time,
all slaves shall switch to the next active master with the highest priority. The network may accommodate more than one time synchronization master working at the same time. In this case, only the master with the lowest node ID should be active;
other masters should become passive by means of stopping broadcasting time synchronization messages,
and they must synchronize with the active master instead. If the currently active master was not broadcasting time synchronization messages for the duration of
*T<sub>timeout</sub>*, the next master with the highest priority becomes active instead,
and all slaves will synchronize with it. When a higher priority master appears in the network, all other lower-priority masters should become passive,
and all slaves will synchronize with the new master immediately. The message `uavcan.protocol.GlobalTimeSync` contains the exact timestamp of the previous transmission of this message. If the previous message was not yet transmitted,
or if it was transmitted more than *T<sub>max</sub>* time units ago, the field must be set to zero. It is recommended to refer to the existing DroneCAN implementations for reference. ### Master

The following pseudocode describes the logic of a time synchronization master. ```cpp
// State variables:
transfer_id := 0;
previous_tx_timestamp[NUM_IFACES];
previous_broadcast_timestamp;

// This function broadcasts a message with a specified Transfer ID using only one iface:
function broadcastMessage(transfer_id, iface_index, msg);

// This function returns the current value of a monotonic clock (the clock that doesn't change phase or rate)
function getMonotonicTime();

// This callback is invoked when the CAN driver completes transmission of a time sync message
// The tx_timestamp argument contains the exact timestamp when the CAN frame was delivered to the bus
function messageTxTimestampCallback(iface_index, tx_timestamp)
{
    previous_tx_timestamp[iface_index] := tx_timestamp;
}

// Publishes the message of type uavcan.protocol.GlobalTimeSync to each available interface
function broadcastTimeSync()
{
    current_time := getMonotonicTime();

    if (current_time - previous_broadcast_timestamp < MIN_PUBLICATION_PERIOD)
    {
        return;     // Rate limiting
    }

    if (current_time - previous_broadcast_timestamp > MAX_PUBLICATION_PERIOD)
    {
        for (i := 0; i < NUM_IFACES; i++)
        {
            previous_tx_timestamp[i] := 0;
        }
    }

    previous_broadcast_timestamp := current_time;

    message := uavcan.protocol.GlobalTimeSync();

    for (i := 0; i < NUM_IFACES; i++)
    {
        message.previous_transmission_timestamp_usec := previous_tx_timestamp[i];
        previous_tx_timestamp[i] := 0;
        broadcastMessage(transfer_id, i, message);
    }

    transfer_id++; // Overflow must be handled correctly
}
```

--- chunk_id: chunk-0158
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 626
content_hash: 7008065ba97ecd21
prev_chunk_id: chunk-0157
next_chunk_id: chunk-0159
section_heading: Node discovery
document_type: specification

### Master

The following pseudocode describes the logic of a time synchronization master. ```cpp
// State variables:
transfer_id := 0;
previous_tx_timestamp[NUM_IFACES];
previous_broadcast_timestamp;

// This function broadcasts a message with a specified Transfer ID using only one iface:
function broadcastMessage(transfer_id, iface_index, msg);

// This function returns the current value of a monotonic clock (the clock that doesn't change phase or rate)
function getMonotonicTime();

// This callback is invoked when the CAN driver completes transmission of a time sync message
// The tx_timestamp argument contains the exact timestamp when the CAN frame was delivered to the bus
function messageTxTimestampCallback(iface_index, tx_timestamp)
{
    previous_tx_timestamp[iface_index] := tx_timestamp;
}

// Publishes the message of type uavcan.protocol.GlobalTimeSync to each available interface
function broadcastTimeSync()
{
    current_time := getMonotonicTime();

    if (current_time - previous_broadcast_timestamp < MIN_PUBLICATION_PERIOD)
    {
        return;     // Rate limiting
    }

    if (current_time - previous_broadcast_timestamp > MAX_PUBLICATION_PERIOD)
    {
        for (i := 0; i < NUM_IFACES; i++)
        {
            previous_tx_timestamp[i] := 0;
        }
    }

    previous_broadcast_timestamp := current_time;

    message := uavcan.protocol.GlobalTimeSync();

    for (i := 0; i < NUM_IFACES; i++)
    {
        message.previous_transmission_timestamp_usec := previous_tx_timestamp[i];
        previous_tx_timestamp[i] := 0;
        broadcastMessage(transfer_id, i, message);
    }

    transfer_id++; // Overflow must be handled correctly
}
``` ### Slave

The following pseudocode describes the logic of a time synchronization slave. ```cpp
// State variables:
previous_rx_real_timestamp := 0;               // This time is being synchronized
previous_rx_monotonic_timestamp := 0;     // This is the monotonic time (doesn't jump or change rate)
previous_transfer_id := 0;
state := STATE_UPDATE;       // STATE_UPDATE, STATE_ADJUST
master_node_id := -1;        // Invalid value
iface_index := -1;           // Invalid value

// This function performs local clock adjustment:
function adjustLocalTime(phase_error);

function adjust(message)
{
    // Clock adjustment will be performed every second message
    local_time_phase_error := previous_rx_real_timestamp - msg.previous_transmission_timestamp_usec;
    adjustLocalTime(local_time_phase_error);
    state := STATE_UPDATE;
}

function update(message)
{
    // Message is assumed to have two timestamps:
    //   Real - sampled from the clock that is being synchronized
    //   Monotonic - clock that never jumps and never changes rate
    previous_rx_real_timestamp := message.rx_real_timestamp;
    previous_rx_monotonic_timestamp := message.rx_monotonic_timestamp;
    master_node_id := message.source_node_id;
    iface_index := message.iface_index;
    previous_transfer_id := message.transfer_id;
    state := STATE_ADJUST;
}

// Accepts the message of type uavcan.protocol.GlobalTimeSync (please refer to the DSDL definition)
function handleReceivedTimeSyncMessage(message)
{
    time_since_previous_msg := message.monotonic_timestamp - previous_rx_monotonic_timestamp;

    // Resolving the state flags:
    needs_init := (master_node_id < 0) or (iface_index < 0);
    switch_master := message.source_node_id < master_node_id;
    publisher_timed_out := time_since_previous_msg > PUBLISHER_TIMEOUT;

    if (needs_init or switch_master or publisher_timed_out)
    {
        update(message);
    }
    else if ((message.iface_index == iface_index) and (message.source_node_id == master_node_id))
    {
        // Revert the state to STATE_UPDATE if needed
        if (state == STATE_ADJUST)
        {
            msg_invalid := message.previous_transmission_timestamp_usec == 0;
            wrong_tid := message.transfer_id != (previous_transfer_id + 1);    // Overflow must be handled correctly
            wrong_timing := time_since_previous_msg > MAX_PUBLICATION_PERIOD;
            if (msg_invalid or wrong_tid or wrong_timing)
            {
                state := STATE_UPDATE;
            }
        }
        // Handle the current state
        if (state == STATE_ADJUST)
        {
            adjust(message);
        }
        else
        {
            update(message);
        }
    }
    else
    {
        ; // Ignore this message
    }
}
```

--- chunk_id: chunk-0159
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 384
content_hash: 945c688f6c87f7f0
prev_chunk_id: chunk-0158
next_chunk_id: chunk-0160
section_heading: Node discovery
document_type: specification

### Slave

The following pseudocode describes the logic of a time synchronization slave. ```cpp
// State variables:
previous_rx_real_timestamp := 0;               // This time is being synchronized
previous_rx_monotonic_timestamp := 0;     // This is the monotonic time (doesn't jump or change rate)
previous_transfer_id := 0;
state := STATE_UPDATE;       // STATE_UPDATE, STATE_ADJUST
master_node_id := -1;        // Invalid value
iface_index := -1;           // Invalid value

// This function performs local clock adjustment:
function adjustLocalTime(phase_error);

function adjust(message)
{
    // Clock adjustment will be performed every second message
    local_time_phase_error := previous_rx_real_timestamp - msg.previous_transmission_timestamp_usec;
    adjustLocalTime(local_time_phase_error);
    state := STATE_UPDATE;
}

function update(message)
{
    // Message is assumed to have two timestamps:
    //   Real - sampled from the clock that is being synchronized
    //   Monotonic - clock that never jumps and never changes rate
    previous_rx_real_timestamp := message.rx_real_timestamp;
    previous_rx_monotonic_timestamp := message.rx_monotonic_timestamp;
    master_node_id := message.source_node_id;
    iface_index := message.iface_index;
    previous_transfer_id := message.transfer_id;
    state := STATE_ADJUST;
}

// Accepts the message of type uavcan.protocol.GlobalTimeSync (please refer to the DSDL definition)
function handleReceivedTimeSyncMessage(message)
{
    time_since_previous_msg := message.monotonic_timestamp - previous_rx_monotonic_timestamp;

    // Resolving the state flags:
    needs_init := (master_node_id < 0) or (iface_index < 0);
    switch_master := message.source_node_id < master_node_id;
    publisher_timed_out := time_since_previous_msg > PUBLISHER_TIMEOUT;

    if (needs_init or switch_master or publisher_timed_out)
    {
        update(message);
    }
    else if ((message.iface_index == iface_index) and (message.source_node_id == master_node_id))
    {
        // Revert the state to STATE_UPDATE if needed
        if (state == STATE_ADJUST)
        {
            msg_invalid := message.previous_transmission_timestamp_usec == 0;
            wrong_tid := message.transfer_id != (previous_transfer_id + 1);    // Overflow must be handled correctly
            wrong_timing := time_since_previous_msg > MAX_PUBLICATION_PERIOD;
            if (msg_invalid or wrong_tid or wrong_timing)
            {
                state := STATE_UPDATE;
            }
        }
        // Handle the current state
        if (state == STATE_ADJUST)
        {
            adjust(message);
        }
        else
        {
            update(message);
        }
    }
    else
    {
        ; // Ignore this message
    }
}
``` {% include dsdl.md prefix='uavcan.protocol.GlobalTimeSync' %}

--- chunk_id: chunk-0160
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 452
content_hash: d47e331024452beb
prev_chunk_id: chunk-0159
next_chunk_id: chunk-0161
section_heading: Node configuration
document_type: specification

## Node configuration

DroneCAN defines standard services for management of remote node's configuration parameters. Support for these services is not mandatory but is highly recommended. The services are as follows:

* `uavcan.protocol.param.GetSet` - gets or sets a single configuration parameter value, either by name or by index. * `uavcan.protocol.param.ExecuteOpcode` - allows control of the node configuration,
including saving the configuration into the non-volatile memory, or resetting the configuration to default settings. * `uavcan.protocol.RestartNode` - restarts a node remotely. Some nodes may require a restart before new configuration parameters can be applied. In some cases, a node may require more complex configuration than can be conveniently managed via these services. If this is the case, the recommendation is to manage the node's configuration through configuration files accessible via
the standard file management services (documented in this section). {% include dsdl.md prefix='uavcan.protocol.param.' %}

### Standard configuration parameters

There are some configuration parameters that are common for most DroneCAN nodes. Examples of such common parameters include message publication frequencies, non-default data type ID settings,
local node ID, etc. The DroneCAN specification improves compatibility by providing the following naming
conventions for DroneCAN-related configuration parameters. Following these conventions is highly encouraged, but not mandatory. As can be seen below, all standard DroneCAN-related parameters share the same prefix `uavcan.`. #### Data type ID

Parameter name: `uavcan.dtid-X`, where **X** stands for the full data type name, e.g. `uavcan.dtid-uavcan.protocol.NodeStatus`. This parameter configures the data type ID value for a given data type. #### Message publication period

Parameter name: `uavcan.pubp-X`, where **X** stands for the full data type name; e.g. `uavcan.pubp-uavcan.protocol.NodeStatus`. This parameter configures the publication period for a given data type, in integer number of microseconds. Zero value means that publication should be disabled. #### Transfer priority

Parameter name: `uavcan.prio-X`, where **X** stands for the full data type name, e.g. `uavcan.prio-uavcan.protocol.NodeStatus`. This parameter configures the transport priority level that will be used when publishing messages or
calling services of a given data type. #### Node ID

Parameter name: `uavcan.node_id`. This parameter configures ID of the local node.

--- chunk_id: chunk-0161
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 382
content_hash: 4b0b5f5e14e9d0f4
prev_chunk_id: chunk-0160
next_chunk_id: chunk-0162
section_heading: Node configuration
document_type: specification

#### Node ID

Parameter name: `uavcan.node_id`. This parameter configures ID of the local node. Zero means that the node ID is unconfigured, which may prompt the node to resort to dynamic node ID
allocation after startup. #### CAN bus bit rate

Parameter name: `uavcan.bit_rate`. This parameter configures CAN bus bit rate. Zero value should trigger automatic bit rate detection, which should be the default option. Please refer to the hardware design recommendations for recommended values and other details. #### Instance ID

Parameter name: `uavcan.id-X-Y`, where **X** is namespace name; **Y** is ID field name. Some DroneCAN messages (standard and possibly vendor-specific ones) use special fields that identify the instance of
a certain function - *ID fields*. For example, messages related to actuator control use fields named `actuator_id`,
some sensor messages use fields named `sensor_id`, etc. In order to improve compatibility, the specification offers a naming convention for parameters that define the
values used in ID fields. Given messages located in the namespace **X** that share an ID field named **Y**,
the corresponding parameter name would be `uavcan.id-X-Y`. For example, the parameter for the field `esc_index` that is used in the message `uavcan.equipment.esc.Status`
and that defines the array index in `uavcan.equipment.esc.RawCommand`, will be named as follows:

    uavcan.id-uavcan.equipment.esc-esc_index

In the case that an ID field is shared across different namespaces,
then the most common outer shared namespace should be used as **X**. This is not the case for any of the standard messages, so an example cannot be provided. In the case that an ID field is used in the standard namespace (`uavcan.*`) and in some vendor-specific namespaces
at the same time, the prefix should be used as though the ID field was used only in the standard namespace.

--- chunk_id: chunk-0162
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 318
content_hash: 317175e49bdf2362
prev_chunk_id: chunk-0161
next_chunk_id: chunk-0163
section_heading: File transfer
document_type: specification

## File transfer

File transfer is a very generic feature of DroneCAN, that allows access to the file system on remote nodes. The feature is based upon a set of DroneCAN services that are listed below. ### Firmware update

In terms of DroneCAN, firmware update is a special case of file transfer. The process of firmware update involves two or three nodes:

* The node that initiates the process of firmware update, or *updater*. * The node that provides access to the firmware file, or *file server*. In most cases, the updater will be acting as a file server and only two nodes are involved. * The node that is being updated, or *updatee*. The process can be described as follows:

1. The updater decides that a certain node (the *updatee*) should be updated. 2. The updater invokes the service `uavcan.protocol.file.BeginFirmwareUpdate` on the updatee. The information about the location of the firmware file will be passed to the updatee via the service request. 3. If the updatee chooses to accept the update request, it performs initialization procedures as required by its
implementation (e.g., rebooting into the bootloader, etc). 4. The updatee receives new firmware file from the file server using information received via the service request above. 5. The updatee completes the update and restarts. Typically, the updatee will also resort to the dynamic node ID allocation process,
which is documented in this section. {% include dsdl.md prefix='uavcan.protocol.file.' %}

--- chunk_id: chunk-0163
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 438
content_hash: 069b161637a3e9c3
prev_chunk_id: chunk-0162
next_chunk_id: chunk-0164
section_heading: Debug features
document_type: specification

## Debug features

The following messages are designed to facilitate debugging and to provide means of reporting events in
a human-readable representation. {% include dsdl.md prefix='uavcan.protocol.debug.' %}

### Command shell access
The following service allows execution of arbitrary commands on a remote node via direct access to its
internal command shell. {% include dsdl.md prefix='uavcan.protocol.AccessCommandShell' %}

### Panic mode
The panic message allows the broadcaster to quickly shut down the system in the event of an emergency. {% include dsdl.md prefix='uavcan.protocol.Panic' %}

### Dynamic node ID allocation
In order to be able to operate in a DroneCAN network, a node must have a node ID that is unique within the network. Typically, a valid node ID can be configured manually for each node; however, in certain use cases the manual
approach is either undesirable or impossible, therefore DroneCAN defines the high-level feature of dynamic node ID
allocation, that allows nodes to obtain a node ID value automatically upon connection to the network. Dynamic node ID allocation combined with automatic CAN bus bit rate detection makes it easy to
implement nodes that can join any DroneCAN network without any manual configuration. These sorts of nodes are referred to as *plug-and-play nodes*. A dynamically allocated node ID cannot be persistent. This means that if a node is configured to use a dynamic node ID,
it *must* perform a new allocation every time it starts or reboots. The process of dynamic node ID allocation always involves two types of nodes: *allocators*, which serve
allocation requests; and *allocatees*, which request dynamic node ID from allocators. A DroneCAN network may implement the following configurations of allocators:

* Zero allocators, in which case the feature of dynamic node ID allocation will not be available. * One allocator, in which case the feature of dynamic node ID allocation will become unavailable if the allocator fails. In this configuration, the role of the allocator can be performed even by a very
resource-constrained system, e.g. a low-end microcontroller.

--- chunk_id: chunk-0164
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 426
content_hash: 125b05b16da39afc
prev_chunk_id: chunk-0163
next_chunk_id: chunk-0165
section_heading: Debug features
document_type: specification

In this configuration, the role of the allocator can be performed even by a very
resource-constrained system, e.g. a low-end microcontroller. * Three allocators, in which case the allocators will be using a replicated state via a distributed consensus
algorithm. In this configuration, the network can tolerate the loss of one allocator and continue to serve allocation
requests. This configuration requires that the allocators to maintain large data structures for the purposes of the
distributed consensus algorithm, and may therefore require a slightly more sophisticated computational platform,
e.g. a high-end microcontroller. * Five allocators, is the same as the three allocator configuration except that the network can tolerate the loss of two
allocators and still continue to serve allocation requests. In order to get a dynamic node ID, each allocatee must have a globally unique 128-bit integer identifier,
known as *unique ID*. This is the same value that is used in the field `unique_id` of the data type `uavcan.protocol.HardwareVersion`. Every node that requires a dynamic ID allocation must support the service `uavcan.protocol.GetNodeInfo`,
and the nodes must use the same unique ID value during dynamic node ID allocation
and when responding to `uavcan.protocol.GetNodeInfo` requests. During dynamic allocation, the allocatee communicates its unique ID to the allocator (or allocators),
which then use it to produce an appropriate allocation response. Unique ID values are kept by allocators in *allocation tables* -
data structures that contain mappings between unique ID and corresponding node ID values. Allocation tables are write-only data structures that can only grow. Once a new allocatee has requested a node ID,
its unique ID will be recorded into the allocation table,
and all subsequent allocation requests from the same allocatee will be served with the same node ID value. In configurations with redundant allocators, every allocator maintains a replica of the same allocation table
(a DroneCAN network cannot contain more than one allocation table, regardless of the number of allocators employed).

--- chunk_id: chunk-0165
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: 486ada51d53e137e
prev_chunk_id: chunk-0164
next_chunk_id: chunk-0166
section_heading: Debug features
document_type: specification

Once a new allocatee has requested a node ID,
its unique ID will be recorded into the allocation table,
and all subsequent allocation requests from the same allocatee will be served with the same node ID value. In configurations with redundant allocators, every allocator maintains a replica of the same allocation table
(a DroneCAN network cannot contain more than one allocation table, regardless of the number of allocators employed). While the allocation table is write-only data structure that can only grow,
it is still possible to wipe the table completely, forcing the allocators to
forget known nodes and perform all following allocations anew. In the context of this chapter, nodes that are using dynamic node ID will be referred to as *dynamic nodes*, and
nodes that are using manually-configured node ID will be referred to as *static nodes*. It is assumed that in most cases, allocators will be static nodes themselves (since there's no other authority on the
network that can grant dynamic node ID, allocators will not be able to dynamically allocate themselves). Excepting allocators, it is not recommended to mix dynamic and static nodes on the same network; i.e.,
normally, a DroneCAN network should contain either all static nodes, or all dynamic nodes (except allocators). In case if this recommendation cannot be followed,
the following rules of safe co-existence of dynamic nodes with static nodes must be considered:

1. It is safe to connect dynamic nodes to the bus at any time. 2. A static node can be connected to the bus if the allocator (allocators) is (are) already aware of them,
i.e. these static nodes are already in the allocation table. 3. A new static node (i.e. a node that does not meet the above condition) can be connected to the bus only if:
   1. New dynamic allocations are not happening at the moment. 2. The allocators are capable of serving new allocations.

--- chunk_id: chunk-0166
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 402
content_hash: b3918e21ea7027be
prev_chunk_id: chunk-0165
next_chunk_id: chunk-0167
section_heading: Debug features
document_type: specification

2. The allocators are capable of serving new allocations. As can be inferred from the above, the process of dynamic node ID allocation involves up to two types of
communications:

* *Allocatee-allocator* - this communication is used when an allocatee requests a dynamic node ID from the allocator
(allocators), and when the allocator (allocators) transmits a response back to the allocatee. This communication is invariant to the allocator configuration used, i.e., the allocatees are not aware of
how many allocators are available on the network and how they are configured. * *Allocator-allocator* - this communication is used by allocators for the purpose of maintenance of the
replicated allocation table and for other needs of the distributed consensus algorithm. Allocatees are completely
isolated and unaware of these exchanges. This communication is not applicable for the single-allocator configuration. ### Allocatee-allocator exchanges

Allocatee-allocator exchanges are performed using only one message type -
`uavcan.protocol.dynamic_node_id.Allocation`. Allocators use it with regular message broadcast transfers; allocatees use it with anonymous message transfers. The specification and usage info for this data type is provided below. The general idea of the allocatee-allocator exchanges is that the allocatee communicates to the allocator its
unique ID and, if applicable, the preferred node ID value, using anonymous message transfers of type
`uavcan.protocol.dynamic_node_id.Allocation`. The allocator performs the allocation and sends a response using the same message type, where the field for
unique ID is populated with the unique ID of the requesting node and the field for node ID is populated with the
allocated node ID. Note that since the allocator that serves the allocation always has a node ID, it is free to use multi-frame transfers,
therefore the allocator can directly send the response using a single message transfer. The allocatees, however, are restricted to single-frame transfers, due to limitations of anonymous message transfers.

--- chunk_id: chunk-0167
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 789
content_hash: b7f8508d889180a1
prev_chunk_id: chunk-0166
next_chunk_id: chunk-0168
section_heading: Debug features
document_type: specification

Note that since the allocator that serves the allocation always has a node ID, it is free to use multi-frame transfers,
therefore the allocator can directly send the response using a single message transfer. The allocatees, however, are restricted to single-frame transfers, due to limitations of anonymous message transfers. Therefore, the allocatees send their unique ID to the allocator using three single-frame transfers, where the first
transfer contains the first part of their unique ID, second transfer contains the continuation, and the last transfer
contains the last few bytes of the unique ID. The details are provided in the DSDL description of the message type. The specification of the data type contains a description of the exchange protocol on the side of allocatee. On the allocator's side the algorithm should be implemented as shown in the following pseudocode. Please note that the pseudocode refers to a function named `canPublishFollowupAllocationResponse()`,
which is only applicable in the case of a redundant allocator configuration. It evaluates the current state of the distributed consensus and decides whether the current node
is allowed to engage in allocation exchanges. The logic of this function will be reviewed in the chapter dedicated to redundant allocators. In the non-redundant allocator configuration, this function will always return true,
meaning that the allocator is always allowed to engage in allocation exchanges. ```cpp
// Constants:
InvalidStage = 0;

// State variables:
last_message_timestamp;
current_unique_id;

// This function will be invoked when a complete unique ID is received.
// Typically, the actual allocation will be carried out in this function.
function handleAllocationRequest(unique_id, preferred_node_id);

// This function is only applicable in a configuration with redundant allocators.
// Its return value depends on the current state of the distributed consensus algorithm.
// Please refer to the allocator-allocator communication logic for details.
// In the non-redundant configuration this function will always return true.
function canPublishFollowupAllocationResponse();

// This is an internal function; see below.
function detectRequestStage(msg)
{
    if ((msg.unique_id.size() != MAX_LENGTH_OF_UNIQUE_ID_IN_REQUEST) &&
        (msg.unique_id.size() != (msg.unique_id.capacity() - MAX_LENGTH_OF_UNIQUE_ID_IN_REQUEST * 2U)) &&
        (msg.unique_id.size() != msg.unique_id.capacity()))     // For CAN FD
    {
        return InvalidStage;
    }
    if (msg.first_part_of_unique_id)
    {
        return 1;       // Note that CAN FD frames can deliver the unique ID in one stage!
    }
    if (msg.unique_id.size() == MAX_LENGTH_OF_UNIQUE_ID_IN_REQUEST)
    {
        return 2;
    }
    if (msg.unique_id.size() < MAX_LENGTH_OF_UNIQUE_ID_IN_REQUEST)
    {
        return 3;
    }
    return InvalidStage;
}

// This is an internal function; see below.
function getExpectedStage()
{
    if (current_unique_id.empty())
    {
        return 1;
    }
    if (current_unique_id.size() >= (MAX_LENGTH_OF_UNIQUE_ID_IN_REQUEST * 2))
    {
        return 3;
    }
    if (current_unique_id.size() >= MAX_LENGTH_OF_UNIQUE_ID_IN_REQUEST)
    {
        return 2;
    }
    return InvalidStage;
}

// This function is invoked when the allocator receives a message of type uavcan.protocol.dynamic_node_id.Allocation.
function handleAllocation(msg)
{
    if (!msg.isAnonymousTransfer())
    {
        return;         // This is a response from another allocator, ignore
    }

    // Reset the expected stage on timeout
    if (msg.getMonotonicTimestamp() > (last_message_timestamp + FOLLOWUP_TIMEOUT))
    {
        current_unique_id.clear();
    }

    // Checking if request stage matches the expected stage
    request_stage = detectRequestStage(msg);
    if (request_stage == InvalidStage)
    {
        return;             // Malformed request - ignore without resetting
    }

    if (request_stage != getExpectedStage())
    {
        return;             // Ignore - stage mismatch
    }

    if (msg.unique_id.size() > current_unique_id.capacity() - current_unique_id.size())
    {
        return;             // Malformed request
    }

    // Updating the local state
    for (i = 0; i < msg.unique_id.size(); i++)
    {
        current_unique_id.push_back(msg.unique_id[i]);
    }

    if (current_unique_id.size() == current_unique_id.capacity())
    {
        // Proceeding with allocation.
        handleAllocationRequest(current_unique_id, msg.node_id);
        current_unique_id.clear();
    }
    else
    {
        // Publishing the follow-up if possible.
        if (canPublishFollowupAllocationResponse())
        {
            msg = uavcan.protocol.dynamic_node_id.Allocation();
            msg.unique_id = current_unique_id;
            broadcast(msg);
        }
        else
        {
            current_unique_id.clear();
        }
    }

    // It is important to update the timestamp only if the request has been processed successfully.
    last_message_timestamp = msg.getMonotonicTimestamp();
}
```

--- chunk_id: chunk-0168
source_document: Specification__6._Application_level_functions.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 3516
content_hash: 86cd765f71e8fbc3
prev_chunk_id: chunk-0167
next_chunk_id: chunk-0169
section_heading: Debug features
document_type: specification

{% include dsdl.md prefix='uavcan.protocol.dynamic_node_id.Allocation' header_prefix='####' %}

The following diagram may aid understanding of the allocatee side of the algorithm (click to enlarge):

{% include lightbox.html url="/Specification/figures/dynamic_node_id_allocatee_algorithm.svg" title="Dynamic node ID allocation algorithm" maxwidth="75%" %}

#### Example

The following log provides a real-world example of a dynamic node ID allocation process:

    Time   CAN ID     CAN data field
    1.117  1EEE8100   01 44 C0 8B 63 5E 05 C0
    1.117  1E000101   00 44 C0 8B 63 5E 05 C0
    1.406  1EEBE500   00 F4 BC 10 96 DF 11 C1
    1.406  1E000101   05 B0 00 44 C0 8B 63 81
    1.406  1E000101   5E 05 F4 BC 10 96 DF 21
    1.406  1E000101   11 41
    1.485  1E41E100   00 A8 BA 54 47 C2
    1.485  1E000101   29 BA FA 44 C0 8B 63 82
    1.485  1E000101   5E 05 F4 BC 10 96 DF 22
    1.485  1E000101   11 A8 BA 54 47 42

First, the allocatee waits for a random time interval in order to ensure that other allocations are not happening
at the moment.
After the delay, the allocatee announces its intention to get a node ID allocation by broadcasting the
following anonymous message:

    1.117  1EEE8100   01 44 C0 8B 63 5E 05 C0

The allocator responds immediately with confirmation:

    1.117  1E000101   00 44 C0 8B 63 5E 05 C0

The allocatee waits for another random time interval in order to ensure that it will not conflict with
other nodes that have unique node ID with the same first six bytes.
After the delay, the allocatee sends the second-stage request:

    1.406  1EEBE500   00 F4 BC 10 96 DF 11 C1

The allocator responds immediately with confirmation.
This time, the confirmation contains 12 bytes of unique ID, so it doesn't fit one CAN frame,
therefore the allocator resorts to a multi-frame transfer:

    1.406  1E000101   05 B0 00 44 C0 8B 63 81
    1.406  1E000101   5E 05 F4 BC 10 96 DF 21
    1.406  1E000101   11 41

The allocatee waits for another random time interval in order to ensure that it will not conflict with
other nodes that have unique node ID with the same first twelve bytes.
After the delay, the allocatee sends the third-stage request:

    1.485  1E41E100   00 A8 BA 54 47 C2

At this moment the allocator has received full unique ID and the preferred node ID of the allocatee as well.
The allocator can carry out the actual allocation and send a response:

    1.485  1E000101   29 BA FA 44 C0 8B 63 82
    1.485  1E000101   5E 05 F4 BC 10 96 DF 22
    1.485  1E000101   11 A8 BA 54 47 42

This completes the process.
Next time the allocatee sends an allocation request, it will be provided with the same node ID.

The values used in the example above were the following:

Name                | Value
--------------------|--------------------------------------------------------------------------------------------------
Unique ID           | `44 C0 8B 63 5E 05 F4 BC 10 96 DF 11 A8 BA 54 47` (hex)
Preferred node ID   | 0 (any)
Allocated node ID   | 125

### Non-redundant allocator

DroneCAN does not impose specific requirements to the implementation of a non-redundant allocator,
except its duties listed below.

#### Duties of the allocator

The allocator is tasked with monitoring the nodes present in the network.
When a new node appears, the allocator must invoke `uavcan.protocol.GetNodeInfo` on it,
and check the received unique ID against the allocation table.
If a matching entry is not found in the table, the allocator will create one.
If the node failed to respond to `uavcan.protocol.GetNodeInfo` after at least 3 attempts,
the allocator will extend the allocation table with a *mock entry*,
where the node ID is matching the real node ID of the non-responding node, and unique ID is set to zero.
This ensures that dynamic nodes will not be granted a node ID value that is already taken by a static node.
This requirement demonstrates why is it mandatory that dynamic nodes use the same unique ID
both when responding to `uavcan.protocol.GetNodeInfo` and when publishing allocation requests.

### Redundant allocators

The algorithm used for replication of the allocation table across redundant allocators is a fairly direct
implementation of the [Raft consensus algorithm](https://raft.github.io/), as published in the paper
"In Search of an Understandable Consensus Algorithm (Extended Version)" (Diego Ongaro and John Ousterhout).
The following text assumes that the reader is familiar with the paper.

#### Raft log

The *Raft log* contains entries of type `uavcan.protocol.dynamic_node_id.server.Entry` (defined below),
where every entry contains Raft term number, unique ID, and the matching node ID value.
Therefore, the raft log is the allocation table itself.

Since the maximum number of entries in the allocation table is limited by the range of node ID,
the log cannot contain more than 127 entries.
Therefore, snapshot transfer and log compaction are not required, so they are not implemented in the algorithm.

When a server becomes the leader, it checks if the Raft log contains an entry for its own unique ID, and if it doesn't,
the leader adds its own allocation entry to the log.
This feature guarantees that the raft log always contains at least one entry,
therefore it is not necessary to support negative log indices, as proposed by the Raft paper.

Since the log is write-only and limited in growth, all allocations are permanent.
This restriction is acceptable, since DroneCAN is a vehicle bus, and configuration of vehicle's components is not
expected to change frequently.
Old allocations can be removed in order to free node IDs for new allocations, by clearing the Raft log
on all allocators.

#### Cluster configuration

The allocators need to be aware of each other's node ID in order to form a cluster.
In order to learn each other's node ID values, the allocators broadcast messages of type
`uavcan.protocol.dynamic_node_id.server.Discovery` (defined below) until the cluster is fully discovered.

This extension to the Raft algorithm makes the cluster almost configuration-free - the only parameter that must be
configured on all servers of the cluster is the number of nodes in the cluster (everything else will be auto-detected).

Runtime cluster membership changes are not supported, since they are not needed for a vehicle bus.

#### Duties of the leader

The leader is tasked with monitoring the nodes present in the network.
Please refer to the section dedicated to duties of a non-redundant allocator for details.

Only the leader can process allocation requests and engage in communication with allocatees.
An allocator is allowed to send allocation responses only if both conditions are met:

* The allocator is a leader.
* Its replica of the Raft log does not contain uncommitted entries
(i.e. the last allocation request has been completed successfully).

The second condition needs to be explained by an example.

Consider a case with two Raft nodes that are residing in different network partitions,
unable to communicate with each other - **A** and **B**, both of them are leaders;
**A** can commit to the log, and **B** is in a minor partition.
Then there is an allocatee **X** that can exchange with both leaders,
and an allocatee **Y** that can exchange only with **A**.
Such a situation can occur as a result of a specific failure mode of redundant interfaces.

Both allocatees **X** and **Y** initially send first-stage allocation requests;
**A** responds to **Y** with a first-stage response, whereas **B** responds to **X**.
Both **X** and **Y** will issue follow-up requests,
which may cause **A** to mix allocation requests from different nodes,
leading to reception of an invalid unique ID.
When both leaders receive full unique ID values
(**A** will receive an invalid one, and **B** will receive a valid unique ID of **X**),
only **A** will be able to make a commit, because **B** is in a minor partition.
Since both allocatees were unable to receive node ID values in this round, they will retry later.

Now, in order to prevent **B** from disrupting allocatee-allocator communication again,
we introduce this second restriction:
an allocator cannot exchange with allocatees as long as its log contains uncommitted entries.

Note that this restriction does not apply to allocation requests sent via CAN FD frames
as these allow larger frames such that all necessary information to be exchanged in a single request and response.
Only CAN FD can offer perfectly reliable allocation exchanges.

{% include dsdl.md prefix='uavcan.protocol.dynamic_node_id.server' header_prefix='####' %}

#### Example

The following log demonstrates relevant messages that were transferred over the CAN bus in the process of
a dynamic node ID allocation for one allocatee, where the allocators were running a three-node Raft cluster.
All node status messages were removed for clarity.

The configuration was as follows:

Name                            | Value
--------------------------------|--------------------------------------------------------------------------------------
Number of allocators            | 3
Allocators' node ID             | 1, 2, 3
Leader's node ID                | 1
Allocatee's unique ID           | `44 C0 8B 63 5E 05 F4 BC 83 3B 3A 88 1C 43 60 50` (hex)
Preferred node ID               | 0 (any)
Allocated node ID               | 125
Discovery broadcasting interval | 1 second
AppendEntries interval          | 1 second per follower


    Time   CAN ID     CAN data field
    0.000  1E018601   03 01 C0
    0.512  1E018602   03 02 01 C0
    0.905  1E018603   03 03 01 02 C0
    1.000  1E018601   03 01 02 03 C1
    1.512  1E018602   03 02 01 03 C1
    <cluster maintenance traffic omitted for clarity>
    2.569  1EEE8100   01 44 C0 8B 63 5E 05 C0
    2.569  1E000101   00 44 C0 8B 63 5E 05 C0
    2.684  1E238D00   00 F4 BC 83 3B 3A 88 C1
    2.684  1E000101   5C EF 00 44 C0 8B 63 81
    2.684  1E000101   5E 05 F4 BC 83 3B 3A 21
    2.684  1E000101   88 41
    2.756  1E1E8381   5F CF 2E 00 00 00 04 85
    2.756  1E1E8381   00 00 00 05 05 65
    2.756  1E1E0183   2E 00 00 00 80 C5
    2.871  1E63ED00   00 1C 43 60 50 C2
    3.256  1E1E8281   9C 38 2E 00 00 00 04 87
    3.256  1E1E8281   00 00 00 05 05 2E 00 27
    3.256  1E1E8281   00 00 44 C0 8B 63 5E 07
    3.256  1E1E8281   05 F4 BC 83 3B 3A 88 27
    3.256  1E1E8281   1C 43 60 50 7D 47
    3.258  1E1E0182   2E 00 00 00 80 C7
    3.563  1E2F0D00   01 44 C0 8B 63 5E 05 C3
    3.756  1E1E8381   9C 38 2E 00 00 00 04 86
    3.756  1E1E8381   00 00 00 05 05 2E 00 26
    3.756  1E1E8381   00 00 44 C0 8B 63 5E 06
    3.756  1E1E8381   05 F4 BC 83 3B 3A 88 26
    3.756  1E1E8381   1C 43 60 50 7D 46
    3.756  1E000101   C7 36 FA 44 C0 8B 63 82
    3.756  1E000101   5E 05 F4 BC 83 3B 3A 22
    3.756  1E000101   88 1C 43 60 50 42
    3.758  1E1E0183   2E 00 00 00 80 C6
    4.256  1E1E8281   65 19 2E 00 00 00 2E 88
    4.256  1E1E8281   00 00 00 06 06 68
    4.256  1E1E0182   2E 00 00 00 80 C8
    4.756  1E1E8381   65 19 2E 00 00 00 2E 87
    4.756  1E1E8381   00 00 00 06 06 67
    4.756  1E1E0183   2E 00 00 00 80 C7

Once the first node of the cluster has been started,
it has published a cluster discovery message so it could become aware of its siblings,
and other two nodes that were started a fraction of a second later did the same:

    0.000  1E018601   03 01 C0

    0.512  1E018602   03 02 01 C0

    0.905  1E018603   03 03 01 02 C0

    1.000  1E018601   03 01 02 03 C1

    1.512  1E018602   03 02 01 03 C1

It can be seen that the last two discovery messages contain complete list of all nodes in the cluster.
The allocators have detected the fact that all nodes in the cluster were now aware of each other,
and ceased to broadcast discovery messages in order to not pollute the bus with redundant traffic.

Afterwards, the allocators ran elections and have elected the node 1 as their leader.
The leader then performed a few AppendEntries calls in order to synchronize the replicated log.
These exchanges are not shown for the sake of clarity.

The allocatee has appeared on the bus and has published first-stage and second-stage allocation requests.
The current leader was in charge with communicating with allocatee, other two allocators were silent:

    2.569  1EEE8100   01 44 C0 8B 63 5E 05 C0   <-- First stage request

    2.569  1E000101   00 44 C0 8B 63 5E 05 C0   <-- First stage response

    2.684  1E238D00   00 F4 BC 83 3B 3A 88 C1   <-- Second stage request

    2.684  1E000101   5C EF 00 44 C0 8B 63 81   <-- Second stage response
    2.684  1E000101   5E 05 F4 BC 83 3B 3A 21
    2.684  1E000101   88 41

While the allocatee was waiting for expiration of the random timeout,
the leader has performed a keep-alive AppendEntries call to the allocator 3:

    2.756  1E1E8381   5F CF 2E 00 00 00 04 85   <-- Empty AppendEntries request
    2.756  1E1E8381   00 00 00 05 05 65

    2.756  1E1E0183   2E 00 00 00 80 C5         <-- AppendEntries response

Then the allocatee has broadcasted the third-stage allocation request:

    2.871  1E63ED00   00 1C 43 60 50 C2

At this point the leader had the full unique ID of the allocatee,
so it has started the process of allocation and log replication.
In order to complete the allocation, the leader had to replicate the new entry of the Raft log
to a majority of allocators (see the Raft paper for details):

    3.256  1E1E8281   9C 38 2E 00 00 00 04 87   <-- AppendEntries request with new allocation
    3.256  1E1E8281   00 00 00 05 05 2E 00 27
    3.256  1E1E8281   00 00 44 C0 8B 63 5E 07
    3.256  1E1E8281   05 F4 BC 83 3B 3A 88 27
    3.256  1E1E8281   1C 43 60 50 7D 47

    3.258  1E1E0182   2E 00 00 00 80 C7         <-- AppendEntries response with confirmation

It can be seen that the follower took 2 milliseconds to update its persistent storage.

While the leader was busy replicating the allocation table
(it could not complete the allocation until the new log entry was committed),
the allocatee has given up waiting for a response and decided to restart the process.
This is not an error condition, but a normal behavior.
This time the leader did not engage in communication with the allocatee,
because the Raft log contained uncommitted entries.

    3.563  1E2F0D00   01 44 C0 8B 63 5E 05 C3   <-- First stage request, no response from the leader

Some time later the leader decided to replicate the new log entry to the other follower:

    3.756  1E1E8381   9C 38 2E 00 00 00 04 86   <-- AppendEntries request with new allocation
    3.756  1E1E8381   00 00 00 05 05 2E 00 26
    3.756  1E1E8381   00 00 44 C0 8B 63 5E 06
    3.756  1E1E8381   05 F4 BC 83 3B 3A 88 26
    3.756  1E1E8381   1C 43 60 50 7D 46

Immediately afterwards, the leader has noticed that the new entry has already been replicated
to a majority of allocators, therefore (see the Raft paper) the commit index could be incremented,
which completed the allocation.
Having detected that, the leader has published the allocation response:

    3.756  1E000101   C7 36 FA 44 C0 8B 63 82
    3.756  1E000101   5E 05 F4 BC 83 3B 3A 22
    3.756  1E000101   88 1C 43 60 50 42

While the leader was engaged in communications with the allocatee,
the follower 3 has finished updating its persistent storage and responded with confirmation:

    3.758  1E1E0183   2E 00 00 00 80 C6

At this moment the process was finished.
The leader then continued to invoke keep-alive AppendEntries calls to the followers:

    4.256  1E1E8281   65 19 2E 00 00 00 2E 88   <-- Empty AppendEntries request
    4.256  1E1E8281   00 00 00 06 06 68

    4.256  1E1E0182   2E 00 00 00 80 C8         <-- AppendEntries response

    4.756  1E1E8381   65 19 2E 00 00 00 2E 87   <-- Empty AppendEntries request
    4.756  1E1E8381   00 00 00 06 06 67

    4.756  1E1E0183   2E 00 00 00 80 C7         <-- AppendEntries response

--- chunk_id: chunk-0169
source_document: Specification__7._List_of_standard_data_types.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 82
content_hash: 5a4861db14914805
prev_chunk_id: chunk-0168
next_chunk_id: chunk-0170
section_heading: List of standard data types
document_type: specification

# List of standard data types

This section lists all standard data types. Link to the repository that contains the sources of all DSDL definitions
can be found on the [contacts page](/Contact). Autogenerated {{ site.time | date_to_rfc822 }}. {% include dsdl.md split_by_namespace=true prefix='uavcan' %}
{% include dsdl.md split_by_namespace=true prefix='dronecan' %}
{% include dsdl.md split_by_namespace=true prefix='ardupilot' %}
{% include dsdl.md split_by_namespace=true prefix='com' %}

--- chunk_id: chunk-0170
source_document: Specification__8._Hardware_design_recommendations.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 44
content_hash: c03c97ea6932181b
prev_chunk_id: chunk-0169
next_chunk_id: chunk-0171
section_heading: Hardware design recommendations
document_type: specification

# Hardware design recommendations

This chapter contains best-practice recommendations for hardware design. Following these guidelines will ensure the highest level of inter-vendor compatibility
and allow the developers to avoid many common design pitfalls.

--- chunk_id: chunk-0171
source_document: Specification__8._Hardware_design_recommendations.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 452
content_hash: 3e49a71438ddd6cf
prev_chunk_id: chunk-0170
next_chunk_id: chunk-0172
section_heading: Physical connector definition
document_type: specification

## Physical connector definition

{% include lightbox.html url="/Specification/figures/connector_size_comparison.png" title="Size comparison of different DroneCAN connector types. The blue PCB is a small UAV avionic device given for scale." thumbnail=true %}

The DroneCAN standard defines several connector types, targeted towards different application domains:
from highly compact systems to large deployments, from low-cost to safety-critical applications. The following table provides an overview of the currently defined connector types. The image to the right comparatively demonstrates the size of the connector types. Other connector types may be added in future revisions of the specification. Connector name |Base connector type            |Bus power          | Known compatible standards
------------------------------------------------------------ |-------------------------------|-------------------| --------------------------------------
**<span style="white-space: nowrap;">DroneCAN D-Sub</span>** |Generic D-Subminiature DE-9    |24 V, 3 A          | De-facto standard connector for CAN, supported by many current specifications
**<span style="white-space: nowrap;">DroneCAN M8</span>** |Generic M8 5-circuit B-coded   |24 V, 3 A          | CiA 103 (CANopen)
**<span style="white-space: nowrap;">DroneCAN Micro</span>** |JST GH 4-circuit               |5 V, 1 A           | Dronecode Autopilot Connector Standard

### DroneCAN D-Sub connector

{% include lightbox.html url="/Specification/figures/de-9_connector_male_plug.jpg" title="DroneCAN D-Sub male plug connector. (https://commons.wikimedia.org/wiki/File:Serial_plug1.jpg)" thumbnail=true %}
{% include lightbox.html url="/Specification/figures/de-9_cable_female_socket.jpg" title="DroneCAN D-Sub cable with female socket connectors. (https://www.flickr.com/photos/57018633@N04/5662914060/)" thumbnail=true %}
{% include lightbox.html url="/Specification/figures/de-9_pin_numbering.png" title="DE-9 connector pin numbering." thumbnail=true %}

The DroneCAN D-Sub connector type is based upon, and compatible with, the D-Subminiature DE-9 CAN connector (this is the most popular CAN connector type, in effect the de-facto industry standard). This connector is fully compatible with CANopen and many other current specifications. #### Advantages

* Highest level of compatibility with the existing commercial off the shelf (COTS) hardware. Connectors, cables, termination plugs, and other components can be easily purchased from many different vendors. * High-reliability options are available from multiple vendors. * Low-cost options are available from multiple vendors. * PCB mounted and panel mounted types are available. #### Disadvantages

D-Subminiature connectors are the largest connector type defined by DroneCAN. Due to its significant size and weight, it may be unsuitable for many vehicular applications. #### Specification

The DroneCAN D-Sub connector is based on the industry-standard **D-Sub DE-9** (9-circuit) connector type.

--- chunk_id: chunk-0172
source_document: Specification__8._Hardware_design_recommendations.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 461
content_hash: 3ec530c032cd63fc
prev_chunk_id: chunk-0171
next_chunk_id: chunk-0173
section_heading: Physical connector definition
document_type: specification

Due to its significant size and weight, it may be unsuitable for many vehicular applications. #### Specification

The DroneCAN D-Sub connector is based on the industry-standard **D-Sub DE-9** (9-circuit) connector type. Devices are equipped with the male plug connector type (see the image) mounted on the panel or on the PCB,
and the cables are equipped with the female socket connectors on both ends. If the device uses two parallel connectors per CAN bus interface (as recommended), then all of the lines
of the paired connectors, including those that are not used by the current specification,
must be interconnected one to one. This will ensure compatibility with future revisions of the specification that make use of currently unused
circuits of the connector. The CAN physical layer standard that can be used with this connector type is
[ISO 11898-2](http://www.can-cia.org/index.php?id=systemdesign-can-physicallayer#high),
also known as high-speed CAN. Devices that deliver power to the bus are required to provide 23.0---30.0 V on the bus power line, 24 V nominal. The maximum current draw is up to 3 A per connector. Devices that are powered from the bus should expect 18.0---30.0 V on the bus power line. The maximum recommended current draw from the bus is 500 mA per device. The table below documents the pinout specification for the DroneCAN D-Sub connector type. The provided pinout, as has been indicated above, is the de-facto industry standard for the CAN bus. Note that the signals `CAN High` and `CAN Low` must belong to the same twisted pair. Usage of twisted or flat wires for all other signals remains at the discretion of the implementer. Circuit number | Function          | Note
---------------- |-------------------| ----------------------------------------------------------------------------------
1 |                   | Reserved for future use. 2 |CAN Low            | Twisted with CAN High (pin 7). 3 |CAN Ground         | Must be interconnected with Ground (pin 6) within the device. 4 |                   | Reserved for future use. 5 |CAN Shield         | Optional. 6 |Ground             | Must be interconnected with CAN Ground (pin 3) within the device. 7 |CAN High           | Twisted with CAN Low (pin 2). 8 |                   |

--- chunk_id: chunk-0173
source_document: Specification__8._Hardware_design_recommendations.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 429
content_hash: af85fe04aaea2757
prev_chunk_id: chunk-0172
next_chunk_id: chunk-0174
section_heading: Physical connector definition
document_type: specification

8 |                   | Error line, not used by DroneCAN. See CiA 303 for details. 9 |Bus power supply   | 24 V nominal. Power supply requirements are documented above. ### DroneCAN M8 connector

{% include lightbox.html url="/Specification/figures/m8_connector_male_plug.jpg" title="DroneCAN M8 male plug connector" thumbnail=true %}
{% include lightbox.html url="/Specification/figures/m8_cable_female_socket.jpg" title="DroneCAN M8 cable with female socket connectors" thumbnail=true %}

The DroneCAN M8 connector is based on the standard circular M8 B-coded 5-circuit connector type (pictured). This is a popular industry-standard connector, and there are many vendors that manufacture
compatible components: connectors, cables, termination plugs, T-connectors, and so on. The pinning, physical layer, and supply voltages used in this connector type are compatible with CiA 103 (CANopen)
and some other CAN bus standards. The M8 connector is preferred for most DroneCAN applications (it is the default choice, except when there are specific reasons to select another connector). #### Advantages

* Compatibility with existing COTS hardware. Connectors, cables, termination plugs, and other components can be purchased from many different vendors. * High-reliability options are available from multiple vendors. * Low-cost options are available from multiple vendors. * Reasonably compact. M8 connectors are much smaller than D-Sub. * PCB mounted and panel mounted types are available. #### Disadvantages

* M8 connectors may be a poor fit for applications that have severe weight and space constraints. * The level of adoption in the industry is noticeably lower than that of the D-Sub connector type. #### Specification

The DroneCAN M8 connector is based on the industry-standard **circular M8 B-coded 5-circuit** connector type. Devices are equipped with the male plug connector type (see the image) mounted on the panel or on the PCB,
and the cables are equipped with the female socket connectors on both ends. *Do not confuse A-coded and B-coded M8 connectors — they are not mutually compatible*. The CAN physical layer standard that can be used with this connector type is
[ISO 11898-2](http://www.can-cia.org/index.php?id=systemdesign-can-physicallayer#high),
also known as high-speed CAN.

--- chunk_id: chunk-0174
source_document: Specification__8._Hardware_design_recommendations.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 456
content_hash: 4a4cadd74d616445
prev_chunk_id: chunk-0173
next_chunk_id: chunk-0175
section_heading: Physical connector definition
document_type: specification

*Do not confuse A-coded and B-coded M8 connectors — they are not mutually compatible*. The CAN physical layer standard that can be used with this connector type is
[ISO 11898-2](http://www.can-cia.org/index.php?id=systemdesign-can-physicallayer#high),
also known as high-speed CAN. Devices that deliver power to the bus are required to provide 23.0---30.0 V on the bus power line, 24 V nominal. The maximum current draw is up to 3 A per connector. Devices that are powered from the bus should expect 18.0---30.0 V on the bus power line. The maximum recommended current draw from the bus is 500 mA per device. The table below documents the pinout specification for the DroneCAN M8 connector type. The provided pinout, as indicated above, is compatible with the CiA 103 specification (CANopen). Note that the wires `CAN High` and `CAN Low` should be a twisted pair. Circuit number | Function          | Note
---------------- |-------------------| ----------------------------------------------------------------------------------
1 |Bus power supply   | 24 V nominal. Power supply requirements are documented above. 2 |CAN Shield         | Optional. 3 |CAN High           | Twisted with CAN Low (pin 4). 4 |CAN Low            | Twisted with CAN High (pin 3). 5 |Ground             | ### DroneCAN Micro connector

{% include lightbox.html url="/Specification/figures/jst_gh_patch_cable.jpg" title="DroneCAN Micro patch cable (twisted)" thumbnail=true %}
{% include lightbox.html url="/Specification/figures/jst_gh_termination_plug.jpg" title="DroneCAN Micro termination plug" thumbnail=true %}
{% include lightbox.html url="/Specification/figures/jst_gh_1st_pin_mark.png" title="Location of the first pin of a JST GH plug is indicated with a mark, as shown on the figure" thumbnail=true %}

The DroneCAN Micro connector is intended for weight- and space-sensitive applications. It is a board-level connector, meaning that it can be installed on the PCB rather than on the panel. The Micro connector is compatible with the Dronecode Autopilot Connector Standard. This connector type is recommended for small UAV and nanosatellites. It is also the recommended connector for attaching external panel-mounted connectors
(such as the M8 or D-Sub types) to the PCB inside the enclosure. #### Advantages

* Extremely compact, low-profile. The PCB footprint is under 9✕5 millimeters. * Secure positive lock ensures that the connection will not self-disconnect when exposed to vibrations.

--- chunk_id: chunk-0175
source_document: Specification__8._Hardware_design_recommendations.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 328
content_hash: 0ab7a203b3cd461e
prev_chunk_id: chunk-0174
next_chunk_id: chunk-0176
section_heading: Physical connector definition
document_type: specification

The PCB footprint is under 9✕5 millimeters. * Secure positive lock ensures that the connection will not self-disconnect when exposed to vibrations. * Low-cost, easy to stock. #### Disadvantages

* Board-level connections only. No panel-mounted options available. * No shielding available. * Not suitable for safety-critical hardware. #### Specification

The Micro connector is based on the proprietary
**[JST GH](http://www.jst-mfg.com/product/pdf/eng/eGH.pdf) 4-circuit**
connector type. The suitable cable types are flat or twisted pair #30 to #26 AWG, outer insulation diameter 0.8---1.0 mm,
multi-strand. Non-twisted (flat) cables can only be used in very small deployments free of significant EMI,
otherwise reliable functioning of the bus cannot be guaranteed. The CAN physical layer standard that can be used with this connector type is
[ISO 11898-2](http://www.can-cia.org/index.php?id=systemdesign-can-physicallayer#high),
also known as high-speed CAN. Devices that deliver power to the bus are required to provide 5.0---5.5 V on the bus power line. The anticipated current draw is up to 1 A per connector. Devices that are powered from the bus should expect 4.0---5.5 V on the bus power line. The maximum recommended current draw from the bus is 500 mA per device. Circuit number | Function          | Recommended wire designation for 25-pair-color-coded cables
---------------- |-------------------| ----------------------------------------------------------------------------------
1 | Bus power supply  | <img src="/Specification/figures/wire_white_blue_stripe.svg"   style="width:4em;" /> pair 1 tip
2 | CAN High          | <img src="/Specification/figures/wire_orange.svg"              style="width:4em;" /> pair 2 ring
3 | CAN Low           | <img src="/Specification/figures/wire_white_orange_stripe.svg" style="width:4em;" /> pair 2 tip
4 | Ground            | <img src="/Specification/figures/wire_blue.svg"                style="width:4em;" /> pair 1 ring

--- chunk_id: chunk-0176
source_document: Specification__8._Hardware_design_recommendations.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 382
content_hash: 861cfac3fda76fcd
prev_chunk_id: chunk-0175
next_chunk_id: chunk-0177
section_heading: Design recommendations
document_type: specification

## Design recommendations
### Connectors

It is highly recommended to provide two identical parallel connectors for each CAN interface per device,
so that the device can be connected to the bus without the need to use T-connectors. T-connectors should be avoided when possible because generally they add an extra point of failure,
increase the stub length, weight, and often require more complex and expensive wiring harnesses. The figure below demonstrates a CAN bus wired according to the above recommendation. {% include lightbox.html url="/Specification/figures/can_chaining_non_redundant.png" title="Non-redundant CAN bus wiring" %}

The next figure shows a bus where the devices are equipped with doubly redundant interfaces. The same principles apply to a triply-redundant bus as well. {% include lightbox.html url="/Specification/figures/can_chaining_doubly_redundant.png" title="Doubly-redundant CAN bus wiring" %}

DroneCAN permits keeping one of the redundant interfaces unused. An example of such wiring is shown on the following figure. {% include lightbox.html url="/Specification/figures/can_chaining_doubly_redundant_one_unused.png" title="Non-redundant CAN bus wiring where nodes are equipped with redundant interfaces" %}

### Devices with different number of redundant interfaces

Mission critical devices and non-mission critical devices often need to co-exist on the same DroneCAN network. Non-mission critical devices are likely to be equipped with a non-redundant CAN bus interface,
which can create the situation where multiple devices with a different number of redundant interfaces need to be
connected to the same DroneCAN network. If multiple devices with a different number of interfaces need to co-exist on the same DroneCAN network,
the following rules should be followed:

* Each available CAN bus (DroneCAN supports up to 3) is assigned a level of importance (primary or backup). * All devices should be connected to the primary CAN bus. * Only devices with redundant interfaces should be also connected to the backup bus/buses.

--- chunk_id: chunk-0177
source_document: Specification__8._Hardware_design_recommendations.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 453
content_hash: c2ac1b673277d9eb
prev_chunk_id: chunk-0176
next_chunk_id: chunk-0178
section_heading: Design recommendations
document_type: specification

* All devices should be connected to the primary CAN bus. * Only devices with redundant interfaces should be also connected to the backup bus/buses. The figure below shows a doubly redundant CAN bus, but the same considerations apply to a triply redundant bus:

{% include lightbox.html url="/Specification/figures/redundant_can_bus.png" title="Redundant CAN bus" %}

### Bus power supply

{% include lightbox.html url="/Specification/figures/can_phy_power_reference.png" title="Example schematic of a bus-powered device with a doubly redundant CAN bus interface" thumbnail=true %}

#### Bus-powered devices

This section applies to devices that draw power from the bus. Each power input must be protected with an overcurrent protection circuit (for example, a fuse),
so that an accidental short circuit on the device will not bring down the power on the entire bus. If the device incorporates redundant bus interfaces, it must prevent direct current flow between power inputs
from different interface connectors, so that if one bus suffers a power failure (e.g. a short circuit)
it won’t be propagated to other buses. #### Bus-powering devices

This section applies to devices that deliver power to the bus. Similar to the case of bus-powered devices,
DroneCAN power sources should take into account that one of the redundant interfaces may suffer a short circuit
or a failure of similar mode. Should that happen, the power source should shut down the failing bus and continue to supply the remaining
bus interfaces. ### CAN bus parameters

DroneCAN is bit rate agnostic, so technically any bit rate can be used as long as it is supported by the physical layer. However, only the recommended bit rates from the table below should be used to ensure compatibility. All recommended bit rates and other relevant CAN bus parameters are listed in the table below. Bit rate | Valid range for location of sample point | Recommended location of sample point | Max bus length | Max stub length
--------------------- |------------------------------------------|--------------------------------------|----------------| ----------------
1000 kbit/s | 75% to 90%                               | 87.5%                                | 40 m           | 0.3 m
500 kbit/s | 85% to 90%                               | 87.5%                                | 100 m          |

--- chunk_id: chunk-0178
source_document: Specification__8._Hardware_design_recommendations.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 224
content_hash: d1538fc9794c1cfa
prev_chunk_id: chunk-0177
next_chunk_id: chunk-0179
section_heading: Design recommendations
document_type: specification

0.3 m
500 kbit/s | 85% to 90%                               | 87.5%                                | 100 m          | 0.3 m
250 kbit/s | 85% to 90%                               | 87.5%                                | 250 m          | 0.3 m
125 kbit/s | 85% to 90%                               | 87.5%                                | 500 m          | 0.3 m

The estimated bus length limits are based on the assumption that the propagation delay does not exceed 5 ns/m,
not including additional delay times of CAN transceivers and other components. #### Automatic bit rate detection

Designers are encouraged to implement CAN auto bit rate detection when applicable. Please refer to the CiA 801 application note for recommended practices. DroneCAN enables the use of the simple bit time measuring approach,
as it is guaranteed that any functioning DroneCAN network will always exchange node status messages,
which can be expected to be published at a rate no lower than 1 Hz,
and that contain a suitable alternating bit pattern in the CAN ID field. Please refer to the [chapter dedicated to the application-level functions](/Specification/6._Application_level_functions)
for details.

--- chunk_id: chunk-0179
source_document: Specification__8._Hardware_design_recommendations.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 36
content_hash: b71a15db152f83fb
prev_chunk_id: chunk-0178
next_chunk_id: chunk-0180
section_heading: See also
document_type: specification

## See also

* [Controller Area Network Physical Layer Requirements](http://www.ti.com/lit/an/slla270/slla270.pdf) (Application Report, SLLA270–January 2008) 
* [CAN and CAN-FD a brief tutorial](http://www.computer-solutions.co.uk/info/Embedded_tutorials/can_tutorial.htm) (www.computer-solutions.co.uk)
* [CAN CiA Specifications](https://www.can-cia.org/standardization/specifications) (www.can-cia.org)

--- chunk_id: chunk-0180
source_document: index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 48
content_hash: e365b72e1829b787
prev_chunk_id: chunk-0179
next_chunk_id: chunk-0181
section_heading: DroneCAN
document_type: technical_reference

<img src="image/logo_w_props.png" width="128"/>
# DroneCAN

DroneCAN is the primary CAN protocol used by the ArduPilot and PX4 projects for communication with CAN peripherals. It is an open protocol with open communication, specification and multiple open implementations.

--- chunk_id: chunk-0181
source_document: index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 152
content_hash: a8c9cb2843ce88d1
prev_chunk_id: chunk-0180
next_chunk_id: chunk-0182
section_heading: Key Features
document_type: technical_reference

## Key Features

The first version of DroneCAN, known as DroneCAN v1, is identical to the older UAVCAN protocol. This means that the large number of existing UAVCAN devices used throughout the drone industry are already DroneCAN v1 compliant. Features inherited from UAVCAN include:
 - detailed protocol specification
 - DSDL message description language for message description
 - DNA (dynamic node allocation) for assignment of CAN node IDs
 - multiple open DSDL compilers that produce C and C++ bindings
 - rich python implementation
 - feature rich graphical user interface for diagnostics and device configuration
 - mature implementations in ArduPilot and PX4 autopilots
 - [AP_Periph](https://ardupilot.org/dev/docs/ap-peripheral-landing-page.html) and [PX4 cannode](https://docs.px4.io/master/en/uavcan/) toolkits for easy creation of feature rich peripherals

--- chunk_id: chunk-0182
source_document: index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 174
content_hash: cba564715fac0d10
prev_chunk_id: chunk-0181
next_chunk_id: chunk-0183
section_heading: Continued Evolution
document_type: technical_reference

## Continued Evolution

DroneCAN is a continually evolving protocol. Starting with DroneCAN v1 the protocol will evolve to add new features to assist in the widespread adoption of CAN throughout the UAV industry. The DroneCAN project is committed to ensuring this evolution is done in a manner which retains compatibility with existing DroneCAN devices. Key features planned for DroneCAN in the near future:
 - support for FDCAN, allowing for higher data rates and larger frame sizes
 - a node capability message to allow the DNA server to determine both the hardware and software capabilities of connected nodes, to facilitate smooth transitions to updated protocol versions
 - support for extending messages definitions while retaining compatibility with existing implementations
 - a comprehensive re-work of existing DSDL message structures to improve efficiency and flexibility

--- chunk_id: chunk-0183
source_document: index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 348
content_hash: c60fe9c5754b0f40
prev_chunk_id: chunk-0182
next_chunk_id: chunk-0184
section_heading: Development
document_type: technical_reference

## Development

The DroneCAN project has an active development community. - discussions on discord at [https://dronecan.org/discord](https://dronecan.org/discord)
 - development on github at [https://github.com/DroneCAN](https://github.com/DroneCAN)

### Joining DroneCAN
If you would like to publicly support the DroneCAN project then please
fill in the [application form](https://dronecan.org/apply)

### Supporters
<table style="padding:10px">
  <tr>
    <td><a href="https://ardupilot.org" target="_blank"><img src="image/ArduPilot2.png" alt="ArduPilot" width="256px"></a></td>
    <td><a href="https://px4.io" target="_blank"><img src="image/px4.png" alt="PX4" width="256px"></a></td>
    <td><a href="https://www.currawongeng.com/" target="_blank"><img src="image/Currawong.png" alt="Currawong" width="256px"></a></td>
   </tr>
  <tr>
    <td><a href="https://cubepilot.org/" target="_blank"><img src="image/Cubepilot.png" alt="Cubepilot" width="256px"></a></td>
    <td><a href="https://arkelectron.com/" target="_blank"><img src="image/ARK.png" alt="ARK" width="256px"></a></td>
    <td><a href="https://hitecnology.com/" target="_blank"><img src="image/Hitec.png" alt="Hitec" width="256px"></a></td>
   </tr>
  <tr>
    <td><a href="https://mrobotics.io/" target="_blank"><img src="image/mRo.png" alt="mRo" width="256px"></a></td>
    <td><a href="https://krausaerospace.com/" target="_blank"><img src="image/kraus.png" alt="Kraus" width="256px"></a></td>
    <td><a href="https://wurzbachelectronics.com/" target="_blank"><img src="image/WurzbachElectronics.jpg" alt="WurzbachElectronics" width="256px"></a></td>
   </tr>
  <tr>
    <td><a href="https://www.spektreworks.com/" target="_blank"><img src="image/SpektreWorks.png" alt="SpektreWorks" width="256px"></a></td>
    <td><a href="https://www.mateksys.com/" target="_blank"><img src="image/mateksys.png" alt="Matek" width="256px"></a></td>
    <td><a href="https://www.cuav.net/" target="_blank"><img src="image/cuav.png" alt="CUAV" width="256px"></a></td>
   </tr>
  <tr>
    <td><a href="https://www.qio-tek.com/" target="_blank"><img src="image/qiotek.png" alt="Qiotek" width="256px"></a></td>
    <td><a href="https://www.linkedin.com/company/sierraaerospace/" target="_blank"><img src="image/Sierra.png" alt="Sierra" width="256px"></a></td>
    <td><a href="https://www.bfdsystems.com/" target="_blank"><img src="image/BFDsystemSHOPy.png" alt="BFD" width="256px"></a></td>
   </tr>
  <tr>
    <td><a href="http://www.holybro.com/" target="_blank"><img src="image/holybro.png" alt="Holybro" width="256px"></a></td>
    <td><a href="https://www.zeus-actuators.com/" target="_blank"><img src="image/zeus.png" alt="Zeus" width="256px"></a></td>
    <td><a href="https://bolderflight.com/" target="_blank"><img src="image/bolderflight.svg" alt="BolderFlight" width="256px"></a></td>
   </tr>
  <tr>
    <td><a href="https://raccoonlab.co/" target="_blank"><img src="image/racoon.png" alt="Racoon" width="256px"></a></td>
    <td><a href="https://www.alvaindustries.com/" target="_blank"><img src="image/alvaindustries.svg" alt="AlvaIndustries" width="256px"></a></td>
    <td><a href="https://krausaerospace.com/" target="_blank"><img src="image/kraus.jpg" alt="KrausHamdani" width="256px"></a></td>
   </tr>
  <tr>
    <td><a href="https://dronebility.com/" target="_blank"><img src="image/droneability.png" alt="Droneability" width="256px"></a></td>
    <td><a href="https://vectortechnics.com/" target="_blank"><img src="image/vectortechnics.jpg" alt="VectorTechnics" width="256px"></a></td>
    <td><a href="https://www.vimdrones.com/" target="_blank"><img src="image/vimdrones.png" alt="VimDrones" width="256px"></a></td>
   </tr>
  <tr>
    <td><a href="https://www.volz-servos.com/" target="_blank"><img src="image/volz.jpg" alt="VolzServos" width="256px"></a></td>
    <td><a href="https://hargravetechnologies.com/" target="_blank"><img src="image/hargrave.jpg" alt="Hargrave" width="256px"></a></td>
    <td><a href="https://KDEDirect.com/" target="_blank"><img src="image/KDE.png" alt="KDE" width="256px"></a></td>
   </tr>
  <tr>
    <td><a href="https://www.vertiq.co/" target="_blank"><img src="image/vertiq.png" alt="Vertiq" width="256px"></a></td>
    <td><a href="https://linamik.com/" target="_blank"><img src="image/linamik.png" alt="Linamik" width="256px"></a></td>
    <td><a href="https://www.makeflyeasy.com/" target="_blank"><img src="image/makeflyeasy.jpg" alt="Makeflyeasy" width="256px"></a></td>
  </tr>
  <tr>
    <td><a href="https://www.aeroatoms.com/" target="_blank"><img src="image/aeroatoms.png" alt="Aeroatoms" width="256px"></a></td>
    <td><a href="https://xlr8aerospace.com/" target="_blank"><img src="image/xlr8aerospace.jpg" alt="xlr8aerospace" width="256px"></a></td>
  </tr>
</table>

--- chunk_id: chunk-0184
source_document: index.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 128
content_hash: a4e5a7b5c4c0b04c
prev_chunk_id: chunk-0183
next_chunk_id: null
section_heading: History
document_type: technical_reference

## History

DroneCAN was created to continue the development of the widely used
UAVCAN protocol. This protocol has proven itself as robust and feature
rich and has been widely deployed in the commercial drone industry and
enjoys broad support among industry partners. The proposed
introduction of the UAVCAN v1 protocol (now known as cyphal) involved
changes to UAVCAN that increased complexity and did not offer a smooth
migration path for existing deployments. After extended discussions
within the UAVCAN consortium it was decided that the best solution was
to continue development of UAVCAN under the name DroneCAN.
