# Residual board — HR9917_AI_Kill_Switch_Act_119IH

Status: **success**

## Counts
- in kb: 6  |  muted / off RAG: 0  |  on RAG path: 6
- embedded rows: 6
- reconciled: True

## Quality score (if present)
- avg_extraction_quality: **1.0**
- measures: text-layer coverage / extractability (pages that produced usable text), not character-level OCR accuracy

## Limits / open items
- (none recorded)

