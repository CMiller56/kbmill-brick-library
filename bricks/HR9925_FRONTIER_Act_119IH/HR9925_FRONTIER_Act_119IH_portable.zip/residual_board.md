# Residual board — HR9925_FRONTIER_Act_119IH

Status: **success**

## Counts
- in kb: 48  |  muted / off RAG: 0  |  on RAG path: 48
- embedded rows: 48
- reconciled: True

## Quality score (if present)
- avg_extraction_quality: **1.0**
- measures: text-layer coverage / extractability (pages that produced usable text), not character-level OCR accuracy

## Limits / open items
- (none recorded)

