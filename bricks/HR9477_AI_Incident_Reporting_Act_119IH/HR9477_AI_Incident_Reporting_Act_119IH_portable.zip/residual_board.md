# Residual board — HR9477_AI_Incident_Reporting_Act_119IH

Status: **success**

## Counts
- in kb: 8  |  muted / off RAG: 0  |  on RAG path: 8
- embedded rows: 8
- reconciled: True

## Quality score (if present)
- avg_extraction_quality: **1.0**
- measures: text-layer coverage / extractability (pages that produced usable text), not character-level OCR accuracy

## Limits / open items
- (none recorded)

