---
kb_id: articles-of-confederation-us-founding-documents
title: Articles of Confederation — US Founding Documents
author: Unknown Author
created_date: 2026-08-05
classification: Internal
confidence_level: High
domain_tags: ["security", "rmf", "ato", "general"]
document_type: Technical Reference
primary_subject: Articles of Confederation 1781
sources: [{"filename": "Articles_of_Confederation.md", "path": "docs/library/US_Founding_Documents/Articles_of_Confederation/Articles_of_Confederation.md", "page_count": 1}]
ingest_provenance: {"captured_at": "2026-08-05T18:33:20.573718", "page_count": 1, "extraction_methods": {"txt": 1}, "avg_extraction_quality": 1.0, "docling_triage_pages": 0, "docling_triage_rate": 0.0, "extraction_stats": null}
dark_data_inferred_fields: ["author", "classification", "confidence_level", "created_date", "document_type", "document_type_confidence", "document_type_inferred", "domain_tags", "ingest_provenance", "kb_id", "sources"]
brick_role: Public-domain Articles of Confederation (predecessor national frame, 1781–1789). Series: US Founding Documents.
usage_notes: Use for confederation structure, state sovereignty under the Articles, contrast with Constitution. Not current law. Not legal advice.
out_of_scope: ["Modern legal advice or litigation strategy", "Current statutory code or case law holdings", "Copyrighted modern commentary or textbooks"]
series: US Founding Documents
document_type_inferred: True
document_type_confidence: 0.545
kb_name: Articles_of_Confederation
created: 2026-08-05T18:33:20.573809
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 19
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-08-05T18:33:31.987030
  chunk_count: 19
  strict_air_gapped: true
---

--- chunk_id: chunk-0000
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 57
content_hash: 08dc5e49e6784207
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: Articles of Confederation
document_type: technical_reference

# Articles of Confederation

**Series:** US Founding Documents  
**Instrument:** Articles of Confederation and Perpetual Union (1777; in force 1781–1789)  
**Provenance:** Public domain text via Yale Avalon Project (18th Century Documents). **Out of scope:** Modern legal advice; not the current frame of government. ---

--- chunk_id: chunk-0001
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 229
content_hash: f5d6ac708c16a80b
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
section_heading: Articles of Confederation and Perpetual Union
document_type: technical_reference

## Articles of Confederation and Perpetual Union

To all to whom these Presents shall come, we the undersigned Delegates of the States affixed to our Names send greeting. Articles of Confederation and perpetual Union between the states of New Hampshire, Massachusetts-bay Rhode Island and Providence Plantations, Connecticut, New York, New Jersey, 
Pennsylvania, Delaware, Maryland, Virginia, North Carolina, South Carolina and Georgia. ### Article I
The Stile of this Confederacy shall be  

         "The United States of America". ### Article II
Each state retains its sovereignty, freedom, and independence, and every power, jurisdiction, and right, which is not by this Confederation expressly delegated to the United States, in Congress assembled. ### Article III
The said States hereby severally enter into a firm league of friendship with each other, for their common defense, the security of their liberties, and their mutual and general welfare, binding themselves to assist each other, against all force offered to, or attacks made upon them, or any of them, on account of religion, sovereignty, trade, or any other pretense whatever.

--- chunk_id: chunk-0002
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 317
content_hash: 786e978e4f8484c5
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: Article IV
document_type: technical_reference

## Article IV

The better to secure and perpetuate mutual friendship and intercourse among the people of the different States in this Union, the free inhabitants of each of these States, paupers, vagabonds, and fugitives from justice excepted, shall be entitled to all privileges and immunities of free citizens in the several States; and the people of each State shall free ingress and regress to and from any other State, and shall enjoy therein all the privileges of trade and commerce, subject to the same duties, impositions, and restrictions as the inhabitants thereof respectively, provided that such restrictions shall not extend so far as to prevent the removal of property imported into any State, to any other State, of which the owner is an inhabitant; provided also that no imposition, duties or restriction shall be laid by any State, on the property of the United States, or either of them. If any person guilty of, or charged with, treason, felony, or other high misdemeanor in any State, shall flee from justice, and be found in any of the United States, he shall, upon demand of the Governor or executive power of the State from which he fled, be delivered up and removed to the State having jurisdiction of his offense. Full faith and credit shall be given in each of these States to the records, acts, and judicial proceedings of the courts and magistrates of every other State.

--- chunk_id: chunk-0003
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 330
content_hash: b792c7bb353e786e
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: Article V
document_type: technical_reference

## Article V

For the most convenient management of the general interests of the United States, delegates shall be annually appointed in such manner as the legislatures of each State shall direct, to meet in Congress on the first Monday in November, in every year, with a powerreserved to each State to recall its delegates, or any of them, at any time within the year, and to send others in their stead for the remainder of the year. No State shall be represented in Congress by less than two, nor more than seven members; and no person shall be capable of being a delegate for more than three years in any term of six years; nor shall any person, being a delegate, be capable of holding any office under the United States, for which he, or another for his benefit, receives any salary, fees or emolument of any kind. Each State shall maintain its own delegates in a meeting of the States, and while they act as members of the committee of the States. In determining questions in the United States in Congress assembled, each State shall have one vote. Freedom of speech and debate in Congress shall not be impeached or questioned in any court or place out of Congress, and the members of Congress shall be protected in their persons from arrests or imprisonments, during the time of their going to and from, and attendence on Congress, except for treason, felony, or breach of the peace.

--- chunk_id: chunk-0004
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 424
content_hash: 840adaeee4868bab
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: Article VI
document_type: technical_reference

## Article VI

No State, without the consent of the United States in Congress assembled, shall send any embassy to, or receive any embassy from, or enter into any conference, agreement, alliance or treaty with any King, Prince or State; nor shall any person holding any office of profit or trust under the United States, or any of them, accept any present, emolument, office or title of any kind whatever from any King, Prince or foreign State; nor shall the United States in Congress assembled, or any of them, grant any title of nobility. No two or more States shall enter into any treaty, confederation or alliance whatever between them, without the consent of the United States in Congress assembled, specifying accurately the purposes for which the same is to be entered into, and how long it shall continue. No State shall lay any imposts or duties, which may interfere with any stipulations in treaties, entered into by the United States in Congress assembled, with any King, Prince or State, in pursuance of any treaties already proposed by Congress, to the courts of France and Spain. No vessel of war shall be kept up in time of peace by any State, except such number only, as shall be deemed necessary by the United States in Congress assembled, for the defense of such State, or its trade; nor shall any body of forces be kept up by any State in time of peace, except such number only, as in the judgement of the United States in Congress assembled, shall be deemed requisite to garrison the forts necessary for the defense of such State; but every State shall always keep up a well-regulated and disciplined militia, sufficiently armed and accoutered, and shall provide and constantly have ready for use, in public stores, a due number of filed pieces and tents, and a proper quantity of arms, ammunition and camp equipage.

--- chunk_id: chunk-0005
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 473
content_hash: a2a88dfad4715193
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
section_heading: Article VI
document_type: technical_reference

No State shall lay any imposts or duties, which may interfere with any stipulations in treaties, entered into by the United States in Congress assembled, with any King, Prince or State, in pursuance of any treaties already proposed by Congress, to the courts of France and Spain. No vessel of war shall be kept up in time of peace by any State, except such number only, as shall be deemed necessary by the United States in Congress assembled, for the defense of such State, or its trade; nor shall any body of forces be kept up by any State in time of peace, except such number only, as in the judgement of the United States in Congress assembled, shall be deemed requisite to garrison the forts necessary for the defense of such State; but every State shall always keep up a well-regulated and disciplined militia, sufficiently armed and accoutered, and shall provide and constantly have ready for use, in public stores, a due number of filed pieces and tents, and a proper quantity of arms, ammunition and camp equipage. No State shall engage in any war without the consent of the United States in Congress assembled, unless such State be actually invaded by enemies, or shall have received certain advice of a resolution being formed by some nation of Indians to invade such State, and the danger is so imminent as not to admit of a delay till the United States in Congress assembled can be consulted; nor shall any State grant commissions to any ships or vessels of war, nor letters of marque or reprisal, except it be after a declaration of war by the United States in Congress assembled, and then only against the Kingdom or State and the subjects thereof, against which war has been so declared, and under such regulations as shall be established by the United States in Congress assembled, unless such State be infested by pirates, in which case vessels of war may be fitted out for that occasion, and kept so long as the danger shall continue, or until the United States in Congress assembled shall determine otherwise.

--- chunk_id: chunk-0006
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 260
content_hash: 2a68c79e0d5700e1
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: Article VII
document_type: technical_reference

## Article VII

When land forces are raised by any State for the common defense, all officers of or under the rank of colonel, shall be appointed by the legislature of each State respectively, by whom such forces shall be raised, or in such manner as such State shall direct, and all vacancies shall be filled up by the State which first made the appointment. ### Article VIII
All charges of war, and all other expenses that shall be incurred for the common defense or general welfare, and allowed by the United States in Congress assembled, shall be defrayed out of a common treasury, which shall be supplied by the several States in proportion to the value of all land within each State, granted or surveyed for any person, as such land and the buildings and improvements thereon shall be estimated according to such mode as the United States in Congress assembled, shall from time to time direct and appoint. The taxes for paying that proportion shall be laid and levied by the authority and direction of the legislatures of the several States within the time agreed upon by the United States in Congress assembled.

--- chunk_id: chunk-0007
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 324
content_hash: 614c37638731028f
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: Article IX
document_type: technical_reference

## Article IX

The United States in Congress assembled, shall have the sole and exclusive right and power of determining on peace and war, except in the cases mentioned in the sixth article -- of sending and receiving ambassadors -- entering into treaties and alliances, provided that no treaty of commerce shall be made whereby the legislative power of the respective States shall be restrained from imposing such imposts and duties on foreigners, as their own people are subjected to, or from prohibiting the exportation or importation of any species of goods or commodities whatsoever -- of establishing rules for deciding in all cases, what captures on land or water shall be legal, and in what manner prizes taken by land or naval forces in the service of the United States shall be divided or appropriated -- of granting letters of marque and reprisal in times of peace -- appointing courts for the trial of piracies and felonies commited on the high seas and establishing courts for receiving and determining finally appeals in all cases of captures, provided that no member of Congress shall be appointed a judge of any of the said courts. The United States in Congress assembled shall also be the last resort on appeal in all disputes and differences now subsisting or that hereafter may arise between two or more States concerning boundary, jurisdiction or any other causes whatever; which authority shall always be exercised in the manner following.

--- chunk_id: chunk-0008
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 900
content_hash: d8e3a08eadb0f589
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: Article IX
document_type: technical_reference

## Article IX

The United States in Congress assembled, shall have the sole and exclusive right and power of determining on peace and war, except in the cases mentioned in the sixth article -- of sending and receiving ambassadors -- entering into treaties and alliances, provided that no treaty of commerce shall be made whereby the legislative power of the respective States shall be restrained from imposing such imposts and duties on foreigners, as their own people are subjected to, or from prohibiting the exportation or importation of any species of goods or commodities whatsoever -- of establishing rules for deciding in all cases, what captures on land or water shall be legal, and in what manner prizes taken by land or naval forces in the service of the United States shall be divided or appropriated -- of granting letters of marque and reprisal in times of peace -- appointing courts for the trial of piracies and felonies commited on the high seas and establishing courts for receiving and determining finally appeals in all cases of captures, provided that no member of Congress shall be appointed a judge of any of the said courts. The United States in Congress assembled shall also be the last resort on appeal in all disputes and differences now subsisting or that hereafter may arise between two or more States concerning boundary, jurisdiction or any other causes whatever; which authority shall always be exercised in the manner following. Whenever the legislative or executive authority or lawful agent of any State in controversy with another shall present a petition to Congress stating the matter in question and praying for a hearing, notice thereof shall be given by order of Congress to the legislative or executive authority of the other State in controversy, and a day assigned for the appearance of the parties by their lawful agents, who shall then be directed to appoint by joint consent, commissioners or judges to constitute a court for hearing and determining the matter in question: but if they cannot agree, Congress shall name three persons out of each of the United States, and from the list of such persons each party shall alternately strike out one, the petitioners beginning, until the number shall be reduced to thirteen; and from that number not less than seven, nor more than nine names as Congress shall direct, shall in the presence of Congress be drawn out by lot, and the persons whose names shall be so drawn or any five of them, shall be commissioners or judges, to hear and finally determine the controversy, so always as a major part of the judges who shall hear the cause shall agree in the determination: and if either party shall neglect to attend at the day appointed, without showing reasons, which Congress shall judge sufficient, or being present shall refuse to strike, the Congress shall proceed to nominate three persons out of each State, and the secretary of Congress shall strike in behalf of such party absent or refusing; and the judgement and sentence of the court to be appointed, in the manner before prescribed, shall be final and conclusive; and if any of the parties shall refuse to submit to the authority of such court, or to appear or defend their claim or cause, the court shall nevertheless proceed to pronounce sentence, or judgement, which shall in like manner be final and decisive, the judgement or sentence and other proceedings being in either case transmitted to Congress, and lodged among the acts of Congress for the security of the parties concerned: provided that every commissioner, before he sits in judgement, shall take an oath to be administered by one of the judges of the supreme or superior court of the State, where the cause shall be tried, 'well and truly to hear and determine the matter in question, according to the best of his judgement, without favor, affection or hope of reward': provided also, that no State shall be deprived of territory for the benefit of the United States.

--- chunk_id: chunk-0009
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 768
content_hash: 555a7fd7c0730de1
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
section_heading: Article IX
document_type: technical_reference

The United States in Congress assembled shall also be the last resort on appeal in all disputes and differences now subsisting or that hereafter may arise between two or more States concerning boundary, jurisdiction or any other causes whatever; which authority shall always be exercised in the manner following. Whenever the legislative or executive authority or lawful agent of any State in controversy with another shall present a petition to Congress stating the matter in question and praying for a hearing, notice thereof shall be given by order of Congress to the legislative or executive authority of the other State in controversy, and a day assigned for the appearance of the parties by their lawful agents, who shall then be directed to appoint by joint consent, commissioners or judges to constitute a court for hearing and determining the matter in question: but if they cannot agree, Congress shall name three persons out of each of the United States, and from the list of such persons each party shall alternately strike out one, the petitioners beginning, until the number shall be reduced to thirteen; and from that number not less than seven, nor more than nine names as Congress shall direct, shall in the presence of Congress be drawn out by lot, and the persons whose names shall be so drawn or any five of them, shall be commissioners or judges, to hear and finally determine the controversy, so always as a major part of the judges who shall hear the cause shall agree in the determination: and if either party shall neglect to attend at the day appointed, without showing reasons, which Congress shall judge sufficient, or being present shall refuse to strike, the Congress shall proceed to nominate three persons out of each State, and the secretary of Congress shall strike in behalf of such party absent or refusing; and the judgement and sentence of the court to be appointed, in the manner before prescribed, shall be final and conclusive; and if any of the parties shall refuse to submit to the authority of such court, or to appear or defend their claim or cause, the court shall nevertheless proceed to pronounce sentence, or judgement, which shall in like manner be final and decisive, the judgement or sentence and other proceedings being in either case transmitted to Congress, and lodged among the acts of Congress for the security of the parties concerned: provided that every commissioner, before he sits in judgement, shall take an oath to be administered by one of the judges of the supreme or superior court of the State, where the cause shall be tried, 'well and truly to hear and determine the matter in question, according to the best of his judgement, without favor, affection or hope of reward': provided also, that no State shall be deprived of territory for the benefit of the United States. All controversies concerning the private right of soil claimed under different grants of two or more States, whose jurisdictions as they may respect such lands, and the States which passed such grants are adjusted, the said grants or either of them being at the same time claimed to have originated antecedent to such settlement of jurisdiction, shall on the petition of either party to the Congress of the United States, be finally determined as near as may be in the same manner as is before presecribed for deciding disputes respecting territorial jurisdiction between different States.

--- chunk_id: chunk-0010
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 942
content_hash: e1da7264310e7b0b
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
section_heading: Article IX
document_type: technical_reference

Whenever the legislative or executive authority or lawful agent of any State in controversy with another shall present a petition to Congress stating the matter in question and praying for a hearing, notice thereof shall be given by order of Congress to the legislative or executive authority of the other State in controversy, and a day assigned for the appearance of the parties by their lawful agents, who shall then be directed to appoint by joint consent, commissioners or judges to constitute a court for hearing and determining the matter in question: but if they cannot agree, Congress shall name three persons out of each of the United States, and from the list of such persons each party shall alternately strike out one, the petitioners beginning, until the number shall be reduced to thirteen; and from that number not less than seven, nor more than nine names as Congress shall direct, shall in the presence of Congress be drawn out by lot, and the persons whose names shall be so drawn or any five of them, shall be commissioners or judges, to hear and finally determine the controversy, so always as a major part of the judges who shall hear the cause shall agree in the determination: and if either party shall neglect to attend at the day appointed, without showing reasons, which Congress shall judge sufficient, or being present shall refuse to strike, the Congress shall proceed to nominate three persons out of each State, and the secretary of Congress shall strike in behalf of such party absent or refusing; and the judgement and sentence of the court to be appointed, in the manner before prescribed, shall be final and conclusive; and if any of the parties shall refuse to submit to the authority of such court, or to appear or defend their claim or cause, the court shall nevertheless proceed to pronounce sentence, or judgement, which shall in like manner be final and decisive, the judgement or sentence and other proceedings being in either case transmitted to Congress, and lodged among the acts of Congress for the security of the parties concerned: provided that every commissioner, before he sits in judgement, shall take an oath to be administered by one of the judges of the supreme or superior court of the State, where the cause shall be tried, 'well and truly to hear and determine the matter in question, according to the best of his judgement, without favor, affection or hope of reward': provided also, that no State shall be deprived of territory for the benefit of the United States. All controversies concerning the private right of soil claimed under different grants of two or more States, whose jurisdictions as they may respect such lands, and the States which passed such grants are adjusted, the said grants or either of them being at the same time claimed to have originated antecedent to such settlement of jurisdiction, shall on the petition of either party to the Congress of the United States, be finally determined as near as may be in the same manner as is before presecribed for deciding disputes respecting territorial jurisdiction between different States. The United States in Congress assembled shall also have the sole and exclusive right and power of regulating the alloy and value of coin struck by their own authority, or by that of the respective States -- fixing the standards of weights and measures throughout the United States -- regulating the trade and managing all affairs with the Indians, not members of any of the States, provided that the legislative right of any State within its own limits be not infringed or violated -- establishing or regulating post offices from one State to another, throughout all the United States, and exacting such postage on the papers passing through the same as may be requisite to defray the expenses of the said office -- appointing all officers of the land forces, in the service of the United States, excepting regimental officers -- appointing all the officers of the naval forces, and commissioning all officers whatever in the service of the United States -- making rules for the government and regulation of the said land and naval forces, and directing their operations.

--- chunk_id: chunk-0011
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 710
content_hash: 33c367ab88d8e043
prev_chunk_id: chunk-0010
next_chunk_id: chunk-0012
section_heading: Article IX
document_type: technical_reference

All controversies concerning the private right of soil claimed under different grants of two or more States, whose jurisdictions as they may respect such lands, and the States which passed such grants are adjusted, the said grants or either of them being at the same time claimed to have originated antecedent to such settlement of jurisdiction, shall on the petition of either party to the Congress of the United States, be finally determined as near as may be in the same manner as is before presecribed for deciding disputes respecting territorial jurisdiction between different States. The United States in Congress assembled shall also have the sole and exclusive right and power of regulating the alloy and value of coin struck by their own authority, or by that of the respective States -- fixing the standards of weights and measures throughout the United States -- regulating the trade and managing all affairs with the Indians, not members of any of the States, provided that the legislative right of any State within its own limits be not infringed or violated -- establishing or regulating post offices from one State to another, throughout all the United States, and exacting such postage on the papers passing through the same as may be requisite to defray the expenses of the said office -- appointing all officers of the land forces, in the service of the United States, excepting regimental officers -- appointing all the officers of the naval forces, and commissioning all officers whatever in the service of the United States -- making rules for the government and regulation of the said land and naval forces, and directing their operations. The United States in Congress assembled shall have authority to appoint a committee, to sit in the recess of Congress, to be denominated 'A Committee of the States', and to consist of one delegate from each State; and to appoint such other committees and civil officers as may be necessary for managing the general affairs of the United States under their direction -- to appoint one of their members to preside, provided that no person be allowed to serve in the office of president more than one year in any term of three years; to ascertain the necessary sums of money to be raised for the service of the United States, and to appropriate and apply the same for defraying the public expenses -- to borrow money, or emit bills on the credit of the United States, transmitting every half-year to the respective States an account of the sums of money so borrowed or emitted -- to build and equip a navy -- to agree upon the number of land forces, and to make requisitions from each State for its quota, in proportion to the number of white inhabitants in such State; which requisition shall be binding, and thereupon the legislature of each State shall appoint the regimental officers, raise the men and cloath, arm and equip them in a solid-like manner, at the expense of the United States; and the officers and men so cloathed, armed and equipped shall march to the place appointed, and within the time agreed on by the United States in Congress assembled.

--- chunk_id: chunk-0012
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 716
content_hash: 1c269aa7251a77c3
prev_chunk_id: chunk-0011
next_chunk_id: chunk-0013
section_heading: Article IX
document_type: technical_reference

The United States in Congress assembled shall also have the sole and exclusive right and power of regulating the alloy and value of coin struck by their own authority, or by that of the respective States -- fixing the standards of weights and measures throughout the United States -- regulating the trade and managing all affairs with the Indians, not members of any of the States, provided that the legislative right of any State within its own limits be not infringed or violated -- establishing or regulating post offices from one State to another, throughout all the United States, and exacting such postage on the papers passing through the same as may be requisite to defray the expenses of the said office -- appointing all officers of the land forces, in the service of the United States, excepting regimental officers -- appointing all the officers of the naval forces, and commissioning all officers whatever in the service of the United States -- making rules for the government and regulation of the said land and naval forces, and directing their operations. The United States in Congress assembled shall have authority to appoint a committee, to sit in the recess of Congress, to be denominated 'A Committee of the States', and to consist of one delegate from each State; and to appoint such other committees and civil officers as may be necessary for managing the general affairs of the United States under their direction -- to appoint one of their members to preside, provided that no person be allowed to serve in the office of president more than one year in any term of three years; to ascertain the necessary sums of money to be raised for the service of the United States, and to appropriate and apply the same for defraying the public expenses -- to borrow money, or emit bills on the credit of the United States, transmitting every half-year to the respective States an account of the sums of money so borrowed or emitted -- to build and equip a navy -- to agree upon the number of land forces, and to make requisitions from each State for its quota, in proportion to the number of white inhabitants in such State; which requisition shall be binding, and thereupon the legislature of each State shall appoint the regimental officers, raise the men and cloath, arm and equip them in a solid-like manner, at the expense of the United States; and the officers and men so cloathed, armed and equipped shall march to the place appointed, and within the time agreed on by the United States in Congress assembled. But if the United States in Congress assembled shall, on consideration of circumstances judge proper that any State should not raise men, or should raise a smaller number of men than the quota thereof, such extra number shall be raised, officered, cloathed, armed and equipped in the same manner as the quota of each State, unless the legislature of such State shall judge that such extra number cannot be safely spread out in the same, in which case they shall raise, officer, cloath, arm and equip as many of such extra number as they judeg can be safely spared.

--- chunk_id: chunk-0013
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: 645e9e92f249774e
prev_chunk_id: chunk-0012
next_chunk_id: chunk-0014
section_heading: Article IX
document_type: technical_reference

The United States in Congress assembled shall have authority to appoint a committee, to sit in the recess of Congress, to be denominated 'A Committee of the States', and to consist of one delegate from each State; and to appoint such other committees and civil officers as may be necessary for managing the general affairs of the United States under their direction -- to appoint one of their members to preside, provided that no person be allowed to serve in the office of president more than one year in any term of three years; to ascertain the necessary sums of money to be raised for the service of the United States, and to appropriate and apply the same for defraying the public expenses -- to borrow money, or emit bills on the credit of the United States, transmitting every half-year to the respective States an account of the sums of money so borrowed or emitted -- to build and equip a navy -- to agree upon the number of land forces, and to make requisitions from each State for its quota, in proportion to the number of white inhabitants in such State; which requisition shall be binding, and thereupon the legislature of each State shall appoint the regimental officers, raise the men and cloath, arm and equip them in a solid-like manner, at the expense of the United States; and the officers and men so cloathed, armed and equipped shall march to the place appointed, and within the time agreed on by the United States in Congress assembled. But if the United States in Congress assembled shall, on consideration of circumstances judge proper that any State should not raise men, or should raise a smaller number of men than the quota thereof, such extra number shall be raised, officered, cloathed, armed and equipped in the same manner as the quota of each State, unless the legislature of such State shall judge that such extra number cannot be safely spread out in the same, in which case they shall raise, officer, cloath, arm and equip as many of such extra number as they judeg can be safely spared. And the officers and men so cloathed, armed, and equipped, shall march to the place appointed, and within the time agreed on by the United States in Congress assembled.

--- chunk_id: chunk-0014
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 368
content_hash: d7721065b5d8ea6c
prev_chunk_id: chunk-0013
next_chunk_id: chunk-0015
section_heading: Article IX
document_type: technical_reference

But if the United States in Congress assembled shall, on consideration of circumstances judge proper that any State should not raise men, or should raise a smaller number of men than the quota thereof, such extra number shall be raised, officered, cloathed, armed and equipped in the same manner as the quota of each State, unless the legislature of such State shall judge that such extra number cannot be safely spread out in the same, in which case they shall raise, officer, cloath, arm and equip as many of such extra number as they judeg can be safely spared. And the officers and men so cloathed, armed, and equipped, shall march to the place appointed, and within the time agreed on by the United States in Congress assembled. The United States in Congress assembled shall never engage in a war, nor grant letters of marque or reprisal in time of peace, nor enter into any treaties or alliances, nor coin money, nor regulate the value thereof, nor ascertain the sums and expenses necessary for the defense and welfare of the United States, or any of them, nor emit bills, nor borrow money on the credit of the United States, nor appropriate money, nor agree upon the number of vessels of war, to be built or purchased, or the number of land or sea forces to be raised, nor appoint a commander in chief of the army or navy, unless nine States assent to the same: nor shall a question on any other point, except for adjourning from day to day be determined, unless by the votes of the majority of the United States in Congress assembled.

--- chunk_id: chunk-0015
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 413
content_hash: 7378dacb469982c0
prev_chunk_id: chunk-0014
next_chunk_id: chunk-0016
section_heading: Article IX
document_type: technical_reference

And the officers and men so cloathed, armed, and equipped, shall march to the place appointed, and within the time agreed on by the United States in Congress assembled. The United States in Congress assembled shall never engage in a war, nor grant letters of marque or reprisal in time of peace, nor enter into any treaties or alliances, nor coin money, nor regulate the value thereof, nor ascertain the sums and expenses necessary for the defense and welfare of the United States, or any of them, nor emit bills, nor borrow money on the credit of the United States, nor appropriate money, nor agree upon the number of vessels of war, to be built or purchased, or the number of land or sea forces to be raised, nor appoint a commander in chief of the army or navy, unless nine States assent to the same: nor shall a question on any other point, except for adjourning from day to day be determined, unless by the votes of the majority of the United States in Congress assembled. The Congress of the United States shall have power to adjourn to any time within the year, and to any place within the United States, so that no period of adjournment be for a longer duration than the space of six months, and shall publish the journal of their proceedings monthly, except such parts thereof relating to treaties, alliances or military operations, as in their judgement require secrecy; and the yeas and nays of the delegates of each State on any question shall be entered on the journal, when it is desired by any delegates of a State, or any of them, at his or their request shall be furnished with a transcript of the said journal, except such parts as are above excepted, to lay before the legislatures of the several States.

--- chunk_id: chunk-0016
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 184
content_hash: a643b4deef5971db
prev_chunk_id: chunk-0015
next_chunk_id: chunk-0017
section_heading: Article X
document_type: technical_reference

## Article X

The Committee of the States, or any nine of them, shall be authorized to execute, in the recess of Congress, such of the powers of Congress as the United States in Congress assembled, by the consent of the nine States, shall from time to time think expedient to vest them with; provided that no power be delegated to the said Committee, for the exercise of which, by the Articles of Confederation, the voice of nine States in the Congress of the United States assembled be requisite. ### Article XI
Canada acceding to this confederation, and adjoining in the measures of the United States, shall be admitted into, and entitled to all the advantages of this Union; but no other colony shall be admitted into the same, unless such admission be agreed to by nine States.

--- chunk_id: chunk-0017
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 513
content_hash: 5011c6a5148fb07e
prev_chunk_id: chunk-0016
next_chunk_id: chunk-0018
section_heading: Article XII
document_type: technical_reference

## Article XII

All bills of credit emitted, monies borrowed, and debts contracted by, or under the authority of Congress, before the assembling of the United States, in pursuance of the present confederation, shall be deemed and considered as a charge against the United States, for payment and satisfaction whereof the said United States, and the public faith are hereby solemnly pleged. ### Article XIII
Every State shall abide by the determination of the United States in Congress assembled, on all questions which by this confederation are submitted to them. And the Articles of this Confederation shall be inviolably observed by every State, and the Union shall be perpetual; nor shall any alteration at any time hereafter be made in any of them; unless such alteration be agreed to in a Congress of the United States, and be afterwards confirmed by the legislatures of every State. And Whereas it hath pleased the Great Governor of the World to incline the hearts of the legislatures we respectively represent in Congress, to approve of, and to authorize us to ratify the said Articles of Confederation and perpetual Union. Know Ye that we the undersigned delegates, by virtue of the power and authority to us given for that purpose, do by these presents, in the name and in behalf of our respective constituents, fully and entirely ratify and confirm each and every of the said Articles of Confederation and perpetual Union, and all and singular the matters and things therein contained: And we do further solemnly plight and engage the faith of our respective constituents, that they shall abide by the determinations of the United States in Congress assembled, on all questions, which by the said Confederation are submitted to them. And that the Articles thereof shall be inviolably observed by the States we respectively represent, and that the Union shall be perpetual. In Witness whereof we have hereunto set our hands in Congress. Done at Philadelphia in the State of Pennsylvania the ninth day of July in the Year of our Lord One Thousand Seven Hundred and Seventy-Eight, and in the Third Year of the independence of America. Agreed to by Congress 15 November 1777 In force after ratification by Maryland, 1 March 1781 

Source:

Documents Illustrative of the Formation of the Union of the American States.

--- chunk_id: chunk-0018
source_document: Articles_of_Confederation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 113
content_hash: 30f024f7cc2fa0e9
prev_chunk_id: chunk-0017
next_chunk_id: null
section_heading: Article XII
document_type: technical_reference

Done at Philadelphia in the State of Pennsylvania the ninth day of July in the Year of our Lord One Thousand Seven Hundred and Seventy-Eight, and in the Third Year of the independence of America. Agreed to by Congress 15 November 1777 In force after ratification by Maryland, 1 March 1781 

Source:

Documents Illustrative of the Formation of the Union of the American States. Government Printing Office, 1927. House Document No. 398. Selected, Arranged and Indexed by Charles C. Tansill

18th Century Page
Constitution Page
