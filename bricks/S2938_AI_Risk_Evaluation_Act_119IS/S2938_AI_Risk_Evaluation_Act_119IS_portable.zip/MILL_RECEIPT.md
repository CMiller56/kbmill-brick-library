# Mill receipt — S2938_AI_Risk_Evaluation_Act_119IS

KBMill · VectorForge plant
When: 2026-09-16T17:06:16Z

## Charge (for your books)

- Job id: `mfg-e9222554f4`
- Job class: **Small**
- List price: **$149 USD**
- Pay policy: **pay on success only** — this ZIP is the success artifact. Fail = no charge.
- This is a **mill receipt**, not a tax invoice. File it with the ZIP to track spend.

This package was **manufactured**. It is not a chat export and not a file conversion. Something serious happened under the hood.

## What you are holding
- Portable brick — Markdown, `kb.json`, chunks, embeddings
- Residual board — what is muted, what is still open
- Security report — what we scanned, and what we did not
- Craft brief — how to load this brick and who sits next to it

## Plant gauges
- in kb: 8  ·  muted: 0  ·  on RAG: 8
- embedded rows: 8
- ship cue: see residual board
- avg_extraction_quality: 1.0 — text-layer coverage / extractability (pages that produced usable text), not character-level OCR accuracy

## Adjacent bricks
- (none recorded — one brick, or links not yet authored)

## Security
See `SECURITY_REPORT.md` in this package.
Heuristic plant pass. Not a clearance. Does not absolve your system. What to upload, and whether you may share it, is still your trusted people.

## What this is not
- Not a hosted library — download window, then we purge
- Not permission to skip your own controls
- Not one melted mega-KB if this job was a shelf (siblings stay siblings)

Manufactured by the plant. The magazine is not a customer control.
