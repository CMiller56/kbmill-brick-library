# US_Constitution — VectorForge handoff

Customer-maintainable Engine brick from a VectorForge Pro engagement.

- Brick ID: fdbc5b6c-6093-4724-a911-3180b4e9241d
- KB version: 1
- Total chunks: 34
- Schema score: 92.0%
- Quality benchmark: 98.7/100
- Engine version: 1.0.0
- Pro engagement version: 0.1.0
- Security scan: clean

## Version changes
- No history manifest — append a KB update first

## VF Runtime (customer use after engagement)

This brick is intended for **VF Runtime** — Tool 3 of the VectorForge stack:

| Mode | Interface | Job |
|------|-----------|-----|
| **Connect** | Chat client + MCP | Load / search / answer / cite **this one brick** |
| **Maintain** | CLI | `verify-setup`, health, rebuild, re-export |

### Connect (chat + MCP)

**Chat LLM is not included** — install Ollama or point Open-WebUI at your org endpoint.

```bash
python -m vectorforge.mcp.connect
# then in the client: load_kb("US_Constitution")
```

Connect exposes only: `load_kb`, `search_kb`, `answer_with_sources`, `get_chunk_context`, `get_current_template_info` (no factory / build tools).

### Maintain CLI

After installing the pinned `vectorforge` wheel from your engagement package:

```bash
vectorforge-maintain verify-setup US_Constitution
vectorforge-maintain health US_Constitution
vectorforge-maintain rebuild US_Constitution
vectorforge-maintain export US_Constitution
```

Point commands at the unzipped KB folder, or set `VF_KBS_ROOT` to its parent directory.
Optional offline embeds: set `VECTORFORGE_MODEL_CACHE` to a staged models directory (see engagement `runtime/models/` when provided).

## What you can do without the contractor
- Load, search, and cite this brick with VF Runtime Connect
- Re-run health / verify-setup and export an updated portable ZIP
- Append sources and rebuild when Living KB sources are included (when enabled)

## What requires VectorForge Pro (not in this bundle)
- Timeline curation, orchestrator passes, co-pilot engagement templates
- New engagement brick from raw contractor intake
- Mute/drop/fix of junk that should have been cleaned at handoff

## Bundle contents
- Primary Markdown + kb.json + chunks.jsonl
- Embeddings and images when present
- quality_benchmark.json and security_scan.json when saved
- kb_source_hunt_list.md / .html for printable Topics Needed handoff
- KNOWLEDGE_GAPS.md / knowledge_gaps.csv (legacy gap export)
- spreadsheet_trust.json when spreadsheets were ingested (E5)
- sources/ companion originals (e.g. .xlsx) when staged — **system of record**
- bundle_manifest.json for downstream verification (brick_id, versions, quality summary)

Unzip and point MCP `load_kb` at the folder, or ingest chunks.jsonl downstream.

## Context profiles (Connect working set)

VF Runtime **does not bundle a chat LLM** — you supply Ollama or an OpenAI-compatible endpoint.
Profiles describe how much retrieval + history to put in the model window.
Same tools (`load_kb`, `search_kb`, …); different **budgets**. Design foundation: **Comfort ~65k**.

| Profile | Working set | Retrieval posture | Typical use |
|---------|-------------|-------------------|-------------|
| **Slim** | 8–16k | top-k ~3–5; Short snippets; minimal history; no full-brick dump | Small local models, low VRAM, default short Ollama context |
| **Standard** | 24–32k | top-k ~5–8; Moderate top-k; expand 1–3 hits via get_chunk_context | Common local “good enough” stacks |
| **Comfort** | ~65k | top-k ~8–12; Room for tools + history + richer retrieval (design foundation) | Mid GPU / cloud-small |
| **Wide** | 128k+ | top-k ~as needed; Still prefer retrieve; full MD dump only if brick is small | Large-window models (optional) |

**Tips:**
- Start with **Comfort** if the machine allows; drop to **Standard** or **Slim** if answers get lost or VRAM dies.
- Prefer search + a few `get_chunk_context` expansions over pasting the whole brick.
- `load_kb` returns catalog/guidance only — not the full corpus.

## Handoff cleanliness (VF Runtime bar)

- **Status:** `pass`
- **Bar:** no known junk on RAG path (mute / drop / fix at Pro desk)
- Cleanliness bar met — no known on-path junk detected.
- Chunks scanned: 34
- Muted sources: none recorded
- On-path junk / residual chunks: 0

Engagement practice: **clean brick, not labeled junk.** Mute/drop/fix known-bad chunks at the Pro desk; cut-paste repair is fine. Quality fields on residuals are diagnostics, not a substitute for cleaning.
