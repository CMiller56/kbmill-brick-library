---
kb_id: anti-federalist-selections-us-founding-documents
title: Anti-Federalist Selections — US Founding Documents
author: Unknown Author
created_date: 2026-08-05
classification: Internal
confidence_level: High
domain_tags: ["security", "rmf", "ato", "specification", "requirements"]
document_type: Specification
primary_subject: Anti-Federalist Papers Brutus Centinel Federal Farmer
sources: [{"filename": "Anti_Federalist_Selections.md", "path": "docs/library/US_Founding_Documents/Anti_Federalist_Selections/Anti_Federalist_Selections.md", "page_count": 1}]
ingest_provenance: {"captured_at": "2026-08-05T18:37:54.583746", "page_count": 1, "extraction_methods": {"txt": 1}, "avg_extraction_quality": 1.0, "docling_triage_pages": 0, "docling_triage_rate": 0.0, "extraction_stats": null}
dark_data_inferred_fields: ["author", "classification", "confidence_level", "created_date", "document_type", "document_type_confidence", "document_type_inferred", "domain_tags", "ingest_provenance", "kb_id", "sources"]
brick_role: Curated public-domain Anti-Federalist essays (Brutus, Centinel, Cato, Federal Farmer, Agrippa). Series: US Founding Documents. Ratification critique / opposition arguments.
usage_notes: Use for Anti-Federalist concerns (consolidated power, judiciary, bill of rights, representation). Curated reader — not every Anti-Federalist text. Pair with Federalist_Papers and US_Constitution. Not legal advice.
out_of_scope: ["Modern legal advice or litigation strategy", "Current statutory code or case law holdings", "Copyrighted modern commentary or textbooks"]
series: US Founding Documents
document_type_inferred: True
document_type_confidence: 0.676
kb_name: Anti_Federalist_Selections
created: 2026-08-05T18:37:54.583830
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 320
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-08-05T18:40:26.603096
  chunk_count: 320
  strict_air_gapped: true
---

--- chunk_id: chunk-0000
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 106
content_hash: c31903c769978415
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: Anti-Federalist Selections
document_type: specification

# Anti-Federalist Selections

**Series:** US Founding Documents  
**Instrument:** Selected Anti-Federalist essays (1787–1788) opposing or critiquing the proposed Constitution  
**Provenance:** Public-domain essay texts via constitution.org Anti-Federalist Papers collection (historical 18th-century writings). **Out of scope:** Modern legal advice; not a complete critical edition of all Anti-Federalist literature; not a substitute for the Constitution or Federalist Papers. This brick is a **curated reader** of major essays (Brutus, Centinel, Cato, Federal Farmer where available, Agrippa). Editions and attributions of pseudonyms remain scholarly residual. ---

--- chunk_id: chunk-0001
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 388
content_hash: 510631f742349bd2
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
section_heading: Brutus I
document_type: specification

## Brutus I

*Source file: brutus01.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #1



 

 I


18 October 1787


To the Citizens of the State of New-York. When the public is called to investigate and decide upon a question in which
not only the present members of the community are deeply interested, but upon
which the happiness and misery of generations yet unborn is in great measure
suspended, the benevolent mind cannot help feeling itself peculiarly interested
in the result. In this situation, I trust the feeble efforts of an individual, to lead the
minds of the people to a wise and prudent determination, cannot fail of being
acceptable to the candid and dispassionate part of the community. Encouraged by
this consideration, I have been induced to offer my thoughts upon the present
important crisis of our public affairs. Perhaps this country never saw so critical a period in their political
concerns. We have felt the feebleness of the ties by which these United-States
are held together, and the want of sufficient energy in our present
confederation, to manage, in some instances, our general concerns. Various
expedients have been proposed to remedy these evils, but none have succeeded. At length a Convention of the states has been assembled, they have formed a
constitution which will now, probably, be submitted to the people to ratify or
reject, who are the fountain of all power, to whom alone it of right belongs to
make or unmake constitutions, or forms of government, at their pleasure. The
most important question that was ever proposed to your decision, or to the
decision of any people under heaven, is before you, and you are to decide upon
it by men of your own election, chosen specially for this purpose.

--- chunk_id: chunk-0002
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 429
content_hash: 72b7cb40b8256394
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: Brutus I
document_type: specification

At length a Convention of the states has been assembled, they have formed a
constitution which will now, probably, be submitted to the people to ratify or
reject, who are the fountain of all power, to whom alone it of right belongs to
make or unmake constitutions, or forms of government, at their pleasure. The
most important question that was ever proposed to your decision, or to the
decision of any people under heaven, is before you, and you are to decide upon
it by men of your own election, chosen specially for this purpose. If the
constitution, offered to your acceptance, be a wise one, calculated to preserve
the invaluable blessings of liberty, to secure the inestimable rights of
mankind, and promote human happiness, then, if you accept it, you will lay a
lasting foundation of happiness for millions yet unborn; generations to come
will rise up and call you blessed. You may rejoice in the prospects of this
vast extended continent becoming filled with freemen, who will assert the
dignity of human nature. You may solace yourselves with the idea, that society,
in this favoured land, will fast advance to the highest point of perfection;
the human mind will expand in knowledge and virtue, and the golden age be, in
some measure, realised. But if, on the other hand, this form of government
contains principles that will lead to the subversion of liberty — if it
tends to establish a despotism, or, what is worse, a tyrannic aristocracy;
then, if you adopt it, this only remaining assylum for liberty will be shut up,
and posterity will execrate your memory. Momentous then is the question you have to determine, and you are called
upon by every motive which should influence a noble and virtuous mind, to
examine it well, and to make up a wise judgment. It is insisted, indeed, that
this constitution must be received, be it ever so imperfect.

--- chunk_id: chunk-0003
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 357
content_hash: e6487adb7bf6cf89
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: Brutus I
document_type: specification

Momentous then is the question you have to determine, and you are called
upon by every motive which should influence a noble and virtuous mind, to
examine it well, and to make up a wise judgment. It is insisted, indeed, that
this constitution must be received, be it ever so imperfect. If it has its
defects, it is said, they can be best amended when they are experienced. But
remember, when the people once part with power, they can seldom or never resume
it again but by force. Many instances can be produced in which the people have
voluntarily increased the powers of their rulers; but few, if any, in which
rulers have willingly abridged their authority. This is a sufficient reason to
induce you to be careful, in the first instance, how you deposit the powers of
government. With these few introductory remarks, I shall proceed to a consideration of
this constitution:


The first question that presents itself on the subject is, whether a
confederated government be the best for the United States or not? Or in other
words, whether the thirteen United States should be reduced to one great
republic, governed by one legislature, and under the direction of one executive
and judicial; or whether they should continue thirteen confederated republics,
under the direction and controul of a supreme federal head for certain defined
national purposes only? This enquiry is important, because, although the government reported by the
convention does not go to a perfect and entire consolidation, yet it approaches
so near to it, that it must, if executed, certainly and infallibly terminate in
it.

--- chunk_id: chunk-0004
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 430
content_hash: 175fa314214e837e
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: Brutus I
document_type: specification

Or in other
words, whether the thirteen United States should be reduced to one great
republic, governed by one legislature, and under the direction of one executive
and judicial; or whether they should continue thirteen confederated republics,
under the direction and controul of a supreme federal head for certain defined
national purposes only? This enquiry is important, because, although the government reported by the
convention does not go to a perfect and entire consolidation, yet it approaches
so near to it, that it must, if executed, certainly and infallibly terminate in
it. This government is to possess absolute and uncontroulable power,
legislative, executive and judicial, with respect to every object to which it
extends, for by the last clause of section 8th, article 1st, it is declared
"that the Congress shall have power to make all laws which shall be
necessary and proper for carrying into execution the foregoing powers, and all
other powers vested by this constitution, in the government of the United
States; or in any department or office thereof." And by the 6th article,
it is declared "that this constitution, and the laws of the United States,
which shall be made in pursuance thereof, and the treaties made, or which shall
be made, under the authority of the United States, shall be the supreme law of
the land; and the judges in every state shall be bound thereby, any thing in
the constitution, or law of any state to the contrary notwithstanding." It
appears from these articles that there is no need of any intervention of the
state governments, between the Congress and the people, to execute any one
power vested in the general government, and that the constitution and laws of
every state are nullified and declared void, so far as they are or shall be
inconsistent with this constitution, or the laws made in pursuance of it, or
with treaties made under the authority of the United States.

--- chunk_id: chunk-0005
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 449
content_hash: 7004ff04bcf9848a
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
section_heading: Brutus I
document_type: specification

This enquiry is important, because, although the government reported by the
convention does not go to a perfect and entire consolidation, yet it approaches
so near to it, that it must, if executed, certainly and infallibly terminate in
it. This government is to possess absolute and uncontroulable power,
legislative, executive and judicial, with respect to every object to which it
extends, for by the last clause of section 8th, article 1st, it is declared
"that the Congress shall have power to make all laws which shall be
necessary and proper for carrying into execution the foregoing powers, and all
other powers vested by this constitution, in the government of the United
States; or in any department or office thereof." And by the 6th article,
it is declared "that this constitution, and the laws of the United States,
which shall be made in pursuance thereof, and the treaties made, or which shall
be made, under the authority of the United States, shall be the supreme law of
the land; and the judges in every state shall be bound thereby, any thing in
the constitution, or law of any state to the contrary notwithstanding." It
appears from these articles that there is no need of any intervention of the
state governments, between the Congress and the people, to execute any one
power vested in the general government, and that the constitution and laws of
every state are nullified and declared void, so far as they are or shall be
inconsistent with this constitution, or the laws made in pursuance of it, or
with treaties made under the authority of the United States. — The
government then, so far as it extends, is a complete one, and not a
confederation. It is as much one complete government as that of New-York or
Massachusetts, has as absolute and perfect powers to make and execute all laws,
to appoint officers, institute courts, declare offences, and annex penalties,
with respect to every object to which it extends, as any other in the world.

--- chunk_id: chunk-0006
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 322
content_hash: f8a244ac33ab1956
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: Brutus I
document_type: specification

— The
government then, so far as it extends, is a complete one, and not a
confederation. It is as much one complete government as that of New-York or
Massachusetts, has as absolute and perfect powers to make and execute all laws,
to appoint officers, institute courts, declare offences, and annex penalties,
with respect to every object to which it extends, as any other in the world. So
far therefore as its powers reach, all ideas of confederation are given up and
lost. It is true this government is limited to certain objects, or to speak
more properly, some small degree of power is still left to the states, but a
little attention to the powers vested in the general government, will convince
every candid man, that if it is capable of being executed, all that is reserved
for the individual states must very soon be annihilated, except so far as they
are barely necessary to the organization of the general government. The powers
of the general legislature extend to every case that is of the least importance
— there is nothing valuable to human nature, nothing dear to freemen, but
what is within its power. It has authority to make laws which will affect the
lives, the liberty, and property of every man in the United States; nor can the
constitution or laws of any state, in any way prevent or impede the full and
complete execution of every power given.

--- chunk_id: chunk-0007
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 413
content_hash: 0758afd7e168caa1
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: Brutus I
document_type: specification

The powers
of the general legislature extend to every case that is of the least importance
— there is nothing valuable to human nature, nothing dear to freemen, but
what is within its power. It has authority to make laws which will affect the
lives, the liberty, and property of every man in the United States; nor can the
constitution or laws of any state, in any way prevent or impede the full and
complete execution of every power given. The legislative power is competent to
lay taxes, duties, imposts, and excises; — there is no limitation to this
power, unless it be said that the clause which directs the use to which those
taxes, and duties shall be applied, may be said to be a limitation: but this is
no restriction of the power at all, for by this clause they are to be applied
to pay the debts and provide for the common defence and general welfare of the
United States; but the legislature have authority to contract debts at their
discretion; they are the sole judges of what is necessary to provide for the
common defence, and they only are to determine what is for the general welfare;
this power therefore is neither more nor less, than a power to lay and collect
taxes, imposts, and excises, at their pleasure; not only [is] the power to lay
taxes unlimited, as to the amount they may require, but it is perfect and
absolute to raise them in any mode they please. No state legislature, or any
power in the state governments, have any more to do in carrying this into
effect, than the authority of one state has to do with that of another. In the
business therefore of laying and collecting taxes, the idea of confederation is
totally lost, and that of one entire republic is embraced.

--- chunk_id: chunk-0008
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: f248d919f0dfb447
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: Brutus I
document_type: specification

No state legislature, or any
power in the state governments, have any more to do in carrying this into
effect, than the authority of one state has to do with that of another. In the
business therefore of laying and collecting taxes, the idea of confederation is
totally lost, and that of one entire republic is embraced. It is proper here to
remark, that the authority to lay and collect taxes is the most important of
any power that can be granted; it connects with it almost all other powers, or
at least will in process of time draw all other after it; it is the great mean
of protection, security, and defence, in a good government, and the great
engine of oppression and tyranny in a bad one. This cannot fail of being the
case, if we consider the contracted limits which are set by this constitution,
to the late [state?] governments, on this article of raising money. No state
can emit paper money — lay any duties, or imposts, on imports, or exports,
but by consent of the Congress; and then the net produce shall be for the
benefit of the United States: the only mean therefore left, for any state to
support its government and discharge its debts, is by direct taxation; and the
United States have also power to lay and collect taxes, in any way they please. Every one who has thought on the subject, must be convinced that but small sums
of money can be collected in any country, by direct taxe[s], when the foederal
government begins to exercise the right of taxation in all its parts, the
legislatures of the several states will find it impossible to raise monies to
support their governments. Without money they cannot be supported, and they
must dwindle away, and, as before observed, their powers absorbed in that of
the general government.

--- chunk_id: chunk-0009
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 436
content_hash: d743bf88cf4a554c
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
section_heading: Brutus I
document_type: specification

Every one who has thought on the subject, must be convinced that but small sums
of money can be collected in any country, by direct taxe[s], when the foederal
government begins to exercise the right of taxation in all its parts, the
legislatures of the several states will find it impossible to raise monies to
support their governments. Without money they cannot be supported, and they
must dwindle away, and, as before observed, their powers absorbed in that of
the general government. It might be here shewn, that the power in the federal legislative, to raise
and support armies at pleasure, as well in peace as in war, and their controul
over the militia, tend, not only to a consolidation of the government, but the
destruction of liberty. — I shall not, however, dwell upon these, as a few
observations upon the judicial power of this government, in addition to the
preceding, will fully evince the truth of the position. The judicial power of the United States is to be vested in a supreme court,
and in such inferior courts as Congress may from time to time ordain and
establish. The powers of these courts are very extensive; their jurisdiction
comprehends all civil causes, except such as arise between citizens of the same
state; and it extends to all cases in law and equity arising under the
constitution. One inferior court must be established, I presume, in each state,
at least, with the necessary executive officers appendant thereto. It is easy
to see, that in the common course of things, these courts will eclipse the
dignity, and take away from the respectability, of the state courts. These
courts will be, in themselves, totally independent of the states, deriving
their authority from the United States, and receiving from them fixed salaries;
and in the course of human events it is to be expected, that they will swallow
up all the powers of the courts in the respective states.

--- chunk_id: chunk-0010
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 438
content_hash: 95b8fa1732966675
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
section_heading: Brutus I
document_type: specification

It is easy
to see, that in the common course of things, these courts will eclipse the
dignity, and take away from the respectability, of the state courts. These
courts will be, in themselves, totally independent of the states, deriving
their authority from the United States, and receiving from them fixed salaries;
and in the course of human events it is to be expected, that they will swallow
up all the powers of the courts in the respective states. How far the clause in the 8th section of the 1st article may operate to do
away all idea of confederated states, and to effect an entire consolidation of
the whole into one general government, it is impossible to say. The powers
given by this article are very general and comprehensive, and it may receive a
construction to justify the passing almost any law. A power to make all laws,
which shall be necessary and proper, for carrying into execution, all
powers vested by the constitution in the government of the United States, or
any department or officer thereof, is a power very comprehensive and definite
[indefinite?], and may, for ought I know, be exercised in a such manner as
entirely to abolish the state legislatures. Suppose the legislature of a state
should pass a law to raise money to support their government and pay the state
debt, may the Congress repeal this law, because it may prevent the collection
of a tax which they may think proper and necessary to lay, to provide for the
general welfare of the United States? For all laws made, in pursuance of this
constitution, are the supreme lay of the land, and the judges in every state
shall be bound thereby, any thing in the constitution or laws of the different
states to the contrary notwithstanding. — By such a law, the government of
a particular state might be overturned at one stroke, and thereby be deprived
of every means of its support.

--- chunk_id: chunk-0011
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 429
content_hash: b730bdd1261410fd
prev_chunk_id: chunk-0010
next_chunk_id: chunk-0012
section_heading: Brutus I
document_type: specification

For all laws made, in pursuance of this
constitution, are the supreme lay of the land, and the judges in every state
shall be bound thereby, any thing in the constitution or laws of the different
states to the contrary notwithstanding. — By such a law, the government of
a particular state might be overturned at one stroke, and thereby be deprived
of every means of its support. It is not meant, by stating this case, to insinuate that the constitution
would warrant a law of this kind; or unnecessarily to alarm the fears of the
people, by suggesting, that the federal legislature would be more likely to
pass the limits assigned them by the constitution, than that of an individual
state, further than they are less responsible to the people. But what is meant
is, that the legislature of the United States are vested with the great and
uncontroulable powers, of laying and collecting taxes, duties, imposts, and
excises; of regulating trade, raising and supporting armies, organizing,
arming, and disciplining the militia, instituting courts, and other general
powers. And are by this clause invested with the power of making all laws,
proper and necessary, for carrying all these into execution; and they
may so exercise this power as entirely to annihilate all the state governments,
and reduce this country to one single government. And if they may do it, it is
pretty certain they will; for it will be found that the power retained by
individual states, small as it is, will be a clog upon the wheels of the
government of the United States; the latter therefore will be naturally
inclined to remove it out of the way. Besides, it is a truth confirmed by the
unerring experience of ages, that every man, and every body of men, invested
with power, are ever disposed to increase it, and to acquire a superiority over
every thing that stands in their way.

--- chunk_id: chunk-0012
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 398
content_hash: 876e91207342a5dc
prev_chunk_id: chunk-0011
next_chunk_id: chunk-0013
section_heading: Brutus I
document_type: specification

And if they may do it, it is
pretty certain they will; for it will be found that the power retained by
individual states, small as it is, will be a clog upon the wheels of the
government of the United States; the latter therefore will be naturally
inclined to remove it out of the way. Besides, it is a truth confirmed by the
unerring experience of ages, that every man, and every body of men, invested
with power, are ever disposed to increase it, and to acquire a superiority over
every thing that stands in their way. This disposition, which is implanted in
human nature, will operate in the federal legislature to lessen and ultimately
to subvert the state authority, and having such advantages, will most certainly
succeed, if the federal government succeeds at all. It must be very evident
then, that what this constitution wants of being a complete consolidation of
the several parts of the union into one complete government, possessed of
perfect legislative, judicial, and executive powers, to all intents and
purposes, it will necessarily acquire in its exercise and operation. Let us now proceed to enquire, as I at first proposed, whether it be best
the thirteen United States should be reduced to one great republic, or not? It
is here taken for granted, that all agree in this, that whatever government we
adopt, it ought to be a free one; that it should be so framed as to secure the
liberty of the citizens of America, and such an one as to admit of a full,
fair, and equal representation of the people. The question then will be,
whether a government thus constituted, and founded on such principles, is
practicable, and can be exercised over the whole United States, reduced into
one state?

--- chunk_id: chunk-0013
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 442
content_hash: ea6acd03bdbbc574
prev_chunk_id: chunk-0012
next_chunk_id: chunk-0014
section_heading: Brutus I
document_type: specification

It
is here taken for granted, that all agree in this, that whatever government we
adopt, it ought to be a free one; that it should be so framed as to secure the
liberty of the citizens of America, and such an one as to admit of a full,
fair, and equal representation of the people. The question then will be,
whether a government thus constituted, and founded on such principles, is
practicable, and can be exercised over the whole United States, reduced into
one state? If respect is to be paid to the opinion of the greatest and wisest men who
have ever thought or wrote on the science of government, we shall be
constrained to conclude, that a free republic cannot succeed over a country of
such immense extent, containing such a number of inhabitants, and these
encreasing in such rapid progression as that of the whole United States. Among
the many illustrious authorities which might be produced to this point, I shall
content myself with quoting only two. The one is the baron de Montesquieu,
spirit of laws, chap. xvi. vol. I [book VIII]. "It is natural to a
republic to have only a small territory, otherwise it cannot long subsist. In a
large republic there are men of large fortunes, and consequently of less
moderation; there are trusts too great to be placed in any single subject; he
has interest of his own; he soon begins to think that he may be happy, great
and glorious, by oppressing his fellow citizens; and that he may raise himself
to grandeur on the ruins of his country. In a large republic, the public good
is sacrificed to a thousand views; it is subordinate to exceptions, and depends
on accidents. In a small one, the interest of the public is easier perceived,
better understood, and more within the reach of every citizen; abuses are of
less extent, and of course are less protected." Of the same opinion is the
marquis Beccarari.

--- chunk_id: chunk-0014
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 397
content_hash: 00dfcabe413a26d6
prev_chunk_id: chunk-0013
next_chunk_id: chunk-0015
section_heading: Brutus I
document_type: specification

In a large republic, the public good
is sacrificed to a thousand views; it is subordinate to exceptions, and depends
on accidents. In a small one, the interest of the public is easier perceived,
better understood, and more within the reach of every citizen; abuses are of
less extent, and of course are less protected." Of the same opinion is the
marquis Beccarari. History furnishes no example of a free republic, any thing like the extent
of the United States. The Grecian republics were of small extent; so also was
that of the Romans. Both of these, it is true, in process of time, extended
their conquests over large territories of country; and the consequence was,
that their governments were changed from that of free governments to those of
the most tyrannical that ever existed in the world. Not only the opinion of the greatest men, and the experience of mankind, are
against the idea of an extensive republic, but a variety of reasons may be
drawn from the reason and nature of things, against it. In every government,
the will of the sovereign is the law. In despotic governments, the supreme
authority being lodged in one, his will is law, and can be as easily expressed
to a large extensive territory as to a small one. In a pure democracy the
people are the sovereign, and their will is declared by themselves; for this
purpose they must all come together to deliberate, and decide. This kind of
government cannot be exercised, therefore, over a country of any considerable
extent; it must be confined to a single city, or at least limited to such
bounds as that the people can conveniently assemble, be able to debate,
understand the subject submitted to them, and declare their opinion concerning
it.

--- chunk_id: chunk-0015
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: 7431ba746f8b2949
prev_chunk_id: chunk-0014
next_chunk_id: chunk-0016
section_heading: Brutus I
document_type: specification

In a pure democracy the
people are the sovereign, and their will is declared by themselves; for this
purpose they must all come together to deliberate, and decide. This kind of
government cannot be exercised, therefore, over a country of any considerable
extent; it must be confined to a single city, or at least limited to such
bounds as that the people can conveniently assemble, be able to debate,
understand the subject submitted to them, and declare their opinion concerning
it. In a free republic, although all laws are derived from the consent of the
people, yet the people do not declare their consent by themselves in person,
but by representatives, chosen by them, who are supposed to know the minds of
their constituents, and to be possessed of integrity to declare this mind. In every free government, the people must give their assent to the laws by
which they are governed. This is the true criterion between a free government
and an arbitrary one. The former are ruled by the will of the whole, expressed
in any manner they may agree upon; the latter by the will of one, or a few. If
the people are to give their assent to the laws, by persons chosen and
appointed by them, the manner of the choice and the number chosen, must be
such, as to possess, be disposed, and consequently qualified to declare the
sentiments of the people; for if they do not know, or are not disposed to speak
the sentiments of the people, the people do not govern, but the sovereignty is
in a few. Now, in a large extended country, it is impossible to have a
representation, possessing the sentiments, and of integrity, to declare the
minds of the people, without having it so numerous and unwieldly, as to be
subject in great measure to the inconveniency of a democratic government.

--- chunk_id: chunk-0016
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 432
content_hash: 002dee9d8ba50d65
prev_chunk_id: chunk-0015
next_chunk_id: chunk-0017
section_heading: Brutus I
document_type: specification

If
the people are to give their assent to the laws, by persons chosen and
appointed by them, the manner of the choice and the number chosen, must be
such, as to possess, be disposed, and consequently qualified to declare the
sentiments of the people; for if they do not know, or are not disposed to speak
the sentiments of the people, the people do not govern, but the sovereignty is
in a few. Now, in a large extended country, it is impossible to have a
representation, possessing the sentiments, and of integrity, to declare the
minds of the people, without having it so numerous and unwieldly, as to be
subject in great measure to the inconveniency of a democratic government. The territory of the United States is of vast extent; it now contains near
three millions of souls, and is capable of containing much more than ten times
that number. Is it practicable for a country, so large and so numerous as they
will soon become, to elect a representation, that will speak their sentiments,
without their becoming so numerous as to be incapable of transacting public
business? It certainly is not. In a republic, the manners, sentiments, and interests of the people should
be similar. If this be not the case, there will be a constant clashing of
opinions; and the representatives of one part will be continually striving
against those of the other. This will retard the operations of government, and
prevent such conclusions as will promote the public good. If we apply this
remark to the condition of the United States, we shall be convinced that it
forbids that we should be one government. The United States includes a variety
of climates. The productions of the different parts of the union are very
variant, and their interests, of consequence, diverse. Their manners and habits
differ as much as their climates and productions; and their sentiments are by
no means coincident.

--- chunk_id: chunk-0017
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 394
content_hash: 7df1311a00f03179
prev_chunk_id: chunk-0016
next_chunk_id: chunk-0018
section_heading: Brutus I
document_type: specification

The productions of the different parts of the union are very
variant, and their interests, of consequence, diverse. Their manners and habits
differ as much as their climates and productions; and their sentiments are by
no means coincident. The laws and customs of the several states are, in many
respects, very diverse, and in some opposite; each would be in favor of its own
interests and customs, and, of consequence, a legislature, formed of
representatives from the respective parts, would not only be too numerous to
act with any care or decision, but would be composed of such heterogenous and
discordant principles, as would constantly be contending with each other. The laws cannot be executed in a republic, of an extent equal to that of the
United States, with promptitude. The magistrates in every government must be supported in the execution of
the laws, either by an armed force, maintained at the public expence for that
purpose; or by the people turning out to aid the magistrate upon his command,
in case of resistance. In despotic governments, as well as in all the monarchies of Europe,
standing armies are kept up to execute the commands of the prince or the
magistrate, and are employed for this purpose when occasion requires: But they
have always proved the destruction of liberty, and [are] abhorrent to the
spirit of a free republic. In England, where they depend upon the parliament
for their annual support, they have always been complained of as oppressive and
unconstitutional, and are seldom employed in executing of the laws; never
except on extraordinary occasions, and then under the direction of a civil
magistrate. A free republic will never keep a standing army to execute its laws. It must
depend upon the support of its citizens.

--- chunk_id: chunk-0018
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 442
content_hash: df7ba3187c7db378
prev_chunk_id: chunk-0017
next_chunk_id: chunk-0019
section_heading: Brutus I
document_type: specification

A free republic will never keep a standing army to execute its laws. It must
depend upon the support of its citizens. But when a government is to receive
its support from the aid of the citizens, it must be so constructed as to have
the confidence, respect, and affection of the people." Men who, upon the
call of the magistrate, offer themselves to execute the laws, are influenced to
do it either by affection to the government, or from fear; where a standing
army is at hand to punish offenders, every man is actuated by the latter
principle, and therefore, when the magistrate calls, will obey: but, where this
is not the case, the government must rest for its support upon the confidence
and respect which the people have for their government and laws. The body of
the people being attached, the government will always be sufficient to support
and execute its laws, and to operate upon the fears of any faction which may be
opposed to it, not only to prevent an opposition to the execution of the laws
themselves, but also to compel the most of them to aid the magistrate; but the
people will not be likely to have such confidence in their rulers, in a
republic so extensive as the United States, as necessary for these purposes. The confidence which the people have in their rulers, in a free republic,
arises from their knowing them, from their being responsible to them for their
conduct, and from the power they have of displacing them when they misbehave:
but in a republic of the extent of this continent, the people in general would
be acquainted with very few of their rulers: the people at large would know
little of their proceedings, and it would be extremely difficult to change
them. The people in Georgia and New-Hampshire would not know one another's
mind, and therefore could not act in concert to enable them to effect a general
change of representatives.

--- chunk_id: chunk-0019
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 430
content_hash: 69464bf3f7ae873d
prev_chunk_id: chunk-0018
next_chunk_id: chunk-0020
section_heading: Brutus I
document_type: specification

The confidence which the people have in their rulers, in a free republic,
arises from their knowing them, from their being responsible to them for their
conduct, and from the power they have of displacing them when they misbehave:
but in a republic of the extent of this continent, the people in general would
be acquainted with very few of their rulers: the people at large would know
little of their proceedings, and it would be extremely difficult to change
them. The people in Georgia and New-Hampshire would not know one another's
mind, and therefore could not act in concert to enable them to effect a general
change of representatives. The different parts of so extensive a country could
not possibly be made acquainted with the conduct of their representatives, nor
be informed of the reasons upon which measures were founded. The consequence
will be, they will have no confidence in their legislature, suspect them of
ambitious views, be jealous of every measure they adopt, and will not support
the laws they pass. Hence the government will be nerveless and inefficient, and
no way will be left to render it otherwise, but by establishing an armed force
to execute the laws at the point of the bayonet — a government of all
others the most to be dreaded. In a republic of such vast extent as the United-States, the legislature
cannot attend to the various concerns and wants of its different parts. It
cannot be sufficiently numerous to be acquainted with the local condition and
wants of the different districts, and if it could, it is impossible it should
have sufficient time to attend to and provide for all the variety of cases of
this nature, that would be continually arising. In so extensive a republic, the great officers of government would soon
become above the controul of the people, and abuse their power to the purpose
of aggrandizing themselves, and oppressing them.

--- chunk_id: chunk-0020
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 398
content_hash: 71932fe6c21ff53e
prev_chunk_id: chunk-0019
next_chunk_id: chunk-0021
section_heading: Brutus I
document_type: specification

It
cannot be sufficiently numerous to be acquainted with the local condition and
wants of the different districts, and if it could, it is impossible it should
have sufficient time to attend to and provide for all the variety of cases of
this nature, that would be continually arising. In so extensive a republic, the great officers of government would soon
become above the controul of the people, and abuse their power to the purpose
of aggrandizing themselves, and oppressing them. The trust committed to the
executive offices, in a country of the extent of the United-States, must be
various and of magnitude. The command of all the troops and navy of the
republic, the appointment of officers, the power of pardoning offences, the
collecting of all the public revenues, and the power of expending them, with a
number of other powers, must be lodged and exercised in every state, in the
hands of a few. When these are attended with great honor and emolument, as they
always will be in large states, so as greatly to interest men to pursue them,
and to be proper objects for ambitious and designing men, such men will be ever
restless in their pursuit after them. They will use the power, when they have
acquired it, to the purposes of gratifying their own interest and ambition, and
it is scarcely possible, in a very large republic, to call them to account for
their misconduct, or to prevent their abuse of power. These are some of the reasons by which it appears, that a free republic
cannot long subsist over a country of the great extent of these states. If then
this new constitution is calculated to consolidate the thirteen states into
one, as it evidently is, it ought not to be adopted.

--- chunk_id: chunk-0021
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 321
content_hash: d8ce1dde5c1b089a
prev_chunk_id: chunk-0020
next_chunk_id: chunk-0022
section_heading: Brutus I
document_type: specification

These are some of the reasons by which it appears, that a free republic
cannot long subsist over a country of the great extent of these states. If then
this new constitution is calculated to consolidate the thirteen states into
one, as it evidently is, it ought not to be adopted. Though I am of opinion, that it is a sufficient objection to this
government, to reject it, that it creates the whole union into one government,
under the form of a republic, yet if this objection was obviated, there are
exceptions to it, which are so material and fundamental, that they ought to
determine every man, who is a friend to the liberty and happiness of mankind,
not to adopt it. I beg the candid and dispassionate attention of my countrymen
while I state these objections — they are such as have obtruded themselves
upon my mind upon a careful attention to the matter, and such as I sincerely
believe are well founded. There are many objections, of small moment, of which
I shall take no notice — perfection is not to be expected in any thing
that is the production of man — and if I did not in my conscience believe
that this scheme was defective in the fundamental principles — in the
foundation upon which a free and equal government must rest — I would hold
my peace. Brutus. Next | Text Version | Brutus Contents |

--- chunk_id: chunk-0022
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 422
content_hash: eb26ba5b14ff3373
prev_chunk_id: chunk-0021
next_chunk_id: chunk-0023
section_heading: Brutus II
document_type: specification

## Brutus II

*Source file: brutus02.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #2



 

 II


 1 November 1787


To the Citizens of the State of New-York. I flatter myself that my last address established this position, that to
reduce the Thirteen States into one government, would prove the destruction of
your liberties. But lest this truth should be doubted by some, I will now proceed to
consider its merits. Though it should be admitted, that the argument[s] against reducing all the
states into one consolidated government, are not sufficient fully to establish
this point; yet they will, at least, justify this conclusion, that in forming a
constitution for such a country, great care should be taken to limit and
definite its powers, adjust its parts, and guard against an abuse of authority. How far attention has been paid to these objects, shall be the subject of
future enquiry. When a building is to be erected which is intended to stand for
ages, the foundation should be firmly laid. The constitution proposed to your
acceptance, is designed not for yourselves alone, but for generations yet
unborn. The principles, therefore, upon which the social compact is founded,
ought to have been clearly and precisely stated, and the most express and full
declaration of rights to have been made — But on this subject there is
almost an entire silence. If we may collect the sentiments of the people of America, from their own
most solemn declarations, they hold this truth as self evident, that all men
are by nature free. No one man, therefore, or any class of men, have a right,
by the law of nature, or of God, to assume or exercise authority over their
fellows. The origin of society then is to be sought, not in any natural right
which one man has to exercise authority over another, but in the united consent
of those who associate.

--- chunk_id: chunk-0023
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 434
content_hash: da9adaa945bc4b31
prev_chunk_id: chunk-0022
next_chunk_id: chunk-0024
section_heading: Brutus II
document_type: specification

No one man, therefore, or any class of men, have a right,
by the law of nature, or of God, to assume or exercise authority over their
fellows. The origin of society then is to be sought, not in any natural right
which one man has to exercise authority over another, but in the united consent
of those who associate. The mutual wants of men, at first dictated the
propriety of forming societies; and when they were established, protection and
defence pointed out the necessity of instituting government. In a state of
nature every individual pursues his own interest; in this pursuit it frequently
happened, that the possessions or enjoyments of one were sacrificed to the
views and designs of another; thus the weak were a prey to the strong, the
simple and unwary were subject to impositions from those who were more crafty
and designing. In this state of things, every individual was insecure; common
interest therefore directed, that government should be established, in which
the force of the whole community should be collected, and under such
directions, as to protect and defend every one who composed it. The common
good, therefore, is the end of civil government, and common consent, the
foundation on which it is established. To effect this end, it was necessary
that a certain portion of natural liberty should be surrendered, in order, that
what remained should be preserved: how great a proportion of natural freedom is
necessary to be yielded by individuals, when they submit to government, I shall
not now enquire. So much, however, must be given up, as will be sufficient to
enable those, to whom the administration of the government is committed, to
establish laws for the promoting the happiness of the community, and to carry
those laws into effect. But it is not necessary, for this purpose, that
individuals should relinquish all their natural rights. Some are of such a
nature that they cannot be surrendered.

--- chunk_id: chunk-0024
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 452
content_hash: ef5d3198d5ee9858
prev_chunk_id: chunk-0023
next_chunk_id: chunk-0025
section_heading: Brutus II
document_type: specification

But it is not necessary, for this purpose, that
individuals should relinquish all their natural rights. Some are of such a
nature that they cannot be surrendered. Of this kind are the rights of
conscience, the right of enjoying and defending life, etc. Others are not
necessary to be resigned, in order to attain the end for which government is
instituted, these therefore ought not to be given up. To surrender them, would
counteract the very end of government, to wit, the common good. From these
observations it appears, that in forming a government on its true principles,
the foundation should be laid in the manner I before stated, by expressly
reserving to the people such of their essential natural rights, as are not
necessary to be parted with. The same reasons which at first induced mankind to
associate and institute government, will operate to influence them to observe
this precaution. If they had been disposed to conform themselves to the rule of
immutable righteousness, government would not have been requisite. It was
because one part exercised fraud, oppression, and violence on the other, that
men came together, and agreed that certain rules should be formed, to regulate
the conduct of all, and the power of the whole community lodged in the hands of
rulers to enforce an obedience to them. But rulers have the same propensities
as other men; they are as likely to use the power with which they are vested
for private purposes, and to the injury and oppression of those over whom they
are placed, as individuals in a state of nature are to injure and oppress one
another. It is therefore as proper that bounds should be set to their
authority, as that government should have at first been instituted to restrain
private injuries. This principle, which seems so evidently founded in the reason and nature of
things, is confirmed by universal experience. Those who have governed, have
been found in all ages ever active to enlarge their powers and abridge the
public liberty.

--- chunk_id: chunk-0025
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 412
content_hash: cb76ec7a0eda297f
prev_chunk_id: chunk-0024
next_chunk_id: chunk-0026
section_heading: Brutus II
document_type: specification

This principle, which seems so evidently founded in the reason and nature of
things, is confirmed by universal experience. Those who have governed, have
been found in all ages ever active to enlarge their powers and abridge the
public liberty. This has induced the people in all countries, where any sense
of freedom remained, to fix barriers against the encroachments of their rulers. The country from which we have derived our origin, is an eminent example of
this. Their magna charta and bill of rights have long been the boast, as well
as the security, of that nation. I need say no more, I presume, to an American,
than, that this principle is a fundamental one, in all the constitutions of our
own states; there is not one of them but what is either founded on a
declaration or bill of rights, or has certain express reservation of rights
interwoven in the body of them. From this it appears, that at a time when the
pulse of liberty beat high and when an appeal was made to the people to form
constitutions for the government of themselves, it was their universal sense,
that such declarations should make a part of their frames of government. It is
therefore the more astonishing, that this grand security, to the rights of the
people, is not to be found in this constitution. It has been said, in answer to this objection, that such declaration[s] of
rights, however requisite they might be in the constitutions of the states, are
not necessary in the general constitution, because, "in the former case,
every thing which is not reserved is given, but in the latter the reverse of
the proposition prevails, and every thing which is not given is reserved."
It requires but little attention to discover, that this mode of reasoning is
rather specious than solid.

--- chunk_id: chunk-0026
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 441
content_hash: 9beb109640609d3a
prev_chunk_id: chunk-0025
next_chunk_id: chunk-0027
section_heading: Brutus II
document_type: specification

It is
therefore the more astonishing, that this grand security, to the rights of the
people, is not to be found in this constitution. It has been said, in answer to this objection, that such declaration[s] of
rights, however requisite they might be in the constitutions of the states, are
not necessary in the general constitution, because, "in the former case,
every thing which is not reserved is given, but in the latter the reverse of
the proposition prevails, and every thing which is not given is reserved."
It requires but little attention to discover, that this mode of reasoning is
rather specious than solid. The powers, rights, and authority, granted to the
general government by this constitution, are as complete, with respect to every
object to which they extend, as that of any state government — It reaches
to every thing which concerns human happiness — Life, liberty, and
property, are under its controul. There is the same reason, therefore, that the
exercise of power, in this case, should be restrained within proper limits, as
in that of the state governments. To set this matter in a clear light, permit
me to instance some of the articles of the bills of rights of the individual
states, and apply them to the case in question. For the security of life, in criminal prosecutions, the bills of rights of
most of the states have declared, that no man shall be held to answer for a
crime until he is made fully acquainted with the charge brought against him; he
shall not be compelled to accuse, or furnish evidence against himself —
The witnesses against him shall be brought face to face, and he shall be fully
heard by himself or counsel. That it is essential to the security of life and
liberty, that trial of facts be in the vicinity where they happen. Are not
provisions of this kind as necessary in the general government, as in that of a
particular state?

--- chunk_id: chunk-0027
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: 82b637fc494f0133
prev_chunk_id: chunk-0026
next_chunk_id: chunk-0028
section_heading: Brutus II
document_type: specification

That it is essential to the security of life and
liberty, that trial of facts be in the vicinity where they happen. Are not
provisions of this kind as necessary in the general government, as in that of a
particular state? The powers vested in the new Congress extend in many cases to
life; they are authorised to provide for the punishment of a variety of capital
crimes, and no restraint is laid upon them in its exercise, save only, that
"the trial of all crimes, except in cases of impeachment, shall be by
jury; and such trial shall be in the state where the said crimes shall have
been committed." No man is secure of a trial in the county where he is
charged to have committed a crime; he may be brought from Niagara to New-York,
or carried from Kentucky to Richmond for trial for an offence, supposed to be
committed. What security is there, that a man shall be furnished with a full
and plain description of the charges against him? That he shall be allowed to
produce all proof he can in his favor? That he shall see the witnesses against
him face to face, or that he shall be fully heard in his own defence by himself
or counsel? For the security of liberty it has been declared, "that excessive bail
should not be required, nor excessive fines imposed, nor cruel or unusual
punishments inflicted — That all warrants, without oath or affirmation, to
search suspected places, or seize any person, his papers or property, are
grievous and oppressive."


These provisions are as necessary under the general government as under that
of the individual states; for the power of the former is as complete to the
purpose of requiring bail. imposing fines, inflicting punishments, granting
search warrants, and seizing persons, papers, or property, in certain cases, as
the other.

--- chunk_id: chunk-0028
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 448
content_hash: 0887fe295a8f5835
prev_chunk_id: chunk-0027
next_chunk_id: chunk-0029
section_heading: Brutus II
document_type: specification

For the security of liberty it has been declared, "that excessive bail
should not be required, nor excessive fines imposed, nor cruel or unusual
punishments inflicted — That all warrants, without oath or affirmation, to
search suspected places, or seize any person, his papers or property, are
grievous and oppressive."


These provisions are as necessary under the general government as under that
of the individual states; for the power of the former is as complete to the
purpose of requiring bail. imposing fines, inflicting punishments, granting
search warrants, and seizing persons, papers, or property, in certain cases, as
the other. For the purpose of securing the property of the citizens, it is declared by
all the states, "that in all controversies at law, respecting property,
the ancient mode of trial by jury is one of the best securities of the rights
of the people, and ought to remain sacred and inviolable."


Does not the same necessity exist of reserving this right, under this
national compact, as in that of these states? Yet nothing is said respecting
it. In the bills of rights of the states it is declared, that a well regulated
militia is the proper and natural defence of a free government — That as
standing armies in time of peace are dangerous, they are not to be kept up, and
that the military should be kept under strict subordination to, and controuled
by the civil power. The same security is as necessary in this constitution, and much more so;
for the general government will have the sole power to raise and to pay armies,
and are under no controul in the exercise of it; yet nothing of this is to be
found in this new system. I might proceed to instance a number of other rights, which were as
necessary to be reserved, such as, that elections should be free, that the
liberty of the press should be held sacred; but the instances adduced, are
sufficient to prove, that this argument is without foundation.

--- chunk_id: chunk-0029
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 438
content_hash: 7d48d1dc2f90b202
prev_chunk_id: chunk-0028
next_chunk_id: chunk-0030
section_heading: Brutus II
document_type: specification

The same security is as necessary in this constitution, and much more so;
for the general government will have the sole power to raise and to pay armies,
and are under no controul in the exercise of it; yet nothing of this is to be
found in this new system. I might proceed to instance a number of other rights, which were as
necessary to be reserved, such as, that elections should be free, that the
liberty of the press should be held sacred; but the instances adduced, are
sufficient to prove, that this argument is without foundation. — Besides,
it is evident, that the reason here assigned was not the true one, why the
framers of this constitution omitted a bill of rights; if it had been, they
would not have made certain reservations, while they totally omitted others of
more importance. We find they have, in the 9th section of the 1st article,
declared, that the writ of habeas corpus shall not be suspended, unless in
cases of rebellion — that no bill of attainder, or expost facto law, shall
be passed — that no title of nobility shall be granted by the United
States, &c. If every thing which is not given is reserved, what propriety
is there in these exceptions? Does this constitution any where grant the power
of suspending the habeas corpus, to make expost facto laws, pass bills of
attainder, or grant titles of nobility? It certainly does not in express terms. The only answer that can be given is, that these are implied in the general
powers granted. With equal truth it may be said, that all the powers, which the
bills of right, guard against the abuse of, are contained or implied in the
general ones granted by this constitution. So far it is from being true, that a bill of rights is less necessary in the
general constitution than in those of the states, the contrary is evidently the
fact.

--- chunk_id: chunk-0030
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 442
content_hash: 237b5ffd0cc1d637
prev_chunk_id: chunk-0029
next_chunk_id: chunk-0031
section_heading: Brutus II
document_type: specification

With equal truth it may be said, that all the powers, which the
bills of right, guard against the abuse of, are contained or implied in the
general ones granted by this constitution. So far it is from being true, that a bill of rights is less necessary in the
general constitution than in those of the states, the contrary is evidently the
fact. — This system, if it is possible for the people of America to accede
to it, will be an original compact: and being the last, will, in the nature of
things, vacate every former agreement inconsistent with it. For it being a plan
of government received and ratified by the whole people, all other forms, which
are in existence at the time of its adoption, must yield to it. This is
expressed in positive and unequivocal terms, in the 6th article, "That
this constitution and the laws of the United States, which shall be made in
pursuance thereof, and all treaties made, or which shall be made, under the
authority of the United States, shall be the supreme law of the land; and the
judges in every state shall be bound thereby, any thing in the
constitution, or laws of any state, to the contrary
notwithstanding. "The senators and representatives before-mentioned, and the members of
the several state legislatures, and all executive and judicial officers, both
of the United States, and of the several states, shall be bound, by oath or
affirmation, to support this constitution."


It is therefore not only necessarily implied thereby, but positively
expressed. that the different state constitutions are repealed and entirely
done away. so far as they are inconsistent with this, with the laws which shall
be made in pursuance thereof, or with treaties made. or which shall be made,
under the authority of the United States; of what avail will the constitutions
of the respective states be to preserve the rights of its citizens? should they
be plead, the answer would be.

--- chunk_id: chunk-0031
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 448
content_hash: 2abce9486be0ebe2
prev_chunk_id: chunk-0030
next_chunk_id: chunk-0032
section_heading: Brutus II
document_type: specification

or which shall be made,
under the authority of the United States; of what avail will the constitutions
of the respective states be to preserve the rights of its citizens? should they
be plead, the answer would be. the constitution of the United States, and the
laws made in pursuance thereof, is the supreme law, and all legislatures and
judicial officers, whether of the general or state governments, are bound by
oath to support it. No priviledge, reserved by the bills of rights, or secured
by the state government, can limit the power granted by this, or restrain any
laws made in pursuance of it. It stands therefore on its own bottom, and must
receive a construction by itself without any reference to any other — And
hence it was of the highest importance, that the most precise and express
declarations and reservations of rights should have been made. This will appear the more necessary, when it is considered, that not only
the constitution and laws made in pursuance thereof, but all treaties made, or
which shall be made, under the authority of the United States, are the supreme
law of the land, and supersede the constitutions of all the states. The power
to make treaties, is vested in the president, by and with the advice and
consent of two thirds of the senate. I do not find any limitation, or
restriction, to the exercise of this power. The most important article in any
constitution may therefore be repealed, even without a legislative act. Ought
not a government, vested with such extensive and indefinite authority. to have
been restricted by a declaration of rights? It certainly ought. So clear a point is this, that I cannot help suspecting, that persons who
attempt to persuade people, that such reservations were less necessary under
this constitution than under those of the states, are wilfully endeavouring to
deceive, and to lead you into an absolute state of vassalage. Brutus. Next | Previous | Text Version | Brutus
Contents |

--- chunk_id: chunk-0032
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 426
content_hash: 487efc62fb360986
prev_chunk_id: chunk-0031
next_chunk_id: chunk-0033
section_heading: Brutus III
document_type: specification

## Brutus III

*Source file: brutus03.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #3



 

 III


 15 November 1787


To the Citizens of the State of New-York. In the investigation of the constitution, under your consideration, great
care should be taken, that you do not form your opinions respecting it, from
unimportant provisions, or fallacious appearances. On a careful examination, you will find, that many of its parts, of little
moment, are well formed; in these it has a specious resemblance of a free
government — but this is not sufficient to justify the adoption of it
— the gilded pill, is often found to contain the most deadly poison. You are not however to expect, a perfect form of government, any more than
to meet with perfection in man: your views therefore, ought to be directed to
the main pillars upon which a free government is to rest; if these are well
placed, on a foundation that will support the superstructure, you should be
satisfied, although the building may want a number of ornaments, which, if your
particular tastes were gratified, you would have added to it: on the other
hand. if the foundation is insecurely laid. and the main supports are wanting,
or not properly fixed, however the fabric may be decorated and adorned, you
ought to reject it. Under these impressions, it has been my object to turn your attention to the
principal defects in this system. I have attempted to shew, that a consolidation of this extensive continent,
under one government, for internal, as well as external purposes, which is
evidently the tendency of this constitution, cannot succeed, without a
sacrifice of your liberties; and therefore that the attempt is not only
preposterous, but extremely dangerous; and I have shewn, independent of this,
that the plan is radically defective in a fundamental principle, which ought to
be found in every free government; to wit, a declaration of rights.

--- chunk_id: chunk-0033
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 388
content_hash: b9fb8b304a8bb0de
prev_chunk_id: chunk-0032
next_chunk_id: chunk-0034
section_heading: Brutus III
document_type: specification

Under these impressions, it has been my object to turn your attention to the
principal defects in this system. I have attempted to shew, that a consolidation of this extensive continent,
under one government, for internal, as well as external purposes, which is
evidently the tendency of this constitution, cannot succeed, without a
sacrifice of your liberties; and therefore that the attempt is not only
preposterous, but extremely dangerous; and I have shewn, independent of this,
that the plan is radically defective in a fundamental principle, which ought to
be found in every free government; to wit, a declaration of rights. I shall now proceed to take a nearer view of this system, to examine its
parts more minutely, and shew that the powers are not properly deposited, for
the security of public liberty. The first important object that presents itself in the organization of this
government, is the legislature. This is to be composed of two branches; the
first to be called the general assembly, and is to be chosen by the people of
the respective states, in proportion to the number of their inhabitants, and is
to consist of sixty five members, with powers in the legislature to encrease
the number, not to exceed one for every thirty thousand inhabitants. The second
branch is to be called the senate, and is to consist of twenty-six members, two
of which are to be chosen by the legislatures of each of the states. In the former of these there is an appearance of justice, in the appointment
of its members — but if the clause, which provides for this branch, be
stripped of its ambiguity, it will be found that there is really no equality of
representation, even in this house.

--- chunk_id: chunk-0034
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 381
content_hash: c34d2b372fc6b616
prev_chunk_id: chunk-0033
next_chunk_id: chunk-0035
section_heading: Brutus III
document_type: specification

The second
branch is to be called the senate, and is to consist of twenty-six members, two
of which are to be chosen by the legislatures of each of the states. In the former of these there is an appearance of justice, in the appointment
of its members — but if the clause, which provides for this branch, be
stripped of its ambiguity, it will be found that there is really no equality of
representation, even in this house. The words are "representatives and direct taxes, shall be apportioned
among the several states, which may be included in this union, according to
their respective numbers, which shall be determined by adding to the whole
number of free persons, including those bound to service for a term of years,
and excluding Indians not taxed, three fifths of all other persons."
— What a strange and unnecessary accumulation of words are here used to
conceal from the public eye. what might have been expressed in the following
concise manner. Representatives are to be proportioned among the states
respectively, according to the number of freemen and slaves inhabiting them,
counting five slaves for three free men. "In a free state." says the celebrated Montesquieu, "every
man. who is supposed to be a free agent, ought to be concerned in his own
government. therefore the legislature should reside in the whole body of the
people, or their representatives." But it has never been alledged that
those who are not free agents, can, upon any rational principle, have any thing
to do in government, either by themselves or others. If they have no share in
government. why is the number of members in the assembly, to be increased on
their account?

--- chunk_id: chunk-0035
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: 8213dec8fac317a1
prev_chunk_id: chunk-0034
next_chunk_id: chunk-0036
section_heading: Brutus III
document_type: specification

If they have no share in
government. why is the number of members in the assembly, to be increased on
their account? Is it because in some of the states, a considerable part of the
property of the inhabitants consists in a number of their fellow men, who are
held in bondage, in defiance of every idea of benevolence, justice, and
religion, and contrary to all the principles of liberty, which have been
publickly avowed in the late glorious revolution? If this be a just ground for
representation, the horses in some of the states, and the oxen in others, ought
to be represented — for a great share of property in some of them. consists in these animals; and they have as much controul over their own
actions, as these poor unhappy creatures, who are intended to be described in
the above recited clause, by the words, "all other persons." By this
mode of apportionment, the representatives of the different pans of the union,
will be extremely unequal: in some of the southern states, the slaves are
nearly equal in number to the free men; and for all these slaves, they will be
entitled to a proportionate share in the legislature — this will give them
an unreasonable weight in the government, which can derive no additional
strength, protection, nor defence from the slaves, but the contrary. Why then
should they be represented? What adds to the evil is, that these states are to
be permitted to continue the inhuman traffic of importing slaves, until the
year 1808 — and for every cargo of these unhappy people, which unfeeling. unprincipled, barbarous, and avaricious wretches, may tear from their country,
friends and tender connections, and bring into those states, they are to be
rewarded by having an increase of members in the general assembly. There appears at the first view a manifest inconsistency, in the
apportionment of representatives in the senate, upon the plan of a consolidated
government.

--- chunk_id: chunk-0036
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 401
content_hash: 6ec12920b878635c
prev_chunk_id: chunk-0035
next_chunk_id: chunk-0037
section_heading: Brutus III
document_type: specification

unprincipled, barbarous, and avaricious wretches, may tear from their country,
friends and tender connections, and bring into those states, they are to be
rewarded by having an increase of members in the general assembly. There appears at the first view a manifest inconsistency, in the
apportionment of representatives in the senate, upon the plan of a consolidated
government. On every principle of equity, and propriety, representation in a
government should be in exact proportion to the numbers, or the aids afforded
by the persons represented. How unreasonable, and unjust then is it. that
Delaware should have a representation in the senate, equal to Massachusetts, or
Virginia? The latter of which contains ten times her numbers. and is to
contribute to the aid of the general government in that proportion? This
article of the constitution will appear the more objectionable, if it is
considered, that the powers vested in this branch of the legislature are very
extensive, and greatly surpass those lodged in the assembly, not only for
general purposes, but. in many instances, for the internal police of the
states. The Other branch of the legislature, in which, if in either, a f[a]int
spark of democracy is to be found, should have been properly organized and
established — but upon examination you will find, that this branch does
not possess the qualities of a just representation, and that there is no kind
of security, imperfect as it is. for its remaining in the hands of the people. It has been observed, that the happiness of society is the end of government
— that every free government is founded in compact: and that, because it
is impracticable for the whole community to assemble, or when assembled, to
deliberate with wisdom, and decide with dispatch, the mode of legislating by
representation was devised.

--- chunk_id: chunk-0037
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 394
content_hash: b8ac3b4cc86ee55a
prev_chunk_id: chunk-0036
next_chunk_id: chunk-0038
section_heading: Brutus III
document_type: specification

for its remaining in the hands of the people. It has been observed, that the happiness of society is the end of government
— that every free government is founded in compact: and that, because it
is impracticable for the whole community to assemble, or when assembled, to
deliberate with wisdom, and decide with dispatch, the mode of legislating by
representation was devised. The very term, representative, implies, that the person or body chosen for
this purpose, should resemble those who appoint them — a representation of
the people of America, if it be a true one, must be like the people. It ought
to be so constituted, that a person, who is a stranger to the country, might be
able to form a just idea of their character, by knowing that of their
representatives. They are the sign — the people are the thing signified. It is absurd to speak of one thing being the representative of another, upon
any other principle. The ground and reason of representation, in a free
government, implies the same thing. Society instituted government to promote
the happiness of the whole, and this is the great end always in view in the
delegation of powers. It must then have been intended, that those who are
placed instead of the people, should possess their sentiments and feelings, and
be governed by their interests, or, in other words, should bear the strongest
resemblance of those in whose room they are substituted. It is obvious, that
for an assembly to be a true likeness of the people of any country, they must
be considerably numerous. — One man. or a few men, cannot possibly
represent the feelings, opinions, and characters of a great multitude. In this
respect, the new constitution is radically defective.

--- chunk_id: chunk-0038
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 397
content_hash: 5d619422a9a60bad
prev_chunk_id: chunk-0037
next_chunk_id: chunk-0039
section_heading: Brutus III
document_type: specification

or a few men, cannot possibly
represent the feelings, opinions, and characters of a great multitude. In this
respect, the new constitution is radically defective. — The house of
assembly, which is intended as a representation of the people of America, will
not, nor cannot, in the nature of things, be a proper one — sixty-five men
cannot be found in the United States, who hold the sentiments, possess the
feelings, or are acqainted with the wants and interests of this vast country. This extensive continent is made up of a number of different classes of people;
and to have a proper representation of them. each class ought to have an
opportunity of choosing their best informed men for the purpose; but this
cannot possibly be the case in so small a number. The state of New-York, on the
present apportionment, will send six members to the assembly: I will venture to
affirm, that number cannot be found in the state, who will bear a just
resemblance to the several classes of people who compose it. In this assembly,
the farmer, merchant, mecanick. and other various orders of people, ought to be
represented according to their respective weight and numbers; and the
representatives ought to be intimately acquainted with the wants, understand
the interests of the several orders in the society, and feel a proper sense and
becoming zeal to promote their prosperity. I cannot conceive that any six men
in this state can be found properly qualified in these respects to discharge
such important duties: but supposing it possible to find them, is there the
least degree of probability that the choice of the people will fall upon such
men? According to the common course of human affairs, the natural aristocracy
of the country will be elected.

--- chunk_id: chunk-0039
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 436
content_hash: 44640ace236bf51d
prev_chunk_id: chunk-0038
next_chunk_id: chunk-0040
section_heading: Brutus III
document_type: specification

I cannot conceive that any six men
in this state can be found properly qualified in these respects to discharge
such important duties: but supposing it possible to find them, is there the
least degree of probability that the choice of the people will fall upon such
men? According to the common course of human affairs, the natural aristocracy
of the country will be elected. Wealth always creates influence, and this is
generally much increased by large family connections: this class in society
will for ever have a great number of dependents; besides, they will always
favour each other — it is their interest to combine — they will
therefore constantly unite their efforts to procure men of their own rank to be
elected — they will concenter all their force in every part of the state
into one point, and by acting together, will most generally carry their
election. It is probable, that but few of the merchants, and those the most
opulent and ambitious, will have a representation from their body — few of
them are characters sufficiently conspicuous to attract the notice of the
electors of the state in so limited a representation. The great body of the
yeomen of the country cannot expect any of their order in this assembly —
the station will be too elevated for them to aspire to — the distance
between the people and their representatives, will be so very great, that there
is no probability that a farmer, however respectable, will be chosen — the
mechanicks of every branch, must expect to be excluded from a seat in this Body
— It will and must be esteemed a station too high and exalted to be filled
by any but the first men in the state, in point of fortune; so that in reality
there will be no part of the people represented, but the rich, even in that
branch of the legislature, which is called the democratic.

--- chunk_id: chunk-0040
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 434
content_hash: 7eeaf1c4b5a18320
prev_chunk_id: chunk-0039
next_chunk_id: chunk-0041
section_heading: Brutus III
document_type: specification

It is probable, that but few of the merchants, and those the most
opulent and ambitious, will have a representation from their body — few of
them are characters sufficiently conspicuous to attract the notice of the
electors of the state in so limited a representation. The great body of the
yeomen of the country cannot expect any of their order in this assembly —
the station will be too elevated for them to aspire to — the distance
between the people and their representatives, will be so very great, that there
is no probability that a farmer, however respectable, will be chosen — the
mechanicks of every branch, must expect to be excluded from a seat in this Body
— It will and must be esteemed a station too high and exalted to be filled
by any but the first men in the state, in point of fortune; so that in reality
there will be no part of the people represented, but the rich, even in that
branch of the legislature, which is called the democratic. — The well
born, and highest orders in life, as they term themselves, will be ignorant of
the sentiments of the midling class of citizens, strangers to their ability,
wants, and difficulties, and void of sympathy, and fellow feeling. This branch
of the legislature will not only be an imperfect representation, but there will
be no security in so small a body, against bribery, and corruption — It
will consist at first, of sixty-five, and can never exceed one for every thirty
thousand inhabitants; a majority of these, that is, thirty-three, are a quorum,
and a majority of which, or seventeen, may pass any law — so that
twenty-five men, will have the power to give away all the property of the
citizens of these states — what security therefore can there be for the
people, where their liberties and property are at the disposal of so few men?

--- chunk_id: chunk-0041
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 413
content_hash: 0ef8b1bfbadd5fb7
prev_chunk_id: chunk-0040
next_chunk_id: chunk-0042
section_heading: Brutus III
document_type: specification

— The well
born, and highest orders in life, as they term themselves, will be ignorant of
the sentiments of the midling class of citizens, strangers to their ability,
wants, and difficulties, and void of sympathy, and fellow feeling. This branch
of the legislature will not only be an imperfect representation, but there will
be no security in so small a body, against bribery, and corruption — It
will consist at first, of sixty-five, and can never exceed one for every thirty
thousand inhabitants; a majority of these, that is, thirty-three, are a quorum,
and a majority of which, or seventeen, may pass any law — so that
twenty-five men, will have the power to give away all the property of the
citizens of these states — what security therefore can there be for the
people, where their liberties and property are at the disposal of so few men? It will literally be a government in the hands of the few to oppress and
plunder the many. You may conclude with a great degree of certainty, that it,
like all others of a similar nature, will be managed by influence and
corruption, and that the period is not far distant, when this will be the case,
if it should be adopted; for even now there are some among us, whose characters
stand high in the public estimation, and who have had a principal agency in
framing this constitution, who do not scruple to say, that this is the only
practicable mode of governing a people, who think with that degree of freedom
which the Americans do — this government will have in their gift a vast
number of offices of great honor and emolument. The members of the legislature
are not excluded from appointments; and twenty-five of them, as the case may
be, being secured, any measure may be carried.

--- chunk_id: chunk-0042
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 360
content_hash: 342e459040e5f31b
prev_chunk_id: chunk-0041
next_chunk_id: chunk-0043
section_heading: Brutus III
document_type: specification

You may conclude with a great degree of certainty, that it,
like all others of a similar nature, will be managed by influence and
corruption, and that the period is not far distant, when this will be the case,
if it should be adopted; for even now there are some among us, whose characters
stand high in the public estimation, and who have had a principal agency in
framing this constitution, who do not scruple to say, that this is the only
practicable mode of governing a people, who think with that degree of freedom
which the Americans do — this government will have in their gift a vast
number of offices of great honor and emolument. The members of the legislature
are not excluded from appointments; and twenty-five of them, as the case may
be, being secured, any measure may be carried. The rulers of this country must be composed of very different materials from
those of any other, of which history gives us any account, if the majority of
the legislature are not, before many years, entirely at the devotion of the
executive — and these states will soon be under the absolute domination of
one, or a few, with the fallacious appearance of being governed by men of their
own election. The more I reflect on this subject, the more firmly am I persuaded, that the
representation is merely nominal — a mere burlesque; and that no security
is provided against corruption and undue influence. No free people on earth,
who have elected persons to legislate for them, ever reposed that confidence in
so small a number.

--- chunk_id: chunk-0043
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 342
content_hash: 3286196c3c76bdf5
prev_chunk_id: chunk-0042
next_chunk_id: chunk-0044
section_heading: Brutus III
document_type: specification

The more I reflect on this subject, the more firmly am I persuaded, that the
representation is merely nominal — a mere burlesque; and that no security
is provided against corruption and undue influence. No free people on earth,
who have elected persons to legislate for them, ever reposed that confidence in
so small a number. The British house of commons consists of five hundred and
fifty-eight members; the number of inhabitants in Great-Britain, is computed at
eight millions — this gives one member for a little more than fourteen
thousand, which exceeds double the proportion this country can ever have: and
yet we require a larger representation in proportion to our numbers, than
Great-Britain, because this country is much more extensive, and differs more in
its productions, interests, manners, and habits. The democratic branch of the
legislatures of the several states in the union consists, I believe at present,
of near two thousand; and this number was not thought too large for the
security of liberty by the framers of our state constitutions: some of the
states may have erred in this respect, but the difference between two thousand,
and sixty-five, is so very great, that it will bear no comparison. Other objections offer themselves against this part of the constitution
— I shall reserve them for a future paper, when I shall shew, defective as
this representation is, no security is provided, that even this shadow of the
right, will remain with the people. Brutus. Next | Previous | Text Version | Brutus
Contents |

--- chunk_id: chunk-0044
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 422
content_hash: 2e4d5a559a04fa15
prev_chunk_id: chunk-0043
next_chunk_id: chunk-0045
section_heading: Brutus IV
document_type: specification

## Brutus IV

*Source file: brutus04.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #4



 

 IV


 29 November 1787


To the People of the State of New-York. There can be no free government where the people are not possessed of the
power of making the laws by which they are governed, either in their own
persons, or by others substituted in their stead. Experience has taught mankind, that legislation by representatives is the
most eligible, and the only practicable mode in which the people of any country
can exercise this right, either prudently or beneficially. But then, it is a
matter of the highest importance, in forming this representation, that it be so
constituted as to be capable of understanding the true interests of the society
for which it acts, and so disposed as to pursue the good and happiness of the
people as its ultimate end. The object of every free government is the public
good, and all lesser interests yield to it. That of every tyrannical
government, is the happiness and aggrandisement of one, or a few, and to this
the public felicity, and every other interest must submit. — The reason of
this difference in these governments is obvious. The first is so constituted as
to collect the views and wishes of the whole people in that of their rulers,
while the latter is so framed as to separate the interests of the governors
from that of the governed. The principle of self love, therefore, that will
influence the one to promote the good of the whole, will prompt the other to
follow its own private advantage. The great art, therefore, in forming a good
constitution, appears to be this, so to frame it, as that those to whom the
power is committed shall be subject to the same feelings, and aim at the same
objects as the people do, who transfer to them their authority.

--- chunk_id: chunk-0045
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 438
content_hash: 133b9f04f8c83b3c
prev_chunk_id: chunk-0044
next_chunk_id: chunk-0046
section_heading: Brutus IV
document_type: specification

The principle of self love, therefore, that will
influence the one to promote the good of the whole, will prompt the other to
follow its own private advantage. The great art, therefore, in forming a good
constitution, appears to be this, so to frame it, as that those to whom the
power is committed shall be subject to the same feelings, and aim at the same
objects as the people do, who transfer to them their authority. There is no
possible way to effect this but by an equal, full and fair representation;
this, therefore, is the great desideratum in politics. However fair an
appearance any government may make, though it may possess a thousand plausible
articles and be decorated with ever so many ornaments, yet if it is deficient
in this essential principle of a full and just representation of the people, it
will be only like a painted sepulcher — For, without this it cannot be a
free government; let the administration of it be good or ill, it still will be
a government, not according to the will of the people, but according to the
will of a few. To test this new constitution then, by this principle, is of the last
importance — It is to bring it to the touch-stone of national liberty, and
I hope I shall be excused, if, in this paper. I pursue the subject commenced in
my last number, to wit, the necessity of an equal and full representation in
the legislature. — In that, I showed that it was not equal, because the
smallest states are to send the same number of members to the senate as the
largest, and, because the slaves, who afford neither aid or defence to the
government, are to encrease the proportion of members. To prove that it was not
a just or adequate representation, it was urged, that so small a number could
not resemble the people, or possess their sentiments and dispositions.

--- chunk_id: chunk-0046
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 381
content_hash: 6aa5553a9abbdf47
prev_chunk_id: chunk-0045
next_chunk_id: chunk-0047
section_heading: Brutus IV
document_type: specification

— In that, I showed that it was not equal, because the
smallest states are to send the same number of members to the senate as the
largest, and, because the slaves, who afford neither aid or defence to the
government, are to encrease the proportion of members. To prove that it was not
a just or adequate representation, it was urged, that so small a number could
not resemble the people, or possess their sentiments and dispositions. That the
choice of members would commonly fall upon the rich and great, while the
middling class of the community would be excluded. That in so small a
representation there was no security against bribery and corruption. The small number which is to compose this legislature, will not only expose
it to the danger of that kind of corruption, and undue influence. which will
arise from the gift of places of honor and emolument, or the more direct one of
bribery, but it will also subject it to another kind of influence no less fatal
to the liberties of the people, though it be not so flagrantly repugnant to the
principles of rectitude. It is not to be expected that a legislature will be
found in any country that will not have some of its members, who will pursue
their private ends. and for which they will sacrifice the public good. Men of
this character are, generally, artful and designing, and frequently possess
brilliant talents and abilities; they commonly act in concert, and agree to
share the spoils of their country among them; they will keep their object ever
in view, and follow it with constancy. To effect their purpose, they will
assume any shape, and, Proteus like.

--- chunk_id: chunk-0047
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 320
content_hash: 8cdd4d181a0e3eda
prev_chunk_id: chunk-0046
next_chunk_id: chunk-0048
section_heading: Brutus IV
document_type: specification

Men of
this character are, generally, artful and designing, and frequently possess
brilliant talents and abilities; they commonly act in concert, and agree to
share the spoils of their country among them; they will keep their object ever
in view, and follow it with constancy. To effect their purpose, they will
assume any shape, and, Proteus like. mould themselves into any form —
where they find members proof against direct bribery or gifts of offices, they
will endeavor to mislead their minds by specious and false reasoning, to impose
upon their unsuspecting honesty by an affectation of zeal for the public good;
they will form juntos, and hold out-door meetings; they will operate upon the
good nature of their opponents, by a thousand little attentions, and teize them
into compliance by the earnestness of solicitation. Those who are acquainted
with the manner of conducting business in public assemblies, know how prevalent
art and address are in carrying a measure, even over men of the best
intentions, and of good understanding. The firmest security against this kind
of improper and dangerous influence, as well as all other, is a strong and
numerous representation: in such a house of assembly, so great a number must be
gained over, before the private views of individuals could be gratified that
there could be scarce a hope of success. But in the foederal assembly,
seventeen men are all that is necessary to pass a law.

--- chunk_id: chunk-0048
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 406
content_hash: 1d56eb64165fc2b3
prev_chunk_id: chunk-0047
next_chunk_id: chunk-0049
section_heading: Brutus IV
document_type: specification

The firmest security against this kind
of improper and dangerous influence, as well as all other, is a strong and
numerous representation: in such a house of assembly, so great a number must be
gained over, before the private views of individuals could be gratified that
there could be scarce a hope of success. But in the foederal assembly,
seventeen men are all that is necessary to pass a law. It is probable, it will
seldom happen that more than twenty-five will be requisite to form a majority,
when it is considered what a number of places of honor and emolument will be in
the gift of the executive, the powerful influence that great and designing men
have over the honest and unsuspecting, by their art and address, their soothing
manners and civilities, and their cringing flattery, joined with their affected
patriotism; when these different species of influence are combined, it is
scarcely to be hoped that a legislature, composed of so small a number, as the
one proposed by the new constitution, will long resist their force. A farther objection against the feebleness of the representation is. that it
will not possess the confidence of the people. The execution of the laws in a
free government must rest on this confidence, and this must be founded on the
good opinion they entertain of the framers of the laws. Every government must
be supported, either by the people having such an attachment to it, as to be
ready, when called upon, to support it, or by a force at the command of the
government, to compel obedience. The latter mode destroys every idea of a free
government; for the same force that may be employed to compel obedience to good
laws, might, and probably would be used to wrest from the people their
constitutional liberties.

--- chunk_id: chunk-0049
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 377
content_hash: 4a770c96c4b1e233
prev_chunk_id: chunk-0048
next_chunk_id: chunk-0050
section_heading: Brutus IV
document_type: specification

Every government must
be supported, either by the people having such an attachment to it, as to be
ready, when called upon, to support it, or by a force at the command of the
government, to compel obedience. The latter mode destroys every idea of a free
government; for the same force that may be employed to compel obedience to good
laws, might, and probably would be used to wrest from the people their
constitutional liberties. — Whether it is practicable to have a
representation for the whole union sufficiently numerous to obtain that
confidence which is necessary for the purpose of internal taxation, and other
powers to which this proposed government extends, is an important question. I
am clearly of opinion, it is not, and therefore I have stated this in my first
number, as one of the reasons against going into an entire consolidation of the
states — one of the most capital errors in the system, is that of
extending the powers of the foederal government to objects to which it is not
adequate, which it cannot exercise without endangering public liberty, and
which it is not necessary they should possess, in order to preserve the union
and manage our national concerns; of this, however, I shall treat more fully in
some future paper — But, however this may be. certain it is, that the
representation in the legislature is not so formed as to give reasonable ground
for public trust. In order for the people safely to repose themselves on their rulers, they
should not only be of their own choice. But it is requisite they should be
acquainted with their abilities to manage the public concerns with wisdom.

--- chunk_id: chunk-0050
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 390
content_hash: 5ce80021c56c4e13
prev_chunk_id: chunk-0049
next_chunk_id: chunk-0051
section_heading: Brutus IV
document_type: specification

In order for the people safely to repose themselves on their rulers, they
should not only be of their own choice. But it is requisite they should be
acquainted with their abilities to manage the public concerns with wisdom. They
should be satisfied that those who represent them are men of integrity, who
will pursue the good of the community with fidelity; and will not be turned
aside from their duty by private interest, or corrupted by undue influence; and
that they will have such a zeal for the good of those whom they represent, as
to excite them to be diligent in their service; but it is impossible the people
of the United States should have sufficient knowledge of their representatives,
when the numbers are so few, to acquire any rational satisfaction on either of
these points. The people of this state will have very little acquaintance with
those who may be chosen to represent them; a great part of them will, probably,
not know the characters of their own members, much less that of a majority of
those who will compose the foederal assembly; they will consist of men, whose
names they have never heard, and whose talents and regard for the public good,
they are total strangers to; and they will have no persons so immediately of
their choice so near them, of their neighbours and of their own rank in life,
that they can feel themselves secure in trusting their interests in their
hands. The representatives of the people cannot, as they now do, after they
have passed laws, mix with the people, and explain to them the motives which
induced the adoption of any measure, point out its utility, and remove
objections or silence unreasonable clamours against it.

--- chunk_id: chunk-0051
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 288
content_hash: ac7b2f080d88d791
prev_chunk_id: chunk-0050
next_chunk_id: chunk-0052
section_heading: Brutus IV
document_type: specification

The people of this state will have very little acquaintance with
those who may be chosen to represent them; a great part of them will, probably,
not know the characters of their own members, much less that of a majority of
those who will compose the foederal assembly; they will consist of men, whose
names they have never heard, and whose talents and regard for the public good,
they are total strangers to; and they will have no persons so immediately of
their choice so near them, of their neighbours and of their own rank in life,
that they can feel themselves secure in trusting their interests in their
hands. The representatives of the people cannot, as they now do, after they
have passed laws, mix with the people, and explain to them the motives which
induced the adoption of any measure, point out its utility, and remove
objections or silence unreasonable clamours against it. — The number will
be so small that but a very few of the most sensible and respectable yeomanry
of the country can ever have any knowledge of them: being so far removed from
the people, their station will be elevated and important, and they will be
considered as ambitious and designing. They will not be viewed by the people as

--- chunk_id: chunk-0052
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 408
content_hash: c087c27d64823e5b
prev_chunk_id: chunk-0051
next_chunk_id: chunk-0053
section_heading: part of themselves, but as a body distinct from them, and having separate
document_type: specification

part of themselves, but as a body distinct from them, and having separate
interests to pursue; the consequence will be, that a perpetual jealousy will
exist in the minds of the people against them; their conduct will be narrowly
watched; their measures scrutinized; and their laws opposed, evaded, or
reluctantly obeyed. This is natural, and exactly corresponds with the conduct
of individuals towards those in whose hands they intrust important concerns. If
the person confided in, be a neighbour with whom his employer is intimately
acquainted, whose talents, he knows, are sufficient to manage the business with
which he is charged, his honesty and fidelity unsuspected, and his friendship
and zeal for the service of this principal unquestionable, he will commit his
affairs into his hands with unreserved confidence, and feel himself secure; all
the transactions of the agent will meet with the most favorable construction,
and the measures he takes will give satisfaction. But, if the person employed
be a stranger, whom he has never seen, and whose character for ability or
fidelity he cannot fully learn — If he is constrained to choose him,
because it was not in his power to procure one more agreeable to his wishes, he
will trust him with caution, and be suspicious of all his conduct. If then this government should not derive support from the good will of the
people, it must be executed by force, or not executed at all; either case would
lead to the total destruction of liberty. — The convention seemed aware of
this, and have therefore provided for calling out the militia to execute the
laws of the union. If this system was so framed as to command that respect from
the people, which every good free government will obtain, this provision was
unnecessary — the people would support the civil magistrate.

--- chunk_id: chunk-0053
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 422
content_hash: daa17b050f85ff4c
prev_chunk_id: chunk-0052
next_chunk_id: chunk-0054
section_heading: part of themselves, but as a body distinct from them, and having separate
document_type: specification

— The convention seemed aware of
this, and have therefore provided for calling out the militia to execute the
laws of the union. If this system was so framed as to command that respect from
the people, which every good free government will obtain, this provision was
unnecessary — the people would support the civil magistrate. This power is
a novel one, in free governments — these have depended for the execution
of the laws on the Posse Comitatus, and never raised an idea, that the people
would refuse to aid the civil magistrate in executing those laws they
themselves had made. I shall now dismiss the subject of the incompetency of the
representation, and proceed, as I promised, to shew, that, impotent as it is,
the people have no security that they will enjoy the exercise of the right of
electing this assembly, which, at best, can be considered but as the shadow of
representation. By section 4, article I, the Congress are authorized, at any time, by law,
to make, or alter, regulations respecting the time, place, and manner of
holding elections for senators and representatives, except as to the places of
choosing senators. By this clause the right of election itself, is, in a great
measure, transferred from the people to their rulers. — One would think,
that if any thing was necessary to be made a fundamental article of the
original compact, it would be, that of fixing the branches of the legislature,
so as to put it out of its power to alter itself by modifying the election of
its own members at will and pleasure. When a people once resign the privilege
of a fair election, they clearly have none left worth contending for. It is clear that, under this article, the foederal legislature may institute
such rules respecting elections as to lead to the choice of one description of
men.

--- chunk_id: chunk-0054
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 405
content_hash: b4708646cab3ec10
prev_chunk_id: chunk-0053
next_chunk_id: chunk-0055
section_heading: part of themselves, but as a body distinct from them, and having separate
document_type: specification

When a people once resign the privilege
of a fair election, they clearly have none left worth contending for. It is clear that, under this article, the foederal legislature may institute
such rules respecting elections as to lead to the choice of one description of
men. The weakness of the representation, tends but too certainly to confer on
the rich and well-born, all honours; but the power granted in this
article, may be so exercised, as to secure it almost beyond a possibility of
controul. The proposed Congress may make the whole state one district, and
direct, that the capital (the city of New-York, for instance) shall be the
place for holding the election; the consequence would be, that none but men of
the most elevated rank in society would attend, and they would as certainly
choose men of their own class; as it is true what the Apostle Paul
saith, that "no man ever yet hated his own flesh, but nourisheth and
cherisheth it." — They may declare that those members who have the
greatest number of votes, shall be considered as duly elected; the consequence
would be that the people, who are dispersed in the interior parts of the state,
would give their votes for a variety of candidates, while any order, or
profession, residing in populous places, by uniting their interests, might
procure whom they pleased to be chosen — and by this means the
representatives of the state may be elected by one tenth part of the people who
actually vote. This may be effected constitutionally, and by one of those
silent operations which frequently takes place without being noticed, but which
often produces such changes as entirely to alter a government, subvert a free
constitution, and rivet the chains on a free people before they perceive they
are forged.

--- chunk_id: chunk-0055
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 440
content_hash: c3cde2332c5a3c53
prev_chunk_id: chunk-0054
next_chunk_id: chunk-0056
section_heading: part of themselves, but as a body distinct from them, and having separate
document_type: specification

The proposed Congress may make the whole state one district, and
direct, that the capital (the city of New-York, for instance) shall be the
place for holding the election; the consequence would be, that none but men of
the most elevated rank in society would attend, and they would as certainly
choose men of their own class; as it is true what the Apostle Paul
saith, that "no man ever yet hated his own flesh, but nourisheth and
cherisheth it." — They may declare that those members who have the
greatest number of votes, shall be considered as duly elected; the consequence
would be that the people, who are dispersed in the interior parts of the state,
would give their votes for a variety of candidates, while any order, or
profession, residing in populous places, by uniting their interests, might
procure whom they pleased to be chosen — and by this means the
representatives of the state may be elected by one tenth part of the people who
actually vote. This may be effected constitutionally, and by one of those
silent operations which frequently takes place without being noticed, but which
often produces such changes as entirely to alter a government, subvert a free
constitution, and rivet the chains on a free people before they perceive they
are forged. Had the power of regulating elections been left under the direction
of the state legislatures, where the people are not only nominally but
substantially represented, it would have been secure; but if it was taken out
of their hands, it surely ought to have been fixed on such a basis as to have
put it out of the power of the foederal legislature to deprive the people of it
by law. Provision should have been made for marking out the states into
districts, and for choosing, by a majority of votes, a person out of each of
them of permanent property and residence in the district which he was to
represent.

--- chunk_id: chunk-0056
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 394
content_hash: 02dcd58c3933d0fd
prev_chunk_id: chunk-0055
next_chunk_id: chunk-0057
section_heading: part of themselves, but as a body distinct from them, and having separate
document_type: specification

Had the power of regulating elections been left under the direction
of the state legislatures, where the people are not only nominally but
substantially represented, it would have been secure; but if it was taken out
of their hands, it surely ought to have been fixed on such a basis as to have
put it out of the power of the foederal legislature to deprive the people of it
by law. Provision should have been made for marking out the states into
districts, and for choosing, by a majority of votes, a person out of each of
them of permanent property and residence in the district which he was to
represent. If the people of America will submit to a constitution that will vest in the
hands of any body of men a right to deprive them by law of the privilege of a
fair election, they will submit to almost any thing. Reasoning with them will
be in vain, they must be left until they are brought to reflection by feeling
oppression — they will then have to wrest from their oppressors, by a
strong hand. that which they now possess, and which they may retain if they
will exercise but a moderate share of prudence and firmness. I know it is said that the dangers apprehended from this clause are merely
imaginary, that the proposed general legislature will be disposed to regulate
elections upon proper principles, and to use their power with discretion, and
to promote the public good. On this, I would observe, that constitutions are
not so necessary to regulate the conduct of good rulers as to restrain that of
bad ones. — Wise and good men will exercise power so as to promote the
public happiness under any form of government.

--- chunk_id: chunk-0057
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 422
content_hash: 624493d69bb88c0b
prev_chunk_id: chunk-0056
next_chunk_id: chunk-0058
section_heading: part of themselves, but as a body distinct from them, and having separate
document_type: specification

On this, I would observe, that constitutions are
not so necessary to regulate the conduct of good rulers as to restrain that of
bad ones. — Wise and good men will exercise power so as to promote the
public happiness under any form of government. If we are to take it for
granted, that those who administer the government under this system, will
always pay proper attention to the rights and interests of the people, nothing
more was necessary than to say who should be invested with the powers of
government, and leave them to exercise it at will and pleasure. Men are apt to
be deceived both with respect to their own dispositions and those of others. Though this truth is proved by almost every page of the history of nations, to
wit, that power, lodged in the hands of rulers to be used at discretion, is
almost always exercised to the oppression of the people, and the aggrandizement
of themselves; yet most men think if it was lodged in their hands they would
not employ it in this manner. — Thus when the prophet Elisha told
Hazael, "I know the evil that thou wilt do unto the children of
Israel; their strong holds wilt thou set on fire, and their young men, wilt
thou slay with the sword, and wilt dash their children, and rip up their women
with child." Hazael had no idea that he ever should be guilty of such
horrid cruelty, and said to the prophet, "Is thy servant a dog that he
should do this great thing." Elisha answered, "The Lord hath shewed
me that thou shalt be king of Syria." The event proved, that Hazael only
wanted an opportunity to perpetrate these enormities without restraint, and he
had a disposition to do them, though he himself knew it not. Brutus. Next | Previous | Text Version | Brutus
Contents |

--- chunk_id: chunk-0058
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 405
content_hash: f3cdb41f5665bc79
prev_chunk_id: chunk-0057
next_chunk_id: chunk-0059
section_heading: Brutus V
document_type: specification

## Brutus V

*Source file: brutus05.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #5



 

 V


13 December 1787


To the People of the State of New-York. It was intended in this Number to have prosecuted the enquiry into the
organization of this new system; particularly to have considered the dangerous
and premature union of the President and Senate, and the mixture of
legislative, executive, and judicial powers in the Senate. But there is such an intimate connection between the several branches in
whom the different species of authority is lodged, and the powers with which
they are invested, that on reflection it seems necessary first to proceed to
examine the nature and extent of the powers granted to the legislature. This enquiry will assist us the better to determine, whether the legislature
is so constituted, as to provide proper checks and restrictions for the
security of our rights, and to guard against the abuse of power — For the
means should be suited to the end; a government should be framed with a view to
the objects to which it extends: if these be few in number, and of such a
nature as to give but small occasion or opportunity to work oppression in the
exercise of authority, there will be less need of a numerous representation,
and special guards against abuse, than if the powers of the government are very
extensive, and include a great variety of cases. It will also be found
necessary to examine the extent of these powers, in order to form a just
opinion how far this system can be considered as a confederation, or a
consolidation of the states. Many of the advocates for, and most of the
opponents to this system, agree that the form of government most suitable for
the United States, is that of a confederation.

--- chunk_id: chunk-0059
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 438
content_hash: 185a6f82e3c5aa4a
prev_chunk_id: chunk-0058
next_chunk_id: chunk-0060
section_heading: Brutus V
document_type: specification

It will also be found
necessary to examine the extent of these powers, in order to form a just
opinion how far this system can be considered as a confederation, or a
consolidation of the states. Many of the advocates for, and most of the
opponents to this system, agree that the form of government most suitable for
the United States, is that of a confederation. The idea of a confederated
government is that of a number of independent states entering into a compact,
for the conducting certain general concerns, in which they have a common
interest, leaving the management of their internal and local affairs to their
separate governments. But whether the system proposed is of this nature cannot
be determined without a strict enquiry into the powers proposed to be granted. This constitution considers the people of the several states as one body
corporate, and is intended as an original compact, it will therefore dissolve
all contracts which may be inconsistent with it. This not only results from its
nature, but is expressly declared in the 6th article of it. The design of the
constitution is expressed in the preamble, to be, "in order to form a more
perfect union, to establish justice, insure domestic tranquility, provide for
the common defence, promote the general welfare, and secure the blessings of
liberty to ourselves and posterity." These are the ends this government is
to accomplish, and for which it is invested with certain powers, among these is
the power "to make all laws which are necessary and proper for
carrying into execution the foregoing powers, and all other powers
vested by this constitution in the government of the United States, or in any
department or officer thereof." It is a rule in construing a law to
consider the objects the legislature had in view in passing it, and to give it
such an explanation as to promote their intention. The same rule will apply in
explaining a constitution.

--- chunk_id: chunk-0060
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 390
content_hash: 003177433a75dee7
prev_chunk_id: chunk-0059
next_chunk_id: chunk-0061
section_heading: Brutus V
document_type: specification

The design of the
constitution is expressed in the preamble, to be, "in order to form a more
perfect union, to establish justice, insure domestic tranquility, provide for
the common defence, promote the general welfare, and secure the blessings of
liberty to ourselves and posterity." These are the ends this government is
to accomplish, and for which it is invested with certain powers, among these is
the power "to make all laws which are necessary and proper for
carrying into execution the foregoing powers, and all other powers
vested by this constitution in the government of the United States, or in any
department or officer thereof." It is a rule in construing a law to
consider the objects the legislature had in view in passing it, and to give it
such an explanation as to promote their intention. The same rule will apply in
explaining a constitution. The great objects then are declared in this preamble
in general and indefinite terms to be to provide for the common defence,
promote the general welfare, and an express power being vested in the
legislature to make all laws which shall be necessary and proper for carrying
into execution all the powers vested in the general government. The inference
is natural that the legislature will have an authority to make all laws which
they shall judge necessary for the common safety, and to promote the general
welfare. This amounts to a power to make laws at discretion: No terms can be
found more indefinite than these, and it is obvious, that the legislature alone
must judge what laws are proper and necessary for the purpose. It may be said,
that this way of explaining the constitution, is torturing and making it speak
what it never intended.

--- chunk_id: chunk-0061
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 400
content_hash: 8b4a7467df60a2bd
prev_chunk_id: chunk-0060
next_chunk_id: chunk-0062
section_heading: Brutus V
document_type: specification

This amounts to a power to make laws at discretion: No terms can be
found more indefinite than these, and it is obvious, that the legislature alone
must judge what laws are proper and necessary for the purpose. It may be said,
that this way of explaining the constitution, is torturing and making it speak
what it never intended. This is far from my intention, and I shall not even
insist upon this implied power, but join issue with those who say we are to
collect the idea of the powers given from the express words of the clauses
granting them; and it will not be difficult to shew that the same authority is
expressly given which is supposed to be implied in the forgoing paragraphs. In the 1st article, 8th section, it is declared, "that Congress shall
have power to lay and collect taxes, duties, imposts and excises, to pay the
debts, and provide for the common defence, and general welfare of the United
States." In the preamble, the intent of the constitution, among other
things, is declared to be to provide for the common defence, and promote the
general welfare, and in this clause the power is in express words given to
Congress "to provide for the common defence, and general welfare."
— And in the last paragraph of the same section there is an express
authority to make all laws which shall be necessary and proper for carrying
into execution this power. It is therefore evident, that the legislature under
this constitution may pass any law which they may think proper. It is true the
9th section restrains their power with respect to certain objects. But these
restrictions are very limited, some of them improper, some unimportant, and
others not easily understood, as I shall hereafter shew.

--- chunk_id: chunk-0062
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 400
content_hash: 7e49c388920f5416
prev_chunk_id: chunk-0061
next_chunk_id: chunk-0063
section_heading: Brutus V
document_type: specification

It is true the
9th section restrains their power with respect to certain objects. But these
restrictions are very limited, some of them improper, some unimportant, and
others not easily understood, as I shall hereafter shew. It has been urged that
the meaning I give to this part of the constitution is not the true one, that
the intent of it is to confer on the legislature the power to lay and collect
taxes, etc. in order to provide for the common defence and general welfare. To
this I would reply, that the meaning and intent of the constitution is to be
collected from the words of it, and I submit to the public, whether the
construction I have given it is not the most natural and easy. But admitting
the contrary opinion to prevail, I shall nevertheless, be able to shew, that
the same powers are substantially vested in the general government, by several
other articles in the constitution. It invests the legislature with authority
to lay and collect taxes, duties, imposts and excises, in order to provide for
the common defence, and promote the general welfare, and to pass all laws which
shall be necessary and proper for carrying this power into effect. To
comprehend the extent of this authority, it will be requisite to examine 1st. what is included in this power to lay and collect taxes, duties, imposts and
excises. 2d. What is implied in the authority, to pass all laws which shall be
necessary and proper for carrying this power into execution. 3d. What limitation, if any, is set to the exercise of this power by the
constitution. 1st. To detail the particulars comprehended in the general terms, taxes,
duties, imposts and excises, would require a volume, instead of a single piece
in a news-paper.

--- chunk_id: chunk-0063
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 434
content_hash: c1c3d99dfe367b4f
prev_chunk_id: chunk-0062
next_chunk_id: chunk-0064
section_heading: Brutus V
document_type: specification

1st. To detail the particulars comprehended in the general terms, taxes,
duties, imposts and excises, would require a volume, instead of a single piece
in a news-paper. Indeed it would be a task far beyond my ability, and to which
no one can be competent, unless possessed of a mind capable of comprehending
every possible source of revenue; for they extend to every possible way of
raising money, whether by direct or indirect taxation. Under this clause may be
imposed a poll-tax, a land-tax, a tax on houses and buildings, on windows and
fire places, on cattle and on all kinds of personal property: — It extends
to duties on all kinds of goods to any amount, to tonnage and poundage on
vessels, to duties on written instruments, newspapers, almanacks, and books:
— It comprehends an excise on all kinds of liquors, spirits, wines, cyder,
beer, etc. and indeed takes in duty or excise on every necessary or conveniency
of life; whether of foreign or home growth or manufactory. In short, we can
have no conception of any way in which a government can raise money from the
people, but what is included in one or other of three general terms. We may say
then that this clause commits to the hands of the general legislature every
conceivable source of revenue within the United States. Not only are these
terms very comprehensive, and extend to a vast number of objects, but the power
to lay and collect has great latitude; it will lead to the passing a vast
number of laws, which may affect the personal rights of the citizens of the
states, expose their property to fines and confiscation, and put their lives in
jeopardy: it opens a door to the appointment of a swarm of revenue and excise
officers to pray [sic] upon the honest and industrious part of the
community, eat up their substance, and riot on the spoils of the country. 2d.

--- chunk_id: chunk-0064
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 448
content_hash: af976372149198c7
prev_chunk_id: chunk-0063
next_chunk_id: chunk-0065
section_heading: Brutus V
document_type: specification

Not only are these
terms very comprehensive, and extend to a vast number of objects, but the power
to lay and collect has great latitude; it will lead to the passing a vast
number of laws, which may affect the personal rights of the citizens of the
states, expose their property to fines and confiscation, and put their lives in
jeopardy: it opens a door to the appointment of a swarm of revenue and excise
officers to pray [sic] upon the honest and industrious part of the
community, eat up their substance, and riot on the spoils of the country. 2d. We will next enquire into what is implied in the authority to pass all
laws which shall be necessary and proper to carry this power into execution. It is, perhaps, utterly impossible fully to define this power. The authority
granted in the first clause can only be understood in its full extent, by
descending to all the particular cases in which a revenue can be raised; the
number and variety of these cases are so endless, and as it were infinite, that
no man living has, as yet, been able to reckon them up. The greatest geniuses
in the world have been for ages employed in the research, and when mankind had
supposed that the subject was exhausted they have been astonished with the
refined improvements that have been made in modem times, and especially in the
English nation on the subject — If then the objects of this power cannot
be comprehended, how is it possible to understand the extent of that power
which can pass all laws which shall be necessary and proper for carrying it
into execution? It is truly incomprehensible. A case cannot be conceived of,
which is not included in this power. It is well known that the subject of
revenue is the most difficult and extensive in the science of government. It
requires the greatest talents of a statesman, and the most numerous and exact
provisions of the legislature.

--- chunk_id: chunk-0065
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 385
content_hash: 206d9a9e68090fbc
prev_chunk_id: chunk-0064
next_chunk_id: chunk-0066
section_heading: Brutus V
document_type: specification

It is well known that the subject of
revenue is the most difficult and extensive in the science of government. It
requires the greatest talents of a statesman, and the most numerous and exact
provisions of the legislature. The command of the revenues of a state gives the
command of every thing in it. — He that has the purse will have the sword,
and they that have both, have every thing; so that the legislature having every
source from which money can be drawn under their direction, with a right to
make all laws necessary and proper for drawing forth all the resource of the
country, would have, in fact, all power. Were I to enter into the detail, it would be easy to shew how this power in
its operation, would totally destroy all the powers of the individual states. But this is not necessary for those who will think for themselves, and it will
be useless to such as take things upon trust, nothing will awaken them to
reflection, until the iron hand of oppression compel them to it. I shall only remark, that this power, given to the federal legislature,
directly annihilates all the powers of the state legislatures. There cannot be
a greater solecism in politics than to talk of power in a government, without
the command of any revenue. It is as absurd as to talk of an animal without
blood, or the subsistence of one without food. Now the general government
having in their controul every possible source of revenue, and authority to
pass any law they may deem necessary to draw them forth, or to facilitate their
collection; no source of revenue is therefore left in the hands of any state.

--- chunk_id: chunk-0066
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 361
content_hash: 3209c618d9e771c9
prev_chunk_id: chunk-0065
next_chunk_id: chunk-0067
section_heading: Brutus V
document_type: specification

It is as absurd as to talk of an animal without
blood, or the subsistence of one without food. Now the general government
having in their controul every possible source of revenue, and authority to
pass any law they may deem necessary to draw them forth, or to facilitate their
collection; no source of revenue is therefore left in the hands of any state. Should any state attempt to raise money by law, the general government may
repeal or arrest it in the execution, for all their laws will be the supreme
law of the land: If then any one can be weak enough to believe that a
government can exist without having the authority to raise money to pay a
door-keeper to their assembly, he may believe that the state government can
exist, should this new constitution take place. It is agreed by most of the advocates of this new system, that the
government which is proper for the United States should be a confederated one;
that the respective states ought to retain a portion of their sovereignty, and
that they should preserve not only the forms of their legislatures, but also
the power to conduct certain internal concerns. How far the powers to be
retained by the states shall extend, is the question; we need not spend much
time on this subject, as it respects this constitution, for a government
without the power to raise money is one only in name. It is clear that the
legislatures of the respective states must be altogether dependent on the will
of the general legislature, for the means of supporting their government.

--- chunk_id: chunk-0067
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 426
content_hash: cc6cddcbd837cbdf
prev_chunk_id: chunk-0066
next_chunk_id: chunk-0068
section_heading: Brutus V
document_type: specification

How far the powers to be
retained by the states shall extend, is the question; we need not spend much
time on this subject, as it respects this constitution, for a government
without the power to raise money is one only in name. It is clear that the
legislatures of the respective states must be altogether dependent on the will
of the general legislature, for the means of supporting their government. The
legislature of the United States will have a right to exhaust every source of
revenue in every state, and to annul all laws of the states which may stand in
the way of effecting it; unless therefore we can suppose the state governments
can exist without money to support the officers who execute them, we must
conclude they will exist no longer than the general legislature choose they
should. Indeed the idea of any government existing, in any respect, as an
independent one, without any means of support in their own hands, is an
absurdity. If therefore, this constitution has in view, what many of its
framers and advocates say it has, to secure and guarantee to the separate
states the exercise of certain powers of government[,] it certainly ought to
have left in their hands some sources of revenue. It should have marked the
line in which the general government should have raised money, and set bounds
over which they should not pass, leaving to the separate states other means to
raise supplies for the support of their governments, and to discharge their
respective debts. To this it is objected, that the general government ought to
have power competent to the purposes of the union; they are to provide for the
common defence, to pay the debts of the United States, support foreign
ministers, and the civil establishment of the union, and to do these they ought
to have authority to raise money adequate to the purpose.

--- chunk_id: chunk-0068
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 394
content_hash: 5d004b5a1ae8f69d
prev_chunk_id: chunk-0067
next_chunk_id: chunk-0069
section_heading: Brutus V
document_type: specification

It should have marked the
line in which the general government should have raised money, and set bounds
over which they should not pass, leaving to the separate states other means to
raise supplies for the support of their governments, and to discharge their
respective debts. To this it is objected, that the general government ought to
have power competent to the purposes of the union; they are to provide for the
common defence, to pay the debts of the United States, support foreign
ministers, and the civil establishment of the union, and to do these they ought
to have authority to raise money adequate to the purpose. On this I observe,
that the state governments have also contracted debts, they require money to
support their civil officers, and how this is to be done, if they give to the
general government a power to raise money in every way in which it can possibly
be raised, with such a controul over the state legislatures as to prohibit
them, whenever the general legislature may think proper, from raising any
money. It is again objected that it is very difficult, if not impossible, to
draw the line of distinction between the powers of the general and state
governments on this subject. The first, it is said, must have the power of
raising the money necessary for the purposes of the union, if they are limited
to certain objects the revenue may fall short of a sufficiency for the public
exigencies, they must therefore have discretionary power. The line may be
easily and accurately drawn between the powers of the two governments on this
head. The distinction between external and internal taxes, is not a novel one
in this country, it is a plain one, and easily understood.

--- chunk_id: chunk-0069
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: 39ec73f621873c93
prev_chunk_id: chunk-0068
next_chunk_id: chunk-0070
section_heading: Brutus V
document_type: specification

The line may be
easily and accurately drawn between the powers of the two governments on this
head. The distinction between external and internal taxes, is not a novel one
in this country, it is a plain one, and easily understood. The first includes
impost duties on all imported goods; this species of taxes it is proper should
be laid by the general government; many reasons might be urged to shew that no
danger is to be apprehended from their exercise of it. They may be collected in
few places, and from few hands with certainty and expedition. But few officers
are necessary to be imployed in collecting them, and there is no danger of
oppression in laying them, because, if they are laid higher than trade will
bear, the merchants will cease importing, or smuggle their goods. We have
therefore sufficient security, arising from the nature of the thing, against
burdensome and intolerable impositions from this kind of tax. But the case is
far otherwise with regard to direct taxes; these include poll taxes, land
taxes, excises, duties on written instruments, on every thing we eat, drink, or
wear; they take hold of every species of property, and come home to every man's
house and packet. These are often so oppressive, as to grind the face of the
poor, and render the lives of the common people a burden to them. The great and
only security the people can have against oppression from this kind of taxes,
must rest in their representatives. If they are sufficiently numerous to be
well informed of the circumstances, and ability of those who send them, and
have a proper regard for the people, they will be secure. The general
legislature, as I have shewn in a former paper, will not be thus qualified, and
therefore, on this account, ought not to exercise the power of direct taxation.

--- chunk_id: chunk-0070
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 326
content_hash: 14447e818db9551a
prev_chunk_id: chunk-0069
next_chunk_id: chunk-0071
section_heading: Brutus V
document_type: specification

If they are sufficiently numerous to be
well informed of the circumstances, and ability of those who send them, and
have a proper regard for the people, they will be secure. The general
legislature, as I have shewn in a former paper, will not be thus qualified, and
therefore, on this account, ought not to exercise the power of direct taxation. If the power of laying imposts will not be sufficient, some other specific mode
of raising a revenue should have been assigned the general government; many may
be suggested in which their power may be accurately defined and limited, and it
would be much better to give them authority to lay and collect a duty on
exports, not to exceed a certain rate per cent, than to have surrendered every
kind of resource that the country has, to the complete abolition of the state
governments, and which will introduce such an infinite number of laws and
ordinances, fines and penalties, courts, and judges, collectors, and excisemen,
that when a man can number them, he may enumerate the stars of Heaven. I shall resume this subject in my next, and by an induction of particulars
shew, that this power, in its exercise, will subvert all state authority, and
will work to the oppression of the people, and that there are no restrictions
in the constitution that will soften its rigour, but rather the contrary. Brutus. Next | Previous | Text Version | Brutus
Contents |

--- chunk_id: chunk-0071
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 426
content_hash: dafe7eed51a0af9c
prev_chunk_id: chunk-0070
next_chunk_id: chunk-0072
section_heading: Brutus VI
document_type: specification

## Brutus VI

*Source file: brutus06.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #6



 

 VI


 27 December 1787


It is an important question, whether the general government of the United
States should be so framed, as to absorb and swallow up the state governments? or whether, on the contrary, the former ought not to be confined to certain
defined national objects, while the latter should retain all the powers which
concern the internal police of the states? I have, in my former papers, offered a variety of arguments to prove, that a
simple free government could not be exercised over this whole continent, and
that therefore we must either give up our liberties and submit to an arbitrary
one, or frame a constitution on the plan of confederation. Further reasons
might be urged to prove this point — but it seems unnecessary, because the
principal advocates of the new constitution admit of the position. The question
therefore between us, this being admitted, is, whether or not this system is so
formed as either directly to annihilate the state governments, or that in its
operation it will certainly effect it. If this is answered in the affirmative,
then the system ought not to be adopted, without such amendments as will avoid
this consequence. If on the contrary it can be shewn, that the state
governments are secured in their rights to manage the internal police of the
respective states, we must confine ourselves in our enquiries to the
organization of the government and the guards and provisions it contains to
prevent a misuse or abuse of power. To determine this question, it is
requisite, that we fully investigate the nature, and the extent of the powers
intended to be granted by this constitution to the rulers. In my last number I called your attention to this subject, and proved, as I
think, uncontrovertibly, that the powers given the legislature under the 8th

--- chunk_id: chunk-0072
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: 6037e21c46075ab3
prev_chunk_id: chunk-0071
next_chunk_id: chunk-0073
section_heading: section of the 1st article, had no other limitation than the discretion of the
document_type: specification

section of the 1st article, had no other limitation than the discretion of the
Congress. It was shewn, that even if the most favorable construction was given
to this paragraph, that the advocates for the new constitution could wish, it
will convey a power to lay and collect taxes, imposts, duties, and excises,
according to the discretion of the legislature, and to make all laws which they
shall judge proper and necessary to carry this power into execution. This I
shewed would totally destroy all the power of the state governments. To confirm
this, it is worth while to trace the operation of the government in some
particular instances. The general government is to be vested with authority to levy and collect
taxes, duties, and excises; the separate states have also power to impose
taxes, duties, and excises, except that they cannot lay duties on exports and
imports without the consent of Congress. Here then the two governments have
concurrent jurisdiction; both may lay impositions of this kind. But then the
general government have supperadded to this power, authority to make all laws
which shall be necessary and proper for carrying the foregoing power into
execution. Suppose then that both governments should lay taxes, duties, and
excises, and it should fall so heavy on the people that they would be unable,
or be so burdensome that they would refuse to pay them both — would it not
be necessary that the general legislature should suspend the collection of the
state tax? It certainly would. For, if the people could not, or would not pay
both, they must be discharged from the tax to the state, or the tax to the
general government could not be collected. — The conclusion therefore is
inevitable, that the respective state governments will not have the power to
raise one shilling in any way, but by the permission of the Congress.

--- chunk_id: chunk-0073
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 401
content_hash: 06d81f1e3c819be0
prev_chunk_id: chunk-0072
next_chunk_id: chunk-0074
section_heading: section of the 1st article, had no other limitation than the discretion of the
document_type: specification

For, if the people could not, or would not pay
both, they must be discharged from the tax to the state, or the tax to the
general government could not be collected. — The conclusion therefore is
inevitable, that the respective state governments will not have the power to
raise one shilling in any way, but by the permission of the Congress. I presume
no one will pretend, that the states can exercise legislative authority, or
administer justice among their citizens for any length of time, without being
able to raise a sufficiency to pay those who administer their governments. If this be true, and if the states can raise money only by permission of the
general government, it follows that the state governments will be dependent on
the will of the general government for their existence. What will render this power in Congress effectual and sure in its operation
is, that the government will have complete judicial and executive authority to
carry all their laws into effect, which will be paramount to the judicial and
executive authority of the individual states: in vain therefore will be all
interference of the legislatures, courts, or magistrates of any of the states
on the subject; for they will be subordinate to the general government, and
engaged by oath to support it, and will be constitutionally bound to submit to
their decisions. The general legislature will be empowered to lay any tax they chuse, to
annex any penalties they please to the breach of their revenue laws; and to
appoint as many officers as they may think proper to collect the taxes. They
will have authority to farm the revenues and to vest the farmer general, with
his subalterns, with plenary powers to collect them, in any way which to them
may appear eligible.

--- chunk_id: chunk-0074
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 417
content_hash: ec931d3775102f65
prev_chunk_id: chunk-0073
next_chunk_id: chunk-0075
section_heading: section of the 1st article, had no other limitation than the discretion of the
document_type: specification

The general legislature will be empowered to lay any tax they chuse, to
annex any penalties they please to the breach of their revenue laws; and to
appoint as many officers as they may think proper to collect the taxes. They
will have authority to farm the revenues and to vest the farmer general, with
his subalterns, with plenary powers to collect them, in any way which to them
may appear eligible. And the courts of law, which they will be authorized to
institute, will have cognizance of every case arising under the revenue laws,
the conduct of all the officers employed in collecting them; and the officers
of these courts will execute their judgments. There is no way, therefore, of
avoiding the destruction of the state governments, whenever the Congress please
to do it, unless the people rise up, and, with a strong hand, resist and
prevent the execution of constitutional laws. The fear of this, will, it is
presumed, restrain the general government, for some time, within proper bounds;
but it will not be many years before they will have a revenue, and force, at
their command, which will place them above any apprehensions on that score. How far the power to lay and collect duties and excises, may operate to
dissolve the state governments, and oppress the people, it is impossible to
say. It would assist us much in forming a just opinion on this head, to
consider the various objects to which this kind of taxes extend, in European
nations, and the infinity of laws they have passed respecting them. Perhaps, if
leisure will permit, this may be essayed in some future paper. It was observed in my last number, that the power to lay and collect duties
and excises, would invest the Congress with authority to impose a duty and
excise on every necessary and convenience of life.

--- chunk_id: chunk-0075
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 353
content_hash: 61faae4a6902d1d5
prev_chunk_id: chunk-0074
next_chunk_id: chunk-0076
section_heading: section of the 1st article, had no other limitation than the discretion of the
document_type: specification

Perhaps, if
leisure will permit, this may be essayed in some future paper. It was observed in my last number, that the power to lay and collect duties
and excises, would invest the Congress with authority to impose a duty and
excise on every necessary and convenience of life. As the principal object of
the government, in laying a duty or excise, will be, to raise money, it is
obvious, that they will fix on such articles as are of the most general use and
consumption; because, unless great quantities of the article, on which the duty
is laid, is used, the revenue cannot be considerable. We may therefore presume,
that the articles which will be the object of this species of taxes will be
either the real necessaries of life; or if not these, such as from custom and
habit are esteemed so. I will single out a few of the productions of our own
country, which may, and probably will, be of the number. Cider is an article that most probably will be one of those on which an
excise will be laid, because it is one, which this country produces in great
abundance, which is in very general use, is consumed in great quantities, and
which may be said too not to be a real necessary of life. An excise on this
would raise a large sum of money in the United States. How would the power, to
lay and collect an excise on cider, and to pass all laws proper and necessary
to carry it into execution, operate in its exercise?

--- chunk_id: chunk-0076
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 426
content_hash: 51e314bf23e44e05
prev_chunk_id: chunk-0075
next_chunk_id: chunk-0077
section_heading: section of the 1st article, had no other limitation than the discretion of the
document_type: specification

An excise on this
would raise a large sum of money in the United States. How would the power, to
lay and collect an excise on cider, and to pass all laws proper and necessary
to carry it into execution, operate in its exercise? It might be necessary, in
order to collect the excise on cider, to grant to one man, in each county, an
exclusive right of building and keeping cider-mills, and oblige him to give
bonds and security for payment of the excise; or, if this was not done, it
might be necessary to license the mills, which are to make this liquor, and to
take from them security, to account for the excise; or, if otherwise, a great
number of officers must be employed, to take account of the cider made, and to
collect the duties on it. Porter, ale, and all kinds of malt-liquors, are articles that would probably
be subject also to an excise. It would be necessary, in order to collect such
an excise, to regulate the manufactory of these, that the quantity made might
be ascertained or otherwise security could not be had for the payment of the
excise. Every brewery must then be licensed, and officers appointed, to take
account of its product, and to secure the payment of the duty, or excise,
before it is sold. Many other articles might be named, which would be objects
of this species of taxation, but I refrain from enumerating them. It will
probably be said, by those who advocate this system, that the observations
already made on this head, are calculated only to inflame the minds of the
people, with the apprehension of dangers merely imaginary. That there is not
the least reason to apprehend, the general legislature will exercise their
power in this manner. To this I would only say, that these kinds of taxes exist
in Great Britain, and are severely felt.

--- chunk_id: chunk-0077
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 413
content_hash: 41c40aed04b80849
prev_chunk_id: chunk-0076
next_chunk_id: chunk-0078
section_heading: section of the 1st article, had no other limitation than the discretion of the
document_type: specification

That there is not
the least reason to apprehend, the general legislature will exercise their
power in this manner. To this I would only say, that these kinds of taxes exist
in Great Britain, and are severely felt. The excise on cider and perry, was
imposed in that nation a few years ago, and it is in the memory of every one,
who read the history of the transaction, what great tumults it occasioned. This power, exercised without limitation, will introduce itself into every
comer of the city, and country — It will wait upon the ladies at their
toilett, and will not leave them in any of their domestic concerns; it will
accompany them to the ball, the play, and the assembly; it will go with them
when they visit, and will, on all occasions, sit beside them in their
carriages, nor will it desert them even at church; it will enter the house of
every gentleman, watch over his cellar, wait upon his cook in the kitchen,
follow the servants into the parlour, preside over the table, and note down all
he eats or drinks; it will attend him to his bed-chamber, and watch him while
he sleeps; it will take cognizance of the professional man in his office, or
his study; it will watch the merchant in the counting-house, or in his store;
it will follow the mechanic to his shop, and in his work, and will haunt him in
his family, and in his bed; it will be a constant companion of the industrious
farmer in all his labour, it will be with him in the house, and in the field,
observe the toil of his hands, and the sweat of his brow; it will penetrate
into the most obscure cottage; and finally, it will light upon the head of
every person in the United States.

--- chunk_id: chunk-0078
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 402
content_hash: 57e784c5af07964c
prev_chunk_id: chunk-0077
next_chunk_id: chunk-0079
section_heading: section of the 1st article, had no other limitation than the discretion of the
document_type: specification

The excise on cider and perry, was
imposed in that nation a few years ago, and it is in the memory of every one,
who read the history of the transaction, what great tumults it occasioned. This power, exercised without limitation, will introduce itself into every
comer of the city, and country — It will wait upon the ladies at their
toilett, and will not leave them in any of their domestic concerns; it will
accompany them to the ball, the play, and the assembly; it will go with them
when they visit, and will, on all occasions, sit beside them in their
carriages, nor will it desert them even at church; it will enter the house of
every gentleman, watch over his cellar, wait upon his cook in the kitchen,
follow the servants into the parlour, preside over the table, and note down all
he eats or drinks; it will attend him to his bed-chamber, and watch him while
he sleeps; it will take cognizance of the professional man in his office, or
his study; it will watch the merchant in the counting-house, or in his store;
it will follow the mechanic to his shop, and in his work, and will haunt him in
his family, and in his bed; it will be a constant companion of the industrious
farmer in all his labour, it will be with him in the house, and in the field,
observe the toil of his hands, and the sweat of his brow; it will penetrate
into the most obscure cottage; and finally, it will light upon the head of
every person in the United States. To all these different classes of people,
and in all these circumstances, in which it will attend them, the language in
which it will address them, will be GIVE! GIVE!

--- chunk_id: chunk-0079
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 417
content_hash: 0e0273d7ad9b7664
prev_chunk_id: chunk-0078
next_chunk_id: chunk-0080
section_heading: section of the 1st article, had no other limitation than the discretion of the
document_type: specification

To all these different classes of people,
and in all these circumstances, in which it will attend them, the language in
which it will address them, will be GIVE! GIVE! A power that has such latitude, which reaches every person in the community
in every conceivable circumstance, and lays hold of every species of property
they possess, and which has no bounds set to it, but the discretion of those
who exercise it[,] I say, such a power must necessarily, from its very nature,
swallow up all the power of the state governments. I shall add but one other observation on this head, which is this — It
appears to me a solecism, for two men, or bodies of men, to have unlimited
power respecting the same object. It contradicts the scripture maxim, which
saith, "no man can serve two masters," the one power or the other
must prevail, or else they will destroy each other, and neither of them effect
their purpose. It may be compared to two mechanic powers, acting upon the same
body in opposite directions, the consequence would be, if the powers were
equal, the body would remain in a state of rest, or if the force of the one was
superior to that of the other, the stronger would prevail, and overcome the
resistance of the weaker. But it is said, by some of the advocates of this system, "That the idea
that Congress can levy taxes at pleasure, is false, and the suggestion wholly
unsupported: that the preamble to the constitution is declaratory of the
purposes of the union, and the assumption of any power not necessary to
establish justice, &c. to provide for the common defence, &c. will be
unconstitutional. Besides, in the very clause which gives the power of levying
duties and taxes, the purposes to which the money shall be appropriated, are
specified, viz.

--- chunk_id: chunk-0080
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 420
content_hash: dd6eab7b11678746
prev_chunk_id: chunk-0079
next_chunk_id: chunk-0081
section_heading: section of the 1st article, had no other limitation than the discretion of the
document_type: specification

will be
unconstitutional. Besides, in the very clause which gives the power of levying
duties and taxes, the purposes to which the money shall be appropriated, are
specified, viz. to pay the debts, and provide for the common defence and
general welfare."1 I would ask
those, who reason thus, to define what ideas are included under the terms, to
provide for the common defence and general welfare? Are these terms definite,
and will they be understood in the same manner, and to apply to the same cases
by every one? No one will pretend they will. It will then be matter of opinion,
what tends to the general welfare; and the Congress will be the only judges in
the matter. To provide for the general welfare, is an abstract proposition,
which mankind differ in the explanation of, as much as they do on any political
or moral proposition that can be proposed; the most opposite measures may be
pursued by different parties, and both may profess, that they have in view the
general welfare; and both sides may be honest in their professions, or both may
have sinister views. Those who advocate this new constitution declare, they are
influenced by a regard to the general welfare; those who oppose it, declare
they are moved by the same principle; and I have no doubt but a number on both
sides are honest in their professions; and yet nothing is more certain than
this, that to adopt this constitution, and not to adopt it, cannot both of them
be promotive of the general welfare. It is as absurd to say, that the power of Congress is limited by these
general expressions, "to provide for the common safety, and general
welfare," as it would be to say, that it would be limited, had the
constitution said they should have power to lay taxes, &c. at will and
pleasure.

--- chunk_id: chunk-0081
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 420
content_hash: affe9e0ad48fa0f1
prev_chunk_id: chunk-0080
next_chunk_id: chunk-0082
section_heading: section of the 1st article, had no other limitation than the discretion of the
document_type: specification

It is as absurd to say, that the power of Congress is limited by these
general expressions, "to provide for the common safety, and general
welfare," as it would be to say, that it would be limited, had the
constitution said they should have power to lay taxes, &c. at will and
pleasure. Were this authority given, it might be said, that under it the
legislature could not do injustice, or pursue any measures, but such as were
calculated to promote the public good, and happiness. For every man, rulers as
well as others, are bound by the immutable laws of God and reason, always to
will what is right. It is certainly right and fit, that the governors of every
people should provide for the common defence and general welfare; every
government, therefore, in the world, even the greatest despot, is limited in
the exercise of his power. But however just this reasoning may be, it would be
found, in practice, a most pitiful restriction. The government would always
say, their measures were designed and calculated to promote the public good;
and there being no judge between them and the people, the rulers themselves
must, and would always, judge for themselves. There are others of the favourers of this system, who admit, that the power
of the Congress under it, with respect to revenue, will exist without
limitation, and contend, that so it ought to be. It is said, "The power to raise armies, to build and equip fleets, and
to provide for their support, ought to exist without limitation, because it is
impossible to foresee, or to define, the extent and variety of national
exigencies, or the correspondent extent and variety of the means which may be
necessary to satisfy them.["]


This, it is said, "is one of those truths which, to correct and
unprejudiced minds, carries its own evidence along with it.

--- chunk_id: chunk-0082
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 425
content_hash: cba89ff2f57c3f69
prev_chunk_id: chunk-0081
next_chunk_id: chunk-0083
section_heading: section of the 1st article, had no other limitation than the discretion of the
document_type: specification

There are others of the favourers of this system, who admit, that the power
of the Congress under it, with respect to revenue, will exist without
limitation, and contend, that so it ought to be. It is said, "The power to raise armies, to build and equip fleets, and
to provide for their support, ought to exist without limitation, because it is
impossible to foresee, or to define, the extent and variety of national
exigencies, or the correspondent extent and variety of the means which may be
necessary to satisfy them.["]


This, it is said, "is one of those truths which, to correct and
unprejudiced minds, carries its own evidence along with it. It rests upon
axioms as simple as they are universal: the means ought to be proportioned to
the end; the person, from whose agency the attainment of any end is expected,
ought to possess the means by which it is to be attained."2


This same writer insinuates, that the opponents to the plan promulgated by
the convention, manifests a want of candor, in objecting to the extent of the
powers proposed to be vested in this government; because he asserts, with an
air of confidence, that the powers ought to be unlimited as to the object to
which they extend; and that this position, if not self-evident, is at least
clearly demonstrated by the foregoing mode of reasoning. But with submission to
this author's better judgment, I humbly conceive his reasoning will appear,
upon examination, more specious than solid. The means, says the gentleman,
ought to be proportioned to the end: admit the proposition to be true it is
then necessary to enquire, what is the end of the government of the United
States, in order to draw any just conclusions from it. Is this end simply to
preserve the general government, and to provide for the common defence and
general welfare of the union only?

--- chunk_id: chunk-0083
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 432
content_hash: defdac320eb81b1a
prev_chunk_id: chunk-0082
next_chunk_id: chunk-0084
section_heading: section of the 1st article, had no other limitation than the discretion of the
document_type: specification

The means, says the gentleman,
ought to be proportioned to the end: admit the proposition to be true it is
then necessary to enquire, what is the end of the government of the United
States, in order to draw any just conclusions from it. Is this end simply to
preserve the general government, and to provide for the common defence and
general welfare of the union only? certainly not: for beside this, the state
governments are to be supported, and provision made for the managing such of
their internal concerns as are allotted to them. It is admitted, "that the
circumstances of our country are such, as to demand a compound, instead of a
simple, a confederate, instead of a sole government," that the objects of
each ought to be pointed out, and that each ought to possess ample authority to
execute the powers committed to them. The government then, being complex in its
nature, the end it has in view is so also; and it is as necessary, that the
state governments should possess the means to attain the ends expected from
them, as for the general government. Neither the general government, nor the
state governments, ought to be vested with all the powers proper to be
exercised for promoting the ends of government. The powers are divided between
them — certain ends are to be attained by the one, and other certain ends
by the other; and these, taken together, include all the ends of good
government. This being the case, the conclusion follows, that each should be
furnished with the means, to attain the ends, to which they are designed. To apply this reasoning to the case of revenue; the general government is
charged with the care of providing for the payment of the debts of the United
States; supporting the general government, and providing for the defence of the
union. To obtain these ends, they should be furnished with means.

--- chunk_id: chunk-0084
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 441
content_hash: 24e3c30d5bf27889
prev_chunk_id: chunk-0083
next_chunk_id: chunk-0085
section_heading: section of the 1st article, had no other limitation than the discretion of the
document_type: specification

To apply this reasoning to the case of revenue; the general government is
charged with the care of providing for the payment of the debts of the United
States; supporting the general government, and providing for the defence of the
union. To obtain these ends, they should be furnished with means. But does it
thence follow, that they should command all the revenues of the United States! Most certainly it does not. For if so, it will follow, that no means will be
left to attain other ends, as necessary to the happiness of the country, as
those committed to their care. The individual states have debts to discharge;
their legislatures and executives are to be supported, and provision is to be
made for the administration of justice in the respective states. For these
objects the general government has no authority to provide; nor is it proper it
should. It is clear then. that the states should have the command of such
revenues, as to answer the ends they have to obtain. To say, "that the
circumstances that endanger the safety of nations are infinite," and from
hence to infer, that all the sources of revenue in the states should be yielded
to the general government, is not conclusive reasoning: for the Congress are
authorized only to controul in general concerns, and not regulate local and
internal ones; and these are as essentially requisite to be provided for as
those. The peace and happiness of a community is as intimately connected with
the prudent direction of their domestic affairs, and the due administration of
justice among themselves, as with a competent provision for their defence
against foreign invaders, and indeed more so. Upon the whole, I conceive, that there cannot be a clearer position than
this, that the state governments ought to have an uncontroulable power to raise
a revenue, adequate to the exigencies of their governments; and, I presume, no
such power is left them by this constitution. Brutus. 1.

--- chunk_id: chunk-0085
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 45
content_hash: c33907e97b65ae55
prev_chunk_id: chunk-0084
next_chunk_id: chunk-0086
section_heading: section of the 1st article, had no other limitation than the discretion of the
document_type: specification

Brutus. 1. Vide an examination into the leading principles of
the federal constitution, printed in Philadelphia, Page 34. 2. Vide the Federalist, No. 23. Next | Previous | Text Version | Brutus
Contents |

--- chunk_id: chunk-0086
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 320
content_hash: 67efcc91443c04ef
prev_chunk_id: chunk-0085
next_chunk_id: chunk-0087
section_heading: Brutus VII
document_type: specification

## Brutus VII

*Source file: brutus07.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #7



 

 VII


 3 January 1788


The result of our reasoning in the two preceeding numbers is this, that in a
confederated government, where the powers are divided between the general and
the state government, it is essential to its existence, that the revenues of
the country, without which no government can exist, should be divided between
them, and so apportioned to each, as to answer their respective exigencies, as
far as human wisdom can effect such a division and apportionment. It has been shewn, that no such allotment is made in this constitution, but
that every source of revenue is under the controul of the Congress; it
therefore follows, that if this system is intended to be a complex and not a
simple, a confederate and not an entire consolidated government, it contains in
it the sure seeds of its own dissolution. — One of two things must happen
— Either the new constitution will become a mere nudum pactum, and
all the authority of the rulers under it be cried down, as has happened to the
present confederation — Or the authority of the individual states will be
totally supplanted, and they will retain the mere form without any of the
powers of government. — To one or the other of these issues, I think, this
new government, if it is adopted, will advance with great celerity.

--- chunk_id: chunk-0087
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 374
content_hash: 3ef3248379d8818b
prev_chunk_id: chunk-0086
next_chunk_id: chunk-0088
section_heading: Brutus VII
document_type: specification

— One of two things must happen
— Either the new constitution will become a mere nudum pactum, and
all the authority of the rulers under it be cried down, as has happened to the
present confederation — Or the authority of the individual states will be
totally supplanted, and they will retain the mere form without any of the
powers of government. — To one or the other of these issues, I think, this
new government, if it is adopted, will advance with great celerity. It is said, I know, that such a separation of the sources of revenue, cannot
be made without endangering the public safety — "unless (says a
writer) it can be shewn that the circumstances which may affect the public
safety are reducible within certain determinate limits; unless the contrary of
this position can be fairly and rationally disputed; it must be admitted as a
necessary consequence, that there can be no limitation of that authority which
is to provide for the defence and protection of the community,
&c."1


The pretended demonstration of this writer will instantly vanish, when it is
considered, that the protection and defence of the community is not
intended to be entrusted solely into the hands of the general
government, and by his own confession it ought not to be. It is true this
system commits to the general government the protection and defence of the
community against foreign force and invasion, against piracies and felonies on
the high seas, and against insurrections among ourselves. They are also
authorised to provide for the administration of justice in certain matters of a
general concern, and in some that I think are not so.

--- chunk_id: chunk-0088
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 385
content_hash: ece93a0b6a872441
prev_chunk_id: chunk-0087
next_chunk_id: chunk-0089
section_heading: Brutus VII
document_type: specification

It is true this
system commits to the general government the protection and defence of the
community against foreign force and invasion, against piracies and felonies on
the high seas, and against insurrections among ourselves. They are also
authorised to provide for the administration of justice in certain matters of a
general concern, and in some that I think are not so. But it ought to be left
to the state governments to provide for the protection and defence of the
citizen against the hand of private violence, and the wrongs done or attempted
by individuals to each other — Protection and defence against the
murderer, the robber, the thief, the cheat, and the unjust person, is to be
derived from the respective state governments. — The just way of reasoning
therefore on this subject is this, the general government is to provide for the
protection and defence of the community against foreign attacks, &c., they
therefore ought to have authority sufficient to effect this, so far as is
consistent with the providing for our internal protection and defence. The
state governments are entrusted with the care of administring justice among its
citizens, and the management of other internal concerns, they ought therefore
to retain power adequate to the end. The preservation of internal peace and
good order, and the due administration of law and justice, ought to be the
first care of every government. — The happiness of a people depends
infinitely more on this than it does upon all that glory and respect which
nations acquire by the most brilliant martial achievements — and I believe
history will furnish but few examples of nations who have duly attended to
these, who have been subdued by foreign invaders.

--- chunk_id: chunk-0089
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 446
content_hash: a0a2eabd1c7d29e5
prev_chunk_id: chunk-0088
next_chunk_id: chunk-0090
section_heading: Brutus VII
document_type: specification

The preservation of internal peace and
good order, and the due administration of law and justice, ought to be the
first care of every government. — The happiness of a people depends
infinitely more on this than it does upon all that glory and respect which
nations acquire by the most brilliant martial achievements — and I believe
history will furnish but few examples of nations who have duly attended to
these, who have been subdued by foreign invaders. If a proper respect and
submission to the laws prevailed over all orders of men in our country; and if
a spirit of public and private justice, oeconomy and industry influenced the
people, we need not be under any apprehensions but what they would be ready to
repel any invasion that might be made on the country. And more than this, I
would not wish from them — A defensive war is the only one I think
justifiable — I do not make these observations to prove, that a government
ought not to be authorised to provide for the protection and defence of a
country against external enemies, but to shew that this is not the most
important, much less the only object of their care. The European governments are almost all of them framed, and administered
with a view to arms, and war, as that in which their chief glory consists; they
mistake the end of government — it was designed to save men[']s lives, not
to destroy them. We ought to furnish the world with an example of a great
people, who in their civil institutions hold chiefly in view, the attainment of
virtue, and happiness among ourselves. Let the monarchs, in Europe, share among
them the glory of depopulating countries, and butchering thousands of their
innocent citizens, to revenge private quarrels, or to punish an insult offered
to a wife, a mistress, or a favorite: I envy them not the honor, and I pray
heaven this country may never be ambitious of it.

--- chunk_id: chunk-0090
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 405
content_hash: 582b8fa4f5c99ce4
prev_chunk_id: chunk-0089
next_chunk_id: chunk-0091
section_heading: Brutus VII
document_type: specification

We ought to furnish the world with an example of a great
people, who in their civil institutions hold chiefly in view, the attainment of
virtue, and happiness among ourselves. Let the monarchs, in Europe, share among
them the glory of depopulating countries, and butchering thousands of their
innocent citizens, to revenge private quarrels, or to punish an insult offered
to a wife, a mistress, or a favorite: I envy them not the honor, and I pray
heaven this country may never be ambitious of it. The czar Peter the great,
acquired great glory by his arms; but all this was nothing, compared with the
true glory which he obtained, by civilizing his rude and barbarous subjects,
diffusing among them knowledge, and establishing, and cultivating the arts of
life: by the former he desolated countries, and drenched the earth with human
blood: by the latter he softened the ferocious nature of his people, and
pointed them to the means of human happiness. The most important end of
government then, is the proper direction of its internal policy, and oeconomy;
this is the province of the state governments, and it is evident, and is indeed
admitted, that these ought to be under their controul. Is it not then
preposterous, and in the highest degree absurd, when the state governments are
vested with powers so essential to the peace and good order of society, to take
from them the means of their own preservation? The idea, that the powers of congress in respect to revenue ought to be
unlimited, "because the circumstances which may affect the public safety
are not reducible to certain determinate limits," is novel, as it relates
to the government of the united states. The inconveniencies which resulted from
the feebleness of the present confederation was discerned, and felt soon after
its adoption.

--- chunk_id: chunk-0091
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: 64e3d04bcff260e5
prev_chunk_id: chunk-0090
next_chunk_id: chunk-0092
section_heading: Brutus VII
document_type: specification

The idea, that the powers of congress in respect to revenue ought to be
unlimited, "because the circumstances which may affect the public safety
are not reducible to certain determinate limits," is novel, as it relates
to the government of the united states. The inconveniencies which resulted from
the feebleness of the present confederation was discerned, and felt soon after
its adoption. It was soon discovered, that a power to require money, without
either the authority or means to enforce a collection of it, could not be
relied upon either to provide for the common defence, the discharge of the
national debt, or for support of government. Congress therefore, so early as
February 1781, recommended to the states to invest them with a power to levy an
impost of five per cent ad valorem, on all imported goods, as a fund to be
appropriated to discharge the debts already contracted, or which should
hereafter be contracted for the support of the war, to be continued until the
debts should be fully and finally discharged. There is not the most distant
idea held out in this act, that an unlimited power to collect taxes, duties and
excises was necessary to be vested in the united states, and yet this was a
time of the most pressing danger and distress. The idea then was, that if
certain definite funds were assigned to the union, which were certain in their
natures, productive, and easy of collection, it would enable them to answer
their engagements, and provide for their defence, and the impost of five per
cent was fixed upon for the purpose. This same subject was revived in the winter and spring of 1783, and after a
long consideration of the subject, and many schemes were proposed; the result
was, a recommendation of the revenue system of April 1783; this system does not
suggest an idea that it was necessary to grant the United States unlimited
authority in matters of revenue.

--- chunk_id: chunk-0092
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: 63334886c2995402
prev_chunk_id: chunk-0091
next_chunk_id: chunk-0093
section_heading: Brutus VII
document_type: specification

The idea then was, that if
certain definite funds were assigned to the union, which were certain in their
natures, productive, and easy of collection, it would enable them to answer
their engagements, and provide for their defence, and the impost of five per
cent was fixed upon for the purpose. This same subject was revived in the winter and spring of 1783, and after a
long consideration of the subject, and many schemes were proposed; the result
was, a recommendation of the revenue system of April 1783; this system does not
suggest an idea that it was necessary to grant the United States unlimited
authority in matters of revenue. A variety of amendments were proposed to this
system, some of which are upon the journals of Congress, but it does not appear
that any of them proposed to invest the general government with discretionary
power to raise money. On the contrary, all of them limit them to certain
definite objects, and fix the bounds over which they could not pass. This
recommendation was passed at the conclusion of the war, and was founded on an
estimate of the whole national debt. It was computed, that one million and an
half of dollars, in addition to the impost, was a sufficient sum to pay the
annual interest of the debt, and gradually to abolish the principal. —
Events have proved that their estimate was sufficiently liberal, as the
domestic debt appears upon its being adjusted to be less than it was computed,
and since this period a considerable portion of the principal of the domestic
debt has been discharged by the sale of the western lands. It has been
constantly urged by Congress, and by individuals, ever since, until lately,
that had this revenue been appropriated by the states, as it was recommended,
it would have been adequate to every exigency of the union.

--- chunk_id: chunk-0093
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 449
content_hash: a9359b7f55a5ad95
prev_chunk_id: chunk-0092
next_chunk_id: chunk-0094
section_heading: Brutus VII
document_type: specification

—
Events have proved that their estimate was sufficiently liberal, as the
domestic debt appears upon its being adjusted to be less than it was computed,
and since this period a considerable portion of the principal of the domestic
debt has been discharged by the sale of the western lands. It has been
constantly urged by Congress, and by individuals, ever since, until lately,
that had this revenue been appropriated by the states, as it was recommended,
it would have been adequate to every exigency of the union. Now indeed it is
insisted, that all the treasures of the country are to be under the controul of
that body, whom we are to appoint to provide for our protection and defence
against foreign enemies. The debts of the several states, and the support of
the governments of them are to trust to fortune and accident. If the union
should not have occasion for all the money they can raise, they will leave a
portion for the state, but this must be a matter of mere grace and favor. Doctrines like these would not have been listened to by any state in the union,
at a time when we were pressed on every side by a powerful enemy, and were
called upon to make greater exertions than we have any reason to expect we
shall ever be again. The ability and character of the convention, who framed
the preferred constitution, is sounded forth and reiterated by every declaimer
and writer in its favor, as a powerful argument to induce its adoption. But are
not the patriots who guided our councils in the perilous times of the war,
entitled to equal respect. How has it happened, that none of these perceived a
truth, which it is pretended is capable of such clear demonstration, that the
power to raise a revenue should be deposited in the general government without
limitation? Were the men so dull of apprehension, so incapable of reasoning as
not to be able to draw the inference?

--- chunk_id: chunk-0094
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 405
content_hash: bcea56abcccc99e7
prev_chunk_id: chunk-0093
next_chunk_id: chunk-0095
section_heading: Brutus VII
document_type: specification

How has it happened, that none of these perceived a
truth, which it is pretended is capable of such clear demonstration, that the
power to raise a revenue should be deposited in the general government without
limitation? Were the men so dull of apprehension, so incapable of reasoning as
not to be able to draw the inference? The truth is, no such necessity exists. It is a thing practicable, and by no means so difficult as is pretended, to
limit the powers of the general government in respect to revenue, while yet
they may retain reasonable means to provide for the common defence. It is admitted, that human wisdom cannot foresee all the variety of
circumstances that may arise to endanger the safety of nations — and it
may with equal truth be added, that the power of a nation, exerted with its
utmost vigour, may not be equal to repel a force with which it may be assailed,
much less may it be able, with its ordinary resources and power, to oppose an
extraordinary and unexpected attack; — but yet every nation may form a
rational judgment, what force will be competent to protect and defend it,
against any enemy with which it is probable it may have to contend. In
extraordinary attacks, every country must rely upon the spirit and special
exertions of its inhabitants — and these extraordinary efforts will always
very much depend upon the happiness and good order the people experience from a
wise and prudent administration of their internal government. The states are as
capable of making a just estimate on this head, as perhaps any nation in the
world. — We have no powerful nation in our neighbourhood; if we are to go
to war, it must either be with the Aboriginal natives, or with European
nations.

--- chunk_id: chunk-0095
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 446
content_hash: d311e7bb97f5c8eb
prev_chunk_id: chunk-0094
next_chunk_id: chunk-0096
section_heading: Brutus VII
document_type: specification

The states are as
capable of making a just estimate on this head, as perhaps any nation in the
world. — We have no powerful nation in our neighbourhood; if we are to go
to war, it must either be with the Aboriginal natives, or with European
nations. The first are so unequal to a contest with this whole continent, that
they are rather to be dreaded for the depredations they may make on our
frontiers, than for any impression they will ever be able to make on the body
of the country. Some of the European nations, it is true, have provinces
bordering upon us, but from these, unsupported by their European forces, we
have nothing to apprehend; if any of them should attack us, they will have to
transport their armies across the atlantic, at immense expence, while we should
defend ourselves in our own country, which abounds with every necessary of
life. For defence against any assault, which there is any probability will be
made upon us, we may easily form an estimate. I may be asked to point out the sources, from which the general government
could derive a sufficient revenue, to answer the demands of the union. Many
might be suggested, and for my part, I am not disposed to be tenacious of my
own opinion on the subject. If the object be defined with precision, and will
operate to make the burden fall any thing nearly equal on the different parts
of the union, I shall be satisfied. There is one source of revenue, which it is agreed, the general government
ought to have the sole controul of. This is an impost upon all goods imported
from foreign countries. This would, of itself, be very productive, and would be
collected with ease and certainty. — It will be a fund too, constantly
encreasing — for our commerce will grow, with the productions of the
country; and these, together with our consumption of foreign goods, will
encrease with our population.

--- chunk_id: chunk-0096
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 432
content_hash: 10cd109914065b40
prev_chunk_id: chunk-0095
next_chunk_id: chunk-0097
section_heading: Brutus VII
document_type: specification

This would, of itself, be very productive, and would be
collected with ease and certainty. — It will be a fund too, constantly
encreasing — for our commerce will grow, with the productions of the
country; and these, together with our consumption of foreign goods, will
encrease with our population. It is said, that the impost will not produce a
sufficient sum to satisfy the demands of the general government; perhaps it
would not. Let some other then, equally well defined, be assigned them: —
that this is practicable is certain, because such particular objects were
proposed by some members of Congress when the revenue system of April 1783, was
agitated in that body. It was then moved, that a tax at the rate of _____
ninetieths of a dollar on surveyed land, and a house tax of half a dollar on a
house, should be granted to the United States. I do not mention this, because I
approve of raising a revenue in this mode. I believe such a tax would be
difficult in its collection, and inconvenient in its operation. But it shews,
that it has heretofore been the sense of some of those, who now contend, that
the general government should have unlimited authority in matters of revenue,
that their authority should be definite and limitted on that head. — My
own opinion is, that the objects from which the general government should have
authority to raise a revenue, should be of such a nature, that the tax should
be raised by simple laws, with few officers, with certainty and expedition, and
with the least interference with the internal police of the states. — Of
this nature is the impost on imported goods — and it appears to me that a
duty on exports, would also be of this nature — and therefore, for ought I
can discover, this would be the best source of revenue to grant the general
government.

--- chunk_id: chunk-0097
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 372
content_hash: de4a2a5a7e8583d4
prev_chunk_id: chunk-0096
next_chunk_id: chunk-0098
section_heading: Brutus VII
document_type: specification

— My
own opinion is, that the objects from which the general government should have
authority to raise a revenue, should be of such a nature, that the tax should
be raised by simple laws, with few officers, with certainty and expedition, and
with the least interference with the internal police of the states. — Of
this nature is the impost on imported goods — and it appears to me that a
duty on exports, would also be of this nature — and therefore, for ought I
can discover, this would be the best source of revenue to grant the general
government. I know neither the Congress nor the state legislatures will have
authority under the new constitution to raise a revenue in this way. But I
cannot perceive the reason of the restriction. It appears to me evident, that a
tax on articles exported, would be as nearly equal as any that we can expect to
lay, and it certainly would be collected with more ease and less expence than
any direct tax. I do not however, contend for this mode, it may be liable to
well founded objections that have not occurred to me. But this I do contend
for, that some mode is practicable, and that limits must be marked between the
general government, and the states on this head, or if they be not, either the
Congress in the exercise of this power, will deprive the state legislatures of
the means of their existence, or the states by resisting the constitutional
authority of the general government, will render it nugatory. Brutus. 1. Federalist, No. 23. Next | Previous | Text Version | Brutus
Contents |

--- chunk_id: chunk-0098
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 433
content_hash: daff6edbea09ae8e
prev_chunk_id: chunk-0097
next_chunk_id: chunk-0099
section_heading: Brutus VIII
document_type: specification

## Brutus VIII

*Source file: brutus08.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #8



 

 VIII


 10 January 1788


The next powers vested by this constitution in the general government, which
we shall consider, are those, which authorise them to "borrow money on the
credit of the United States, and to raise and support armies." I take
these two together and connect them with the power to lay and collect taxes,
duties, imposts and excises, because their extent, and the danger that will
arise from the exercise of these powers, cannot be fully understood, unless
they are viewed in relation to each other. The power to borrow money is general and unlimited, and the clause so often
before referred to, authorises the passing any laws proper and necessary to
carry this into execution. Under this authority, the Congress may mortgage any
or all the revenues of the union, as a fund to loan money upon, and it is
probably, in this way, they may borrow of foreign nations, a principal sum, the
interest of which will be equal to the annual revenues of the country. —
By this means, they may create a national debt, so large, as to exceed the
ability of the country ever to sink. I can scarcely contemplate a greater
calamity that could befal this country, than to be loaded with a debt exceeding
their ability ever to discharge. If this be a just remark, it is unwise and
improvident to vest in the general government a power to borrow at discretion,
without any limitation or restriction. It may possibly happen that the safety and welfare of the country may
require, that money be borrowed, and it is proper when such a necessity arises
that the power should be exercised by the general government. — But it
certainly ought never to be exercised, but on the most urgent occasions, and
then we should not borrow of foreigners if we could possibly avoid it.

--- chunk_id: chunk-0099
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 398
content_hash: 0afe48bf06079d4a
prev_chunk_id: chunk-0098
next_chunk_id: chunk-0100
section_heading: Brutus VIII
document_type: specification

It may possibly happen that the safety and welfare of the country may
require, that money be borrowed, and it is proper when such a necessity arises
that the power should be exercised by the general government. — But it
certainly ought never to be exercised, but on the most urgent occasions, and
then we should not borrow of foreigners if we could possibly avoid it. The constitution should therefore have so restricted, the exercise of this
power as to have rendered it very difficult for the government to practise it. The present confederation requires the assent of nine states to exercise this,
and a number of the other important powers of the confederacy — and it
would certainly have been a wise provision in this constitution, to have made
it necessary that two thirds of the members should assent to borrowing money
— when the necessity was indispensable, this assent would always be given,
and in no other cause ought it to be. The power to raise armies, is indefinite and unlimited, and authorises the
raising forces, as well in peace as in war. Whether the clause which impowers
the Congress to pass all laws which are proper and necessary, to carry this
into execution, will not authorise them to impress men for the army, is a
question well worthy consideration? If the general legislature deem it for the
general welfare to raise a body of troops, and they cannot be procured by
voluntary enlistments, it seems evident, that it will be proper and necessary
to effect it, that men be impressed from the militia to make up the deficiency. These powers taken in connection, amount to this: that the general
government have unlimitted authority and controul over all the wealth and all
the force of the union.

--- chunk_id: chunk-0100
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 428
content_hash: e3ad434979b1163d
prev_chunk_id: chunk-0099
next_chunk_id: chunk-0101
section_heading: Brutus VIII
document_type: specification

If the general legislature deem it for the
general welfare to raise a body of troops, and they cannot be procured by
voluntary enlistments, it seems evident, that it will be proper and necessary
to effect it, that men be impressed from the militia to make up the deficiency. These powers taken in connection, amount to this: that the general
government have unlimitted authority and controul over all the wealth and all
the force of the union. The advocates for this scheme, would favor the world
with a new discovery, if they would shew, what kind of freedom or independency
is left to the state governments, when they cannot command any part of the
property or of the force of the country, but at the will of the Congress. It
seems to me as absurd, as it would be to say, that I was free and independent,
when I had conveyed all my property to another, and was tenant to will to him,
and had beside, given an indenture of myself to serve him during life. —
The power to keep up standing armies in time of peace, has been justly
objected, to this system, as dangerous and improvident. The advocates who have
wrote in its favor, have some of them ridiculed the objection, as though it
originated in the distempered brain of its opponents, and others have taken
pains to shew, that it is a power that was proper to be granted to the rulers
in this constitution. That you may be enabled to form a just opinion on this
subject, I shall first make some remarks, tending to prove, that this power
ought to be restricted, and then animadvert on the arguments which have been
adduced to justify it. I take it for granted, as an axiom in politic, that the people should never
authorise their rulers to do any thing, which if done, would operate to their
injury.

--- chunk_id: chunk-0101
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 360
content_hash: 99b5a1814999916f
prev_chunk_id: chunk-0100
next_chunk_id: chunk-0102
section_heading: Brutus VIII
document_type: specification

That you may be enabled to form a just opinion on this
subject, I shall first make some remarks, tending to prove, that this power
ought to be restricted, and then animadvert on the arguments which have been
adduced to justify it. I take it for granted, as an axiom in politic, that the people should never
authorise their rulers to do any thing, which if done, would operate to their
injury. It seems equally clear, that in a case where a power, if given and
exercised, will generally produce evil to the community, and seldom good —
and which, experience has proved, has most frequently been exercised to the
great injury, and very often to the total destruction of the government; in
such a case, I say, this power, if given at all, should if possible be so
restricted, as to prevent the ill effect of its operation. Let us then enquire, whether standing armies in time of peace, would be ever
beneficial to our country — or if in some extraordinary cases, they might
be necessary; whether it is not true, that they have generally proved a scourge
to a country, and destructive of their liberty. I shall not take up much of your time in proving a point, in which the
friends of liberty, in all countries, have so universally agreed. The following
extract from Mr. Pultney's speech, delivered in the house of commons of
Great-Britain, on a motion for reducing the army, is so full to the point, and
so much better than any thing I can say, that I shall be excused for inserting
it.

--- chunk_id: chunk-0102
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 440
content_hash: 1f642a973ce054e1
prev_chunk_id: chunk-0101
next_chunk_id: chunk-0103
section_heading: Brutus VIII
document_type: specification

The following
extract from Mr. Pultney's speech, delivered in the house of commons of
Great-Britain, on a motion for reducing the army, is so full to the point, and
so much better than any thing I can say, that I shall be excused for inserting
it. He says, "I have always been, and always shall be against a standing
army of any kind; to me it is a terrible thing, whether under that of a
parliamentary, or any other designation; a standing army is still a standing
army by whatever name it is called; they are a body of men distinct from the
body of the people; they are governed by different laws, and blind obedience,
and an entire submission to the orders of their commanding officer, is their
only principle; the nations around us, sir, are already enslaved, and have been
enslaved by those very means; by means of their standing armies they have every
one lost their liberties; it is indeed impossible that the liberties of the
people in any country can be preserved where a numerous standing army is kept
up. Shall we then take our measures from the example of our neighbours? No,
sir, on the contrary, from their misfortunes we ought to learn to avoid those
rocks upon which they have split. "It signifies nothing to tell me that our army is commanded by such
gentlemen as cannot be supposed to join in any measures for enslaving their
country; it may be so; I have a very good opinion of many gentlemen now in the
army; I believe they would not join in any such measures; but their lives are
uncertain, nor can we be sure how long they will be kept in command, they may
all be dismissed in a moment, and proper tools of power put in their room. Besides, sir, we know the passions of men, we know how dangerous it is to trust
the best of men with too much power.

--- chunk_id: chunk-0103
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 296
content_hash: 0d893480c2ab2db2
prev_chunk_id: chunk-0102
next_chunk_id: chunk-0104
section_heading: Brutus VIII
document_type: specification

"It signifies nothing to tell me that our army is commanded by such
gentlemen as cannot be supposed to join in any measures for enslaving their
country; it may be so; I have a very good opinion of many gentlemen now in the
army; I believe they would not join in any such measures; but their lives are
uncertain, nor can we be sure how long they will be kept in command, they may
all be dismissed in a moment, and proper tools of power put in their room. Besides, sir, we know the passions of men, we know how dangerous it is to trust
the best of men with too much power. Where was a braver army than that under
Jul. Caesar? Where was there ever an army that had served their country more
faithfully? That army was commanded generally by the best citizens of Rome, by
men of great fortune and figure in their country, yet that army enslaved their
country. The affections of the soldiers towards their country, the honor and
integrity of the under officers, are not to be depended on. By the military law
the administration of justice is so quick, and the punishment so severe, that
neither the officer nor soldier dare dispute the orders of his supreme
commander; he must not consult his own inclination.

--- chunk_id: chunk-0104
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 361
content_hash: 1239464fc1f91f92
prev_chunk_id: chunk-0103
next_chunk_id: chunk-0105
section_heading: Brutus VIII
document_type: specification

The affections of the soldiers towards their country, the honor and
integrity of the under officers, are not to be depended on. By the military law
the administration of justice is so quick, and the punishment so severe, that
neither the officer nor soldier dare dispute the orders of his supreme
commander; he must not consult his own inclination. If an officer were
commanded to pull his own father out of this house, he must do it; he dares not
disobey; immediate death would be the sure consequence of the least grumbling:
and if an officer were sent into the court of request, accompanied by a body of
musketeers with screwed bayonets, and with orders to tell us what we ought to
do, and how we were to vote: I know what would be the duty of this house; I
know it would be our duty to order the officer to be hanged at the door of the
lobby; but I doubt, sir, I doubt much, if such a spirit could be found in the
house, or in any house of commons that will ever be in England. "Sir, I talk not of imaginary things? I talk of what has happened to an
English house of commons, from an English army; not only from an English army,
but an army that was raised by that very house of commons, an army that was
paid by them, and an army that was commanded by generals appointed by them;
therefore do not let us vainly imagine, that an army, raised and maintained by
authority of parliament, will always be so submissive to them.

--- chunk_id: chunk-0105
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 285
content_hash: ac16ef48571e1a52
prev_chunk_id: chunk-0104
next_chunk_id: chunk-0106
section_heading: Brutus VIII
document_type: specification

"Sir, I talk not of imaginary things? I talk of what has happened to an
English house of commons, from an English army; not only from an English army,
but an army that was raised by that very house of commons, an army that was
paid by them, and an army that was commanded by generals appointed by them;
therefore do not let us vainly imagine, that an army, raised and maintained by
authority of parliament, will always be so submissive to them. If an army be so
numerous as to have it in their power to overawe the parliament, they will be
submissive as long as the parliament does nothing to disoblige their favourite
general; but when that case happens, I am afraid, that in place of the
parliament's dismissing the army, the army will dismiss the parliament."
— If this great man's reasoning be just, it follows, that keeping up a
standing army, would be in the highest degree dangerous to the liberty and
happiness of the community — and if so, the general government ought not
to have authority to do it; for no government should be empowered to do that
which if done, would tend to destroy public liberty. Brutus. Next | Previous | Text Version | Brutus
Contents |

--- chunk_id: chunk-0106
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 442
content_hash: 2f0742f931a44a2a
prev_chunk_id: chunk-0105
next_chunk_id: chunk-0107
section_heading: Brutus IX
document_type: specification

## Brutus IX

*Source file: brutus09.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #9



 

 IX


 17 January 1788


The design of civil government is to protect the rights and promote the
happiness of the people. For this end, rulers are invested with powers. But we cannot from hence
justly infer that these powers should be unlimited. There are certain rights
which mankind possess, over which government ought not to have any controul,
because it is not necessary they should, in order to attain the end of its
institution. There are certain things which rulers should be absolutely
prohibited from doing, because, if they should do them, they would work an
injury, not a benefit to the people. Upon the same principles of reasoning, if
the exercise of a power, is found generally or in most cases to operate to the
injury of the community, the legislature should be restricted in the exercise
of that power, so as to guard, as much as possible, against the danger. These
principles seem to be the evident dictates of common sense, and what ought to
give sanction to them in the minds of every American, they are the great
principles of the late revolution, and those which governed the framers of all
our state constitutions. Hence we find, that all the state constitutions,
contain either formal bills of rights, which set bounds to the powers of the
legislature, or have restrictions for the same purpose in the body of the
constitutions. Some of our new political Doctors, indeed, reject the idea of
the necessity, or propriety of such restrictions in any elective government,
but especially in the general one. But it is evident, that the framers of this new system were of a contrary
opinion, because they have prohibited the general government, the exercise of
some powers, and restricted them in that of others. I shall adduce two instances, which will serve to illustrate my meaning, as
well as to confirm the truth of the preceeding remark.

--- chunk_id: chunk-0107
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 441
content_hash: 347a906e6f13750a
prev_chunk_id: chunk-0106
next_chunk_id: chunk-0108
section_heading: Brutus IX
document_type: specification

But it is evident, that the framers of this new system were of a contrary
opinion, because they have prohibited the general government, the exercise of
some powers, and restricted them in that of others. I shall adduce two instances, which will serve to illustrate my meaning, as
well as to confirm the truth of the preceeding remark. In the 9th section, it is declared, "no bill of attainder shall be
passed." This clause takes from the legislature all power to declare a
particular person guilty of a crime by law. It is proper the legislature should
be deprived of the exercise of this power, because it seldom is exercised to
the benefit of the community, but generally to its injury. In the same section it is provided, that "the privilege of the writ of
habeas corpus shall not be suspended, unless when in cases of rebellion and
invasion, the public safety may require it." This clause limits the power
of the legislature to deprive a citizen of the right of habeas corpus, to
particular cases viz. those of rebellion and invasion; the reason is plain,
because in no other cases can this power be exercised for the general good. Let us apply these remarks to the case of standing armies in times of peace. If they generally prove the destruction of the happiness and liberty of the
people, the legislature ought not to have power to keep them up, or if they
had, this power should be so restricted, as to secure the people against the
danger arising from the exercise of it. That standing armies are dangerous to the liberties of a people was proved
in my last number — If it was necessary, the truth of the position might
be confirmed by the history of almost every nation in the world. A cloud of the
most illustrious patriots of every age and country, where freedom has been
enjoyed, might be adduced as witnesses in support of the sentiment.

--- chunk_id: chunk-0108
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 390
content_hash: b56fe64d760063ae
prev_chunk_id: chunk-0107
next_chunk_id: chunk-0109
section_heading: Brutus IX
document_type: specification

That standing armies are dangerous to the liberties of a people was proved
in my last number — If it was necessary, the truth of the position might
be confirmed by the history of almost every nation in the world. A cloud of the
most illustrious patriots of every age and country, where freedom has been
enjoyed, might be adduced as witnesses in support of the sentiment. But I
presume it would be useless, to enter into a laboured argument, to prove to the
people of America, a position, which has so long and so generally been received
by them as a kind of axiom. Some of the advocates for this new system controvert this sentiment, as they
do almost every other that has been maintained by the best writers on free
government. — Others, though they will not expressly deny, that standing
armies in times of peace are dangerous, yet join with these in maintaining,
that it is proper the general government should be vested with the power to do
it. I shall now proceed to examine the arguments they adduce in support of
their opinions. A writer, in favor of this system, treats this objection as a ridiculous
one. He supposes it would be as proper to provide against the introduction of
Turkish janizaries, or against making the Alcoran a rule of faith. From the positive, and dogmatic manner, in which this author delivers his
opinions, and answers objections made to his sentiments — one would
conclude, that he was some pedantic pedagogue who had been accustomed to
deliver his dogmas to pupils, who always placed implicit faith in what he
delivered. But, why is this provision so ridiculous? because, says this author, it is
unnecessary. But, why is it unnecessary?

--- chunk_id: chunk-0109
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 422
content_hash: 1af2ea7fceaf109c
prev_chunk_id: chunk-0108
next_chunk_id: chunk-0110
section_heading: Brutus IX
document_type: specification

because, says this author, it is
unnecessary. But, why is it unnecessary? "because, the principles and
habits, as well as the power of the Americans are directly opposed to standing
armies; and there is as little necessity to guard against them by positive
constitutions, as to prohibit the establishment of the Mahometan
religion." It is admitted then, that a standing army in time of peace, is
an evil. I ask then, why should this government be authorised to do evil? If
the principles and habits of the people of this country are opposed to standing
armies in time of peace, if they do not contribute to the public good, but
would endanger the public liberty and happiness, why should the government be
vested with the power? No reason can be given, why rulers should be authorised
to do, what, if done, would oppose the principles and habits of the people, and
endanger the public safety, but there is every reason in the world, that they
should be prohibited from the exercise of such a power. But this author
supposes, that no danger is to be apprehended from the exercise of this power,
because, if armies are kept up, it will be by the people themselves, and
therefore, to provide against it, would be as absurd as for a man to "pass
a law in his family, that no troops should be quartered in his family by his
consent." This reasoning supposes, that the general government is to be
exercised by the people of America themselves — But such an idea is
groundless and absurd. There is surely a distinction between the people and
their rulers, even when the latter are representatives of the former. —
They certainly are not identically the same, and it cannot be disputed, but it
may and often does happen, that they do not possess the same sentiments or
pursue the same interests.

--- chunk_id: chunk-0110
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 394
content_hash: e09240f1e8138e6a
prev_chunk_id: chunk-0109
next_chunk_id: chunk-0111
section_heading: Brutus IX
document_type: specification

There is surely a distinction between the people and
their rulers, even when the latter are representatives of the former. —
They certainly are not identically the same, and it cannot be disputed, but it
may and often does happen, that they do not possess the same sentiments or
pursue the same interests. I think I have shewn, that as this government is
constituted, there is little reason to expect, that the interest of the people
and their rulers will be the same. Besides, if the habits and sentiments of the people of America are to be
relied upon, as the sole security against the encroachment of their rulers, all
restrictions in constitutions are unnecessary; nothing more is requisite, than
to declare who shall be authorized to exercise the powers of government, and
about this we need not be very careful — for the habits and principles of
the people will oppose every abuse of power. This I suppose to be the
sentiments of this author, as it seems to be of many of the advocates of this
new system. An opinion like this, is as directly opposed to the principles and
habits of the people of America, as it is to the sentiments of every writer of
reputation on the science of government, and repugnant to the principles of
reason and common sense. The idea that there is no danger of the establishment of a standing army,
under the new constitution, is without foundation. It is a well known fact, that a number of those who had an agency in
producing this system, and many of those who it is probable will have a
principal share in the administration of the government under it, if it is
adopted, are avowedly in favour of standing armies.

--- chunk_id: chunk-0111
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 426
content_hash: 12873bc8ff284b27
prev_chunk_id: chunk-0110
next_chunk_id: chunk-0112
section_heading: Brutus IX
document_type: specification

The idea that there is no danger of the establishment of a standing army,
under the new constitution, is without foundation. It is a well known fact, that a number of those who had an agency in
producing this system, and many of those who it is probable will have a
principal share in the administration of the government under it, if it is
adopted, are avowedly in favour of standing armies. It is a language common
among them, "That no people can be kept in order, unless the government
have an army to awe them into obedience; it is necessary to support the dignity
of government, to have a military establishment." And there will not be
wanting a variety of plausible reason to justify the raising one, drawn from
the danger we are in from the Indians on our frontiers, or from the European
provinces in our neighbourhood. If to this we add, that an army will afford a
decent support, and agreeable employment to the young men of many families, who
are too indolent to follow occupations that will require care and industry, and
too poor to live without doing any business[,] we can have little reason to
doubt, but that we shall have a large standing army, as soon as this government
can find money to pay them, and perhaps sooner. A writer, who is the boast of the advocates of this new constitution, has
taken great pains to shew, that this power was proper and necessary to be
vested in the general government. He sets out with calling in question the candour and integrity of those who
advance the objection, and with insinuating, that it is their intention to
mislead the people, by alarming their passions, rather than to convince them by
arguments addressed to their understandings. The man who reproves another for a fault, should be careful that he himself
be not guilty of it.

--- chunk_id: chunk-0112
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 417
content_hash: 8a4d91b9b67e5f46
prev_chunk_id: chunk-0111
next_chunk_id: chunk-0113
section_heading: Brutus IX
document_type: specification

He sets out with calling in question the candour and integrity of those who
advance the objection, and with insinuating, that it is their intention to
mislead the people, by alarming their passions, rather than to convince them by
arguments addressed to their understandings. The man who reproves another for a fault, should be careful that he himself
be not guilty of it. How far this writer has manifested a spirit of candour,
and has pursued fair reasoning on this subject, the impartial public will
judge, when his arguments pass before them in review. He first attempts to shew, that this objection is futile and disingenuous,
because the power to keep up standing armies, in time of peace, is vested,
under the present government, in the legislature of every state in the union,
except two. Now this is so far from being true, that it is expressly declared,
by the present articles of confederation, that no body of forces "shall be
kept up by any state, in time of peace, except such number only, as in the
judgment of the United States in Congress assembled, shall be deemed requisite
to garrison the forts necessary for the defence of such state." Now, was
it candid and ingenuous to endeavour to persuade the public, that the general
government had no other power than your own legislature have on this head; when
the truth is, your legislature have no authority to raise and keep up any
forces? He next tells us, that the power given by this constitution, on this head,
is similar to that which Congress possess under the present confederation. As
little ingenuity is manifested in this representation as in that of the former. I shall not undertake to enquire whether or not Congress are vested with a
power to keep up a standing army in time of peace; it has been a subject.

--- chunk_id: chunk-0113
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 434
content_hash: 2d4f458d50512ca0
prev_chunk_id: chunk-0112
next_chunk_id: chunk-0114
section_heading: Brutus IX
document_type: specification

As
little ingenuity is manifested in this representation as in that of the former. I shall not undertake to enquire whether or not Congress are vested with a
power to keep up a standing army in time of peace; it has been a subject. warmly debated in Congress, more than once, since the peace; and one of the
most respectable states in the union, were so fully convinced that they had no
such power, that they expressly instructed their delegates to enter a solemn
protest against it on the journals of Congress, should they attempt to exercise
it. But should it be admitted that they have the power, there is such a striking
dissimilarity between the restrictions under which the present Congress can
exercise it, and that of the proposed government, that the comparison will
serve rather to shew the impropriety of vesting the proposed government with
the power, than of justifying it. It is acknowledged by this writer, that the powers of Congress, under the
present confederation, amount to little more than that of recommending. If they
determine to raise troops, they are obliged to effect it through the authority
of the state legislatures. This will, in the first instance, be a most powerful
restraint upon them, against ordering troops to be raised. But if they should
vote an army, contrary to the opinion and wishes of the people, the
legislatures of the respective states would not raise them. Besides, the
present Congress hold their places at the will and pleasure of the legislatures
of the states who send them, and no troops can be raised, but by the assent of
nine states out of the thirteen. Compare the power proposed to be lodged in the
legislature on this head, under this constitution, with that vested in the
present Congress, and every person of the least discernment, whose
understanding is not totally blinded by prejudice, will perceive, that they
bear no analogy to each other.

--- chunk_id: chunk-0114
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: 007c84925b7505f3
prev_chunk_id: chunk-0113
next_chunk_id: chunk-0115
section_heading: Brutus IX
document_type: specification

Besides, the
present Congress hold their places at the will and pleasure of the legislatures
of the states who send them, and no troops can be raised, but by the assent of
nine states out of the thirteen. Compare the power proposed to be lodged in the
legislature on this head, under this constitution, with that vested in the
present Congress, and every person of the least discernment, whose
understanding is not totally blinded by prejudice, will perceive, that they
bear no analogy to each other. Under the present confederation, the
representatives of nine states, out of thirteen, must assent to the raising of
troops, or they cannot be levied: under the proposed constitution, a less
number than the representatives of two states, in the house of representatives,
and the representatives of three states and an half in the senate, with the
assent of the president, may raise any number of troops they please. The
present Congress are restrained from an undue exercise of this power, from this
consideration, they know [that] the state legislatures, through whose authority
it must be carried into effect, would not comply with the requisition for the
purpose, if it was evidently opposed to the public good: the proposed
constitution authorizes the legislature to carry their determinations into
execution, without the intervention of any other body between them and the
people. The Congress under the present form are amenable to, and removable by,
the legislatures of the respective states, and are chosen for one year only:
the proposed constitution does not make the members of the legislature
accountable to, or removeable by the state legislatures at all; and they are
chosen, the one house for six, and the other for two years; and cannot be
removed until their time of service is expired, let them conduct [themselves]
ever so badly. — The public will judge, from the above comparison, how
just a claim this writer has to that candour he affects to possess.

--- chunk_id: chunk-0115
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 252
content_hash: 1c1659cbadd8ad36
prev_chunk_id: chunk-0114
next_chunk_id: chunk-0116
section_heading: Brutus IX
document_type: specification

The Congress under the present form are amenable to, and removable by,
the legislatures of the respective states, and are chosen for one year only:
the proposed constitution does not make the members of the legislature
accountable to, or removeable by the state legislatures at all; and they are
chosen, the one house for six, and the other for two years; and cannot be
removed until their time of service is expired, let them conduct [themselves]
ever so badly. — The public will judge, from the above comparison, how
just a claim this writer has to that candour he affects to possess. In the mean
time, to convince him, and the advocates for this system, that I possess some
share of candor, I pledge myself to give up all opposition to it, on the head
of standing armies, if the power to raise them be restricted as it is in the
present confederation; and I believe I may safely answer, not only for myself,
but for all who make the objection, that they will be satisfied with less. Brutus. Next | Previous | Text Version | Brutus
Contents |

--- chunk_id: chunk-0116
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 433
content_hash: d75447406d3dbfa8
prev_chunk_id: chunk-0115
next_chunk_id: chunk-0117
section_heading: Brutus X
document_type: specification

## Brutus X

*Source file: brutus10.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #10



 

X


24 January 1788


To the People of the State of New-York. The liberties of a people are in danger from a large standing army, not only
because the rulers may employ them for the purposes of supporting themselves in
any usurpations of power, which they may see proper to exercise, but there is
great hazard, that an army will subvert the forms of the government, under
whose authority, they are raised, and establish one, according to the pleasure
of their leader. We are informed, in the faithful pages of history, of such events frequently
happening. — Two instances have been mentioned in a former paper. They are
so remarkable, that they are worthy of the most careful attention of every
lover of freedom. — They are taken from the history of the two most
powerful nations that have ever existed in the world; and who are the most
renowned, for the freedom they enjoyed, and the excellency of their
constitutions: — I mean Rome and Britain. In the first, the liberties of the commonwealth was destroyed, and the
constitution overturned, by an army, lead by Julius Cesar, who was appointed to
the command, by the constitutional authority of that commonwealth. He changed
it from a free republic, whose fame had sounded, and is still celebrated by all
the world, into that of the most absolute despotism. A standing army effected
this change, and a standing army supported it through a succession of ages,
which are marked in the annals of history, with the most horrid cruelties,
bloodshed, and carnage; — The most devilish, beastly, and unnatural vices,
that ever punished or disgraced human nature. The same army, that in Britain, vindicated the liberties of that people from
the encroachments and despotism of a tyrant king, assisted Cromwell, their
General, in wresting from the people, that liberty they had so dearly earned.

--- chunk_id: chunk-0117
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 429
content_hash: c1dd48c274b98eec
prev_chunk_id: chunk-0116
next_chunk_id: chunk-0118
section_heading: Brutus X
document_type: specification

A standing army effected
this change, and a standing army supported it through a succession of ages,
which are marked in the annals of history, with the most horrid cruelties,
bloodshed, and carnage; — The most devilish, beastly, and unnatural vices,
that ever punished or disgraced human nature. The same army, that in Britain, vindicated the liberties of that people from
the encroachments and despotism of a tyrant king, assisted Cromwell, their
General, in wresting from the people, that liberty they had so dearly earned. You may be told, these instances will not apply to our case: — But
those who would persuade you to believe this, either mean to deceive you, or
have not themselves considered the subject. I firmly believe, no country in the world had ever a more patriotic army,
than the one which so ably served this country, in the late war. But had the General who commanded them, been possessed of the spirit of a
Julius Cesar or a Cromwell, the liberties of this country, had in all
probability, terminated with the war; or had they been maintained, might have
cost more blood and treasure, than was expended in the conflict with
Great-Britain. When an anonimous writer addressed the officers of the army at
the close of the war, advising them not to part with their arms, until justice
was done them — the effect it had is well known. It affected them like an
electric shock. He wrote like Cesar; and had the commander in chief, and a few
more officers of rank, countenanced the measure, the desperate resolution had
been taken, to refuse to disband. What the consequences of such a determination
would have been, heaven only knows. — The army were in the full vigor of
health and spirits, in the habit of discipline, and possessed of all our
military stores and apparatus. They would have acquired great accessions of
strength from the country.

--- chunk_id: chunk-0118
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 428
content_hash: 3debaf1a3d847336
prev_chunk_id: chunk-0117
next_chunk_id: chunk-0119
section_heading: Brutus X
document_type: specification

— The army were in the full vigor of
health and spirits, in the habit of discipline, and possessed of all our
military stores and apparatus. They would have acquired great accessions of
strength from the country. — Those who were disgusted at our republican
forms of government (for such there then were, of high rank among us) would
have lent them all their aid. — We should in all probability have seen a
constitution and laws, dictated to us, at the head of an army, and at the point
of a bayonet, and the liberties for which we had so severely struggled,
snatched from us in a moment. It remains a secret, yet to be revealed, whether
this measure was not suggested, or at least countenanced, by some, who have had
great influence in producing the present system. — Fortunately indeed for
this country, it had at the head of the army, a patriot as well as a general;
and many of our principal officers, had not abandoned the characters of
citizens, by assuming that of soldiers, and therefore, the scheme proved
abortive. But are we to expect, that this will always be the case? Are we so
much better than the people of other ages and of other countries, that the same
allurements of power and greatness, which led them aside from their duty, will
have no influence upon men in our country? Such an idea, is wild and
extravagant. — Had we indulged such a delusion, enough has appeared in a
little time past, to convince the most credulous, that the passion for pomp,
power and greatness, works as powerfully in the hearts of many of our better
sort, as it ever did in any country under heaven. — Were the same
opportunity again to offer, we should very probably be grossly disappointed, if
we made dependence, that all who then rejected the overture, would do it again.

--- chunk_id: chunk-0119
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 440
content_hash: 023ebad565ca39e3
prev_chunk_id: chunk-0118
next_chunk_id: chunk-0120
section_heading: Brutus X
document_type: specification

— Had we indulged such a delusion, enough has appeared in a
little time past, to convince the most credulous, that the passion for pomp,
power and greatness, works as powerfully in the hearts of many of our better
sort, as it ever did in any country under heaven. — Were the same
opportunity again to offer, we should very probably be grossly disappointed, if
we made dependence, that all who then rejected the overture, would do it again. From these remarks, it appears, that the evil to be feared from a large
standing army in time of peace, does not arise solely from the apprehension,
that the rulers may employ them for the purpose of promoting their own
ambitious views, but that equal, and perhaps greater danger, is to be
apprehended from their overturning the constitutional powers of the government,
and assuming the power to dictate any form they please. The advocates for power, in support of this right in the proposed
government, urge that a restraint upon the discretion of the legislatures, in
respect to military establishments in time of peace, would be improper to be
imposed, because they say, it will be necessary to maintain small garrisons on
the frontiers, to guard against the depredations of the Indians, and to be
prepared to repel any encroachments or invasions that may be made by Spain or
Britain. The amount of this argument striped of the abundant verbages with which the
author has dressed it, is this:


It will probably be necessary to keep up a small body of troops to garrison
a few posts, which it will be necessary to maintain, in order to guard against
the sudden encroachments of the Indians, or of the Spaniards and British; and
therefore, the general government ought to be invested with power to raise and
keep up a standing army in time of peace, without restraint; at their
discretion. I confess, I cannot perceive that the conclusion follows from the premises.

--- chunk_id: chunk-0120
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 390
content_hash: 95183b466aae9594
prev_chunk_id: chunk-0119
next_chunk_id: chunk-0121
section_heading: Brutus X
document_type: specification

The amount of this argument striped of the abundant verbages with which the
author has dressed it, is this:


It will probably be necessary to keep up a small body of troops to garrison
a few posts, which it will be necessary to maintain, in order to guard against
the sudden encroachments of the Indians, or of the Spaniards and British; and
therefore, the general government ought to be invested with power to raise and
keep up a standing army in time of peace, without restraint; at their
discretion. I confess, I cannot perceive that the conclusion follows from the premises. Logicians say, it is not good reasoning to infer a general conclusion from
particular premises: though I am not much of a Logician, it seems to me, this
argument is very like that species of reasoning. When the patriots in the parliament in Great-Britain, contended with such
force of argument, and all the powers of eloquence, against keeping up standing
armies in time of peace, it is obvious, they never entertained an idea, that
small garrisons on their frontiers, or in the neighbourhood of powers, from
whom they were in danger of encroachments, or guards, to take care of public
arsenals would thereby be prohibited. The advocates for this power farther urge that it is necessary, because it
may, and probably will happen, that circumstances will render it requisite to
raise an army to be prepared to repel attacks of an enemy, before a formal
declaration of war, which in modern times has fallen into disuse. If the
constitution prohibited the raising an army, until a war actually commenced, it
would deprive the government of the power of providing for the defence of the
country, until the enemy were within our territory.

--- chunk_id: chunk-0121
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 409
content_hash: 3c295201682079cc
prev_chunk_id: chunk-0120
next_chunk_id: chunk-0122
section_heading: Brutus X
document_type: specification

The advocates for this power farther urge that it is necessary, because it
may, and probably will happen, that circumstances will render it requisite to
raise an army to be prepared to repel attacks of an enemy, before a formal
declaration of war, which in modern times has fallen into disuse. If the
constitution prohibited the raising an army, until a war actually commenced, it
would deprive the government of the power of providing for the defence of the
country, until the enemy were within our territory. If the restriction is not
to extend to the raising armies in cases of emergency, but only to the keeping
them up, this would leave the matter to the discretion of the legislature; and
they might, under the pretence that there was danger of an invasion, keep up
the army as long as they judged proper — and hence it is inferred, that
the legislature should have authority to raise and keep up an army without any
restriction. But from these premises nothing more will follow than this, that
the legislature should not be so restrained, as to put it out of their power to
raise an army, when such exigencies as are instanced shall arise. But it does
not thence follow, that the government should be empowered to raise and
maintain standing armies at their discretion as well in peace as in war. If
indeed, it is impossible to vest the general government with the power of
raising troops to garrison the frontier posts, to guard arsenals, or to be
prepared to repel an attack, when we saw a power preparing to make one, without
giving them a general and indefinite authority, to raise and keep up armies,
without any restriction or qualification, then this reasoning might have
weight; but this has not been proved nor can it be.

--- chunk_id: chunk-0122
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 350
content_hash: 360e64189e621483
prev_chunk_id: chunk-0121
next_chunk_id: chunk-0123
section_heading: Brutus X
document_type: specification

But it does
not thence follow, that the government should be empowered to raise and
maintain standing armies at their discretion as well in peace as in war. If
indeed, it is impossible to vest the general government with the power of
raising troops to garrison the frontier posts, to guard arsenals, or to be
prepared to repel an attack, when we saw a power preparing to make one, without
giving them a general and indefinite authority, to raise and keep up armies,
without any restriction or qualification, then this reasoning might have
weight; but this has not been proved nor can it be. It is admitted that to prohibit the general government, from keeping up
standing armies, while yet they were authorised to raise them in case of
exigency, would be an insufficient guard against the danger. A discretion of
such latitude would give room to elude the force of the provision. It is also admitted that an absolute prohibition against raising troops,
except in cases of actual war, would be improper; because it will be requisite
to raise and support a small number of troops to garrison the important
frontier posts, and to guard arsenals; and it may happen, that the danger of an
attack from a foreign power may be so imminent, as to render it highly proper
we should raise an army, in order to be prepared to resist them. But to raise
and keep up forces for such purposes and on such occasions, is not included in
the idea, of keeping up standing armies in times of peace.

--- chunk_id: chunk-0123
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 408
content_hash: dfeeae7e01185e3c
prev_chunk_id: chunk-0122
next_chunk_id: chunk-0124
section_heading: Brutus X
document_type: specification

It is also admitted that an absolute prohibition against raising troops,
except in cases of actual war, would be improper; because it will be requisite
to raise and support a small number of troops to garrison the important
frontier posts, and to guard arsenals; and it may happen, that the danger of an
attack from a foreign power may be so imminent, as to render it highly proper
we should raise an army, in order to be prepared to resist them. But to raise
and keep up forces for such purposes and on such occasions, is not included in
the idea, of keeping up standing armies in times of peace. It is a thing very practicable to give the government sufficient authority
to provide for these cases, and at the same time to provide a reasonable and
competent security against the evil of a standing army — a clause to the
following purpose would answer the end:


As standing armies in time of peace are dangerous to liberty, and have often
been the means of overturning the best constitutions of government, no standing
army, or troops of any description whatsoever, shall be raised or kept up by
the legislature, except so many as shall be necessary for guards to the
arsenals of the United States, or for garrisons to such posts on the frontiers,
as it shall be deemed absolutely necessary to hold, to secure the inhabitants,
and facilitate the trade with the Indians: unless when the United States are
threatened with an attack or invasion from some foreign power, in which case
the legislature shall be authorised to raise an army to be prepared to repel
the attack; provided that no troops whatsoever shall be raised in time of
peace, without the assent of two thirds of the members, composing both houses
of the legislature.

--- chunk_id: chunk-0124
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 354
content_hash: 1603c4262c97b277
prev_chunk_id: chunk-0123
next_chunk_id: chunk-0125
section_heading: Brutus X
document_type: specification

But to raise
and keep up forces for such purposes and on such occasions, is not included in
the idea, of keeping up standing armies in times of peace. It is a thing very practicable to give the government sufficient authority
to provide for these cases, and at the same time to provide a reasonable and
competent security against the evil of a standing army — a clause to the
following purpose would answer the end:


As standing armies in time of peace are dangerous to liberty, and have often
been the means of overturning the best constitutions of government, no standing
army, or troops of any description whatsoever, shall be raised or kept up by
the legislature, except so many as shall be necessary for guards to the
arsenals of the United States, or for garrisons to such posts on the frontiers,
as it shall be deemed absolutely necessary to hold, to secure the inhabitants,
and facilitate the trade with the Indians: unless when the United States are
threatened with an attack or invasion from some foreign power, in which case
the legislature shall be authorised to raise an army to be prepared to repel
the attack; provided that no troops whatsoever shall be raised in time of
peace, without the assent of two thirds of the members, composing both houses
of the legislature. A clause similar to this would afford sufficient latitude to the legislature
to raise troops in all cases that were really necessary, and at the same time
competent security against the establishment of that dangerous engine of
despotism a standing army.

--- chunk_id: chunk-0125
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 466
content_hash: 31a2703f4919ecea
prev_chunk_id: chunk-0124
next_chunk_id: chunk-0126
section_heading: Brutus X
document_type: specification

It is a thing very practicable to give the government sufficient authority
to provide for these cases, and at the same time to provide a reasonable and
competent security against the evil of a standing army — a clause to the
following purpose would answer the end:


As standing armies in time of peace are dangerous to liberty, and have often
been the means of overturning the best constitutions of government, no standing
army, or troops of any description whatsoever, shall be raised or kept up by
the legislature, except so many as shall be necessary for guards to the
arsenals of the United States, or for garrisons to such posts on the frontiers,
as it shall be deemed absolutely necessary to hold, to secure the inhabitants,
and facilitate the trade with the Indians: unless when the United States are
threatened with an attack or invasion from some foreign power, in which case
the legislature shall be authorised to raise an army to be prepared to repel
the attack; provided that no troops whatsoever shall be raised in time of
peace, without the assent of two thirds of the members, composing both houses
of the legislature. A clause similar to this would afford sufficient latitude to the legislature
to raise troops in all cases that were really necessary, and at the same time
competent security against the establishment of that dangerous engine of
despotism a standing army. The same writer who advances the arguments I have noticed, makes a number of
other observations with a view to prove that the power to raise and keep up
armies, ought to be discretionary in the general legislature; some of them are
curious; he instances the raising of troops in Massachusetts and Pennsylvania,
to shew the necessity of keeping a standing army in time of peace; the least
reflection must convince every candid mind that both these cases are totally
foreign to his purpose — Massachusetts raised a body of troops for six
months, at the expiration of which they were to disband of course; this looks
very little like a standing army.

--- chunk_id: chunk-0126
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: 4aca83ac2193c541
prev_chunk_id: chunk-0125
next_chunk_id: chunk-0127
section_heading: Brutus X
document_type: specification

A clause similar to this would afford sufficient latitude to the legislature
to raise troops in all cases that were really necessary, and at the same time
competent security against the establishment of that dangerous engine of
despotism a standing army. The same writer who advances the arguments I have noticed, makes a number of
other observations with a view to prove that the power to raise and keep up
armies, ought to be discretionary in the general legislature; some of them are
curious; he instances the raising of troops in Massachusetts and Pennsylvania,
to shew the necessity of keeping a standing army in time of peace; the least
reflection must convince every candid mind that both these cases are totally
foreign to his purpose — Massachusetts raised a body of troops for six
months, at the expiration of which they were to disband of course; this looks
very little like a standing army. But beside, was that commonwealth in a state
of peace at that time? So far from it that they were in the most violent
commotions and contents, and their legislature had formally declared that an
unnatural rebellion existed within the state. The situation of Pennsylvania was
similar; a number of armed men had levied war against the authority of the
state, and openly avowed their intention of withdrawing their allegiance from
it. To what purpose examples are brought, of states raising troops for short
periods in times of war or insurrections, on a question concerning the
propriety of keeping up standing armies in times of peace, the public must
judge. It is farther said, that no danger can arise from this power being lodged in
the hands of the general government, because the legislatures will be a check
upon them, to prevent their abusing it. This is offered, as what force there is in it will hereafter receive a more
particular examination.

--- chunk_id: chunk-0127
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 406
content_hash: 7f7cac6118b04e96
prev_chunk_id: chunk-0126
next_chunk_id: chunk-0128
section_heading: Brutus X
document_type: specification

It is farther said, that no danger can arise from this power being lodged in
the hands of the general government, because the legislatures will be a check
upon them, to prevent their abusing it. This is offered, as what force there is in it will hereafter receive a more
particular examination. At present, I shall only remark, that it is difficult
to conceive how the state legislatures can, in any case, hold a check over the
general legislature, in a constitutional way. The latter has, in every instance
to which their powers extend, complete controul over the former. The state
legislatures can, in no case, by law, resolution, or otherwise, of right,
prevent or impede the general government, from enacting any law, or executing
it, which this constitution authorizes them to enact or execute. If then the
state legislatures check the general legislatures [sic], it must be by
exciting the people to resist constitutional laws. In this way every
individual, or every body of men, may check any government, in proportion to
the influence they may have over the body of the people. But such kinds of
checks as these, though they sometimes correct the abuses of government, oftner
destroy all government. It is further said, that no danger is to be apprehended from the exercise of
this power, because it is lodged in the hands of representatives of the people;
if they abuse it, it is in the power of the people to remove them, and chuse
others who will pursue their interests. Not to repeat what has been said
before, That it is unwise in any people, to authorize their rulers to do, what,
if done, would prove injurious — I have, in some former numbers, shewn,
that the representation in the proposed government will be a mere shadow
without the substance.

--- chunk_id: chunk-0128
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 245
content_hash: 1afcd1f321d72df0
prev_chunk_id: chunk-0127
next_chunk_id: chunk-0129
section_heading: Brutus X
document_type: specification

It is further said, that no danger is to be apprehended from the exercise of
this power, because it is lodged in the hands of representatives of the people;
if they abuse it, it is in the power of the people to remove them, and chuse
others who will pursue their interests. Not to repeat what has been said
before, That it is unwise in any people, to authorize their rulers to do, what,
if done, would prove injurious — I have, in some former numbers, shewn,
that the representation in the proposed government will be a mere shadow
without the substance. I am so confident that I am well founded in this
opinion, that I am persuaded, if it was to be adopted or rejected, upon a fair
discussion of its merits, without taking into contemplation circumstances
extraneous to it, as reasons for its adoption, nineteen-twentieths of the
sensible men in the union would reject it on this account alone; unless its
powers were confined to much fewer objects than it embraces. Brutus. Next | Previous | Text Version | Brutus
Contents |

--- chunk_id: chunk-0129
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 441
content_hash: 2e0a61e705ee202c
prev_chunk_id: chunk-0128
next_chunk_id: chunk-0130
section_heading: Brutus XI
document_type: specification

## Brutus XI

*Source file: brutus11.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #11



 

XI


31 January 1788


The nature and extent of the judicial power of the United States, proposed
to be granted by this constitution, claims our particular attention. Much has been said and written upon the subject of this new system on both
sides, but I have not met with any writer, who has discussed the judicial
powers with any degree of accuracy. And yet it is obvious, that we can form but
very imperfect ideas of the manner in which this government will work, or the
effect it will have in changing the internal police and mode of distributing
justice at present subsisting in the respective states, without a thorough
investigation of the powers of the judiciary and of the manner in which they
will operate. This government is a complete system, not only for making, but
for executing laws. And the courts of law, which will be constituted by it, are
not only to decide upon the constitution and the laws made in pursuance of it,
but by officers subordinate to them to execute all their decisions. The real
effect of this system of government, will therefore be brought home to the
feelings of the people, through the medium of the judicial power. It is,
moreover, of great importance, to examine with care the nature and extent of
the judicial power, because those who are to be vested with it, are to be
placed in a situation altogether unprecedented in a free country. They are to
be rendered totally independent, both of the people and the legislature, both
with respect to their offices and salaries. No errors they may commit can be
corrected by any power above them, if any such power there be, nor can they be
removed from office for making ever so many erroneous adjudications. The only causes for which they can be displaced, is, conviction of treason,
bribery, and high crimes and misdemeanors.

--- chunk_id: chunk-0130
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 450
content_hash: 0238fa929e99b795
prev_chunk_id: chunk-0129
next_chunk_id: chunk-0131
section_heading: Brutus XI
document_type: specification

No errors they may commit can be
corrected by any power above them, if any such power there be, nor can they be
removed from office for making ever so many erroneous adjudications. The only causes for which they can be displaced, is, conviction of treason,
bribery, and high crimes and misdemeanors. This part of the plan is so modelled, as to authorise the courts, not only
to carry into execution the powers expressly given, but where these are wanting
or ambiguously expressed, to supply what is wanting by their own decisions. That we may be enabled to form a just opinion on this subject, I shall, in
considering it,


1st. Examine the nature and extent of the judicial powers — and


2d. Enquire, whether the courts who are to exercise them, are so constituted
as to afford reasonable ground of confidence, that they will exercise them for
the general good. With a regard to the nature and extent of the judicial powers, I have to
regret my want of capacity to give that full and minute explanation of them
that the subject merits. To be able to do this, a man should be possessed of a
degree of law knowledge far beyond what I pretend to. A number of hard words
and technical phrases are used in this part of the system, about the meaning of
which gentlemen learned in the law differ. Its advocates know how to avail themselves of these phrases. In a number of
instances, where objections are made to the powers given to the judicial, they
give such an explanation to the technical terms as to avoid them. Though I am not competent to give a perfect explanation of the powers
granted to this department of the government, I shall yet attempt to trace some
of the leading features of it, from which I presume it will appear, that they
will operate to a total subversion of the state judiciaries, if not, to the
legislative authority of the states. In article 3d, sect.

--- chunk_id: chunk-0131
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 438
content_hash: f266b32c4b1e75f5
prev_chunk_id: chunk-0130
next_chunk_id: chunk-0132
section_heading: Brutus XI
document_type: specification

Though I am not competent to give a perfect explanation of the powers
granted to this department of the government, I shall yet attempt to trace some
of the leading features of it, from which I presume it will appear, that they
will operate to a total subversion of the state judiciaries, if not, to the
legislative authority of the states. In article 3d, sect. 2d, it is said, "The judicial power shall extend
to all cases in law and equity arising under this constitution, the laws of the
United States, and treaties made, or which shall be made, under their
authority, &c."


The first article to which this power extends, is, all cases in law and
equity arising under this constitution. What latitude of construction this clause should receive, it is not easy to
say. At first view, one would suppose, that it meant no more than this, that
the courts under the general government should exercise, not only the powers of
courts of law, but also that of courts of equity, in the manner in which those
powers are usually exercised in the different states. But this cannot be the
meaning, because the next clause authorises the courts to take cognizance of
all cases in law and equity arising under the laws of the United States; this
last article, I conceive, conveys as much power to the general judicial as any
of the state courts possess. The cases arising under the constitution must be different from those
arising under the laws, or else the two clauses mean exactly the same thing. The cases arising under the constitution must include such, as bring into
question its meaning, and will require an explanation of the nature and extent
of the powers of the different departments under it. This article, therefore, vests the judicial with a power to resolve all
questions that may arise on any case on the construction of the constitution,
either in law or in equity. 1st.

--- chunk_id: chunk-0132
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 306
content_hash: a76d3e788436cd01
prev_chunk_id: chunk-0131
next_chunk_id: chunk-0133
section_heading: Brutus XI
document_type: specification

This article, therefore, vests the judicial with a power to resolve all
questions that may arise on any case on the construction of the constitution,
either in law or in equity. 1st. They are authorised to determine all questions that may arise upon the
meaning of the constitution in law. This article vests the courts with
authority to give the constitution a legal construction, or to explain it
according to the rules laid down for construing a law. — These rules give
a certain degree of latitude of explanation. According to this mode of
construction, the courts are to give such meaning to the constitution as
comports best with the common, and generally received acceptation of the words
in which it is expressed, regarding their ordinary and popular use, rather than
their grammatical propriety. Where words are dubious, they will be explained by
the context. The end of the clause will be attended to, and the words will be
understood, as having a view to it; and the words will not be so understood as
to bear no meaning or a very absurd one. 2d. The judicial are not only to decide questions arising upon the meaning
of the constitution in law, but also in equity. By this they are empowered, to explain the constitution according to the
reasoning spirit of it, without being confined to the words or letter.

--- chunk_id: chunk-0133
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 434
content_hash: 04472dfb264c7460
prev_chunk_id: chunk-0132
next_chunk_id: chunk-0134
section_heading: Brutus XI
document_type: specification

The judicial are not only to decide questions arising upon the meaning
of the constitution in law, but also in equity. By this they are empowered, to explain the constitution according to the
reasoning spirit of it, without being confined to the words or letter. "From this method of interpreting laws (says Blackstone) by the reason
of them, arises what we call equity;" which is thus defined by Grotius,
"the correction of that, wherein the law, by reason of its universality,
is deficient["]; for since in laws all cases cannot be foreseen, or
expressed, it is necessary, that when the decrees of the law cannot be applied
to particular cases, there should some where be a power vested of defining
those circumstances, which had they been foreseen the legislator would have
expressed; and these are the cases, which according to Grotius, ["]lex non
exacte definit, sed arbitrio boni viri permittet."


The same learned author observes, "That equity, thus depending
essentially upon each individual case, there can be no established rules and
fixed principles of equity laid down, without destroying its very essence, and
reducing it to a positive law."


From these remarks, the authority and business of the courts of law, under
this clause, may be understood. They will give the sense of every article of the constitution, that may from
time to time come before them. And in their decisions they will not confine
themselves to any fixed or established rules, but will determine, according to
what appears to them, the reason and spirit of the constitution. The opinions
of the supreme court, whatever they may be, will have the force of law; because
there is no power provided in the constitution, that can correct their errors,
or controul their adjudications. From this court there is no appeal. And I
conceive the legislature themselves, cannot set aside a judgment of this court,
because they are authorised by the constitution to decide in the last resort.

--- chunk_id: chunk-0134
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: eea8db3644ed5e58
prev_chunk_id: chunk-0133
next_chunk_id: chunk-0135
section_heading: Brutus XI
document_type: specification

From this court there is no appeal. And I
conceive the legislature themselves, cannot set aside a judgment of this court,
because they are authorised by the constitution to decide in the last resort. The legislature must be controuled by the constitution, and not the
constitution by them. They have therefore no more right to set aside any
judgment pronounced upon the construction of the constitution, than they have
to take from the president, the chief command of the army and navy, and commit
it to some other person. The reason is plain; the judicial and executive derive
their authority from the same source, that the legislature do theirs; and
therefore in all cases, where the constitution does not make the one
responsible to, or controulable by the other, they are altogether independent
of each other. The judicial power will operate to effect, in the most certain, but yet
silent and imperceptible manner, what is evidently the tendency of the
constitution: — I mean, an entire subversion of the legislative, executive
and judicial powers of the individual states. Every adjudication of the supreme
court, on any question that may arise upon the nature and extent of the general
government, will affect the limits of the state jurisdiction. In proportion as
the former enlarge the exercise of their powers, will that of the latter be
restricted. That the judicial power of the United States, will lean strongly in favour
of the general government, and will give such an explanation to the
constitution, as will favour an extension of its jurisdiction, is very evident
from a variety of considerations. 1st. The constitution itself strongly countenances such a mode of
construction. Most of the articles in this system, which convey powers of any
considerable importance, are conceived in general and indefinite terms, which
are either equivocal, ambiguous, or which require long definitions to unfold
the extent of their meaning.

--- chunk_id: chunk-0135
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 329
content_hash: 46f12ddedd310699
prev_chunk_id: chunk-0134
next_chunk_id: chunk-0136
section_heading: Brutus XI
document_type: specification

The constitution itself strongly countenances such a mode of
construction. Most of the articles in this system, which convey powers of any
considerable importance, are conceived in general and indefinite terms, which
are either equivocal, ambiguous, or which require long definitions to unfold
the extent of their meaning. The two most important powers committed to any
government, those of raising money, and of raising and keeping up troops, have
already been considered, and shewn to be unlimitted by any thing but the
discretion of the legislature. The clause which vests the power to pass all
laws which are proper and necessary, to carry the powers given into execution,
it has been shewn, leaves the legislature at liberty, to do every thing, which
in their judgment is best. It is said, I know, that this clause confers no
power on the legislature, which they would not have had without it —
though I believe this is not the fact, yet, admitting it to be, it implies that
the constitution is not to receive an explanation strictly, according to its
letter; but more power is implied than is expressed. And this clause, if it is
to be considered, as explanatory of the extent of the powers given, rather than
giving a new power, is to be understood as declaring, that in construing any of
the articles conveying power, the spirit, intent and design of the clause,
should be attended to, as well as the words in their common acceptation.

--- chunk_id: chunk-0136
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 390
content_hash: 689435d3365357e7
prev_chunk_id: chunk-0135
next_chunk_id: chunk-0137
section_heading: Brutus XI
document_type: specification

It is said, I know, that this clause confers no
power on the legislature, which they would not have had without it —
though I believe this is not the fact, yet, admitting it to be, it implies that
the constitution is not to receive an explanation strictly, according to its
letter; but more power is implied than is expressed. And this clause, if it is
to be considered, as explanatory of the extent of the powers given, rather than
giving a new power, is to be understood as declaring, that in construing any of
the articles conveying power, the spirit, intent and design of the clause,
should be attended to, as well as the words in their common acceptation. This constitution gives sufficient colour for adopting an equitable
construction, if we consider the great end and design it professedly has in
view — these appear from its preamble to be, "to form a more perfect
union, establish justice, insure domestic tranquility, provide for the common
defence, promote the general welfare, and secure the blessings of liberty to
ourselves and posterity." The design of this system is here expressed, and
it is proper to give such a meaning to the various parts, as will best promote
the accomplishment of the end; this idea suggests itself naturally upon reading
the preamble, and will countenance the court in giving the several articles
such a sense, as will the most effectually promote the ends the constitution
had in view — how this manner of explaining the constitution will operate
in practice, shall be the subject of future enquiry. 2d. Not only will the constitution justify the courts in inclining to this
mode of explaining it, but they will be interested in using this latitude of
interpretation.

--- chunk_id: chunk-0137
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 426
content_hash: adcb1df0bae2a567
prev_chunk_id: chunk-0136
next_chunk_id: chunk-0138
section_heading: Brutus XI
document_type: specification

2d. Not only will the constitution justify the courts in inclining to this
mode of explaining it, but they will be interested in using this latitude of
interpretation. Every body of men invested with office are tenacious of power;
they feel interested, and hence it has become a kind of maxim, to hand down
their offices, with all its rights and privileges, unimpared to their
successors; the same principle will influence them to extend their power, and
increase their rights; this of itself will operate strongly upon the courts to
give such a meaning to the constitution in all cases where it can possibly be
done, as will enlarge the sphere of their own authority. Every extension of the
power of the general legislature, as well as of the judicial powers, will
increase the powers of the courts; and the dignity and importance of the
judges, will be in proportion to the extent and magnitude of the powers they
exercise. I add, it is highly probable the emolument of the judges will be
increased, with the increase of the business they will have to transact and its
importance. From these considerations the judges will be interested to extend
the powers of the courts, and to construe the constitution as much as possible,
in such a way as to favour it; and that they will do it, appears probable. 3d. Because they will have precedent to plead, to justify them in it. It is
well known, that the courts in England, have by their own authority, extended
their jurisdiction far beyond the limits set them in their original
institution, and by the laws of the land. The court of exchequer is a remarkable instance of this. It was originally
intended principally to recover the king's debts, and to order the revenues of
the crown. It had a common law jurisdiction, which was established merely for
the benefit of the king's accomptants.

--- chunk_id: chunk-0138
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 370
content_hash: 994519b8737d05cc
prev_chunk_id: chunk-0137
next_chunk_id: chunk-0139
section_heading: Brutus XI
document_type: specification

It was originally
intended principally to recover the king's debts, and to order the revenues of
the crown. It had a common law jurisdiction, which was established merely for
the benefit of the king's accomptants. We learn from Blackstone, that the
proceedings in this court are grounded on a writ called quo minus, in which the
plaintiff suggests, that he is the king's farmer or debtor, and that the
defendant hath done him the damage complained of, by which he is less able to
pay the king. These suits, by the statute of Rutland, are expressly directed to
be confined to such matters as specially concern the king, or his ministers in
the exchequer. And by the articuli super cartas, it is enacted, that no common
pleas be thenceforth held in the exchequer contrary to the form of the great
charter: but now any person may sue in the exchequer. The surmise of being
debtor to the king being matter of form, and mere words of course; and the
court is open to all the nation. When the courts will have a precedent before them of a court which extended
its jurisdiction in opposition to an act of the legislature, is it not to be
expected that they will extend theirs, especially when there is nothing in the
constitution expressly against it? and they are authorised to construe its
meaning, and are not under any controul? This power in the judicial, will enable them to mould the government, into
almost any shape they please. — The manner in which this may be effected
we will hereafter examine. Brutus. Next | Previous | Text Version | Brutus
Contents |

--- chunk_id: chunk-0139
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 444
content_hash: c0c7efe146bd5194
prev_chunk_id: chunk-0138
next_chunk_id: chunk-0140
section_heading: Brutus XII
document_type: specification

## Brutus XII

*Source file: brutus12.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #12



 

XII


7 February 1788


In my last, I shewed, that the judicial power of the United States under the
first clause of the second section of article eight, would be authorized to
explain the constitution, not only according to its letter, but according to
its spirit and intention; and having this power, they would strongly incline to
give it such a construction as to extend the powers of the general government,
as much as possible, to the diminution, and finally to the destruction, of that
of the respective states. I shall now proceed to shew how this power will operate in its exercise to
effect these purposes. In order to perceive the extent of its influence, I
shall consider,


First. How it will tend to extend the legislative authority. Second. In what manner it will increase the jurisdiction of the courts, and 


Third. The way in which it will diminish, and destroy, both the legislative
and judicial authority of the United States. First. Let us enquire how the judicial power will effect an extension of the
legislative authority. Perhaps the judicial power will not be able, by direct and positive decrees,
ever to direct the legislature, because it is not easy to conceive how a
question can be brought before them in a course of legal discussion, in which
they can give a decision, declaring, that the legislature have certain powers
which they have not exercised, and which, in consequence of the determination
of the judges, they will be bound to exercise. But it is easy to see, that in
their adjudications they may establish certain principles, which being received
by the legislature, will enlarge the sphere of their power beyond all bounds. It is to be observed, that the supreme court has the power, in the last
resort, to determine all questions that may arise in the course of legal
discussion, on the meaning and construction of the constitution.

--- chunk_id: chunk-0140
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 438
content_hash: 647268572991c4a0
prev_chunk_id: chunk-0139
next_chunk_id: chunk-0141
section_heading: Brutus XII
document_type: specification

But it is easy to see, that in
their adjudications they may establish certain principles, which being received
by the legislature, will enlarge the sphere of their power beyond all bounds. It is to be observed, that the supreme court has the power, in the last
resort, to determine all questions that may arise in the course of legal
discussion, on the meaning and construction of the constitution. This power
they will hold under the constitution, and independent of the legislature. The
latter can no more deprive the former of this right, than either of them, or
both of them together, can take from the president, with the advice of the
senate, the power of making treaties, or appointing ambassadors. In determining these questions, the court must and will assume certain
principles, from which they will reason, in forming their decisions. These
principles, whatever they may be, when they become fixed, by a course of
decisions, will be adopted by the legislature, and will be the rule by which
they will explain their own powers. This appears evident from this
consideration, that if the legislature pass laws, which, in the judgment of the
court, they are not authorised to do by the constitution, the court will not
take notice of them; for it will not be denied, that the constitution is the
highest or supreme law. And the courts are vested with the supreme and
uncontroulable power, to determine, in all cases that come before them, what
the constitution means; they cannot, therefore, execute a law, which, in their
judgment, opposes the constitution, unless we can suppose they can make a
superior law give way to an inferior. The legislature, therefore, will not go
over the limits by which the courts may adjudge they are confined. And there is
little room to doubt but that they will come up to those bounds, as often as
occasion and opportunity may offer, and they may judge it proper to do it.

--- chunk_id: chunk-0141
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: dbd6cda16fa34f9c
prev_chunk_id: chunk-0140
next_chunk_id: chunk-0142
section_heading: Brutus XII
document_type: specification

The legislature, therefore, will not go
over the limits by which the courts may adjudge they are confined. And there is
little room to doubt but that they will come up to those bounds, as often as
occasion and opportunity may offer, and they may judge it proper to do it. For
as on the one hand, they will not readily pass laws which they know the courts
will not execute, so on the other, we may be sure they will not scruple to pass
such as they know they will give effect, as often as they may judge it proper. From these observations it appears, that the judgment of the judicial, on
the constitution, will become the rule to guide the legislature in their
construction of their powers. What the principles are, which the courts will adopt, it is impossible for
us to say; but taking up the powers as I have explained them in my last number,
which they will possess under this clause, it is not difficult to see, that
they may, and probably will, be very liberal ones. We have seen, that they will be authorized to give the constitution a
construction according to its spirit and reason, and not to confine themselves
to its letter. To discover the spirit of the constitution, it is of the first importance to
attend to the principal ends and designs it has in view. These are expressed in
the preamble, in the following words, viz. "We, the people of the United
States, in order to form a more perfect union, establish justice, insure
domestic tranquility, provide for the common defence, promote the general
welfare, and secure the blessings of liberty to ourselves and our posterity, do
ordain and establish this constitution," &c. If the end of the
government is to be learned from these words, which are clearly designed to
declare it, it is obvious it has in view every object which is embraced by any
government.

--- chunk_id: chunk-0142
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 429
content_hash: fa1f50d885ffd517
prev_chunk_id: chunk-0141
next_chunk_id: chunk-0143
section_heading: Brutus XII
document_type: specification

"We, the people of the United
States, in order to form a more perfect union, establish justice, insure
domestic tranquility, provide for the common defence, promote the general
welfare, and secure the blessings of liberty to ourselves and our posterity, do
ordain and establish this constitution," &c. If the end of the
government is to be learned from these words, which are clearly designed to
declare it, it is obvious it has in view every object which is embraced by any
government. The preservation of internal peace — the due administration of
justice — and to provide for the defence of the community, seems to
include all the objects of government; but if they do not, they are certainly
comprehended in the words, "to provide for the general welfare." If
it be further considered, that this constitution, if it is ratified, will not
be a compact entered into by states, in their corporate capacities, but an
agreement of the people of the United States, as one great body politic, no
doubt can remain, but that the great end of the constitution, if it is to be
collected from the preamble, in which its end is declared, is to constitute a
government which is to extend to every case for which any government is
instituted, whether external or internal. The courts, therefore, will establish
this as a principle in expounding the constitution, and will give every part of
it such an explanation, as will give latitude to every department under it, to
take cognizance of every matter, not only that affects the general and national
concerns of the union, but also of such as relate to the administration of
private justice, and to regulating the internal and local affairs of the
different parts. Such a rule of exposition is not only consistent with the general spirit of
the preamble, but it will stand confirmed by considering more minutely the
different clauses of it.

--- chunk_id: chunk-0143
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 394
content_hash: d20cb38e26b49661
prev_chunk_id: chunk-0142
next_chunk_id: chunk-0144
section_heading: Brutus XII
document_type: specification

The courts, therefore, will establish
this as a principle in expounding the constitution, and will give every part of
it such an explanation, as will give latitude to every department under it, to
take cognizance of every matter, not only that affects the general and national
concerns of the union, but also of such as relate to the administration of
private justice, and to regulating the internal and local affairs of the
different parts. Such a rule of exposition is not only consistent with the general spirit of
the preamble, but it will stand confirmed by considering more minutely the
different clauses of it. The first object declared to be in view is, "To form a perfect
union." It is to be observed, it is not an union of states or bodies
corporate; had this been the case the existence of the state governments, might
have been secured. But it is a union of the people of the United States
considered as one body, who are to ratify this constitution, if it is adopted. Now to make a union of this kind perfect, it is necessary to abolish all
inferior governments, and to give the general one compleat legislative,
executive and judicial powers to every purpose. The courts therefore will
establish it as a rule in explaining the constitution to give it such a
construction as will best tend to perfect the union or take from the state
governments every power of either making or executing laws. The second object
is "to establish justice." This must include not only the idea of
instituting the rule of justice, or of making laws which shall be the measure
or rule of right, but also of providing for the application of this rule or of
administering justice under it.

--- chunk_id: chunk-0144
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 433
content_hash: c1927d20b48030ee
prev_chunk_id: chunk-0143
next_chunk_id: chunk-0145
section_heading: Brutus XII
document_type: specification

The courts therefore will
establish it as a rule in explaining the constitution to give it such a
construction as will best tend to perfect the union or take from the state
governments every power of either making or executing laws. The second object
is "to establish justice." This must include not only the idea of
instituting the rule of justice, or of making laws which shall be the measure
or rule of right, but also of providing for the application of this rule or of
administering justice under it. And under this the courts will in their
decisions extend the power of the government to all cases they possibly can, or
otherwise they will be restricted in doing what appears to be the intent of the
constitution they should do, to wit, pass laws and provide for the execution of
them, for the general distribution of justice between man and man. Another end
declared is "to insure domestic tranquility." This comprehends a
provision against all private breaches of the peace, as well as against all
public commotions or general insurrections; and to attain the object of this
clause fully, the government must exercise the power of passing laws on these
subjects, as well as of appointing magistrates with authority to execute them. And the courts will adopt these ideas in their expositions. I might proceed to
the other clause, in the preamble, and it would appear by a consideration of
all of them separately, as it does by taking them together, that if the spirit
of this system is to be known from its declared end and design in the preamble,
its spirit is to subvert and abolish all the powers of the state government,
and to embrace every object to which any government extends. As it sets out in the preamble with this declared intention, so it proceeds
in the different parts with the same idea. Any person, who will peruse the 8th

--- chunk_id: chunk-0145
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 344
content_hash: 2c7e9707564e58f1
prev_chunk_id: chunk-0144
next_chunk_id: chunk-0146
section_heading: section with attention, in which most of the powers are enumerated, will
document_type: specification

section with attention, in which most of the powers are enumerated, will
perceive that they either expressly or by implication extend to almost every
thing about which any legislative power can be employed. But if this equitable
mode of construction is applied to this part of the constitution; nothing can
stand before it. This will certainly give the first clause in that article a construction
which I confess I think the most natural and grammatical one, to authorise the
Congress to do any thing which in their judgment will tend to provide for the
general welfare, and this amounts to the same thing as general and unlimited
powers of legislation in all cases. (To be continued.)


 XII


 14 February 1788


(Continued from last Thursday's paper.)


This same manner of explaining the constitution, will fix a meaning, and a
very important one too, to the 12th [18th?] clause of the same section, which
authorises the Congress to make all laws which shall be proper and necessary
for carrying into effect the foregoing powers, &c. A voluminous writer in
favor of this system, has taken great pains to convince the public, that this
clause means nothing: for that the same powers expressed in this, are implied
in other parts of the constitution. Perhaps it is so, but still this will
undoubtedly be an excellent auxilliary to assist the courts to discover the
spirit and reason of the constitution, and when applied to any and every of the
other clauses granting power, will operate powerfully in extracting the spirit
from them.

--- chunk_id: chunk-0146
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 408
content_hash: 425b1b3d0cd6cdd7
prev_chunk_id: chunk-0145
next_chunk_id: chunk-0147
section_heading: section with attention, in which most of the powers are enumerated, will
document_type: specification

A voluminous writer in
favor of this system, has taken great pains to convince the public, that this
clause means nothing: for that the same powers expressed in this, are implied
in other parts of the constitution. Perhaps it is so, but still this will
undoubtedly be an excellent auxilliary to assist the courts to discover the
spirit and reason of the constitution, and when applied to any and every of the
other clauses granting power, will operate powerfully in extracting the spirit
from them. I might instance a number of clauses in the constitution, which, if
explained in an equitable manner, would extend the powers of the
government to every case, and reduce the state legislatures to nothing; but, I
should draw out my remarks to an undue length, and I presume enough has been
said to shew, that the courts have sufficient ground in the exercise of this
power, to determine, that the legislature have no bounds set to them by this
constitution, by any supposed right the legislatures of the respective states
may have, to regulate any of their local concerns. I proceed, 2d, To inquire, in what manner this power will increase the
jurisdiction of the courts. I would here observe, that the judicial power extends, expressly, to all
civil cases that may arise save such as arise between citizens of the same
state, with this exception to those of that description, that the judicial of
the United States have cognizance of cases between citizens of the same state,
claiming lands under grants of different states. Nothing more, therefore, is
necessary to give the courts of law, under this constitution, complete
jurisdiction of all civil causes, but to comprehend cases between citizens of
the same state not included in the foregoing exception. I presume there will be no difficulty in accomplishing this.

--- chunk_id: chunk-0147
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 429
content_hash: 3f8e6dfe186b3747
prev_chunk_id: chunk-0146
next_chunk_id: chunk-0148
section_heading: section with attention, in which most of the powers are enumerated, will
document_type: specification

Nothing more, therefore, is
necessary to give the courts of law, under this constitution, complete
jurisdiction of all civil causes, but to comprehend cases between citizens of
the same state not included in the foregoing exception. I presume there will be no difficulty in accomplishing this. Nothing more is
necessary than to set forth, in the process, that the party who brings the suit
is a citizen of a different state from the one against whom the suit is
brought, and there can be little doubt but that the court will take cognizance
of the matter, and if they do, who is to restrain them?" Indeed, I will
freely confess, that it is my decided opinion, that the courts ought to take
cognizance of such causes, under the powers of the constitution. For one of the
great ends of the constitution is, "to establish justice." This
supposes that this cannot be done under the existing governments of the states;
and there is certainly as good reason why individuals, living in the same
state, should have justice, as those who live in different states. Moreover,
the constitution expressly declares, that "the citizens of each state
shall be entitled to all the privileges and immunities of citizens in the
several states." It will therefore be no fiction, for a citizen of one
state to set forth, in a suit, that he is a citizen of another; for he that is
entitled to all the privileges and immunities of a country, is a citizen of
that country. And in truth, the citizen of one state will, under this
constitution, be a citizen of every state. But supposing that the party, who alledges that he is a citizen of another
state, has recourse to fiction in bringing in his suit, it is well known, that
the courts have high authority to plead, to justify them in suffering actions
to be brought before them by such fictions.

--- chunk_id: chunk-0148
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: a9474936e12d7d88
prev_chunk_id: chunk-0147
next_chunk_id: chunk-0149
section_heading: section with attention, in which most of the powers are enumerated, will
document_type: specification

And in truth, the citizen of one state will, under this
constitution, be a citizen of every state. But supposing that the party, who alledges that he is a citizen of another
state, has recourse to fiction in bringing in his suit, it is well known, that
the courts have high authority to plead, to justify them in suffering actions
to be brought before them by such fictions. In my last number I stated, that
the court of exchequer tried all causes in virtue of such a fiction. The court
of king's bench, in England, extended their jurisdiction in the same way. Originally, this court held pleas, in civil cases, only of trespasses and other
injuries alledged to be committed vi et armis. They might likewise, says
Blackstone, upon the division of the aula regia, have originally held
pleas of any other civil action whatsoever (except in real actions which are
now very seldom in use) provided the defendant was an officer of the court, or
in the custody of the marshall or prison-keeper of this court, for breach of
the peace, &c. In process of time, by a fiction, this court began to hold
pleas of any personal action whatsoever; it being surmised, that the defendant
has been arrested for a supposed trespass that "he has never committed,
and being thus in the custody of the marshall of the court, the plaintiff is at
liberty to proceed against him, for any other personal injury: which surmise of
being in the marshall's custody, the defendant is not at liberty to
dispute." By a much less fiction, may the pleas of the courts of the
United States extend to cases between citizens of the same state. I shall add
no more on this head, but proceed briefly to remark, in what way this power
will diminish and destroy both the legislative and judicial authority of the
states.

--- chunk_id: chunk-0149
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 450
content_hash: 4fc28e786c24fd3c
prev_chunk_id: chunk-0148
next_chunk_id: chunk-0150
section_heading: section with attention, in which most of the powers are enumerated, will
document_type: specification

In process of time, by a fiction, this court began to hold
pleas of any personal action whatsoever; it being surmised, that the defendant
has been arrested for a supposed trespass that "he has never committed,
and being thus in the custody of the marshall of the court, the plaintiff is at
liberty to proceed against him, for any other personal injury: which surmise of
being in the marshall's custody, the defendant is not at liberty to
dispute." By a much less fiction, may the pleas of the courts of the
United States extend to cases between citizens of the same state. I shall add
no more on this head, but proceed briefly to remark, in what way this power
will diminish and destroy both the legislative and judicial authority of the
states. It is obvious that these courts will have authority to decide upon the
validity of the laws of any of the states, in all cases where they come in
question before them. Where the constitution gives the general government
exclusive jurisdiction, they will adjudge all laws made by the states, in such
cases, void ab initio. Where the constitution gives them concurrent
jurisdiction, the laws of the United States must prevail, because they are the
supreme law. In such cases, therefore, the laws of the state legislatures must
be repealed, restricted, or so construed, as to give full effect to the laws of
the union on the same subject. From these remarks it is easy to see, that in
proportion as the general government acquires power and jurisdiction, by the
liberal construction which the judges may give the constitution, will those of
the states lose its rights, until they become so trifling and unimportant, as
not to be worth having. I am much mistaken, if this system will not operate to
effect this with as much celerity, as those who have the administration of it
will think prudent to suffer it. The remaining objections to the judicial power
shall be considered in a future paper.

--- chunk_id: chunk-0150
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 74
content_hash: 00dea35824aaead8
prev_chunk_id: chunk-0149
next_chunk_id: chunk-0151
section_heading: section with attention, in which most of the powers are enumerated, will
document_type: specification

I am much mistaken, if this system will not operate to
effect this with as much celerity, as those who have the administration of it
will think prudent to suffer it. The remaining objections to the judicial power
shall be considered in a future paper. Brutus. Next | Previous | Text Version | Brutus
Contents |

--- chunk_id: chunk-0151
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: 09c83d6712800b23
prev_chunk_id: chunk-0150
next_chunk_id: chunk-0152
section_heading: Brutus XIII
document_type: specification

## Brutus XIII

*Source file: brutus13.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #13



 

 XIII


 21 February 1788


Having in the two preceding numbers, examined the nature and tendency of the
judicial power, as it respects the explanation of the constitution, I now
proceed to the consideration of the other matters, of which it has cognizance. — The next paragraph extends its authority, to all cases, in law and
equity, arising under the laws of the United States. This power, as I
understand it, is a proper one. The proper province of the judicial power, in
any government, is, as I conceive, to declare what is the law of the land. To
explain and enforce those laws, which the supreme power or legislature may
pass; but not to declare what the powers of the legislature are. I suppose the
cases in equity, under the laws, must be so construed, as to give the supreme
court not only a legal, but equitable jurisdiction of cases which may be
brought before them, or in other words, so, as to give them, not only the
powers which are now exercised by our courts of law, but those also, which are
now exercised by our court of chancery. If this be the meaning, I have no other
objection to the power, than what arises from the undue extension of the
legislative power. For, I conceive that the judicial power should be
commensurate with the legislative. Or, in other words, the supreme court should
have authority to determine questions arising under the laws of the union. The next paragraph which gives a power to decide in law and equity, on all
cases arising under treaties, is unintelligible to me. I can readily comprehend
what is meant by deciding a case under a treaty. For as treaties will be the
law. of the land, every person who have rights or privileges secured by treaty,
will have aid of the courts of law, in recovering them.

--- chunk_id: chunk-0152
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 433
content_hash: ead094d3a8eccac1
prev_chunk_id: chunk-0151
next_chunk_id: chunk-0153
section_heading: Brutus XIII
document_type: specification

For as treaties will be the
law. of the land, every person who have rights or privileges secured by treaty,
will have aid of the courts of law, in recovering them. But I do not
understand, what is meant by equity arising under a treaty. I presume every
right which can be claimed under a treaty, must be claimed by virtue of some
article or clause contained in it, which gives the right in plain and obvious
words; or at least, I conceive, that the rules for explaining treaties, are so
well ascertained, that there is no need of having recourse to an equitable
construction. If under this power, the courts are to explain treaties,
according to what they conceive are their spirit, which is nothing less than a
power to give them whatever extension they may judge proper, it is a dangerous
and improper power. The cases affecting ambassadors, public ministers, and
consuls — of admiralty and maritime jurisdiction; controversies to which
the United States are a party, and controversies between states, it is proper
should be under the cognizance of the courts of the union, because none but the
general government, can, or ought to pass laws on their subjects. But, I
conceive the clause which extends the power of the judicial to controversies
arising between a state and citizens of another state, improper in itself, and
will, in its exercise, prove most pernicious and destructive. It is improper, because it subjects a state to answer in a court of law, to
the suit of an individual. This is humiliating and degrading to a government,
and, what I believe, the supreme authority of no state ever submitted to. The states are now subject to no such actions. All contracts entered into by
individuals with states, were made upon the faith and credit of the states; and
the individuals never had in contemplation any compulsory mode of obliging the
government to fulfil its engagements.

--- chunk_id: chunk-0153
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 412
content_hash: 94b38054a85aed8d
prev_chunk_id: chunk-0152
next_chunk_id: chunk-0154
section_heading: Brutus XIII
document_type: specification

The states are now subject to no such actions. All contracts entered into by
individuals with states, were made upon the faith and credit of the states; and
the individuals never had in contemplation any compulsory mode of obliging the
government to fulfil its engagements. The evil consequences that will flow from the exercise of this power, will
best appear by tracing it in its operation. The constitution does not direct
the mode in which an individual shall commence a suit against a state or the
manner in which the judgement of the court shall be carried into execution, but
it gives the legislature full power to pass all laws which shall be proper and
necessary for the purpose. And they certainly must make provision for these
purposes, or otherwise the power of the judicial will be nugatory. For, to what
purpose will the power of a judicial be, if they have no mode, in which they
can call the parties before them? Or of what use will it be, to call the
parties to answer, if after they have given judgement, there is no authority to
execute the judgment? We must, therefore, conclude, that the legislature will
pass laws which will be effectual in this head. An individual of one state will
then have a legal remedy against a state for any demand he may have against a
state to which he does not belong. Every state in the union is largely indebted
to individuals. For the payment of these debts they have given notes payable to
the bearer. At least this is the case in this state. Whenever a citizen of
another state becomes possessed of one of these notes, he may commence an
action in the supreme court of the general government; and I cannot see any way
in which he can be prevented from recovering.

--- chunk_id: chunk-0154
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 438
content_hash: 23e706d5c6e97627
prev_chunk_id: chunk-0153
next_chunk_id: chunk-0155
section_heading: Brutus XIII
document_type: specification

At least this is the case in this state. Whenever a citizen of
another state becomes possessed of one of these notes, he may commence an
action in the supreme court of the general government; and I cannot see any way
in which he can be prevented from recovering. It is easy to see, that when this
once happens, the notes of the state will pass rapidly from the hands of
citizens of the state to those of other states. And when the citizens of other states possess them, they may bring suits
against the state for them, and by this means, judgments and executions may be
obtained against the state for the whole amount of the state debt. It is
certain the state, with the utmost exertions it can make, will not be able to
discharge the debt she owes, under a considerable number of years, perhaps with
the best management, it will require twenty or thirty years to discharge it. This new system will protract the time in which the ability of the state will
enable them to pay off their debt, because all the funds of the state will be
transferred to the general government, except those which arise from internal
taxes. The situation of the states will be deplorable. By this system, they will
surrender to the general government, all the means of raising money, and at the
same time, will subject themselves to suits at law, for the recovery of the
debts they have contracted in effecting the revolution. The debts of the individual states will amount to a sum, exceeding the
domestic debt of the United States; these will be left upon them, with power in
the judicial of the general government, to enforce their payment, while the
general government will possess an exclusive command of the most productive
funds, from which the states can derive money, and a command of every other
source of revenue paramount to the authority of any state.

--- chunk_id: chunk-0155
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: 11992432f4ea6155
prev_chunk_id: chunk-0154
next_chunk_id: chunk-0156
section_heading: Brutus XIII
document_type: specification

By this system, they will
surrender to the general government, all the means of raising money, and at the
same time, will subject themselves to suits at law, for the recovery of the
debts they have contracted in effecting the revolution. The debts of the individual states will amount to a sum, exceeding the
domestic debt of the United States; these will be left upon them, with power in
the judicial of the general government, to enforce their payment, while the
general government will possess an exclusive command of the most productive
funds, from which the states can derive money, and a command of every other
source of revenue paramount to the authority of any state. It may be said that the apprehension that the judicial power will operate in
this manner is merely visionary, for that the legislature will never pass laws
that will work these effects. Or if they were disposed to do it, they cannot
provide for levying an execution on a state, for where will the officer find
property whereon to levy? To this I would reply, if this is a power which will not or cannot be
executed, it was useless and unwise to grant it to the judicial. For what
purpose is a power given which it is imprudent or impossible to exercise? If it
be improper for a government to exercise a power, it is improper they should be
vested with it. And it is unwise to authorise a government to do what they
cannot effect. As to the idea that the legislature cannot provide for levying an execution
on a state, I believe it is not well founded. I presume the last paragraph of
the 8th section of article 1, gives the Congress express power to pass any laws
they may judge proper and necessary for carrying into execution the power
vested in the judicial department.

--- chunk_id: chunk-0156
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 414
content_hash: 9f4959d240224024
prev_chunk_id: chunk-0155
next_chunk_id: chunk-0157
section_heading: Brutus XIII
document_type: specification

As to the idea that the legislature cannot provide for levying an execution
on a state, I believe it is not well founded. I presume the last paragraph of
the 8th section of article 1, gives the Congress express power to pass any laws
they may judge proper and necessary for carrying into execution the power
vested in the judicial department. And they must exercise this power, or
otherwise the courts of justice will not be able to carry into effect the
authorities with which they are invested. For the constitution does not direct
the mode in which the courts are to proceed, to bring parties before them, to
try causes, or to carry the judgment of the courts into execution. Unless they
are pointed out by law, how are these to proceed, in any of the cases of which
they have cognizance? They have the same authority to establish regulations in
respect to these matters, where a state is a party, as where an individual is a
party. The only difficulty is, on whom shall process be served, when a state is
a party, and how shall execution be levied. With regard to the first, the way
is easy, either the executive or legislative of the state may be notified, and
upon proof being made of the service of the notice, the court may proceed to a
hearing of the cause. Execution may be levied on any property of the state,
either real or personal. The treasury may be seized by the officers of the
general government, or any lands the property of the state, may be made subject
to seizure and sale to satisfy any judgment against it. Whether the estate of
any individual citizen may not be made answerable for the discharge of
judgments against the state, may be worth consideration. In some corporations
this is the case.

--- chunk_id: chunk-0157
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 226
content_hash: 1493b73c105111c4
prev_chunk_id: chunk-0156
next_chunk_id: chunk-0158
section_heading: Brutus XIII
document_type: specification

Whether the estate of
any individual citizen may not be made answerable for the discharge of
judgments against the state, may be worth consideration. In some corporations
this is the case. If the power of the judicial under this clause will extend to the cases
above stated, it will, if executed, produce the utmost confusion, and in its
progress, will crush the states beneath its weight. And if it does not extend
to these cases, I confess myself utterly at a loss to give it any meaning. For
if the citizen of one state, possessed of a written obligation, given in
pursuance of a solemn act of the legislature, acknowledging a debt due to the
bearer, and promising to pay it, cannot recover in the supreme court, I can
conceive of no case in which they can recover. And it appears to me ridiculous
to provide for obtaining judgment against a state, without giving the means of
levying execution. Brutus. Next | Previous | Text Version | Brutus
Contents |

--- chunk_id: chunk-0158
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 433
content_hash: 22806d8fed2b3dcb
prev_chunk_id: chunk-0157
next_chunk_id: chunk-0159
section_heading: Brutus XIV
document_type: specification

## Brutus XIV

*Source file: brutus14.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #14



 

XIV


28 February 1788


The second paragraph of sect. 2d. art. 3, is in these words: "In all
cases affecting ambassadors, other public ministers and consuls, and those in
which a state shall be a party, the supreme court shall have original
jurisdiction. In all the other cases before mentioned, the supreme court shall
have appellate jurisdiction, both as to law and fact, with such exceptions, and
under such regulations as the Congress shall make.["]


Although it is proper that the courts of the general government should have
cognizance of all matters affecting ambassadors, foreign ministers, and
consuls; yet I question much the propriety of giving the supreme court original
jurisdiction in all cases of this kind. Ambassadors, and other public ministers, claim, and are entitled by the law
of nations, to certain privileges, and exemptions, both for their persons and
their servants. The meanest servant of an ambassador is exempted by the law of nations from
being sued for debt. Should a suit be brought against such an one by a citizen,
through inadvertency or want of information, he will be subject to an action in
the supreme court. All the officers concerned in issuing or executing the
process will be liable to like actions. Thus may a citizen of a state be
compelled, at great expence and inconveniency, to defend himself against a
suit, brought against him in the supreme court, for inadvertently commencing an
action against the most menial servant of an ambassador for a just debt. The appellate jurisdiction granted to the supreme court, in this paragraph,
has justly been considered as one of the most objectionable parts of the
constitution: under this power, appeals may be had from the inferior courts to
the supreme, in every case to which the judicial power extends, except in the
few instances in which the supreme court will have original jurisdiction.

--- chunk_id: chunk-0159
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 446
content_hash: b353ab87e0fddac7
prev_chunk_id: chunk-0158
next_chunk_id: chunk-0160
section_heading: Brutus XIV
document_type: specification

Thus may a citizen of a state be
compelled, at great expence and inconveniency, to defend himself against a
suit, brought against him in the supreme court, for inadvertently commencing an
action against the most menial servant of an ambassador for a just debt. The appellate jurisdiction granted to the supreme court, in this paragraph,
has justly been considered as one of the most objectionable parts of the
constitution: under this power, appeals may be had from the inferior courts to
the supreme, in every case to which the judicial power extends, except in the
few instances in which the supreme court will have original jurisdiction. By this article, appeals will lie to the supreme court, in all criminal as
well as civil causes. This I know, has been disputed by some; but I presume the
point will appear clear to any one, who will attend to the connection of this
paragraph with the one that precedes it. In the former, all the cases, to which
the power of the judicial shall extend, whether civil or criminal, are
enumerated. There is no criminal matter, to which the judicial power of the
United States will extend; but such as are included under some one of the cases
specified in this section. For this section is intended to define all the
cases, of every description, to which the power of the judicial shall reach. But in all these cases it is declared, the supreme court shall have appellate
jurisdiction, except in those which affect ambassadors, other public ministers
and consuls, and those in which a state shall be a party. If then this section
extends the power of the judicial, to criminal cases, it allows appeals in such
cases. If the power of the judicial is not extended to criminal matters by this
section, I ask, by what part of this system does it appear, that they have any
cognizance of them? I believe it is a new and unusual thing to allow appeals in criminal
matters.

--- chunk_id: chunk-0160
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 424
content_hash: 619a06a6059b6789
prev_chunk_id: chunk-0159
next_chunk_id: chunk-0161
section_heading: Brutus XIV
document_type: specification

If the power of the judicial is not extended to criminal matters by this
section, I ask, by what part of this system does it appear, that they have any
cognizance of them? I believe it is a new and unusual thing to allow appeals in criminal
matters. It is contrary to the sense of our laws, and dangerous to the lives
and liberties of the citizen. As our law now stands, a person charged with a
crime has a right to a fair and impartial trial by a jury of his country
[county?], and their verdict is final. If he is acquitted no other court can
call upon him to answer for the same crime. But by this system, a man may have
had ever so fair a trial, have been acquitted by ever so respectable a jury of
his country; and still the officer of the government who prosecutes, may appeal
to the supreme court. The whole matter may have a second hearing. By this
means, persons who may have disobliged those who execute the general
government, may be subjected to intolerable oppression. They may be kept in
long and ruinous confinement, and exposed to heavy and insupportable charges,
to procure the attendence of witnesses, and provide the means of their defence,
at a great distance from their places of residence. I can scarcely believe there can be a considerate citizen of the United
States, that will approve of this appellate jurisdiction, as extending to
criminal cases, if they will give themselves time for reflection. Whether the appellate jurisdiction as it respects civil matters, will not
prove injurious to the rights of the citizens, and destructive of those
privileges which have ever been held sacred by Americans, and whether it will
not render the administration of justice intolerably burthensome, intricate,
and dilatory, will best appear, when we have considered the nature and
operation of this power.

--- chunk_id: chunk-0161
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 417
content_hash: 2ec2cb07b95e6a46
prev_chunk_id: chunk-0160
next_chunk_id: chunk-0162
section_heading: Brutus XIV
document_type: specification

I can scarcely believe there can be a considerate citizen of the United
States, that will approve of this appellate jurisdiction, as extending to
criminal cases, if they will give themselves time for reflection. Whether the appellate jurisdiction as it respects civil matters, will not
prove injurious to the rights of the citizens, and destructive of those
privileges which have ever been held sacred by Americans, and whether it will
not render the administration of justice intolerably burthensome, intricate,
and dilatory, will best appear, when we have considered the nature and
operation of this power. It has been the fate of this clause, as it has of most of those, against
which unanswerable objections have been offered, to be explained different
ways, by the advocates and opponents to the constitution. I confess I do not
know what the advocates of the system, would make it mean, for I have not been
fortunate enough to see in any publication this clause taken up and considered. It is certain however, they do not admit the explanation which those who oppose
the constitution give it, or otherwise they would not so frequently charge them
with want of candor, for alledging that it takes away the trial by jury[;]
appeals from an inferior to a superior court, as practised in the civil law
courts, are well understood. In these courts, the judges determine both on the
law and the fact; and appeals are allowed from the inferior to the superior
courts, on the whole merits: the superior tribunal will re-examine all the
facts as well as the law, and frequently new facts will be introduced, so as
many times to render the cause in the court of appeals very different from what
it was in the court below. If the appellate jurisdiction of the supreme court, be understood in the
above sense, the term is perfectly intelligible.

--- chunk_id: chunk-0162
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 321
content_hash: d0284d427c0da560
prev_chunk_id: chunk-0161
next_chunk_id: chunk-0163
section_heading: Brutus XIV
document_type: specification

In these courts, the judges determine both on the
law and the fact; and appeals are allowed from the inferior to the superior
courts, on the whole merits: the superior tribunal will re-examine all the
facts as well as the law, and frequently new facts will be introduced, so as
many times to render the cause in the court of appeals very different from what
it was in the court below. If the appellate jurisdiction of the supreme court, be understood in the
above sense, the term is perfectly intelligible. The meaning then is, that in
all the civil causes enumerated, the supreme court shall have authority to
re-examine the whole merits of the case, both with respect to the facts and the
law which may arise under it, without the intervention of a jury; that this is
the sense of this part of the system appears to me clear, from the express
words of it, "in all the other cases before mentioned, the supreme court
shall have appellate jurisdiction, both as to law and fact, &c." Who
are the supreme court? Does it not consist of the judges? and they are to have
the same jurisdiction of the fact as they are to have of the law. They will
therefore have the same authority to determine the fact as they will have to
determine the law, and no room is left for a jury on appeals to the supreme
court.

--- chunk_id: chunk-0163
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 380
content_hash: 57f34c5cf1cc964b
prev_chunk_id: chunk-0162
next_chunk_id: chunk-0164
section_heading: Brutus XIV
document_type: specification

and they are to have
the same jurisdiction of the fact as they are to have of the law. They will
therefore have the same authority to determine the fact as they will have to
determine the law, and no room is left for a jury on appeals to the supreme
court. If we understand the appellate jurisdiction in any other way, we shall be
left utterly at a loss to give it a meaning; the common law is a stranger to
any such jurisdiction: no appeals can lie from any of our common law courts,
upon the merits of the case; the only way in which they can go up from an
inferior to a superior tribunal is by habeas corpus before a hearing, or by
certiorari, or writ of error, after they are determined in the subordinate
courts; but in no case, when they are carried up, are the facts re-examined,
but they are always taken as established in the inferior courts. (To be continued.)


 XIV


 6 March 1788


(Continued.)


It may still be insisted that this clause does not take away the trial by
jury on appeals, but that this may be provided for by the legislature, under
that paragraph which authorises them to form regulations and restrictions for
the court in the exercise of this power. The natural meaning of this paragraph seems to be no more than this, that
Congress may declare, that certain cases shall not be subject to the appellate
jurisdiction, and they may point out the mode in which the court shall proceed
in bringing up the causes before them, the manner of their taking evidence to
establish the facts, and the method of the courts proceeding.

--- chunk_id: chunk-0164
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 316
content_hash: 4e24df534d8bc757
prev_chunk_id: chunk-0163
next_chunk_id: chunk-0165
section_heading: Brutus XIV
document_type: specification

(To be continued.)


 XIV


 6 March 1788


(Continued.)


It may still be insisted that this clause does not take away the trial by
jury on appeals, but that this may be provided for by the legislature, under
that paragraph which authorises them to form regulations and restrictions for
the court in the exercise of this power. The natural meaning of this paragraph seems to be no more than this, that
Congress may declare, that certain cases shall not be subject to the appellate
jurisdiction, and they may point out the mode in which the court shall proceed
in bringing up the causes before them, the manner of their taking evidence to
establish the facts, and the method of the courts proceeding. But I presume
they cannot take from the court the right of deciding on the fact, any more
than they can deprive them of the right of determining on the law, when a cause
is once before them; for they have the same jurisdiction as to fact, as they
have as to the law. But supposing the Congress may under this clause establish
the trial by jury on appeals, it does not seem to me that it will render this
article much less exceptionable. An appeal from one court and jury, to another
court and jury, is a thing altogether unknown in the laws of our state, and in
most of the states in the union.

--- chunk_id: chunk-0165
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 334
content_hash: 0aebbe2ebda5d5bd
prev_chunk_id: chunk-0164
next_chunk_id: chunk-0166
section_heading: Brutus XIV
document_type: specification

But supposing the Congress may under this clause establish
the trial by jury on appeals, it does not seem to me that it will render this
article much less exceptionable. An appeal from one court and jury, to another
court and jury, is a thing altogether unknown in the laws of our state, and in
most of the states in the union. A practice of this kind prevails in the
eastern states; actions are there commenced in the inferior courts, and an
appeal lies from them on the whole merits to the superior courts: the
consequence is well known, very few actions are determined in the lower courts;
it is rare that a case of any importance is not carried by appeal to the
supreme court, and the jurisdiction of the inferior courts is merely nominal;
this has proved so burthensome to the people in Massachusetts, that it was one
of the principal causes which excited the insurrection in that state, in the
year past; very few sensible and moderate men in that state but what will
admit, that the inferior courts are almost entirely useless, and answer very
little purpose, save only to accumulate costs against the poor debtors who are
already unable to pay their just debts. But the operation of the appellate power in the supreme judicial of the
United States, would work infinitely more mischief than any such power can do
in a single state. The trouble and expence to the parties would be endless and intolerable.

--- chunk_id: chunk-0166
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 366
content_hash: fe5b97d05937cc93
prev_chunk_id: chunk-0165
next_chunk_id: chunk-0167
section_heading: Brutus XIV
document_type: specification

But the operation of the appellate power in the supreme judicial of the
United States, would work infinitely more mischief than any such power can do
in a single state. The trouble and expence to the parties would be endless and intolerable. No
man can say where the supreme court are to hold their sessions, the presumption
is, however, that it must be at the seat of the general government: in this
case parties must travel many hundred miles, with their witnesses and lawyers,
to prosecute or defend a suit; no man of midling fortune, can sustain the
expence of such a law suit, and therefore the poorer and midling class of
citizens will be under the necessity of submitting to the demands of the rich
and the lordly, in cases that will come under the cognizance of this court. If
it be said, that to prevent this oppression, the supreme court will set in
different parts of the union, it may be replied, that this would only make the
oppression somewhat more tolerable, but by no means so much as to give a chance
of justice to the poor and midling class. It is utterly impossible that the
supreme court can move into so many different parts of the Union, as to make it
convenient or even tolerable to attend before them with witnesses to try causes
from every part of the United states; if to avoid the expence and inconvenience
of calling witnesses from a great distance, to give evidence before the supreme
court, the expedient of taking the deposition of witnesses in writing should be
adopted, it would not help the matter.

--- chunk_id: chunk-0167
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 352
content_hash: 4c5cd763f11b22f0
prev_chunk_id: chunk-0166
next_chunk_id: chunk-0168
section_heading: Brutus XIV
document_type: specification

If
it be said, that to prevent this oppression, the supreme court will set in
different parts of the union, it may be replied, that this would only make the
oppression somewhat more tolerable, but by no means so much as to give a chance
of justice to the poor and midling class. It is utterly impossible that the
supreme court can move into so many different parts of the Union, as to make it
convenient or even tolerable to attend before them with witnesses to try causes
from every part of the United states; if to avoid the expence and inconvenience
of calling witnesses from a great distance, to give evidence before the supreme
court, the expedient of taking the deposition of witnesses in writing should be
adopted, it would not help the matter. It is of great importance in the
distribution of justice that witnesses should be examined face to face, that
the parties should have the fairest opportunity of cross examining them in
order to bring out the whole truth; there is something in the manner in which a
witness delivers his testimony which cannot be committed to paper, and which
yet very frequently gives a complexion to his evidence, very different from
what it would bear if committed to writing, besides the expence of taking
written testimony would be enormous; those who are acquainted with the costs
that arise in the courts, where all the evidence is taken in writing, well know
that they exceed beyond all comparison those of the common law courts, where
witnesses are examined viva voce.

--- chunk_id: chunk-0168
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 386
content_hash: 650e094df819f311
prev_chunk_id: chunk-0167
next_chunk_id: chunk-0169
section_heading: Brutus XIV
document_type: specification

It is utterly impossible that the
supreme court can move into so many different parts of the Union, as to make it
convenient or even tolerable to attend before them with witnesses to try causes
from every part of the United states; if to avoid the expence and inconvenience
of calling witnesses from a great distance, to give evidence before the supreme
court, the expedient of taking the deposition of witnesses in writing should be
adopted, it would not help the matter. It is of great importance in the
distribution of justice that witnesses should be examined face to face, that
the parties should have the fairest opportunity of cross examining them in
order to bring out the whole truth; there is something in the manner in which a
witness delivers his testimony which cannot be committed to paper, and which
yet very frequently gives a complexion to his evidence, very different from
what it would bear if committed to writing, besides the expence of taking
written testimony would be enormous; those who are acquainted with the costs
that arise in the courts, where all the evidence is taken in writing, well know
that they exceed beyond all comparison those of the common law courts, where
witnesses are examined viva voce. The costs accruing in courts generally advance with the grade of the court;
thus the charges attending a suit in our common pleas, is much less than those
in the supreme court, and these are much lower than those in the court of
chancery; indeed the costs in the last mentioned court, are in many cases so
exorbitant and the proceedings so dilatory that the suitor had almost as well
give up his demand as to prosecute his suit.

--- chunk_id: chunk-0169
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 406
content_hash: 15e8884de422ccf0
prev_chunk_id: chunk-0168
next_chunk_id: chunk-0170
section_heading: Brutus XIV
document_type: specification

It is of great importance in the
distribution of justice that witnesses should be examined face to face, that
the parties should have the fairest opportunity of cross examining them in
order to bring out the whole truth; there is something in the manner in which a
witness delivers his testimony which cannot be committed to paper, and which
yet very frequently gives a complexion to his evidence, very different from
what it would bear if committed to writing, besides the expence of taking
written testimony would be enormous; those who are acquainted with the costs
that arise in the courts, where all the evidence is taken in writing, well know
that they exceed beyond all comparison those of the common law courts, where
witnesses are examined viva voce. The costs accruing in courts generally advance with the grade of the court;
thus the charges attending a suit in our common pleas, is much less than those
in the supreme court, and these are much lower than those in the court of
chancery; indeed the costs in the last mentioned court, are in many cases so
exorbitant and the proceedings so dilatory that the suitor had almost as well
give up his demand as to prosecute his suit. We have just reason to suppose,
that the costs in the supreme general court will exceed either of our courts;
the officers of the general court will be more dignified than those of the
states, the lawyers of the most ability will practice in them, and the trouble
and expence of attending them will be greater. From all these considerations,
it appears, that the expence attending suits in the supreme court will be so
great, as to put it out of the power of the poor and midling class of citizens
to contest a suit in it.

--- chunk_id: chunk-0170
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 288
content_hash: 7a5c1ec6b1b1850f
prev_chunk_id: chunk-0169
next_chunk_id: chunk-0171
section_heading: Brutus XIV
document_type: specification

We have just reason to suppose,
that the costs in the supreme general court will exceed either of our courts;
the officers of the general court will be more dignified than those of the
states, the lawyers of the most ability will practice in them, and the trouble
and expence of attending them will be greater. From all these considerations,
it appears, that the expence attending suits in the supreme court will be so
great, as to put it out of the power of the poor and midling class of citizens
to contest a suit in it. From these remarks it appears, that the administration of justice under the
powers of the judicial will be dilatory; that it will be attended with such an
heavy expence as to amount to little short of a denial of justice to the poor
and middling class of people who in every government stand most in need of the
protection of the law; and that the trial by jury, which has so justly been the
boast of our fore fathers as well as ourselves is taken away under them. These extraordinary powers in this court are the more objectionable, because
there does not appear the least necessity for them, in order to secure a due
and impartial distribution of justice.

--- chunk_id: chunk-0171
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 440
content_hash: 4bf98c6abfd35483
prev_chunk_id: chunk-0170
next_chunk_id: chunk-0172
section_heading: Brutus XIV
document_type: specification

From these remarks it appears, that the administration of justice under the
powers of the judicial will be dilatory; that it will be attended with such an
heavy expence as to amount to little short of a denial of justice to the poor
and middling class of people who in every government stand most in need of the
protection of the law; and that the trial by jury, which has so justly been the
boast of our fore fathers as well as ourselves is taken away under them. These extraordinary powers in this court are the more objectionable, because
there does not appear the least necessity for them, in order to secure a due
and impartial distribution of justice. The want of ability or integrity, or a disposition to render justice to
every suitor, has not been objected against the courts of the respective
states: so far as I have been informed, the courts of justice in all the
states, have ever been found ready, to administer justice with promptitude and
impartiality according to the laws of the land; It is true in some of the
states, paper money has been made, and the debtor authorised to discharge his
debts with


it, at a depreciated value, in orders, tender laws have been passed,
obliging the creditor to receive on execution other property than money in
discharge of his demand, and in several of the states laws have been made
unfavorable to the creditor and tending to render property insecure. But these evils have not happened from any defect in the judicial
departments of the states; the courts indeed are bound to take notice of these
laws, and so will the courts of the general government be under obligation to
observe the laws made by the general legislature not repugnant to the
constitution; but so far have the judicial been from giving undue latitude of
construction to laws of this kind, that they have invariably strongly inclined
to the other side.

--- chunk_id: chunk-0172
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 405
content_hash: 518d383b80f8ea9a
prev_chunk_id: chunk-0171
next_chunk_id: chunk-0173
section_heading: Brutus XIV
document_type: specification

The want of ability or integrity, or a disposition to render justice to
every suitor, has not been objected against the courts of the respective
states: so far as I have been informed, the courts of justice in all the
states, have ever been found ready, to administer justice with promptitude and
impartiality according to the laws of the land; It is true in some of the
states, paper money has been made, and the debtor authorised to discharge his
debts with


it, at a depreciated value, in orders, tender laws have been passed,
obliging the creditor to receive on execution other property than money in
discharge of his demand, and in several of the states laws have been made
unfavorable to the creditor and tending to render property insecure. But these evils have not happened from any defect in the judicial
departments of the states; the courts indeed are bound to take notice of these
laws, and so will the courts of the general government be under obligation to
observe the laws made by the general legislature not repugnant to the
constitution; but so far have the judicial been from giving undue latitude of
construction to laws of this kind, that they have invariably strongly inclined
to the other side. All the acts of our legislature, which have been charged
with being of this complexion, have uniformly received the strictest
construction by the judges, and have been extended to no cases but to such as
came within the strict letter of the law. In this way, have our courts, I will
not say evaded the law, but so limited it in its operation as to work the least
possible injustice: the same thing has taken place in Rhode-Island, which has
justly rendered herself infamous, by her tenaciously adhering to her paper
money system.

--- chunk_id: chunk-0173
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 389
content_hash: 4185f8d9ce20cc04
prev_chunk_id: chunk-0172
next_chunk_id: chunk-0174
section_heading: Brutus XIV
document_type: specification

All the acts of our legislature, which have been charged
with being of this complexion, have uniformly received the strictest
construction by the judges, and have been extended to no cases but to such as
came within the strict letter of the law. In this way, have our courts, I will
not say evaded the law, but so limited it in its operation as to work the least
possible injustice: the same thing has taken place in Rhode-Island, which has
justly rendered herself infamous, by her tenaciously adhering to her paper
money system. The judges there gave a decision, in opposition to the words of
the Statute, on this principle, that a construction according to the words of
it, would contradict the fundamental maxims of their laws and constitution. No pretext therefore, can be formed, from the conduct of the judicial courts
which will justify giving such powers to the supreme general court, for their
decisions have been such as to give just ground of confidence in them, that
they will firmly adhere to the principles of rectitude, and there is no
necessity of lodging these powers in the courts, in order to guard against the
evils justly complained of, on the subject of security of property under this
constitution. For it has provided, "that no state shall emit bills of
credit, or make any thing but gold and silver coin a tender in payment of
debts." It has also declared, that "no state shall pass any law
impairing the obligation of contracts." — These prohibitions give the
most perfect security against those attacks upon property which I am sorry to
say some of the states have but too wantonly made, by passing laws sanctioning
fraud in the debtor against his creditor.

--- chunk_id: chunk-0174
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 397
content_hash: c628c79d138b2ac9
prev_chunk_id: chunk-0173
next_chunk_id: chunk-0175
section_heading: Brutus XIV
document_type: specification

No pretext therefore, can be formed, from the conduct of the judicial courts
which will justify giving such powers to the supreme general court, for their
decisions have been such as to give just ground of confidence in them, that
they will firmly adhere to the principles of rectitude, and there is no
necessity of lodging these powers in the courts, in order to guard against the
evils justly complained of, on the subject of security of property under this
constitution. For it has provided, "that no state shall emit bills of
credit, or make any thing but gold and silver coin a tender in payment of
debts." It has also declared, that "no state shall pass any law
impairing the obligation of contracts." — These prohibitions give the
most perfect security against those attacks upon property which I am sorry to
say some of the states have but too wantonly made, by passing laws sanctioning
fraud in the debtor against his creditor. For "this constitution will be
the supreme law of the land, and the judges in every state will be bound
thereby; any thing in the constitution and laws of any state to the contrary
notwithstanding."


The courts of the respective states might therefore have been securely
trusted, with deciding all cases between man and man, whether citizens of the
same state or of different states, or between foreigners and citizens, and
indeed for ought I see every case that can arise under the constitution or laws
of the United States, ought in the first instance to be tried in the court of
the state, except those which might arise between states, such as respect
ambassadors, or other public ministers, and perhaps such as call in question
the claim of lands under grants from different states.

--- chunk_id: chunk-0175
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 408
content_hash: d8ef8833e6aea656
prev_chunk_id: chunk-0174
next_chunk_id: chunk-0176
section_heading: Brutus XIV
document_type: specification

For it has provided, "that no state shall emit bills of
credit, or make any thing but gold and silver coin a tender in payment of
debts." It has also declared, that "no state shall pass any law
impairing the obligation of contracts." — These prohibitions give the
most perfect security against those attacks upon property which I am sorry to
say some of the states have but too wantonly made, by passing laws sanctioning
fraud in the debtor against his creditor. For "this constitution will be
the supreme law of the land, and the judges in every state will be bound
thereby; any thing in the constitution and laws of any state to the contrary
notwithstanding."


The courts of the respective states might therefore have been securely
trusted, with deciding all cases between man and man, whether citizens of the
same state or of different states, or between foreigners and citizens, and
indeed for ought I see every case that can arise under the constitution or laws
of the United States, ought in the first instance to be tried in the court of
the state, except those which might arise between states, such as respect
ambassadors, or other public ministers, and perhaps such as call in question
the claim of lands under grants from different states. The state courts would
be under sufficient controul, if writs of error were allowed from the state
courts to the supreme court of the union, according to the practice of the
courts in England and of this state, on all cases in which the laws of the
union are concerned, and perhaps to all cases in which a foreigner is a party. This method would preserve the good old way of administering justice, would
bring justice to every man's door, and preserve the inestimable right of trial
by jury.

--- chunk_id: chunk-0176
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 428
content_hash: 05cc14a2750db26a
prev_chunk_id: chunk-0175
next_chunk_id: chunk-0177
section_heading: Brutus XIV
document_type: specification

The state courts would
be under sufficient controul, if writs of error were allowed from the state
courts to the supreme court of the union, according to the practice of the
courts in England and of this state, on all cases in which the laws of the
union are concerned, and perhaps to all cases in which a foreigner is a party. This method would preserve the good old way of administering justice, would
bring justice to every man's door, and preserve the inestimable right of trial
by jury. It would be following, as near as our circumstances will admit, the
practice of the courts in England, which is almost the only thing I would wish
to copy in their government. But as this system now stands, there is to be as many inferior courts as
Congress may see fit to appoint, who are to be authorised to originate and in
the first instance to try all the cases falling under the description of this
article; there is no security that a trial by jury shall be had in these
courts, but the trial here will soon become, as it is in Massachusetts'
inferior courts, mere matter of form; for an appeal may be had to the supreme
court on the whole merits. This court is to have power to determine in law and
in equity, on the law and the fact, and this court is exalted above all other
power in the government, subject to no controul, and so fixed as not to be
removeable, but upon impeachment, which I shall hereafter shew, is much the
same thing as not to be removeable at all. To obviate the objections made to the judicial power it has been said, that
the Congress, in forming the regulations and exceptions which they are
authorised to make respecting the appellate jurisdiction, will make provision
against all the evils which are apprehended from this article.

--- chunk_id: chunk-0177
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 316
content_hash: f648159501605729
prev_chunk_id: chunk-0176
next_chunk_id: chunk-0178
section_heading: Brutus XIV
document_type: specification

This court is to have power to determine in law and
in equity, on the law and the fact, and this court is exalted above all other
power in the government, subject to no controul, and so fixed as not to be
removeable, but upon impeachment, which I shall hereafter shew, is much the
same thing as not to be removeable at all. To obviate the objections made to the judicial power it has been said, that
the Congress, in forming the regulations and exceptions which they are
authorised to make respecting the appellate jurisdiction, will make provision
against all the evils which are apprehended from this article. On this I would
remark, that this way of answering the objection made to the power, implies an
admission that the power is in itself improper without restraint, and if so,
why not restrict it in the first instance. The just way of investigating any power given to a government, is to examine
its operation supposing it to be put in exercise. If upon enquiry, it appears
that the power, if exercised, would be prejudicial, it ought not to be given. For to answer objections made to a power given to a government, by saying it
will never be exercised, is really admitting that the power ought not to be
exercised, and therefore ought not to be granted. Brutus. Next | Previous | Text Version | Brutus
Contents |

--- chunk_id: chunk-0178
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 436
content_hash: b2add5469e381aea
prev_chunk_id: chunk-0177
next_chunk_id: chunk-0179
section_heading: Brutus XV
document_type: specification

## Brutus XV

*Source file: brutus15.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #15



 

 XV


 20 March 1788


(Continued.)


I said in my last number, that the supreme court under this constitution
would be exalted above all other power in the government, and subject to no
controul. The business of this paper will be to illustrate this, and to shew
the danger that will result from it. I question whether the world ever saw, in
any period of it, a court of justice invested with such immense powers, and yet
placed in a situation so little responsible. Certain it is, that in England,
and in the several states, where we have been taught to believe, the courts of
law are put upon the most prudent establishment, they are on a very different
footing. The judges in England, it is true, hold their offices during their good
behaviour, but then their determinations are subject to correction by the house
of lords; and their power is by no means so extensive as that of the proposed
supreme court of the union. — I believe they in no instance assume the
authority to set aside an act of parliament under the idea that it is
inconsistent with their constitution. They consider themselves bound to decide
according to the existing laws of the land, and never undertake to controul
them by adjudging that they are inconsistent with the constitution — much
less are they vested with the power of giving an equitable construction
to the constitution. The judges in England are under the controul of the legislature, for they
are bound to determine according to the laws passed by them. But the judges
under this constitution will controul the legislature, for the supreme court
are authorised in the last resort, to determine what is the extent of the
powers of the Congress; they are to give the constitution an explanation, and
there is no power above them to set aside their judgment.

--- chunk_id: chunk-0179
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 410
content_hash: f702edbe6272f70c
prev_chunk_id: chunk-0178
next_chunk_id: chunk-0180
section_heading: Brutus XV
document_type: specification

The judges in England are under the controul of the legislature, for they
are bound to determine according to the laws passed by them. But the judges
under this constitution will controul the legislature, for the supreme court
are authorised in the last resort, to determine what is the extent of the
powers of the Congress; they are to give the constitution an explanation, and
there is no power above them to set aside their judgment. The framers of this
constitution appear to have followed that of the British, in rendering the
judges independent, by granting them their offices during good behaviour,
without following the constitution of England, in instituting a tribunal in
which their errors may be corrected; and without adverting to this, that the
judicial under this system have a power which is above the legislative, and
which indeed transcends any power before given to a judicial by any free
government under heaven. I do not object to the judges holding their commissions during good
behaviour. I suppose it a proper provision provided they were made properly
responsible. But I say, this system has followed the English government in
this, while it has departed from almost every other principle of their
jurisprudence, under the idea, of rendering the judges independent; which, in
the British constitution, means no more than that they hold their places during
good behaviour, and have fixed salaries, they have made the judges
independent, in the fullest sense of the word. There is no power above
them, to controul any of their decisions. There is no authority that can remove
them, and they cannot be controuled by the laws of the legislature. In short,
they are independent of the people, of the legislature, and of every power
under heaven. Men placed in this situation will generally soon feel themselves
independent of heaven itself.

--- chunk_id: chunk-0180
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 444
content_hash: a252d4ed447960b7
prev_chunk_id: chunk-0179
next_chunk_id: chunk-0181
section_heading: Brutus XV
document_type: specification

In short,
they are independent of the people, of the legislature, and of every power
under heaven. Men placed in this situation will generally soon feel themselves
independent of heaven itself. Before I proceed to illustrate the truth of these
assertions, I beg liberty to make one remark — Though in my opinion the
judges ought to hold their offices during good behaviour, yet I think it is
clear, that the reasons in favour of this establishment of the judges in
England, do by no means apply to this country. The great reason assigned, why the judges in Britain ought to be
commissioned during good behaviour, is this, that they may be placed in a
situation, not to be influenced by the crown, to give such decisions, as would
tend to increase its powers and prerogatives. While the judges held their
places at the will and pleasure of the king, on whom they depended not only for
their offices, but also for their salaries, they were subject to every undue
influence. If the crown wished to carry a favorite point, to accomplish which
the aid of the courts of law was necessary, the pleasure of the king would be
signified to the judges. And it required the spirit of a martyr, for the judges
to determine contrary to the king's will. — They were absolutely dependent
upon him both for their offices and livings. The king, holding his office
during life, and transmitting it to his posterity as an inheritance, has much
stronger inducements to increase the prerogatives of his office than those who
hold their offices for stated periods, or even for life. Hence the English
nation gained a great point, in favour of liberty. When they obtained the
appointment of the judges, during good behaviour, they got from the crown a
concession, which deprived it of one of the most powerful engines with which it
might enlarge the boundaries of the royal prerogative and encroach on the
liberties of the people.

--- chunk_id: chunk-0181
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 424
content_hash: 124bec6da1a5590b
prev_chunk_id: chunk-0180
next_chunk_id: chunk-0182
section_heading: Brutus XV
document_type: specification

Hence the English
nation gained a great point, in favour of liberty. When they obtained the
appointment of the judges, during good behaviour, they got from the crown a
concession, which deprived it of one of the most powerful engines with which it
might enlarge the boundaries of the royal prerogative and encroach on the
liberties of the people. But these reasons do not apply to this country, we
have no hereditary monarch; those who appoint the judges do not hold their
offices for life, nor do they descend to their children. The same arguments,
therefore, which will conclude in favor of the tenor of the judge's offices for
good behaviour, lose a considerable part of their weight when applied to the
state and condition of America. But much less can it be shewn, that the nature
of our government requires that the courts should be placed beyond all account
more independent, so much so as to be above controul. I have said that the judges under this system will be independent in
the strict sense of the word: To prove this I will shew — That there is no
power above them that can controul their decisions, or correct their errors. There is no authority that can remove them from office for any errors or want
of capacity, or lower their salaries, and in many cases their power is superior
to that of the legislature. 1st. There is no power above them that can correct their errors or controul
their decisions — The adjudications of this court are final and
irreversible, for there is no court above them to which appeals can lie, either
in error or on the merits. — In this respect it differs from the courts in
England, for there the house of lords is the highest court, to whom appeals, in
error, are carried from the highest of the courts of law. 2d.

--- chunk_id: chunk-0182
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: 2deb2d8820d6aab4
prev_chunk_id: chunk-0181
next_chunk_id: chunk-0183
section_heading: Brutus XV
document_type: specification

— In this respect it differs from the courts in
England, for there the house of lords is the highest court, to whom appeals, in
error, are carried from the highest of the courts of law. 2d. They cannot be removed from office or suffer a dimunition of their
salaries, for any error in judgement or want of capacity. It is expressly declared by the constitution, — "That they shall
at stated times receive a compensation for their services which shall not be
diminished during their continuance in office."


The only clause in the constitution which provides for the removal of the
judges from office, is that which declares, that "the president,
vice-president, and all civil officers of the United States, shall be removed
from office, on impeachment for, and conviction of treason, bribery, or other
high crimes and misdemeanors." By this paragraph, civil officers, in which
the judges are included, are removable only for crimes. Treason and bribery are
named, and the rest are included under the general terms of high crimes and
misdemeanors. — Errors in judgement, or want of capacity to discharge the
duties of the office, can never be supposed to be included in these words,
high crimes and misdemeanors. A man may mistake a case in giving
judgment, or manifest that he is incompetent to the discharge of the duties of
a judge, and yet give no evidence of corruption or want of integrity. To
support the charge, it will be necessary to give in evidence some facts that
will shew, that the judges commited the error from wicked and corrupt motives. 3d. The power of this court is in many cases superior to that of the
legislature. I have shewed, in a former paper, that this court will be
authorised to decide upon the meaning of the constitution, and that, not only
according to the natural and ob[vious] meaning of the words, but also according
to the spirit and intention of it.

--- chunk_id: chunk-0183
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 344
content_hash: dfcb41699deeef07
prev_chunk_id: chunk-0182
next_chunk_id: chunk-0184
section_heading: Brutus XV
document_type: specification

The power of this court is in many cases superior to that of the
legislature. I have shewed, in a former paper, that this court will be
authorised to decide upon the meaning of the constitution, and that, not only
according to the natural and ob[vious] meaning of the words, but also according
to the spirit and intention of it. In the exercise of this power they will not
be subordinate to, but above the legislature. For all the departments of this
government will receive their powers, so far as they are expressed in the
constitution, from the people immediately, who are the source of power. The
legislature can only exercise such powers as are given them by the
constitution, they cannot assume any of the rights annexed to the judicial, for
this plain reason, that the same authority which vested the legislature with
their powers, vested the judicial with theirs — both are derived from the
same source, both therefore are equally valid, and the judicial hold their
powers independently of the legislature, as the legislature do of the judicial. — The supreme court then have a right, independent of the legislature, to
give a construction to the constitution and every part of it, and there is no
power provided in this system to correct their construction or do it away. If,
therefore, the legislature pass any laws, inconsistent with the sense the
judges put upon the constitution, they will declare it void; and therefore in
this respect their power is superior to that of the legislature.

--- chunk_id: chunk-0184
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 369
content_hash: a9d0d0922f3c3d92
prev_chunk_id: chunk-0183
next_chunk_id: chunk-0185
section_heading: Brutus XV
document_type: specification

— The supreme court then have a right, independent of the legislature, to
give a construction to the constitution and every part of it, and there is no
power provided in this system to correct their construction or do it away. If,
therefore, the legislature pass any laws, inconsistent with the sense the
judges put upon the constitution, they will declare it void; and therefore in
this respect their power is superior to that of the legislature. In England the
judges are not only subject to have their decisions set aside by the house of
lords, for error, but in cases where they give an explanation to the laws or
constitution of the country, contrary to the sense of the parliament, though
the parliament will not set aside the judgement of the court, yet, they have
authority, by a new law, to explain a former one, and by this means to prevent
a reception of such decisions. But no such power is in the legislature. The
judges are supreme — and no law, explanatory of the constitution, will be
binding on them. From the preceding remarks, which have been made on the judicial powers
proposed in this system, the policy of it may be fully developed. I have, in the course of my observation on this constitution, affirmed and
endeavored to shew, that it was calculated to abolish entirely the state
governments, and to melt down the states into one entire government, for every
purpose as well internal and local, as external and national. In this opinion
the opposers of the system have generally agreed — and this has been
uniformly denied by its advocates in public.

--- chunk_id: chunk-0185
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 414
content_hash: 961b864c98745227
prev_chunk_id: chunk-0184
next_chunk_id: chunk-0186
section_heading: Brutus XV
document_type: specification

I have, in the course of my observation on this constitution, affirmed and
endeavored to shew, that it was calculated to abolish entirely the state
governments, and to melt down the states into one entire government, for every
purpose as well internal and local, as external and national. In this opinion
the opposers of the system have generally agreed — and this has been
uniformly denied by its advocates in public. Some individuals, indeed, among
them, will confess, that it has this tendency, and scruple not to say, it is
what they wish; and I will venture to predict, without the spirit of prophecy,
that if it is adopted without amendments, or some such precautions as will
ensure amendments immediately after its adoption, that the same gentlemen who
have employed their talents and abilities with such success to influence the
public mind to adopt this plan, will employ the same to persuade the people,
that it will be for their good to abolish the state governments as useless and
burdensome. Perhaps nothing could have been better conceived to facilitate the abolition
of the state governments than the constitution of the judicial. They will be
able to extend the limits of the general government gradually, and by
insensible degrees, and to accomodate themselves to the temper of the people. Their decisions on the meaning of the constitution will commonly take place in
cases which arise between individuals, with which the public will not be
generally acquainted; one adjudication will form a precedent to the next, and
this to a following one. These cases will immediately affect individuals only;
so that a series of determinations will probably take place before even the
people will be informed of them. In the mean time all the art and address of
those who wish for the change will be employed to make converts to their
opinion.

--- chunk_id: chunk-0186
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 421
content_hash: 1e4aff8a142072f6
prev_chunk_id: chunk-0185
next_chunk_id: chunk-0187
section_heading: Brutus XV
document_type: specification

These cases will immediately affect individuals only;
so that a series of determinations will probably take place before even the
people will be informed of them. In the mean time all the art and address of
those who wish for the change will be employed to make converts to their
opinion. The people will be told, that their state officers, and state
legislatures are a burden and expence without affording any solid advantage,
for that all the laws passed by them, might be equally well made by the general
legislature. If to those who will be interested in the change, be added, those
who will be under their influence, and such who will submit to almost any
change of government, which they can be persuaded to believe will ease them of
taxes, it is easy to see, the party who will favor the abolition of the state
governments would be far from being inconsiderable. — In this situation,
the general legislature, might pass one law after another, extending the
general and abridging the state jurisdictions, and to sanction their
proceedings would have a course of decisions of the judicial to whom the
constitution has committed the power of explaining the constitution. — If
the states remonstrated, the constitutional mode of deciding upon the validity
of the law, is with the supreme court, and neither people, nor state
legislatures, nor the general legislature can remove them or reverse their
decrees. Had the construction of the constitution been left with the legislature,
they would have explained it at their peril; if they exceed their powers, or
sought to find, in the spirit of the constitution, more than was expressed in
the letter, the people from whom they derived their power could remove them,
and do themselves right; and indeed I can see no other remedy that the people
can have against their rulers for encroachments of this nature.

--- chunk_id: chunk-0187
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 368
content_hash: 42d6e8ade1eb135e
prev_chunk_id: chunk-0186
next_chunk_id: chunk-0188
section_heading: Brutus XV
document_type: specification

— If
the states remonstrated, the constitutional mode of deciding upon the validity
of the law, is with the supreme court, and neither people, nor state
legislatures, nor the general legislature can remove them or reverse their
decrees. Had the construction of the constitution been left with the legislature,
they would have explained it at their peril; if they exceed their powers, or
sought to find, in the spirit of the constitution, more than was expressed in
the letter, the people from whom they derived their power could remove them,
and do themselves right; and indeed I can see no other remedy that the people
can have against their rulers for encroachments of this nature. A constitution
is a compact of a people with their rulers; if the rulers break the compact,
the people have a right and ought to remove them and do themselves justice; but
in order to enable them to do this with the greater facility, those whom the
people chuse at stated periods, should have the power in the last resort to
determine the sense of the compact; if they determine contrary to the
understanding of the people, an appeal will lie to the people at the period
when the rulers are to be elected, and they will have it in their power to
remedy the evil; but when this power is lodged in the hands of men independent
of the people, and of their representatives, and who are not, constitutionally,
accountable for their opinions, no way is left to controul them but with a
high hand and an outstretched arm. Brutus. Next | Previous | Text Version | Brutus
Contents |

--- chunk_id: chunk-0188
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 337
content_hash: 94c403f176dd464c
prev_chunk_id: chunk-0187
next_chunk_id: chunk-0189
section_heading: Brutus XVI
document_type: specification

## Brutus XVI

*Source file: brutus16.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Brutus #16



 

 XVI


 10 April 1788


When great and extraordinary powers are vested in any man, or body of men,
which in their exercise, may operate to the oppression of the people, it is of
high importance that powerful checks should be formed to prevent the abuse of
it. Perhaps no restraints are more forcible, than such as arise from
responsibility to some superior power. — Hence it is that the true policy
of a republican government is, to frame it in such manner, that all persons who
are concerned in the government, are made accountable to some superior for
their conduct in office. — This responsibility should ultimately rest with
the People. To have a government well administered in all its parts, it is
requisite the different departments of it should be separated and lodged as
much as may be in different hands. The legislative power should be in one body,
the executive in another, and the judicial in one different from either —
But still each of these bodies should be accountable for their conduct. Hence
it is impracticable, perhaps, to maintain a perfect distinction between these
several departments — For it is difficult, if not impossible, to call to
account the several officers in government, without in some degree mixing the
legislative and judicial. The legislature in a free republic are chosen by the
people at stated periods, and their responsibility consists, in their being
amenable to the people.

--- chunk_id: chunk-0189
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 440
content_hash: fb4634f0bf33580f
prev_chunk_id: chunk-0188
next_chunk_id: chunk-0190
section_heading: Brutus XVI
document_type: specification

Hence
it is impracticable, perhaps, to maintain a perfect distinction between these
several departments — For it is difficult, if not impossible, to call to
account the several officers in government, without in some degree mixing the
legislative and judicial. The legislature in a free republic are chosen by the
people at stated periods, and their responsibility consists, in their being
amenable to the people. When the term, for which they are chosen, shall expire,
who will then have opportunity to displace them if they disapprove of their
conduct — but it would be improper that the judicial should be elective,
because their business requires that they should possess a degree of law
knowledge, which is acquired only by a regular education, and besides it is fit
that they should be placed, in a certain degree in an independent situation,
that they may maintain firmness and steadiness in their decisions. As the
people therefore ought not to elect the judges, they cannot be amenable to them
immediately, some other mode of amenability must therefore be devised for
these, as well as for all other officers which do not spring from the immediate
choice of the people: this is to be effected by making one court subordinate to
another, and by giving them cognizance of the behaviour of all officers; but on
this plan we at last arrive at some supreme, over whom there is no power to
controul but the people themselves. This supreme controling power should be in
the choice of the people, or else you establish an authority independent, and
not amenable at all, which is repugnant to the principles of a free government. Agreeable to these principles I suppose the supreme judicial ought to be liable
to be called to account, for any misconduct, by some body of men, who depend
upon the people for their places; and so also should all other great officers
in the State, who are not made amenable to some superior officers.

--- chunk_id: chunk-0190
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 430
content_hash: 06ec9401b7eb9063
prev_chunk_id: chunk-0189
next_chunk_id: chunk-0191
section_heading: Brutus XVI
document_type: specification

This supreme controling power should be in
the choice of the people, or else you establish an authority independent, and
not amenable at all, which is repugnant to the principles of a free government. Agreeable to these principles I suppose the supreme judicial ought to be liable
to be called to account, for any misconduct, by some body of men, who depend
upon the people for their places; and so also should all other great officers
in the State, who are not made amenable to some superior officers. This policy
seems in some measure to have been in view of the framers of the new system,
and to have given rise to the institution of a court of impeachments — How
far this Court will be properly qualified to execute the trust which will be
reposed in them, will be the business of a future paper to investigate. To
prepare the way to do this, it shall be the business of this, to make some
remarks upon the constitution and powers of the Senate, with whom the power of
trying impeachments is lodged. The following things may be observed with respect to the constitution of the
Senate. 1st. They are to be elected by the legislatures of the States and not by the
people, and each State is to be represented by an equal number. 2d. They are to serve for six years, except that one third of those first
chosen are to go out of office at the expiration of two years, one third at the
expiration of four years, and one third at the expiration of six years, after
which this rotation is to be preserved, but still every member will serve for
the term of six years. 3d. If vacancies happen by resignation or otherwise, during the recess of
the legislature of any State, the executive is authorised to make temporary
appointments until the next meeting of the legislature. 4.

--- chunk_id: chunk-0191
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 410
content_hash: a38de163f074c39e
prev_chunk_id: chunk-0190
next_chunk_id: chunk-0192
section_heading: Brutus XVI
document_type: specification

If vacancies happen by resignation or otherwise, during the recess of
the legislature of any State, the executive is authorised to make temporary
appointments until the next meeting of the legislature. 4. No person can be a senator who has not arrived to the age of thirty
years, been nine years a citizen of the United States, and who is not at the
time he is elected an inhabitant of the State for which he is elected. The apportionment of members of Senate among the States is not according to
numbers, or the importance of the States; but is equal. This, on the plan of a
consolidated government, is unequal and improper; but is proper on the system
of confederation — on this principle I approve of it. It is indeed the
only feature of any importance in the constitution of a confederated
government. It was obtained after a vigorous struggle of that part of the
Convention who were in favor of preserving the state governments. It is to be
regretted, that they were not able to have infused other principles into the
plan, to have secured the government of the respective states, and to have
marked with sufficient precision the line between them and the general
government. The term for which the senate are to be chosen, is in my judgment too long,
and no provision being made for a rotation will, I conceive, be of dangerous
consequence. It is difficult to fix the precise period for which the senate should be
chosen. It is a matter of opinion, and our sentiments on the matter must be
formed, by attending to certain principles. Some of the duties which are to be
performed by the senate, seem evidently to point out the propriety of their
term of service being extended beyond the period of that of the assembly.

--- chunk_id: chunk-0192
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 444
content_hash: 919fffe9bed8c820
prev_chunk_id: chunk-0191
next_chunk_id: chunk-0193
section_heading: Brutus XVI
document_type: specification

It is a matter of opinion, and our sentiments on the matter must be
formed, by attending to certain principles. Some of the duties which are to be
performed by the senate, seem evidently to point out the propriety of their
term of service being extended beyond the period of that of the assembly. Besides as they are designed to represent the aristocracy of the country, it
seems fit they should possess more stability, and so continue a longer period
than that branch who represent the democracy. The business of making treaties
and some other which it will be proper to commit to the senate, requires that
they should have experience, and therefore that they should remain some time in
office to acquire it. — But still it is of equal importance that they
should not be so long in office as to be likely to forget the hand that formed
them, or be insensible of their interests. Men long in office are very apt to
feel themselves independent [and] to form and pursue interests separate from
those who appointed them. And this is more likely to be the case with the
senate, as they will for the most part of the time be absent from the state
they represent, and associate with such company as will possess very little of
the feelings of the middling class of people. For it is to be remembered that
there is to be a federal city, and the inhabitants of it will be the
great and the mighty of the earth. For these reasons I would shorten the term
of their service to four years. Six years is a long period for a man to be
absent from his home, it would have a tendency to wean him from his
constituents. A rotation in the senate, would also in my opinion be of great use. It is
probable that senators once chosen for a state will, as the system now stands,
continue in office for life.

--- chunk_id: chunk-0193
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 433
content_hash: c107a7ba698d6a55
prev_chunk_id: chunk-0192
next_chunk_id: chunk-0194
section_heading: Brutus XVI
document_type: specification

A rotation in the senate, would also in my opinion be of great use. It is
probable that senators once chosen for a state will, as the system now stands,
continue in office for life. The office will be honorable if not lucrative. The
persons who occupy it will probably wish to continue in it, and therefore use
all their influence and that of their friends to continue in office. —
Their friends will be numerous and powerful, for they will have it in their
power to confer great favors; besides it will before long be considered as
disgraceful not to be re-elected. It will therefore be considered as a matter
of delicacy to the character of the senator not to return him again. —
Every body acquainted with public affairs knows how difficult it is to remove
from office a person who is [has?] long been in it. It is seldom done except in
cases of gross misconduct. It is rare that want of competent ability procures
it. To prevent this inconvenience I conceive it would be wise to determine,
that a senator should not be eligible after he had served for the period
assigned by the constitution for a certain number of years; perhaps three would
be sufficient. A farther benefit would be derived from such an arrangement; it
would give opportunity to bring forward a greater number of men to serve their
country, and would return those, who had served, to their state, and afford
them the advantage of becoming better acquainted with the condition and
politics of their constituents. It farther appears to me proper, that the
legislatures should retain the right which they now hold under the
confederation, of recalling their members. It seems an evident dictate of
reason, that when a person authorises another to do a piece of business for
him, he should retain the power to displace him, when he does not conduct
according to his pleasure.

--- chunk_id: chunk-0194
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 450
content_hash: 0b095712c3a0311e
prev_chunk_id: chunk-0193
next_chunk_id: chunk-0195
section_heading: Brutus XVI
document_type: specification

It farther appears to me proper, that the
legislatures should retain the right which they now hold under the
confederation, of recalling their members. It seems an evident dictate of
reason, that when a person authorises another to do a piece of business for
him, he should retain the power to displace him, when he does not conduct
according to his pleasure. This power in the state legislatures, under
confederation, has not been exercised to the injury of the government, nor do I
see any danger of its being so exercised under the new system. It may operate
much to the public benefit. These brief remarks are all I shall make on the organization of the senate. The powers with which they are invested will require a more minute
investigation. This body will possess a strange mixture of legislative, executive and
judicial powers, which in my opinion will in some cases clash with each other. 1. They are one branch of the legislature, and in this respect will possess
equal powers in all cases with the house of representatives; for I consider the
clause which gives the house of representatives the right of originating bills
for raising a revenue as merely nominal, seeing the senate be authorised to
propose or concur with amendments. 2. They are a branch of the executive in the appointment of ambassadors and
public ministers, and in the appointment of all other officers, not otherwise
provided for; whether the forming of treaties, in which they are joined with
the president, appertains to the legislative or the executive part of the
government, or to neither, is not material. 3. They are part of the judicial, for they form the court of impeachments. It has been a long established maxim, that the legislative, executive and
judicial departments in government should be kept distinct. It is said, I know,
that this cannot be done. And therefore that this maxim is not just, or at
least that it should only extend to certain leading features in a government.

--- chunk_id: chunk-0195
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 354
content_hash: e6bf5fbb763a2392
prev_chunk_id: chunk-0194
next_chunk_id: chunk-0196
section_heading: Brutus XVI
document_type: specification

It is said, I know,
that this cannot be done. And therefore that this maxim is not just, or at
least that it should only extend to certain leading features in a government. I
admit that this distinction cannot be perfectly preserved. In a due ballanced
government, it is perhaps absolutely necessary to give the executive qualified
legislative powers, and the legislative or a branch of them judicial powers in
the last resort. It may possibly also, in some special cases, be adviseable to
associate the legislature, or a branch of it, with the executive, in the
exercise of acts of great national importance. But still the maxim is a good
one, and a separation of these powers should be sought as far as is
practicable. I can scarcely imagine that any of the advocates of the system
will pretend, that it was necessary to accumulate all these powers in the
senate. There is a propriety in the senate's possessing legislative powers; this is
the principal end which should be held in view in their appointment. I need not
here repeat what has so often and ably been advanced on the subject of a
division of the legislative power into two branches — The arguments in
favor of it I think conclusive. But I think it equally evident, that a branch
of the legislature should not be invested with the power of appointing
officers. This power in the senate is very improperly lodged for a number of
reasons — These shall be detailed in a future number. Brutus. Previous | Text
Version | Brutus Contents |

--- chunk_id: chunk-0196
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 412
content_hash: 8e008a0c7763e1ef
prev_chunk_id: chunk-0195
next_chunk_id: chunk-0197
section_heading: Centinel I
document_type: specification

## Centinel I

*Source file: centin01.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Centinel #1
  
  
  
 

    
    
    "Centinel"


    
    Number 1


    
    October 5, 1787


    
    To the Freemen of Pennsylvania. Friends, Countrymen and Fellow Citizens,


    
    Permit one of yourselves to put you in mind of certain
      liberties and privileges secured to you by the
      constitution of this commonwealth, and to beg your serious
      attention to his uninterested opinion upon the plan of federal government
      submitted to your consideration, before you surrender these great and
      valuable privileges up forever. Your present frame of government, secures
      to you a right to hold yourselves, houses, papers and possessions free
      from search and seizure, and therefore warrants granted without oaths or
      affirmations first made, affording sufficient foundation for them, whereby
      any officer or messenger may be commanded or required to search your
      houses or seize your persons or property, not particularly described in
      such warrant, shall not be granted. Your constitution further provides "that
      in controversies respecting property, and in suits between man and man,
      the parties have a right to trial by jury, which ought to be held
      sacred." It also provides and declares. "that the people
      have a right of FREEDOM OF SPEECH, and of WRITING and PUBLISHING
      their sentiments, therefore THE FREEDOM OF THE PRESS OUGHT NOT TO
      BE RESTRAINED. " The constitution of Pennsylvania is yet in
      existence, as yet you have the right to freedom of speech,
      and of publishing your sentiments. How long those rights will
      appertain to you, you yourselves are called upon to say, whether your houses
      shall continue to be your castles; whether your papers,
      your persons and your property, are to be held sacred
      and free from general warrants, you are now to determine. Whether
      the trial by jury is to continue as your birth-right, the freemen
      of Pennsylvania, nay, of all America, are now called upon to declare.

--- chunk_id: chunk-0197
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 372
content_hash: f307e82909c8f4c2
prev_chunk_id: chunk-0196
next_chunk_id: chunk-0198
section_heading: Centinel I
document_type: specification

How long those rights will
      appertain to you, you yourselves are called upon to say, whether your houses
      shall continue to be your castles; whether your papers,
      your persons and your property, are to be held sacred
      and free from general warrants, you are now to determine. Whether
      the trial by jury is to continue as your birth-right, the freemen
      of Pennsylvania, nay, of all America, are now called upon to declare. Without presuming upon my own judgement, I cannot think
      it an unwarrantable presumption to offer my private opinion, and call upon
      others for their's, and if I use my pen with the boldness of a freeman, it
      is because I know that the liberty of the press yet remains
      unviolated, and juries yet are judges. The late convention have submitted to your
      consideration a plan of a new federal government — The subject is highly
      interesting to your future welfare — Whether it be calculated to promote the
      great ends of civil society, viz. the happiness and prosperity of the
      community; it behoves you well to consider, uninfluenced by the authority
      of names. Instead of that frenzy of enthusiasm, that has actuated the
      citizens of Philadelphia, in their approbation of the proposed plan,
      before it was possible that it could be the result of a rational
      investigation into its principles; it ought to be dispassionately and
      deliberately examined, and its own intrinsic merit the only criterion of
      your patronage. If ever free and unbiased discussion was proper or
      necessary, it is on such an occasion. — All the blessings of liberty and the
      dearest privileges of freemen, are now at stake and dependent on your
      present conduct.

--- chunk_id: chunk-0198
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 376
content_hash: 547052b900346ab6
prev_chunk_id: chunk-0197
next_chunk_id: chunk-0199
section_heading: Centinel I
document_type: specification

If ever free and unbiased discussion was proper or
      necessary, it is on such an occasion. — All the blessings of liberty and the
      dearest privileges of freemen, are now at stake and dependent on your
      present conduct. Those who are competent to the task of developing the
      principles of government, ought to be encouraged to come forward, and
      thereby the better enable the people to make a proper judgment; for the
      science of government is so abstruse, that few are able to judge for
      themselves: without such assistance the people are too apt to yield an
      implicit assent to the opinions of those characters, whose abilities are
      held in the highest esteem, and to those in whose integrity and patriotism
      they can confide: not considering that the love of domination is generally
      in proportion to talents, abilities, and superior acquirements; and that
      the men of the greatest purity of intention may be made instruments of
      despotism in the hands of the artful and designing. If it were not
      for the stability and attachment which time and habit gives to forms of
      government it would be in the power of the enlightened and aspiring few,
      if they should combine, at any time to destroy the best establishments,
      and even make the people the instruments of their own subjugation. The late revolution having effaced in a great measure
      all former habits, and the present institutions are so recent, that there
      exists not that great reluctance to innovation, so remarkable in old
      communities, and which accords with reason, for the most comprehensive
      mind cannot foresee the full operation of material changes-on civil
      polity; it is the genius of the common law to resist innovation.

--- chunk_id: chunk-0199
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 442
content_hash: 8790ecbe6646e636
prev_chunk_id: chunk-0198
next_chunk_id: chunk-0200
section_heading: Centinel I
document_type: specification

If it were not
      for the stability and attachment which time and habit gives to forms of
      government it would be in the power of the enlightened and aspiring few,
      if they should combine, at any time to destroy the best establishments,
      and even make the people the instruments of their own subjugation. The late revolution having effaced in a great measure
      all former habits, and the present institutions are so recent, that there
      exists not that great reluctance to innovation, so remarkable in old
      communities, and which accords with reason, for the most comprehensive
      mind cannot foresee the full operation of material changes-on civil
      polity; it is the genius of the common law to resist innovation. The wealthy and ambitious, who in every community think
      they have a right to lord it over their fellow creatures, have availed
      themselves, very successfully, of this favorable disposition; for the
      people thus unsettled in their sentiments, have been prepared to accede to
      any extreme of government; all the distresses and difficulties they
      experience, proceeding from various causes, have been ascribed to the
      impotency of the present confederation, and thence they have been led to
      expect full relief from the adoption of the proposed system of government,
      and in the other event, immediately ruin and annihilation as a nation. These characters flatter themselves that they have lulled all distrust and
      jealousy of their new plan, by gaining the concurrence of the two men in
      whom America has the highest confidence, and now triumphantly exult in the
      completion of their long meditated schemes of power and aggrandisement. I
      would be very far from insinuating that the two illustrious personages
      alluded to, have not the welfare of their country at heart, but that the
      unsuspecting goodness and zeal of the one, has been imposed on, in a
      subject of which he must be necessarily inexperienced, from his other
      arduous engagements; and that the weakness and indecision attendant on old
      age, has been practiced on in the other.

--- chunk_id: chunk-0200
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 405
content_hash: abb7897f5ca36899
prev_chunk_id: chunk-0199
next_chunk_id: chunk-0201
section_heading: Centinel I
document_type: specification

These characters flatter themselves that they have lulled all distrust and
      jealousy of their new plan, by gaining the concurrence of the two men in
      whom America has the highest confidence, and now triumphantly exult in the
      completion of their long meditated schemes of power and aggrandisement. I
      would be very far from insinuating that the two illustrious personages
      alluded to, have not the welfare of their country at heart, but that the
      unsuspecting goodness and zeal of the one, has been imposed on, in a
      subject of which he must be necessarily inexperienced, from his other
      arduous engagements; and that the weakness and indecision attendant on old
      age, has been practiced on in the other. I am fearful that the principles of government
      inculcated in Mr. Adams's treatise, and enforced in the numerous essays
      and paragraphs in the newspapers, have misled some well designing members
      of the late Convention. — But it will appear in the sequel, that the
      construction of the proposed plan of government is infinitely more
      extravagant. I have been anxiously expecting that some enlightened
      patriot would, ere this, have taken up the pen to expose the futility, and
      counteract the baneful tendency of such principles. Mr. Adams's sine
      qua non of a good government is three balancing powers, whose
      repelling qualities are to produce an equilibrium of interests, and
      thereby promote the happiness of the whole community. He asserts that the
      administrators of every government, will ever be actuated by views of
      private interest and ambition, to the prejudice of the public good; that
      therefore the only effectual method to secure the rights of the people and
      promote their welfare, is to create an opposition of interests between the
      members of two distinct bodies, in the exercise of the powers of
      government, and balanced by those of a third.

--- chunk_id: chunk-0201
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 404
content_hash: 34bd9219e10b2ec5
prev_chunk_id: chunk-0200
next_chunk_id: chunk-0202
section_heading: Centinel I
document_type: specification

Adams's sine
      qua non of a good government is three balancing powers, whose
      repelling qualities are to produce an equilibrium of interests, and
      thereby promote the happiness of the whole community. He asserts that the
      administrators of every government, will ever be actuated by views of
      private interest and ambition, to the prejudice of the public good; that
      therefore the only effectual method to secure the rights of the people and
      promote their welfare, is to create an opposition of interests between the
      members of two distinct bodies, in the exercise of the powers of
      government, and balanced by those of a third. This hypothesis supposes
      human wisdom competent to the task of instituting three co-equal orders in
      government, and a corresponding weight in the community to enable them
      respectively to exercise their several parts, and whose views and
      interests should be so distinct as to prevent a coalition of any two of
      them for the destruction of the third. Mr. Adams, although he has traced
      the constitution of every form of government that ever existed, as far as
      history affords materials, has not been able to adduce a single instance
      of such a government; he indeed says that the British constitution is such
      in theory, but this is rather a confirmation that his principles are
      chimerical and not to be reduced to practice. If such an organization of
      power were practicable, how long would it continue? not a day — for there is
      so great a disparity in the talents, wisdom and industry of mankind, that
      the scale would presently preponderate to one or the other body, and with
      every accession of power the means of further increase would be greatly
      extended. The state of society in England is much more favorable to such a
      scheme of government than that of America.

--- chunk_id: chunk-0202
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 396
content_hash: 2e3f80d15af89ee0
prev_chunk_id: chunk-0201
next_chunk_id: chunk-0203
section_heading: Centinel I
document_type: specification

not a day — for there is
      so great a disparity in the talents, wisdom and industry of mankind, that
      the scale would presently preponderate to one or the other body, and with
      every accession of power the means of further increase would be greatly
      extended. The state of society in England is much more favorable to such a
      scheme of government than that of America. There they have a powerful
      hereditary nobility, and real distinctions of rank and interests; but even
      there, for want of that perfect equallity of power and distinction of
      interests, in the three orders of government, they exist but in name; the
      only operative and efficient check, upon the conduct of administration, is
      the sense of the people at large. Suppose a government could be formed and supported on
      such principles, would it answer the great purposes of civil society; if
      the administrators of every government are actuated by views of private
      interest and ambition, how is the welfare and happiness of the community
      to be the result of such jarring adverse interests? Therefore, as different orders in government will not
      produce the good of the whole, we must recur to other principles. I
      believe it will be found that the form of government, which holds those
      entrusted with power, in the greatest responsibility to their
      constituents, the best calculated for freemen. A republican, or free
      government, can only exist where the body of the people are virtuous, and
      where property is pretty equally divided; in such a government the people
      are the sovereign and their sense or opinion is the criterion of every
      public measure; for when this ceases to be the case, the nature of the
      government is changed, and an aristocracy, monarchy or despotism will rise
      on its ruin.

--- chunk_id: chunk-0203
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 401
content_hash: 5449906170d55152
prev_chunk_id: chunk-0202
next_chunk_id: chunk-0204
section_heading: Centinel I
document_type: specification

I
      believe it will be found that the form of government, which holds those
      entrusted with power, in the greatest responsibility to their
      constituents, the best calculated for freemen. A republican, or free
      government, can only exist where the body of the people are virtuous, and
      where property is pretty equally divided; in such a government the people
      are the sovereign and their sense or opinion is the criterion of every
      public measure; for when this ceases to be the case, the nature of the
      government is changed, and an aristocracy, monarchy or despotism will rise
      on its ruin. The highest responsibility is to be attained, in a simple
      structure of government, for the great body of the people never steadily
      attend to the operations of government, and for want of due information
      are liable to be imposed on — If you complicate the plan by various orders,
      the people will be perplexed and divided in their sentiments about the
      source of abuses or misconduct, some will impute it to the senate, others
      to the house of representatives, and so on, that the interposition of the
      people may be rendered imperfect or perhaps wholly abortive. But if,
      imitating the constitution of Pennsylvania, you vest all the legislative
      power in one body of men (separating the executive and judicial) elected
      for a short period, and necessarily excluded by rotation from permanency,
      and guarded from precipitancy and surprise by delays imposed on its
      proceedings, you will create the most perfect responsibility for then,
      whenever the people feel a grievance they cannot mistake the authors, and
      will apply the remedy with certainty and effect, discarding them at the
      next election. This tie of responsibility will obviate all the dangers
      apprehended from a single legislature, and will the best secure the rights
      of the people.

--- chunk_id: chunk-0204
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 373
content_hash: 9347da47cd776615
prev_chunk_id: chunk-0203
next_chunk_id: chunk-0205
section_heading: Centinel I
document_type: specification

But if,
      imitating the constitution of Pennsylvania, you vest all the legislative
      power in one body of men (separating the executive and judicial) elected
      for a short period, and necessarily excluded by rotation from permanency,
      and guarded from precipitancy and surprise by delays imposed on its
      proceedings, you will create the most perfect responsibility for then,
      whenever the people feel a grievance they cannot mistake the authors, and
      will apply the remedy with certainty and effect, discarding them at the
      next election. This tie of responsibility will obviate all the dangers
      apprehended from a single legislature, and will the best secure the rights
      of the people. Having premised this much, I shall now proceed to the
      examination of the proposed plan of government, and I trust, shall make it
      appear to the meanest capacity, that it has none of the essential
      requisites of a free government; that it is neither founded on those
      balancing restraining powers, recommended by Mr. Adams and attempted in
      the British constitution, or possessed of that responsibility to its
      constituents, which, in my opinion, is the only effectual security for the
      liberties and happiness of the people; but on the contrary, that it is a
      most daring attempt to establish a despotic aristocracy among freemen,
      that the world has ever witnessed. I shall previously consider the extent of the powers
      intended to be vested in Congress, before I examine the construction of
      the general government. It will not be controverted that the legislative is the
      highest delegated power in government, and that all others are subordinate
      to it. The celebrated Montesquieu establishes it as a maxim, that
      legislation necessarily follows the power of taxation. By sect.

--- chunk_id: chunk-0205
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 317
content_hash: 0fa5045e62b72cc8
prev_chunk_id: chunk-0204
next_chunk_id: chunk-0206
section_heading: Centinel I
document_type: specification

The celebrated Montesquieu establishes it as a maxim, that
      legislation necessarily follows the power of taxation. By sect. 8, of the
      first article of the proposed plan of government, "the Congress are
      to have power to lay and collect taxes, duties, imposts and excises, to
      pay the debts and provide for the common defence and general welfare
      of the United States, but all duties, imposts and excises, shall be
      uniform throughout the United States." Now what can be more
      comprehensive than these words; not content by other sections of this
      plan, to grant all the great executive powers of a confederation, and a
      STANDING ARMY IN TIME OF PEACE, that grand engine of oppression, and
      moreover the absolute control over the commerce of the United States and
      all external objects of revenue, such as unlimited imposts upon imports,
      etc. — they are to be vested with every species of internal taxation; — whatever
      taxes, duties and excises that they may deem requisite for the general
      welfare, may be imposed on the citizens of these states, levied by the
      officers of Congress, distributed through every district in America; and
      the collection would be enforced by the standing army, however grievous or
      improper they may be. The Congress may construe every purpose for which
      the state legislatures now lay taxes, to be for the general welfare,
      and thereby seize upon every object of revenue. The judicial power by 1st sect.

--- chunk_id: chunk-0206
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 361
content_hash: 32281c2836d4be5b
prev_chunk_id: chunk-0205
next_chunk_id: chunk-0207
section_heading: Centinel I
document_type: specification

The Congress may construe every purpose for which
      the state legislatures now lay taxes, to be for the general welfare,
      and thereby seize upon every object of revenue. The judicial power by 1st sect. of article 3 "shall
      extend to all cases, in law and equity, arising under this constitution,
      the laws of the United States, and treaties made or which shall be made
      under their authority; to all cases affecting ambassadors, other public
      ministers and consuls; to all cases of admirality and maritime
      jurisdiction, to controversies to which the United States shall be a
      party, to controversies between two or more states, between a state and
      citizens of another state, between citizens of different states, between
      citizens of the same state claiming lands under grants of different
      states, and between a state, or the citizens thereof, and foreign states,
      citizens or subjects."


    
     The judicial power to be vested in one Supreme Court,
      and in such Inferior Courts as the Congress may from time to time ordain
      and establish. The objects of jurisdiction recited above, are so
      numerous, and the shades of distinction between civil causes are
      oftentimes so slight, that it is more than probable that the state
      judicatories would be wholly superceded; for in contests about
      jurisdiction, the federal court, as the most powerful, would ever prevail. Every person acquainted with The history of the courts in England, knows
      by what ingenious sophisms they have, at different periods, extended the
      sphere of Their jurisdiction over objects out of the line of their
      institution, and contrary to their very nature; courts of a criminal
      jurisdiction obtaining cognizance in civil causes.

--- chunk_id: chunk-0207
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 364
content_hash: 889ab3ca6fc52dc7
prev_chunk_id: chunk-0206
next_chunk_id: chunk-0208
section_heading: Centinel I
document_type: specification

The objects of jurisdiction recited above, are so
      numerous, and the shades of distinction between civil causes are
      oftentimes so slight, that it is more than probable that the state
      judicatories would be wholly superceded; for in contests about
      jurisdiction, the federal court, as the most powerful, would ever prevail. Every person acquainted with The history of the courts in England, knows
      by what ingenious sophisms they have, at different periods, extended the
      sphere of Their jurisdiction over objects out of the line of their
      institution, and contrary to their very nature; courts of a criminal
      jurisdiction obtaining cognizance in civil causes. To put the omnipotency of Congress over the state
      government and judicatories out of all doubt, the 6th article ordains that
      "this constitution and the laws of the United States which shall be
      made in pursuance thereof, and all treaties made, or which shall be made
      under the authority of the United States, shall be thesupreme law of
      the land, and the judges in every state shall be bound thereby, any
      thing in the constitution or laws of any state to the contrary
      notwithstanding."


    
     By these sections the all-prevailing power of taxation,
      and such extensive legislative and judicial powers are vested in the
      general government, as must in their operation, necessarily absorb the
      state legislatures and judicatories; and that such was in the
      contemplation of the framers of it, will appear from the provision made
      for such event, in another part of it; (but that, fearful of alarming the
      people by so great an innovation, they have suffered the forms of the
      separate governments to remain, as a blind.) By sect.

--- chunk_id: chunk-0208
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 409
content_hash: 5593540754c63d6d
prev_chunk_id: chunk-0207
next_chunk_id: chunk-0209
section_heading: Centinel I
document_type: specification

Every person acquainted with The history of the courts in England, knows
      by what ingenious sophisms they have, at different periods, extended the
      sphere of Their jurisdiction over objects out of the line of their
      institution, and contrary to their very nature; courts of a criminal
      jurisdiction obtaining cognizance in civil causes. To put the omnipotency of Congress over the state
      government and judicatories out of all doubt, the 6th article ordains that
      "this constitution and the laws of the United States which shall be
      made in pursuance thereof, and all treaties made, or which shall be made
      under the authority of the United States, shall be thesupreme law of
      the land, and the judges in every state shall be bound thereby, any
      thing in the constitution or laws of any state to the contrary
      notwithstanding."


    
     By these sections the all-prevailing power of taxation,
      and such extensive legislative and judicial powers are vested in the
      general government, as must in their operation, necessarily absorb the
      state legislatures and judicatories; and that such was in the
      contemplation of the framers of it, will appear from the provision made
      for such event, in another part of it; (but that, fearful of alarming the
      people by so great an innovation, they have suffered the forms of the
      separate governments to remain, as a blind.) By sect. 4th of the 1st
      article, "the times, places and manner of holding elections for
      senators and representatives, shall be prescribed in each state by the
      legislature thereof; but the Congress may at any time, by law,
      make or alter such regulations, except as to the place of chusing
      senators." The plain construction of which is, that when the
      state legislatures drop out of sight, from the necessary operation this
      government, then Congress are to provide for the election and appointment
      of representatives and senators.

--- chunk_id: chunk-0209
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 404
content_hash: ef5c14318b7532d1
prev_chunk_id: chunk-0208
next_chunk_id: chunk-0210
section_heading: Centinel I
document_type: specification

To put the omnipotency of Congress over the state
      government and judicatories out of all doubt, the 6th article ordains that
      "this constitution and the laws of the United States which shall be
      made in pursuance thereof, and all treaties made, or which shall be made
      under the authority of the United States, shall be thesupreme law of
      the land, and the judges in every state shall be bound thereby, any
      thing in the constitution or laws of any state to the contrary
      notwithstanding."


    
     By these sections the all-prevailing power of taxation,
      and such extensive legislative and judicial powers are vested in the
      general government, as must in their operation, necessarily absorb the
      state legislatures and judicatories; and that such was in the
      contemplation of the framers of it, will appear from the provision made
      for such event, in another part of it; (but that, fearful of alarming the
      people by so great an innovation, they have suffered the forms of the
      separate governments to remain, as a blind.) By sect. 4th of the 1st
      article, "the times, places and manner of holding elections for
      senators and representatives, shall be prescribed in each state by the
      legislature thereof; but the Congress may at any time, by law,
      make or alter such regulations, except as to the place of chusing
      senators." The plain construction of which is, that when the
      state legislatures drop out of sight, from the necessary operation this
      government, then Congress are to provide for the election and appointment
      of representatives and senators. If the foregoing be a just comment — if the United States
      are to be melted down into one empire, it becomes you to consider, whether
      such a government, however constructed, would be eligible in so extended a
      territory; and whether it would be practicable, consistent with freedom?

--- chunk_id: chunk-0210
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 390
content_hash: 43d0e8e1980035a7
prev_chunk_id: chunk-0209
next_chunk_id: chunk-0211
section_heading: Centinel I
document_type: specification

4th of the 1st
      article, "the times, places and manner of holding elections for
      senators and representatives, shall be prescribed in each state by the
      legislature thereof; but the Congress may at any time, by law,
      make or alter such regulations, except as to the place of chusing
      senators." The plain construction of which is, that when the
      state legislatures drop out of sight, from the necessary operation this
      government, then Congress are to provide for the election and appointment
      of representatives and senators. If the foregoing be a just comment — if the United States
      are to be melted down into one empire, it becomes you to consider, whether
      such a government, however constructed, would be eligible in so extended a
      territory; and whether it would be practicable, consistent with freedom? It is the opinion of the greatest writers, that a very extensive country
      cannot be governed on democratical principles, on any other plan, than a
      confederation of a number of small republics, possessing all the powers of
      internal government, but united in the management of their foreign and
      general concerns. It would not be difficult to prove, that any thing
      short of despotism, could not bind so great a country under one
      government; and that whatever plan you might, at the first setting out,
      establish, it would issue in a despotism. If one general government could be instituted and
      maintained on principles of freedom, it would not be so competent to
      attend to the various local concerns and wants, of every particular
      district, as well as the peculiar governments, who are nearer the scene,
      and possessed of superior means of information, besides, if the business
      of the whole union is to be managed by one government, there would
      not be time.

--- chunk_id: chunk-0211
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 417
content_hash: cfaa02968d268425
prev_chunk_id: chunk-0210
next_chunk_id: chunk-0212
section_heading: Centinel I
document_type: specification

It would not be difficult to prove, that any thing
      short of despotism, could not bind so great a country under one
      government; and that whatever plan you might, at the first setting out,
      establish, it would issue in a despotism. If one general government could be instituted and
      maintained on principles of freedom, it would not be so competent to
      attend to the various local concerns and wants, of every particular
      district, as well as the peculiar governments, who are nearer the scene,
      and possessed of superior means of information, besides, if the business
      of the whole union is to be managed by one government, there would
      not be time. Do we not already see, that the inhabitants in a number of
      larger states, who are remote from the seat of government, are loudly
      complaining of the inconveniencies and disadvantages they are subjected to
      on this account, and that, to enjoy the comforts of local government, they
      are separating into smaller divisions. Having taken a review of the powers, I shall now
      examine the construction of the proposed general government. Art. 1. Sect. 1. "All legislative powers herein
      granted shall be vested in a Congress of the United States, which shall
      consist of a senate and house of representatives." By another
      section? the president (the principal executive officer) has a conditional
      control over their proceedings. Sect. 2. "The house of representatives shall be
      composed of members chosen every second year, by the people of the several
      states. The number of representatives shall not exceed one for every
      30,000 inhabitants."


    
     The senate, the other constituent branch of the
      legislature, is formed by the legislature of each state appointing two
      senators, for the term of six years. The executive power by Art. 2, Sect. 1. is to be vested
      in a president of the United States of America, elected for four years:
      Sect. 2.

--- chunk_id: chunk-0212
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 393
content_hash: 55fbcd0b52306a1e
prev_chunk_id: chunk-0211
next_chunk_id: chunk-0213
section_heading: Centinel I
document_type: specification

is to be vested
      in a president of the United States of America, elected for four years:
      Sect. 2. gives him "power, by and with the consent of the senate to
      make treaties, provided two thirds of the senators present concur; and he
      shall nominate, and by and with the advice and consent of the senate,
      shall appoint ambassadors, other public ministers and consuls, judges of
      the Supreme Court, and all other officers of the United States, whose
      appointments are not herein otherwise provided for, and which shall be
      established by law," etc. And by another section he has the absolute
      power of granting reprieves and pardons for treason and all other high
      crimes and misdemeanors, except in case of impeachment. The foregoing are the outlines of the plan. Thus we see, the house of representatives, are on the
      part of the people to balance the senate, who I suppose will be composed
      of the better sort, the well born, etc. The number of the
      representatives (being only one for every 30,000 inhabitants) appears to
      be too few, either to communicate the requisite information, of the wants,
      local circumstances and sentiments of so extensive an empire, or to
      prevent corruption and undue influence, in the exercise of such great
      powers; the term for which they are to be chosen, too long to preserve a
      due dependence and accountability to their constituents; and the mode and
      places of their election not sufficiently ascertained, for as Congress
      have the control over both, they may govern the choice, by ordering the
      representatives of a whole state, to be elected in
      one place, and that too may be the most inconvenient. The senate, the great efficient body in this plan of
      government, is constituted on the most unequal principles.

--- chunk_id: chunk-0213
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 410
content_hash: cf2bf619747c71f4
prev_chunk_id: chunk-0212
next_chunk_id: chunk-0214
section_heading: Centinel I
document_type: specification

The number of the
      representatives (being only one for every 30,000 inhabitants) appears to
      be too few, either to communicate the requisite information, of the wants,
      local circumstances and sentiments of so extensive an empire, or to
      prevent corruption and undue influence, in the exercise of such great
      powers; the term for which they are to be chosen, too long to preserve a
      due dependence and accountability to their constituents; and the mode and
      places of their election not sufficiently ascertained, for as Congress
      have the control over both, they may govern the choice, by ordering the
      representatives of a whole state, to be elected in
      one place, and that too may be the most inconvenient. The senate, the great efficient body in this plan of
      government, is constituted on the most unequal principles. The smallest
      state in the union has equal weight with the great states of Virginia
      Massachusetts, or Pennsylvania — The Senate, besides its legislative
      functions, has a very considerable share in the Executive; none of the
      principal appointments to office can be made without its advice and
      consent. The term and mode of its appointment, will lead to permanency;
      the members are chosen for six years, the mode is under the control of
      Congress, and as there is no exclusion by rotation, they may be continued
      for life, which, from their extensive means of influence, would follow of
      course. The President, who would be a mere pageant of state, unless he
      coincides with the views of the Senate, would either become the head of
      the aristocratic junto in that body, or its minion, besides, their
      influence being the most predominant, could the best secure his
      re-election to office. And from his power of granting pardons, he might
      skreen from punishment the most treasonable attempts on liberties of the
      people, when instigated by the Senate.

--- chunk_id: chunk-0214
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 368
content_hash: 2b8043d7aebffca1
prev_chunk_id: chunk-0213
next_chunk_id: chunk-0215
section_heading: Centinel I
document_type: specification

The President, who would be a mere pageant of state, unless he
      coincides with the views of the Senate, would either become the head of
      the aristocratic junto in that body, or its minion, besides, their
      influence being the most predominant, could the best secure his
      re-election to office. And from his power of granting pardons, he might
      skreen from punishment the most treasonable attempts on liberties of the
      people, when instigated by the Senate. From this investigation into the organization of this
      government, it appears that it is devoid of all responsibility or
      accountability to the great body of the people, and that so far from being
      a regular balanced government, it would be in practice a permanent
      ARISTOCRACY. The framers of it, actuated by the true spirit of such
      a govermment, which ever abominates and suppresses all free enquiry and
      discussion, have made no provision for the liberty of the press that
      grand palladium of freedom, and scourge of tyrants, but
      observed a total silence on that head. It is the opinion of some great
      writers, that if the liberty of the press, by an institution of religion,
      or otherwise, could be rendered sacred, even in Turkey, that
      despotism would fly before it. And it is worthy of remark, that there is
      no declaration of personal rights, premised in most free constitutions;
      and that trial by jury in civil cases is taken away; for
      what other construction can be put on the following, viz. Article m. Sect. 2d. "In all cases affecting ambassadors, other public ministers and
      consuls, and those in which a State shall be party, the Supreme Court
      shall have original jurisdiction.

--- chunk_id: chunk-0215
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 445
content_hash: db9c9521d5ff5ded
prev_chunk_id: chunk-0214
next_chunk_id: chunk-0216
section_heading: Centinel I
document_type: specification

2d. "In all cases affecting ambassadors, other public ministers and
      consuls, and those in which a State shall be party, the Supreme Court
      shall have original jurisdiction. In all the other cases above mentioned,
      the Supreme Court shall have appellate jurisdiction, both as to
      law and fact?" It would be a novelty in jurisprudence, as
      well as evidently improper to allow an appeal from the verdict of a jury,
      on the matter of fact; therefore, it implies and allows of a dismission of
      the jury in civil cases, and especially when it is considered, that jury
      trial in criminal cases is expresly stipulated for, but not in civil
      cases. But our situation is represented to be so critically
      dreadful that, however reprehensible and exceptionable the proposed
      plan of government may be, there is no alternative, between the adoption
      of it and absolute ruin. — My fellow citizens, things are not at that
      crisis, it is the argument of tyrants; the present distracted state of
      Europe secures us from injury on that quarter, and as to domestic
      dissensions, we have not so much to fear from them, as to precipitate us
      into this form of government, without it is a safe and a proper one. For
      remember, of all possible evils that of despotism is the
      worst and the most to be dreaded. Besides, it cannot be supposed, that the first essay on
      so difficult a subject, is so well digested, as it ought to be, — if toe
      proposed plan, after a mature deliberation, should meet the approbation of
      the respective States, the matter will end, but if it should be found to
      be fraught with dangers and inconveniencies, a future general Convention
      being in possession of the objections, will be the better enabled to plan
      a suitable government. Who's here so base, that would a bondsman be? If any, speak; for
      him have I offended. Who's here so vile, that will not love his
      country? If any, speak; for him have I offended.

--- chunk_id: chunk-0216
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 34
content_hash: 7e1ddcc42f817231
prev_chunk_id: chunk-0215
next_chunk_id: chunk-0217
section_heading: Centinel I
document_type: specification

Who's here so vile, that will not love his
      country? If any, speak; for him have I offended. [Julius
      Caesar, Act 3, Scene 2 ]


    
     Centinel.

--- chunk_id: chunk-0217
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: 4610755e69c0cf36
prev_chunk_id: chunk-0216
next_chunk_id: chunk-0218
section_heading: Centinel II
document_type: specification

## Centinel II

*Source file: centin02.htm (constitution.org AFP collection)*

Anti-Federalist Papers: Centinel #2
  
  

 

    "Centinel"



      Number 2

      (Excerpt)

      October 24, 1787

    


    To the Freemen of Pennsylvania. Friends, Countrymen and Fellow Citizens,

    …



    Mr. [James] Wilson asserts that never was charge made with less
    reason, than that which predicts the institution of a baneful
    aristocracy in the federal Senate.' In my first number, I stated
    that this body would be a very unequal representation of the several
    States, that the members being appointed for the long term of six
    years, and there being no exclusion by rotation, they might be
    continued for life, which would follow of course from their
    extensive means of influence, and that possessing a considerable
    share in the executive as well as the legislative, it would become a
    permanent aristocracy, and swallow up the other orders in the
    government. That these fears are not imaginary, a knowledge of the history of
    other nations, where the powers of government have been
    injudiciously placed, will fully demonstrate. Mr. Wilson says, "the
    senate branches into two characters; the one legislative and the
    other executive. In its legislative character it can effect no
    purpose, without the co-operation of the house of representatives,
    and in its executive character it can accomplish no object without
    the concurrence of the president. Thus fettered, I do not know any
    act which the senate can of itself perform, and such dependence
    necessarily precludes every idea of influence and superiority." This
    I confess is very specious, but experience demonstrates that checks
    in government, unless accompanied with adequate power and
    independently placed, prove merely nominal, and will be inoperative. Is it probable, that the President of the United States, limited as
    he is in power, and dependent on the will of the senate, in
    appointments to office, will either have the firmness or inclination
    to exercise his prerogative of a conditional control upon the
    proceedings of that body, however injurious they may be to the
    public welfare?

--- chunk_id: chunk-0218
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 428
content_hash: 81358a30163f111b
prev_chunk_id: chunk-0217
next_chunk_id: chunk-0219
section_heading: Centinel II
document_type: specification

Thus fettered, I do not know any
    act which the senate can of itself perform, and such dependence
    necessarily precludes every idea of influence and superiority." This
    I confess is very specious, but experience demonstrates that checks
    in government, unless accompanied with adequate power and
    independently placed, prove merely nominal, and will be inoperative. Is it probable, that the President of the United States, limited as
    he is in power, and dependent on the will of the senate, in
    appointments to office, will either have the firmness or inclination
    to exercise his prerogative of a conditional control upon the
    proceedings of that body, however injurious they may be to the
    public welfare? It will be his interest to coincide with the views
    of the senate, and thus become the head of the aristocratic junto. The king of England is a constituent part in the legislature, but
    although an hereditary monarch, in possession of the whole executive
    power, including the unrestrained appointment to offices, and an
    immense revenue, enjoys but in name the prerogative of a negative
    upon the parliament. Even the king of England, circumstanced as he
    is, has not dared to exercise it for near a century past. The check
    of the house of representatives upon the senate will likewise be
    rendered nugatory for want of due weight in the democratic branch,
    and from their constitution they may become so independent of the
    people as to be indifferent of its interests. Nay, as Congress would
    have the control over the mode and place of their election, by
    ordering the representatives of a whole state to be elected at one
    place, and that too the most inconvenient, the ruling powers may
    govern the choice, and thus the house of representatives may be
    composed of the creatures of the senate. Still the semblance of
    checks may remain, but without operation. This mixture of the legislative and executive moreover highly tends
    to corruption.

--- chunk_id: chunk-0219
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 138
content_hash: e08c07b4d74aee35
prev_chunk_id: chunk-0218
next_chunk_id: chunk-0220
section_heading: Centinel II
document_type: specification

Still the semblance of
    checks may remain, but without operation. This mixture of the legislative and executive moreover highly tends
    to corruption. The chief improvement in government, in modern times,
    has been the complete separation of the great distinctions of power;
    placing the legislative in different hands from those which hold the
    executive; and again severing the judicial part from the ordinary
    administrative. "When the legislative and executive powers (says
    Montesquieu) are united in the same person or in the same body of
    magistrates, there can be no liberty."

    Storing, Herbert J., ed. The Complete
    Anti-Federalist. 7 vols. Chicago: University of Chicago Press, 1981.

--- chunk_id: chunk-0220
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 2386
content_hash: 9bbc44eefba6b816
prev_chunk_id: chunk-0219
next_chunk_id: chunk-0221
section_heading: Cato V
document_type: specification

## Cato V

*Source file: cato_05.htm (constitution.org AFP collection)*

Anti-Federalist Papers: "Cato" #5
  
  
  
 

    
    
    "Cato"


    Letter V


    The New-York Journal, November 22, 1787


    
    To the Citizens of the State of New York.


    
    In my last number I endeavored to prove that the
      language of the article relative to the establishment of the executive of
      this new government was vague and inexplicit, that the great powers of the
      President, connected with his duration in office would lead to oppression
      and ruin. That he would be governed by favorites and flatterers, or that a
      dangerous council would be collected from the great officers of state, --
      that the ten miles square, if the remarks of one of the wisest men, drawn
      from the experience of mankind, may be credited, would be the asylum of
      the base, idle, avaricious and ambitious, and that the court would possess
      a language and manners different from yours; that a vice president is as
      unnecessary, as he is dangerous in his influence -- that the president
      cannot represent you because he is not of your own immediate choice, that
      if you adopt this government, you will incline to an arbitrary and odious
      aristocracy or monarchy the that the president possessed of the power,
      given him by this frame of government differs but very immaterially from
      the establishment of monarchy in Great Britain, and I warned you to beware
      of the fallacious resemblance that is held out to you by the advocates of
      this new system between it and your own state governments.


    
    And here I cannot help remarking, that inexplicitness
      seems to pervade this whole political fabric: certainty in political
      compacts, which Mr. Coke calls the mother and nurse of repose and
      quietness, the want of which induced men to engage in political
      society, has ever been held by a wise and free people as essential to
      their security; as, on the one hand it fixes barriers which the ambitious
      and tyrannically disposed magistrate dare not overleap, and on the other,
      becomes a wall of safety to the community -- otherwise stipulations
      between the governors and governed are nugatory; and you might as well
      deposit the important powers of legislation and execution in one or a few
      and permit them to govern according to their disposition and will; but the
      world is too full of examples, which prove that to live by one man's
      will became the cause of all men's misery. Before the existence of
      express political compacts it was reasonably implied that the magistrate
      should govern with wisdom and Justice, but mere implication was too feeble
      to restrain the unbridled ambition of a bad man, or afford security
      against negligence, cruelty, or any other defect of mind. It is alledged
      that the opinions and manners of the people of America, are capable to
      resist and prevent an extension of prerogative or oppression; but you must
      recollect that opinion and manners are mutable, and may not always be a
      permanent obstruction against the encroachments of government; that the
      progress of a commercial society begets luxury, the parent of inequality,
      the foe to virtue, and the enemy to restraint; and that ambition and
      voluptuousness aided by flattery, will teach magistrates, where limits are
      not explicitly fixed to have separate and distinct interests from the
      people, besides it will not be denied that government assimilates the
      manners and opinions of the community to it. Therefore, a general
      presumption that rulers will govern well is not a sufficient security. --
      You are then under a sacred obligation to provide for the safety of your
      posterity, and would you now basely desert their interests, when by a
      small share of prudence you may transmit to them a beautiful political
      patrimony, that will prevent the necessity of their travelling through
      seas of blood to obtain that, which your wisdom might have secured: -- It
      is a duty you owe likewise to your own reputation, for you have a great
      name to lose; you are characterised as cautious, prudent and jealous in
      politics; whence is it therefore, that you are about to precipitate
      yourselves into a sea of uncertainty, and adopt a system so vague, and
      which has discarded so many of your valuable rights. -- Is it because you
      do not believe that an American can be a tyrant? If this be the case you
      rest on a weak basis; Americans are like other men in similar situations,
      when the manners and opinions of the community are changed by the causes I
      mentioned before, and your political compact inexplicit, your posterity
      will find that great power connected with ambition, luxury, and flattery,
      will as readily produce a Caesar, Caligula, Nero, and Domitian in America,
      as the same causes did in the Roman empire.


    
     But the next thing to be considered in conformity to my
      plan, is the first article of this new government, which comprises the
      erection of the house of representatives and senate, and prescribes their
      various powers and objects of legislation. The most general objections to
      the first article, are that biennial elections for representatives are a
      departure from the safe democratical principles- of annual ones -- that
      the number of representatives are too few; that the apportionment and
      principles of increase are unjust; that no attention has been paid to
      either the numbers or property in each state in forming the senate; that
      the mode in which they are appointed and their duration, will lead to the
      establishment of an aristocracy; that the senate and president are
      improperly connected, both as to appointments, and the making of treaties,
      which are to become the supreme law of the land; that the judicial in some
      measure, to-wit, as to the trial of impeachments, is placed in the senate,
      a branch of the legislative, and some times a branch of the executive:
      that Congress have the improper power of making or altering the
      regulations prescribed by the different legislatures, respecting the time,
      place, and manner of holding elections for representatives, and the time
      and manner of choosing senators; that standing armies may be established,
      and appropriation of money made for their support for two years; that the
      militia of the most remote state may be marched into those states situated
      at the opposite extreme of this continent; that the slave trade is, to all
      intents and purposes permanently established; and a slavish capitation, or
      poll-tax, may at any time be levied -- these are some of the many evils
      that will attend the adoption of this government.


    
    But with respect to the first objection, it may be
      remarked that a well digested democracy has this advantage over all
      others, to wit, that it affords to many the opportunity to be advanced to
      the supreme command, and the honors they thereby enjoy fill them with a
      desire of rendering themselves worthy of them; hence this desire becomes
      part of their education, is matured m manhood, and produces an ardent
      affection for their country, and it is the opinion of the great Sidney,
      and Montesquieu that this is in a great measure produced by annual
      election of magistrates.


    
    If annual elections were to exist in this government,
      and learning and information to become more prevalent, you never will want
      men to execute whatever you could design -- Sidney observes "that a
      well governed state is as fruitful to all good purposes as the seven
      headed serpent is said to have been in evil; when one head is cut off,
      many rise up in the place of it." He remarks further, that "it
      was also thought, that free cities by frequent elections of magistrates
      became nurseries of great and able men, every man endeavoring to excel
      others, that he might be advanced to the honor he had no other title to,
      than what might arise from his merit, or reputation," but the framers
      of this perfect government, as it is called, have departed from
      this democratical principle, and established bi-ennial elections for the
      house of representatives, who are to be chosen by the people, and
      sextennial for the senate, who are to be chosen by the legislatures of the
      different states, and have given to the executive the unprecedented power
      of making temporary senators, in case of vacancies, by resignation or
      otherwise, and so far forth establishing a precedent for virtual
      representation (though in fact their original appointment is virtual)
      thereby influencing the choice of the legislatures, or if they should not
      be so complaisant as to conform to his appointment -- offence will be
      given to the executive and the temporary members will appear ridiculous by
      rejection; this temporary member, during his time of appointment, will of
      course act by a power derived from the executive, and for, and under his
      immediate influence.


    
    It is a very important objection to this government,
      that the representation consists of so few; too few to resist the
      influence of corruption, and the temptation to treachery, against which
      all governments ought to take precautions -- how guarded you have been on
      this head, in your own state constitution, and yet the number of senators
      and representatives proposed for this vast continent, does not equal those
      of your own state; how great the disparity, if you compare them with the
      aggregate numbers in the United States. The history of representation in
      England, from which we have taken our model of legislation, is briefly
      this: before the institution of legislating by deputies, the whole free
      part of the community usually met for that purpose; when this became
      impossible by the increase of numbers the community was divided into
      districts, from each of which was sent such a number of deputies as was a
      complete representation of the various numbers and orders of citizens
      within them; but can it be asserted with truth, that six men can be a
      complete and full representation of the numbers and various orders of the
      people in this state? Another thing [that] may be suggested against the
      small number of representatives is, that but few of you will have the
      chance of sharing even in this branch of the legislature; and that the
      choice will be confined to a very few; the more complete it is, the better
      will your interests be preserved, and the greater the opportunity you will
      have to participate in government, one of the principal securities of a
      free people; but this subject has been so ably and fully treated by a
      writer under the signature of Brutus, that I shall content myself with
      referring you to him thereon, reserving further observations on the other
      objections I have mentioned, for my future numbers.


    
    Cato.


    
    
    Text Version |
      Next Letter | Previous
        Letter | Rendered into HTML by
      Jon Roland of the

--- chunk_id: chunk-0221
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 1869
content_hash: 5d54638efefa1257
prev_chunk_id: chunk-0220
next_chunk_id: chunk-0222
section_heading: Cato VII
document_type: specification

## Cato VII

*Source file: cato_07.htm (constitution.org AFP collection)*

Anti-Federalist Papers: "Cato" #7
  
  
  
 

    
    
    "Cato"


    Letter VII


    The New-York Journal, January 3, 1788


    
    To the Citizens of the State of New York.


    
    That the senate and president are further improperly
      connected, will appear, if it is considered, that their dependence on each
      other will prevent either from being a check upon the other; they must act
      in concert, and whether the power and influence of the one or the other is
      to prevail, will depend on the character and abilities of the men who hold
      those offices at the time. The senate is vested with such a proportion of
      the executive, that it would be found necessary that they should be
      constantly sitting. This circumstance did not escape the convention, and
      they have provided for the event, in the 2d article, which declares, that
      the executive may, on extraordinary occasions, convene both houses or
      either of them. No occasion can exist for calling the assembly without
      the senate, the words or either of them, must have been intended
      to apply only to the senate. Their wages are already provided for, and it
      will be therefore readily observed, that the partition between a
      perpetuation of their sessions and a perpetuation of their offices, in the
      progress of the government, will be found to be but thin and feeble.
      Besides, the senate, who have the sole power to try all impeachments, in
      case of the impeachment of the president, are to determine, as judges, the
      propriety of the advice they gave him, as senators. Can the senate in
      this, therefore, be an impartial judicature? And will they not rather
      serve as a screen to great public defaulters?


    
    Among the many evils that are incorporated in this new
      system of government, is that of congress having the power of making or
      altering the regulations prescribed by the different legislatures,
      respecting the time, place, and manner of holding elections for
      representatives, and the time, and manner of choosing senators. If it is
      enquired, in what manner this regulation may be exercised to your injury
      -- the answer is easy.


    
    By the first article the house of representatives shall
      consist of members, chosen every second year by the people of the several
      states, who are qualified to vote for members of their several state
      assemblies; it can therefore readily be believed, that the different state
      legislatures, provided such can exist after the adoption of this
      government, will continue those easy and convenient modes for the election
      of representatives for the national legislature, that are in use, for the
      election of members of assembly for their own states; but the congress
      have, by the constitution, a power to make other regulations, or alter
      those in practice, prescribed by your own state legislature; hence,
      instead of having the places of elections in the precincts, and brought
      home almost to your own doors, Congress may establish a place, or places,
      at either the extremes, center, or outer parts of the states; at a time
      and season too, when it may be very inconvenient to attend; and by these
      means destroy the rights of election; but in opposition to this reasoning,
      it is asserted, that it is a necessary power because the states might omit
      making rules for the purpose, and thereby defeat the existence of that
      branch of the government; this is what logicians call argumentum
      absurdum, for the different states, if they will have any security at
      all in this government, will find it in the house of representatives, and
      they, therefore, would not be very ready to eradicate a principle in which
      it dwells, or involve their country in an instantaneous revolution.
      Besides, if this was the apprehension of the framers, and the ground of
      that provision, why did not they extend this controlling power to the
      other duties of the several state legislatures. To exemplify this the
      states are to appoint senators and electors for choosing of a president;
      but the time is to be under the direction of congress. Now, suppose they
      were to omit the appointment of senators and electors, though congress was
      to appoint the time, which might [as] well be apprehended as the omission
      of regulations for the election of members of the house of
      representatives, provided they had that power; or suppose they were not to
      meet at all: of course, the government cannot proceed in its exercise. And
      from this motive, or apprehension, congress ought to have taken-these
      duties entirely in their own hands, and, by a decisive declaration,
      annihilated them, which they in fact have done by leaving them without the
      means of support, or at least resting on their bounty. To this, the
      advocates for this system oppose the common, empty declamation, that there
      is no danger that congress will abuse this power, but such language, as
      relative to so important a subject, is mere vapour, and sound without
      sense. Is it not in their power, however, to make such regulations as may
      be inconvenient to you? It must be admitted because the words are
      unlimited in their sense. It is a good rule, in the construction of a
      contract, to support, that what may be done will be; therefore, in
      considering this subject, you are to suppose, that in the exercise of this
      government, a regulation of congress will be made, for holding an election
      for the whole state at Poughkeepsie, at New York, or, perhaps, at Fort
      Stanwix: who will then be the actual electors for the house of
      representatives? Very few more than those who may live in the vicinity of
      these places. Could any others afford the expense and time of attending?
      And would not the government by this means have it in their power to put
      whom they pleased in the house of representatives? You ought certainly to
      have as much or more distrust with respect to the exercise of these powers
      by congress, than congress ought to have with respect to the exercise of
      those duties which ought to be entrusted to the several states, because
      over them congress can have a legislative controlling power.


    
    Hitherto we have tied up our rulers in the exercise of
      their duties by positive restrictions_if the cord has been drawn too
      tight, loosen it to the necessary extent, but do not entirely unbind them.
      -- I am no enemy to placing a reasonable confidence in them but such an
      unbounded one as the advocates and framers of this new system advise you
      to, would be dangerous to your liberties; it has been the ruin of other
      governments, and will be yours, if you adopt with all its latitudinal
      powers -- unlimited confidence in governors as well as individuals is
      frequently the parent of deception [despotism?]. -- What facilitated the
      corrupt designs of Philip of Macedon, and caused the ruin of Athens, but
      the unbounded confidence in their statesmen and rulers? Such improper
      confidence Demosthenes was so well convinced had ruined his country, that
      in his second Philippic oration he remarks "that there is one common
      bulwark with which men of prudence are naturally provided, the guard and
      security of all people, particularly of free states, against the assaults
      of tyrants -- What is this? Distrust. Of this be mindful; to this adhere;
      preserve this carefully, and no calamity can affect you." --
      Montesquieu observes, that "the course of government is attended with
      an insensible descent to evil, and there is no reascending to good without
      very great efforts. " The plain inference from this doctrine is, that
      rulers in all governments will erect an interest separate from the ruled,
      which will have a tendency to enslave them. There is therefore no other
      way of interrupting this insensible descent and warding off the evil as
      long as possible, than by establishing principles of distrust in your
      constituents, and cultivating the sentiment among yourselves. But let me
      enquire of you, my countrymen, whether the freedom and independence of
      elections is a point of magnitude? If it is, what kind of a spirit of
      amity, deference and concession, is that which has put in the power of
      congress at one stroke to prevent your interference in government, and do
      away your liberties forever? Does either the situation or circumstances of
      things warrant it?


    
    Cato.


    
    
    Text Version |
      Next Letter | Previous
        Letter | Rendered into HTML by
      Jon Roland of the

--- chunk_id: chunk-0222
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 432
content_hash: e1762db6d61a7c03
prev_chunk_id: chunk-0221
next_chunk_id: chunk-0223
section_heading: Federal Farmer I
document_type: specification

## Federal Farmer I

*Source file: fedfar01.htm (constitution.org AFP collection)*

Letters from the Federal Farmer to the Republican: #01



 

Letters from the Federal Farmer to the Republican


I


October 8th, 1787. Dear Sir,


My letters to you last winter, on the subject of a well balanced national
government for the United States, were the result of free enquiry; when I
passed from that subject to enquiries relative to our commerce, revenues, past
administration, etc. I anticipated the anxieties I feel, on carefully examining
the plan of government proposed by the convention. It appears to be a plan
retaining some federal features; but to be the first important step, and to aim
strongly to one consolidated government of the United States. It leaves the
powers of government, and the representation of the people, so unnaturally
divided between the general and state governments, that the operations of our
system must be very uncertain. My uniform federal attachments, and the interest
I have in the protection of property, and a steady execution of the laws, will
convince you, that, if I am under any biass at all, it is in favor of any
general system which shall promise those advantages. The instability of our
laws increases my wishes for firm and steady government; but then, I can
consent to no government, which, in my opinion, is not calculated equally to
preserve the rights of all orders of men in the community. My object has been
to join with those who have endeavoured to supply the defects in the forms of
our governments by a steady and proper administration of them. Though I have
long apprehended that fraudalent debtors, and embarrassed men, on the one hand,
and men, on the other, unfriendly to republican equality, would produce an
uneasiness among the people, and prepare the way, not for cool and deliberate
reforms in the governments, but for changes calculated to promote the interests
of particular orders of men.

--- chunk_id: chunk-0223
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: 0e7e82f24fea804c
prev_chunk_id: chunk-0222
next_chunk_id: chunk-0224
section_heading: Federal Farmer I
document_type: specification

My object has been
to join with those who have endeavoured to supply the defects in the forms of
our governments by a steady and proper administration of them. Though I have
long apprehended that fraudalent debtors, and embarrassed men, on the one hand,
and men, on the other, unfriendly to republican equality, would produce an
uneasiness among the people, and prepare the way, not for cool and deliberate
reforms in the governments, but for changes calculated to promote the interests
of particular orders of men. Acquit me, sir, of any agency in the formation of
the new system; I shall be satisfied with seeing, if it shall be adopted, a
prudent administration. Indeed I am so much convinced of the truth of Pope's
maxim, that "That which is best administered is best," that I am much
inclined to subscribe to it from experience. I am not disposed to unreasonably
contend about forms. I know our situation is critical, and it behoves us to
make the best of it. A federal government of some sort is necessary. We have
suffered the present to languish; and whether the confederation was capable or
not originally of answering any valuable purposes, it is now but of little
importance. I will pass by the men, and states, who have been particularly
instrumental in preparing the way for a change, and, perhaps, for governments
not very favourable to the people at large. A constitution is now presented
which we may reject, or which we may accept, with or without amendments; and to
which point we ought to direct our exertions, is the question. To determine
this question, with propriety, we must attentively examine the system itself,
and the probable consequences of either step. This I shall endeavour to do, so
far as I am able, with candor and fairness; and leave you to decide upon the
propriety of my opinions, the weight of my reasons, and how far my conclusions
are well drawn.

--- chunk_id: chunk-0224
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 442
content_hash: f73d3b326f6b0b3d
prev_chunk_id: chunk-0223
next_chunk_id: chunk-0225
section_heading: Federal Farmer I
document_type: specification

To determine
this question, with propriety, we must attentively examine the system itself,
and the probable consequences of either step. This I shall endeavour to do, so
far as I am able, with candor and fairness; and leave you to decide upon the
propriety of my opinions, the weight of my reasons, and how far my conclusions
are well drawn. Whatever may be the conduct of others, on the present occasion,
I do not mean, hastily and positively to decide on the merits of the
constitution proposed. I shall be open to conviction, and always disposed to
adopt that which, all things considered, shall appear to me to be most for the
happiness of the community. It must be granted, that if men hastily and blindly
adopt a system of government, they will as hastily and as blindly be led to
alter or abolish it; and changes must ensue, one after another, till the
peaceable and better part of the community will grow weary with changes,
tumults and disorders, and be disposed to accept any government, however
despotic, that shall promise stability and firmness. The first principal question that occurs, is. Whether, considering our
situation, we ought to precipitate the adoption of the proposed constitution? If we remain cool and temperate, we are in no immediate danger of any
commotions; we are in a state of perfect peace, and in no danger of invasions;
the state governments are in the full exercise of their powers; and our
governments answer all present exigencies, except the regulation of trade,
securing credit, in some cases, and providing for the interest, in some
instances, of the public debts; and whether we adopt a change, three or nine
months hence, can make but little odds with the private circumstances of
individuals; their happiness and prosperity, after all, depend principally upon
their own exertions. We are hardly recovered from a long and distressing war:
The farmers, fishmen, &c. have not yet fully repaired the waste made by it.

--- chunk_id: chunk-0225
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 426
content_hash: 65707500be9f3de8
prev_chunk_id: chunk-0224
next_chunk_id: chunk-0226
section_heading: Federal Farmer I
document_type: specification

We are hardly recovered from a long and distressing war:
The farmers, fishmen, &c. have not yet fully repaired the waste made by it. Industry and frugality are again assuming their proper station. Private debts
are lessened, and public debts incurred by the war have been, by various ways,
diminished; and the public lands have now become a productive source for
diminishing them much more. I know uneasy men, who wish very much to
precipitate, do not admit all these facts; but they are facts well known to all
men who are thoroughly informed in the affairs of this country. It must,
however, be admitted, that our federal system is defective, and that some of
the state governments are not well administered; but, then, we impute to the
defects in our governments many evils and embarrassments which are most clearly
the result of the late war. We must allow men to conduct on the present
occasion, as on all similar ones. They will urge a thousand pretences to answer
their purposes on both sides. When we want a man to change his condition, we
describe it as miserable, wretched, and despised; and draw a pleasing picture
of that which we would have him assume. And when we wish the contrary, we
reverse our descriptions. Whenever a clamor is raised, and idle men get to
work, it is highly necessary to examine facts carefully, and without
unreasonably suspecting men of falshood, to examine, and enquire attentively,
under what impressions they act. It is too often the case in political
concerns, that men state facts not as they are, but as they wish them to be;
and almost every man, by calling to mind past scenes, will find this to be
true. Nothing but the passions of ambitious, impatient, or disorderly men, I
conceive, will plunge us into commotions, if time should be taken fully to
examine and consider the system proposed.

--- chunk_id: chunk-0226
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 446
content_hash: b800a747e0e1aea0
prev_chunk_id: chunk-0225
next_chunk_id: chunk-0227
section_heading: Federal Farmer I
document_type: specification

It is too often the case in political
concerns, that men state facts not as they are, but as they wish them to be;
and almost every man, by calling to mind past scenes, will find this to be
true. Nothing but the passions of ambitious, impatient, or disorderly men, I
conceive, will plunge us into commotions, if time should be taken fully to
examine and consider the system proposed. Men who feel easy in their
circumstances, and such as are not sanguine in their expectations relative to
the consequences of the proposed change, will remain quiet under the existing
governments. Many commercial and monied men, who are uneasy, not without just
cause, ought to be respected; and, by no means, unreasonably disappointed in
their expectations and hopes; but as to those who expect employments under the
new constitution; as to those weak and ardent men who always expect to be
gainers by revolutions, and whose lot it generally is to get out of one
difficulty into another, they are very little to be regarded: and as to those
who designedly avail themselves of this weakness and ardor, they are to be
despised. It is natural for men, who wish to hasten the adoption of a measure,
to tell us, now is the crisis — now is the critical moment which must be
seized, or all will be lost: and to shut the door against free enquiry,
whenever conscious the thing presented has defects in it, which time and
investigation will probably discover. This has been the custom of tyrants and
their dependants in all ages. If it is true, what has been so often said, that
the people of this country cannot change their condition for the worse, I
presume it still behoves them to endeavour deliberately to change it for the
better. The fickle and ardent, in any community, are the proper tools for
establishing despotic government. But it is deliberate and thinking men, who
must establish and secure governments on free principles.

--- chunk_id: chunk-0227
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 446
content_hash: 275325d3d1c8f177
prev_chunk_id: chunk-0226
next_chunk_id: chunk-0228
section_heading: Federal Farmer I
document_type: specification

The fickle and ardent, in any community, are the proper tools for
establishing despotic government. But it is deliberate and thinking men, who
must establish and secure governments on free principles. Before they decide on
the plan proposed, they will enquire whether it will probably be a blessing or
a curse to this people. The present moment discovers a new face in our affairs. Our object has been
all along, to reform our federal system, and to strengthen our governments
— to establish peace, order and justice in the community — but a new
object now presents. The plan of government now proposed is evidently
calculated totally to change, in time, our condition as a people. Instead of
being thirteen republics, under a federal head, it is clearly designed to make
us one consolidated government. Of this, I think, I shall fully convince you,
in my following letters on this subject. This consolidation of the states has
been the object of several men in this country for some time past. Whether such
a change can ever be effected in any manner; whether it can be effected without
convulsions and civil wars; whether such a change will not totally destroy the
liberties of this country — time only can determine. To have a just idea of the government before us, and to shew that a
consolidated one is the object in view, it is necessary not only to examine the
plan, but also its history, and the politics of its particular friends. The confederation was formed when great confidence was placed in the
voluntary exertions of individuals, and of the respective states; and the
framers of it, to guard against usurpation, so limited and checked the powers,
that, in many respects, they are inadequate to the exigencies of the union. We
find, therefore, members of congress urging alterations in the federal system
almost as soon as it was adopted. It was early proposed to vest congress with
powers to levy an impost, to regulate trade, etc.

--- chunk_id: chunk-0228
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 408
content_hash: f36437777f01149e
prev_chunk_id: chunk-0227
next_chunk_id: chunk-0229
section_heading: Federal Farmer I
document_type: specification

We
find, therefore, members of congress urging alterations in the federal system
almost as soon as it was adopted. It was early proposed to vest congress with
powers to levy an impost, to regulate trade, etc. but such was known to be the
caution of the states in parting with power, that the vestment, even of these,
was proposed to be under several checks and limitations. During the war, the
general confusion, and the introduction of paper money, infused in the minds of
people vague ideas respecting government and credit. We expected too much from
the return of peace, and of course we have been disappointed. Our governments
have been new and unsettled; and several legislatures, by making tender,
suspension, and paper money laws, have given just cause of uneasiness to
creditors. By these and other causes, several orders of men in the community
have been prepared, by degrees, for a change of government; and this very abuse
of power in the legislatures, which, in some cases, has been charged upon the
democratic part of the community, has furnished aristocratical men with those
very weapons, and those very means, with which, in great measure, they are
rapidly effecting their favourite object. And should an oppressive government
be the consequence of the proposed change, posterity may reproach not only a
few overbearing unprincipled men, but those parties in the states which have
misused their powers. The conduct of several legislatures, touching paper money, and tender laws,
has prepared many honest men for changes in government, which otherwise they
would not have thought of — when by the evils, on the one hand, and by the
secret instigations of artful men, on the other, the minds of men were become
sufficiently uneasy, a bold step was taken, which is usually followed by a
revolution, or a civil war.

--- chunk_id: chunk-0229
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 277
content_hash: 8c833365608e3352
prev_chunk_id: chunk-0228
next_chunk_id: chunk-0230
section_heading: Federal Farmer I
document_type: specification

And should an oppressive government
be the consequence of the proposed change, posterity may reproach not only a
few overbearing unprincipled men, but those parties in the states which have
misused their powers. The conduct of several legislatures, touching paper money, and tender laws,
has prepared many honest men for changes in government, which otherwise they
would not have thought of — when by the evils, on the one hand, and by the
secret instigations of artful men, on the other, the minds of men were become
sufficiently uneasy, a bold step was taken, which is usually followed by a
revolution, or a civil war. A general convention for mere commercial purposes
was moved for — the authors of this measure saw that the people's
attention was turned solely to the amendment of the federal system; and that,
had the idea of a total change been started, probably no state would have
appointed members to the convention. The idea of destroying, ultimately, the
state government, and forming one consolidated system, could not have been
admitted — a convention, therefore, merely for vesting in congress power
to regulate trade was proposed. This was pleasing to the commercial towns; and
the landed people had little or no concern about it.

--- chunk_id: chunk-0230
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 445
content_hash: 17ba99fa1e70e000
prev_chunk_id: chunk-0229
next_chunk_id: chunk-0231
section_heading: Federal Farmer I
document_type: specification

The idea of destroying, ultimately, the
state government, and forming one consolidated system, could not have been
admitted — a convention, therefore, merely for vesting in congress power
to regulate trade was proposed. This was pleasing to the commercial towns; and
the landed people had little or no concern about it. September, 1786, a few men
from the middle states met at Annapolis, and hastily proposed a convention to
be held in May, 1787, for the purpose, generally, of amending the confederation
— this was done before the delegates of Massachusetts, and of the other
states arrived — still not a word was said about destroying the old
constitution, and making a new one — The states still unsuspecting, and
not aware that they were passing the Rubicon, appointed members to the new
convention, for the sole and express purpose of revising and amending the
confederation — and, probably, not one man in ten thousand in the United
States, till within these ten or twelve days, had an idea that the old ship was
to be destroyed, and he put to the alternative of embarking in the new ship
presented, or of being left in danger of sinking — The States. I believe,
universally supposed the convention would report alterations in the
confederation, which would pass an examination in congress, and after being
agreed to there, would be confirmed by all the legislatures, or be rejected. Virginia made a very respectable appointment, and placed at the head of it the
first man in America: In this appointment there was a mixture of political
characters; but Pennsylvania appointed principally those men who are esteemed
aristocratical. Here the favourite moment for changing the government was
evidently discerned by a few men, who seized it with address. Ten other states
appointed, and tho' they chose men principally connected with commerce and the
judicial department yet they appointed many good republican characters —
had they all attended we should now see, I am persuaded a better system
presented.

--- chunk_id: chunk-0231
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 438
content_hash: 6febeb7ef9996732
prev_chunk_id: chunk-0230
next_chunk_id: chunk-0232
section_heading: Federal Farmer I
document_type: specification

Here the favourite moment for changing the government was
evidently discerned by a few men, who seized it with address. Ten other states
appointed, and tho' they chose men principally connected with commerce and the
judicial department yet they appointed many good republican characters —
had they all attended we should now see, I am persuaded a better system
presented. The non-attendance of eight or nine men, who were appointed members
of the convention, I shall ever consider as a very unfortunate event to the
United States. — Had they attended, I am pretty clear, that the result of
the convention would not have had that strong tendency to aristocracy now
discemable in every part of the plan. There would not have been so great an
accumulation of powers, especially as to the internal police of the country, in
a few hands, as the constitution reported proposes to vest in them — the
young visionary men, and the consolidating aristocracy, would have been more
restrained than they have been. Eleven states met in the convention, and after
four months close attention presented the new constitution, to be adopted or
rejected by the people. The uneasy and fickle part of the community may be
prepared to receive any form of government; but, I presume, the enlightened and
substantial part will give any constitution presented for their adoption, a
candid and thorough examination; and silence those designing or empty men, who
weakly and rashly attempt to precipitate the adoption of a system of so much
importance — We shall view the convention with proper respect — and,
at the same time, that we reflect there were men of abilities and integrity in
it, we must recollect how disproportionably the democratic and aristocratic
parts of the community were represented — Perhaps the judicious friends
and opposers of the new constitution will agree, that it is best to let it rest
solely on its own merits, or be condemned for its own defects.

--- chunk_id: chunk-0232
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 424
content_hash: dd56d544ca718dbd
prev_chunk_id: chunk-0231
next_chunk_id: chunk-0233
section_heading: Federal Farmer I
document_type: specification

Eleven states met in the convention, and after
four months close attention presented the new constitution, to be adopted or
rejected by the people. The uneasy and fickle part of the community may be
prepared to receive any form of government; but, I presume, the enlightened and
substantial part will give any constitution presented for their adoption, a
candid and thorough examination; and silence those designing or empty men, who
weakly and rashly attempt to precipitate the adoption of a system of so much
importance — We shall view the convention with proper respect — and,
at the same time, that we reflect there were men of abilities and integrity in
it, we must recollect how disproportionably the democratic and aristocratic
parts of the community were represented — Perhaps the judicious friends
and opposers of the new constitution will agree, that it is best to let it rest
solely on its own merits, or be condemned for its own defects. In the first place, I shall premise, that the plan proposed is a plan of
accommodation — and that it is in this way only, and by giving up a part
of our opinions, that we can ever expect to obtain a government founded in
freedom and compact. This circumstance candid men will always keep in view, in
the discussion of this subject. The plan proposed appears to be partly federal, but principally however,
calculated ultimately to make the states one consolidated government. The first interesting question, therefore suggested, is, how far the states
can be consolidated into one entire government on free principles. In
considering this question extensive objects are to be taken into view, and
important changes in the forms of government to be carefully attended to in all
their consequences. The happiness of the people at large must be the great
object with every honest statesman, and he will direct every movement to this
point.

--- chunk_id: chunk-0233
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 396
content_hash: 7d1db5fc3de48c3e
prev_chunk_id: chunk-0232
next_chunk_id: chunk-0234
section_heading: Federal Farmer I
document_type: specification

In
considering this question extensive objects are to be taken into view, and
important changes in the forms of government to be carefully attended to in all
their consequences. The happiness of the people at large must be the great
object with every honest statesman, and he will direct every movement to this
point. If we are so situated as a people, as not to be able to enjoy equal
happiness and advantages under one government, the consolidation of the states
cannot be admitted. There are three different forms of free government under which the United
States may exist as one nation; and now is, perhaps, the time to determine to
which we will direct our views. 1. Distinct republics connected under a federal
head. In this case the respective state governments must be the principal
guardians of the peoples rights, and exclusively regulate their internal
police; in them must rest the balance of government. The congress of the
states, or federal head, must consist of delegates amenable to, and removeable
by the respective states: This congress must have general directing powers;
powers to require men and monies of the states; to make treaties, peace and
war; to direct the operations of armies, etc. Under this federal modification
of government, the powers of congress would be rather advisary or
recommendatory than coercive. 2. We may do away the several state governments,
and form or consolidate all the states into one entire government, with one
executive, one judiciary, and one legislature, consisting of senators and
representatives collected from all parts of the union: In this case there would
be a compleat consolidation of the states. 3. We may consolidate the states as
to certain national objects, and leave them severally distinct independent
republics, as to internal police generally.

--- chunk_id: chunk-0234
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 420
content_hash: ed508504aee7c803
prev_chunk_id: chunk-0233
next_chunk_id: chunk-0235
section_heading: Federal Farmer I
document_type: specification

3. We may consolidate the states as
to certain national objects, and leave them severally distinct independent
republics, as to internal police generally. Let the general government consist
of an executive, a judiciary, and balanced legislature, and its powers extend
exclusively to all foreign concerns, causes arising on the seas to commerce,
imports, armies, navies, Indian affairs, peace and war, and to a few internal
concerns of the community; to the coin, post-offices, weights and measures, a
general plan for the militia, to naturalization, and, perhaps to
bankruptcies, leaving the internal police of the community, in other
respects, exclusively to the state governments; as the administration of
justice in all causes arising internally, the laying and collecting of internal
taxes, and the forming of the militia according to a general plan prescribed. In this case there would be a compleat consolidation, quoad certain
objects only. Touching the first, or federal plan, I do not think much can be said in its
favor: The sovereignty of the nation, without coercive and efficient powers to
collect the strength of it, cannot always be depended on to answer the purposes
of government; and in a congress of representatives of sovereign states, there
must necessarily be an unreasonable mixture of powers in the same hands. As to the second, or compleat consolidating plan, it deserves to be
carefully considered at this time, by every American: If it be impracticable,
it is a fatal error to model our governments, directing our views ultimately to
it. The third plan, or partial consolidation, is, in my opinion, the only one
that can secure the freedom and happiness of this people. I once had some
general ideas that the second plan was practicable, but from long attention,
and the proceedings of the convention, I am fully satisfied, that this third
plan is the only one we can with safety and propriety proceed upon.

--- chunk_id: chunk-0235
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 422
content_hash: f86e07ca0397ec4f
prev_chunk_id: chunk-0234
next_chunk_id: chunk-0236
section_heading: Federal Farmer I
document_type: specification

The third plan, or partial consolidation, is, in my opinion, the only one
that can secure the freedom and happiness of this people. I once had some
general ideas that the second plan was practicable, but from long attention,
and the proceedings of the convention, I am fully satisfied, that this third
plan is the only one we can with safety and propriety proceed upon. Making this
the standard to point out, with candor and fairness, the parts of the new
constitution which appear to be improper, is my object. The convention appears
to have proposed the partial consolidation evidently with a view to collect all
powers ultimately, in the United States into one entire government; and from
its views in this respect, and from the tenacity of the small states to have an
equal vote in the senate, probably originated the greatest defects in the
proposed plan. Independant of the opinions of many great authors, that a free elective
government cannot be extended over large territories, a few reflections must
evince, that one government and general legislation alone, never can extend
equal benefits to all parts of the United States: Different laws, customs, and
opinions exist in the different states, which by a uniform system of laws would
be unreasonably invaded. The United States contain about a million of square
miles, and in half a century will, probably, contain ten millions of people;
and from the center to the extremes is about 800 miles. Before we do away the state governments, or adopt measures that will tend to
abolish them, and to consolidate the states into one entire government, several
principles should be considered and facts ascertained: — These, and my
examination into the essential parts of the proposed plan, I shall pursue in my
next. Your's &c. The Federal Farmer. Text Version | Next | Contents | Anti-Federalist
Papers | Liberty Library | Home |

--- chunk_id: chunk-0236
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 389
content_hash: db69ab2dd4edca6c
prev_chunk_id: chunk-0235
next_chunk_id: chunk-0237
section_heading: Federal Farmer II
document_type: specification

## Federal Farmer II

*Source file: fedfar02.htm (constitution.org AFP collection)*

Letters from the Federal Farmer to the Republican: #02



 

Letters from the Federal Farmer to the Republican


II


October 9, 1787. Dear Sir,


The essential parts of a free and good government are a full and equal
representation of the people in the legislature, and the jury trial of the
vicinage in the administration of justice — a full and equal
representation, is that which possesses the same interests, feelings, opinions,
and views the people themselves would were they all assembled — a fair
representation, therefore, should be so regulated, that every order of men in
the community, according to the common course of elections, can have a share in
it — in order to allow professional men, merchants, traders, farmers,
mechanics, etc. to bring a just proportion of their best informed men
respectively into the legislature, the representation must be considerably
numerous — We have about 200 state senators in the United States, and a
less number than that of federal representatives cannot, clearly, be a full
representation of this people, in the affairs of internal taxation and police,
were there but one legislature for the whole union. The representation cannot
be equal, or the situation of the people proper for one government only —
if the extreme parts of the society cannot be represented as fully as the
central — It is apparently impracticable that this should be the case in
this extensive country — it would be impossible to collect a
representation of the parts of the country five, six, and seven hundred miles
from the seat of government. Under one general government alone, there could be but one judiciary, one
supreme and a proper number of inferior courts.

--- chunk_id: chunk-0237
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 270
content_hash: b3c44973ea165cca
prev_chunk_id: chunk-0236
next_chunk_id: chunk-0238
section_heading: Federal Farmer II
document_type: specification

The representation cannot
be equal, or the situation of the people proper for one government only —
if the extreme parts of the society cannot be represented as fully as the
central — It is apparently impracticable that this should be the case in
this extensive country — it would be impossible to collect a
representation of the parts of the country five, six, and seven hundred miles
from the seat of government. Under one general government alone, there could be but one judiciary, one
supreme and a proper number of inferior courts. I think it would be totally
impracticable in this case to preserve a due administration of justice, and the
real benefits of the jury trial of the vicinage, — there are now supreme
courts in each state in the union; and a great number of county and other
courts subordinate to each supreme court — most of these supreme and
inferior courts are itinerant, and hold their sessions in different parts every
year of their respective states, counties and districts — with all these
moving courts, our citizens, from the vast extent of the country must travel
very considerable distances from home to find the place where justice is
administered.

--- chunk_id: chunk-0238
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 390
content_hash: 21ed62ea9f6fd9a8
prev_chunk_id: chunk-0237
next_chunk_id: chunk-0239
section_heading: Federal Farmer II
document_type: specification

Under one general government alone, there could be but one judiciary, one
supreme and a proper number of inferior courts. I think it would be totally
impracticable in this case to preserve a due administration of justice, and the
real benefits of the jury trial of the vicinage, — there are now supreme
courts in each state in the union; and a great number of county and other
courts subordinate to each supreme court — most of these supreme and
inferior courts are itinerant, and hold their sessions in different parts every
year of their respective states, counties and districts — with all these
moving courts, our citizens, from the vast extent of the country must travel
very considerable distances from home to find the place where justice is
administered. I am not for bringing justice so near to individuals as to afford
them any temptation to engage in law suits; though I think it one of the
greatest benefits in a good government, that each citizen should find a court
of justice within a reasonable distance, perhaps, within a day's travel of his
home; so that, without great inconveniences and enormous expences, he may have
the advantages of his witnesses and jury — it would be impracticable to
derive these advantages from one judiciary — the one supreme court at most
could only set in the centre of the union, and move once a year into the centre
of the eastern and southern extremes of it — and, in this case, each
citizen, on an average, would travel 150 or 200 miles to find this court —
that, however, inferior courts might be properly placed in the different
counties, and districts of the union, the appellate jurisdiction would be
intolerable and expensive.

--- chunk_id: chunk-0239
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 430
content_hash: daf8ba5dd4581494
prev_chunk_id: chunk-0238
next_chunk_id: chunk-0240
section_heading: Federal Farmer II
document_type: specification

I think it would be totally
impracticable in this case to preserve a due administration of justice, and the
real benefits of the jury trial of the vicinage, — there are now supreme
courts in each state in the union; and a great number of county and other
courts subordinate to each supreme court — most of these supreme and
inferior courts are itinerant, and hold their sessions in different parts every
year of their respective states, counties and districts — with all these
moving courts, our citizens, from the vast extent of the country must travel
very considerable distances from home to find the place where justice is
administered. I am not for bringing justice so near to individuals as to afford
them any temptation to engage in law suits; though I think it one of the
greatest benefits in a good government, that each citizen should find a court
of justice within a reasonable distance, perhaps, within a day's travel of his
home; so that, without great inconveniences and enormous expences, he may have
the advantages of his witnesses and jury — it would be impracticable to
derive these advantages from one judiciary — the one supreme court at most
could only set in the centre of the union, and move once a year into the centre
of the eastern and southern extremes of it — and, in this case, each
citizen, on an average, would travel 150 or 200 miles to find this court —
that, however, inferior courts might be properly placed in the different
counties, and districts of the union, the appellate jurisdiction would be
intolerable and expensive. If it were possible to consolidate the states, and preserve the features of
a free government, still it is evident that the middle states, the parts of the
union, about the seat of government, would enjoy great advantages, while the
remote states would experience the many inconveniences of remote provinces.

--- chunk_id: chunk-0240
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 316
content_hash: a12ec05b05520043
prev_chunk_id: chunk-0239
next_chunk_id: chunk-0241
section_heading: Federal Farmer II
document_type: specification

I am not for bringing justice so near to individuals as to afford
them any temptation to engage in law suits; though I think it one of the
greatest benefits in a good government, that each citizen should find a court
of justice within a reasonable distance, perhaps, within a day's travel of his
home; so that, without great inconveniences and enormous expences, he may have
the advantages of his witnesses and jury — it would be impracticable to
derive these advantages from one judiciary — the one supreme court at most
could only set in the centre of the union, and move once a year into the centre
of the eastern and southern extremes of it — and, in this case, each
citizen, on an average, would travel 150 or 200 miles to find this court —
that, however, inferior courts might be properly placed in the different
counties, and districts of the union, the appellate jurisdiction would be
intolerable and expensive. If it were possible to consolidate the states, and preserve the features of
a free government, still it is evident that the middle states, the parts of the
union, about the seat of government, would enjoy great advantages, while the
remote states would experience the many inconveniences of remote provinces. Wealth, offices, and the benefits of government would collect in the centre:
and the extreme states and their principal towns, become much less important.

--- chunk_id: chunk-0241
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 422
content_hash: 7a7c7b314f33de54
prev_chunk_id: chunk-0240
next_chunk_id: chunk-0242
section_heading: Federal Farmer II
document_type: specification

If it were possible to consolidate the states, and preserve the features of
a free government, still it is evident that the middle states, the parts of the
union, about the seat of government, would enjoy great advantages, while the
remote states would experience the many inconveniences of remote provinces. Wealth, offices, and the benefits of government would collect in the centre:
and the extreme states and their principal towns, become much less important. There are other considerations which tend to prove that the idea of one
consolidated whole, on free principles, is ill-founded — the laws of a
free government rest on the confidence of the people, and operate gently —
and never can extend their influence very far — if they are executed on
free principles, about the centre, where the benefits of the government induce
the people to support it voluntarily; yet they must be executed on the
principles of fear and force in the extremes — This has been the case with
every extensive republic of which we have any accurate account. There are certain unalienable and fundamental rights, which in forming the
social compact, ought to be explicitly ascertained and fixed — a free and
enlightened people, in forming this compact, will not resign all their rights
to those who govern, and they will fix limits to their legislators and rulers,
which will soon be plainly seen by those who are governed, as well as by those
who govern: and the latter will know they cannot be passed unperceived by the
former, and without giving a general alarm — These rights should be made
the basis of every constitution: and if a people be so situated, or have such
different opinions that they cannot agree in ascertaining and fixing them, it
is a very strong argument against their attempting to form one entire society,
to live under one system of laws only.

--- chunk_id: chunk-0242
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 389
content_hash: 55ab61f2efea2b52
prev_chunk_id: chunk-0241
next_chunk_id: chunk-0243
section_heading: Federal Farmer II
document_type: specification

There are other considerations which tend to prove that the idea of one
consolidated whole, on free principles, is ill-founded — the laws of a
free government rest on the confidence of the people, and operate gently —
and never can extend their influence very far — if they are executed on
free principles, about the centre, where the benefits of the government induce
the people to support it voluntarily; yet they must be executed on the
principles of fear and force in the extremes — This has been the case with
every extensive republic of which we have any accurate account. There are certain unalienable and fundamental rights, which in forming the
social compact, ought to be explicitly ascertained and fixed — a free and
enlightened people, in forming this compact, will not resign all their rights
to those who govern, and they will fix limits to their legislators and rulers,
which will soon be plainly seen by those who are governed, as well as by those
who govern: and the latter will know they cannot be passed unperceived by the
former, and without giving a general alarm — These rights should be made
the basis of every constitution: and if a people be so situated, or have such
different opinions that they cannot agree in ascertaining and fixing them, it
is a very strong argument against their attempting to form one entire society,
to live under one system of laws only. — I confess, I never thought the
people of these states differed essentially in these respects; they having
derived all these rights from one common source, the British systems; and
having in the formation of their state constitutions, discovered that their
ideas relative to these rights are very similar.

--- chunk_id: chunk-0243
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 432
content_hash: 0e46eff00a0894c3
prev_chunk_id: chunk-0242
next_chunk_id: chunk-0244
section_heading: Federal Farmer II
document_type: specification

There are certain unalienable and fundamental rights, which in forming the
social compact, ought to be explicitly ascertained and fixed — a free and
enlightened people, in forming this compact, will not resign all their rights
to those who govern, and they will fix limits to their legislators and rulers,
which will soon be plainly seen by those who are governed, as well as by those
who govern: and the latter will know they cannot be passed unperceived by the
former, and without giving a general alarm — These rights should be made
the basis of every constitution: and if a people be so situated, or have such
different opinions that they cannot agree in ascertaining and fixing them, it
is a very strong argument against their attempting to form one entire society,
to live under one system of laws only. — I confess, I never thought the
people of these states differed essentially in these respects; they having
derived all these rights from one common source, the British systems; and
having in the formation of their state constitutions, discovered that their
ideas relative to these rights are very similar. However, it is now said that
the states differ so essentially in these respects, and even in the important
article of the trial by jury, that when assembled in convention, they can agree
to no words by which to establish that trial, or by which to ascertain and
establish many other of these rights, as fundamental articles in the social
compact. If so, we proceed to consolidate the states on no solid basis
whatever. But I do not pay much regard to the reasons given for not bottoming the new
constitution on a better bill of rights. I still believe a complete federal
bill of rights to be very practicable. Nevertheless I acknowledge the
proceedings of the convention furnish my mind with many new and strong reasons,
against a complete consolidation of the states.

--- chunk_id: chunk-0244
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 430
content_hash: bfc13eea4a7113c6
prev_chunk_id: chunk-0243
next_chunk_id: chunk-0245
section_heading: Federal Farmer II
document_type: specification

I still believe a complete federal
bill of rights to be very practicable. Nevertheless I acknowledge the
proceedings of the convention furnish my mind with many new and strong reasons,
against a complete consolidation of the states. They tend to convince me, that
it cannot be carried with propriety very far — that the convention have
gone much farther in one respect than they found it practicable to go in
another; that is, they propose to lodge in the general government very
extensive powers — powers nearly, if not altogether, complete and
unlimited, over the purse and the sword. But, in its organization, they furnish
the strongest proof that the proper limbs, or parts of a government, to support
and execute those powers on proper principles (or in which they can be safely
lodged) cannot be formed. These powers must be lodged somewhere in every
society; but then they should be lodged where the strength and guardians of the
people are collected. They can be wielded, or safely used, in a free country
only by an able executive and judiciary, a respectable senate, and a secure,
full, and equal representation of the people. I think the principles I have
premised or brought into view, are well founded — I think they will not be
denied by any fair reasoner. It is in connection with these, and other solid
principles, we are to examine the constitution. It is not a few democratic
phrases, or a few well formed features, that will prove its merits; or a few
small omissions that will produce its rejection among men of sense; they will
enquire what are the essential powers in a community, and what are nominal
ones; where and how the essential powers shall be lodged to secure government,
and to secure true liberty. In examining the proposed constitution carefully, we must clearly perceive
an unnatural separation of these powers from the substantial representation of
the people.

--- chunk_id: chunk-0245
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 434
content_hash: 31d01c774372f390
prev_chunk_id: chunk-0244
next_chunk_id: chunk-0246
section_heading: Federal Farmer II
document_type: specification

It is not a few democratic
phrases, or a few well formed features, that will prove its merits; or a few
small omissions that will produce its rejection among men of sense; they will
enquire what are the essential powers in a community, and what are nominal
ones; where and how the essential powers shall be lodged to secure government,
and to secure true liberty. In examining the proposed constitution carefully, we must clearly perceive
an unnatural separation of these powers from the substantial representation of
the people. The state governments will exist, with all their governors,
senators, representatives, officers and expences; in these will be
nineteen-twentieths of the representatives of the people; they will have a near
connection, and their members an immediate intercourse with the people; and the
probability is, that the state governments will possess the confidence of the
people, and be considered generally as their immediate guardians. The general government will consist of a new species of executive, a small
senate, and a very small house of representatives. As many citizens will be
more than three hundred miles from the seat of this government as will be
nearer to it, its judges and officers cannot be very numerous, without making
our governments very expensive. Thus will stand the state and the general
governments, should the constitution be adopted without any alterations in
their organization; but as to powers, the general government will possess all
essential ones, at least on paper, and those of the states a mere shadow of
power. And therefore, unless the people shall make some great exertions to
restore to the state governments their powers in matters of internal police; as
the powers to lay and collect, exclusively, internal taxes, to govern the
militia, and to hold the decisions of their own judicial courts upon their own
laws final, the balance cannot possibly continue long; but the state
governments must be annihilated, or continue to exist for no purpose.

--- chunk_id: chunk-0246
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 405
content_hash: dcac1db54e2f9ed6
prev_chunk_id: chunk-0245
next_chunk_id: chunk-0247
section_heading: Federal Farmer II
document_type: specification

Thus will stand the state and the general
governments, should the constitution be adopted without any alterations in
their organization; but as to powers, the general government will possess all
essential ones, at least on paper, and those of the states a mere shadow of
power. And therefore, unless the people shall make some great exertions to
restore to the state governments their powers in matters of internal police; as
the powers to lay and collect, exclusively, internal taxes, to govern the
militia, and to hold the decisions of their own judicial courts upon their own
laws final, the balance cannot possibly continue long; but the state
governments must be annihilated, or continue to exist for no purpose. It is however to be observed, that many of the essential powers given the
national government are not exclusively given; and the general government may
have prudence enough to forbear the exercise of those which may still be
exercised by the respective states. But this cannot justify the impropriety of
giving powers, the exercise of which prudent men will not attempt, and
imprudent men will, or probably can, exercise only in a manner destructive of
free government. The general government, organized as it is, may be adequate to
many valuable objects, and be able to carry its laws into execution on proper
principles in several cases; but I think its wannest friends will not contend,
that it can carry all the powers proposed to be lodged in it into effect,
without calling to its aid a military force, which must very soon destroy all
elective governments in the country, produce anarchy, or establish despotism. Though we cannot have now a complete idea of what will be the operations of the
proposed system, we may, allowing things to have their common course, have a
very tolerable one.

--- chunk_id: chunk-0247
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 416
content_hash: c862a8f7914e3a42
prev_chunk_id: chunk-0246
next_chunk_id: chunk-0248
section_heading: Federal Farmer II
document_type: specification

The general government, organized as it is, may be adequate to
many valuable objects, and be able to carry its laws into execution on proper
principles in several cases; but I think its wannest friends will not contend,
that it can carry all the powers proposed to be lodged in it into effect,
without calling to its aid a military force, which must very soon destroy all
elective governments in the country, produce anarchy, or establish despotism. Though we cannot have now a complete idea of what will be the operations of the
proposed system, we may, allowing things to have their common course, have a
very tolerable one. The powers lodged in the general government, if exercised
by it, must intimately effect the internal police of the states, as well as
external concerns; and there is no reason to expect the numerous state
governments, and their connections, will be very friendly to the execution of
federal laws in those internal affairs, which hitherto have been under their
own immediate management. There is more reason to believe, that the general
government, far removed from the people, and none of its members elected
oftener than once in two years, will be forgot or neglected, and its laws in
many cases disregarded, unless a multitude of officers and military force be
continually kept in view, and employed to enforce the execution of the laws,
and to make the government feared and respected. No position can be truer than
this, that in this country either neglected laws, or a military execution of
them, must lead to a revolution, and to the destruction of freedom. Neglected
laws must first lead to anarchy and confusion; and a military execution of laws
is only a shorter way to the same point — despotic government. Your's, &c. The Federal Farmer. Text Version | Next | Previous | Contents |

--- chunk_id: chunk-0248
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 450
content_hash: 33bafd111df0e5a6
prev_chunk_id: chunk-0247
next_chunk_id: chunk-0249
section_heading: Federal Farmer III
document_type: specification

## Federal Farmer III

*Source file: fedfar03.htm (constitution.org AFP collection)*

Letters from the Federal Farmer to the Republican: #03



 

Letters from the Federal Farmer to the Republican


III


October 10th, 1787. Dear Sir,


The great object of a free people must be so to form their government and
laws, and so to administer them, as to create a confidence in, and respect for
the laws; and thereby induce the sensible and virtuous part of the community to
declare in favor of the laws, and to support them without an expensive military
force. I wish, though I confess I have not much hope, that this may be the case
with the laws of congress under the new constitution. I am fully convinced that
we must organize the national government on different principals, and make the
parts of it more efficient, and secure in it more effectually the different
interests in the community; or else leave in the state governments some powers
propose[d] to be lodged in it — at least till such an organization shall
be found to be practicable. Not sanguine in my. expectations of a good federal
administration, and satisfied, as I am, of the impracticability of
consolidating the states, and at the same time of preserving the rights of the
people at large, I believe we ought still to leave some of those powers in the
state governments, in which the people, in fact, will still be represented
— to define some other powers proposed to be vested in the general
government, more carefully, and to establish a few principles to secure a
proper exercise of the powers given it. It is not my object to multiply
objections, or to contend about inconsiderable powers or amendments; I wish the
system adopted with a few alterations; but those, in my mind, are essential
ones; if adopted without, every good citizen will acquiesce though I shall
consider the duration of our governments, and the liberties of this people,
very much dependant on the administration of the general government.

--- chunk_id: chunk-0249
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 424
content_hash: 5c2c1be760f28796
prev_chunk_id: chunk-0248
next_chunk_id: chunk-0250
section_heading: Federal Farmer III
document_type: specification

expectations of a good federal
administration, and satisfied, as I am, of the impracticability of
consolidating the states, and at the same time of preserving the rights of the
people at large, I believe we ought still to leave some of those powers in the
state governments, in which the people, in fact, will still be represented
— to define some other powers proposed to be vested in the general
government, more carefully, and to establish a few principles to secure a
proper exercise of the powers given it. It is not my object to multiply
objections, or to contend about inconsiderable powers or amendments; I wish the
system adopted with a few alterations; but those, in my mind, are essential
ones; if adopted without, every good citizen will acquiesce though I shall
consider the duration of our governments, and the liberties of this people,
very much dependant on the administration of the general government. A wise and
honest administration, may make the people happy under any government; but
necessity only can justify even our leaving open avenues to the abuse of power,
by wicked, unthinking, or ambitious men. I will examine, first, the
organization of the proposed government, in order to judge; 2d, with propriety,
what powers are improperly, at least prematurely lodged in it. I shall examine,
3d, the undefined powers; and 4th, those powers, the exercise of which is not
secured on safe and proper ground. First. As to the organization — the house of representatives, the
democrative branch, as it is called, is to consist of 65 members: that is,
about one representative for fifty thousand inhabitants, to be chosen
biennially — the federal legislature may increase this number to one for
each thirty thousand inhabitants, abating fractional numbers in each state. — Thirty-three representatives will make a quorum for doing business, and
a majority of those present determine the sense of the house.

--- chunk_id: chunk-0250
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 413
content_hash: 796eef89b591eaef
prev_chunk_id: chunk-0249
next_chunk_id: chunk-0251
section_heading: Federal Farmer III
document_type: specification

As to the organization — the house of representatives, the
democrative branch, as it is called, is to consist of 65 members: that is,
about one representative for fifty thousand inhabitants, to be chosen
biennially — the federal legislature may increase this number to one for
each thirty thousand inhabitants, abating fractional numbers in each state. — Thirty-three representatives will make a quorum for doing business, and
a majority of those present determine the sense of the house. — I have no
idea that the interests, feelings, and opinions of three or four millions of
people, especially touching internal taxation, can be collected in such a
house. — In the nature of things, nine times in ten, men of the elevated
classes in the community only can be chosen — Connecticut, for instance,
will have five representatives — not one man in a hundred of those who
form the democrative branch in the state legislature, will, on a fair
computation, be one of the five — The people of this country, in one
sense, may all be democratic; but if we make the proper distinction between the
few men of wealth and abilities, and consider them, as we ought, as the natural
aristocracy of the country, and the great body of the people, the middle and
lower classes, as the democracy, this federal representative branch will have
but very little democracy in it, even this small representation is not secured
on proper principles. — The branches of the legislature are essential
parts of the fundamental compact, and ought to be so fixed by the people, that
the legislature cannot alter itself by modifying the elections of its own
members. This, by a part of Art. 1. Sect. 4. the general legislature may do, it
may evidently so regulate elections as to secure the choice of any particular
description of men.

--- chunk_id: chunk-0251
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 306
content_hash: c1f976a1f6373989
prev_chunk_id: chunk-0250
next_chunk_id: chunk-0252
section_heading: Federal Farmer III
document_type: specification

4. the general legislature may do, it
may evidently so regulate elections as to secure the choice of any particular
description of men. — It may make the whole state one district — make
the capital, or any places in the state, the place or places of election —
it may declare that the five men (or whatever the number may be the state may
chuse) who shall have the most votes shall be considered as chosen — In
this case it is easy to perceive how the people who live scattered in the
inland towns will bestow their votes on different men — and how a few men
in a city, in any order or profession, may unite and place any five men they
please highest among those that may be voted for — and all this may be
done constitutionally, and by those silent operations, which are not
immediately perceived by the people in general. — I know it is urged, that
the general legislature will be disposed to regulate elections on fair and just
principles: — This may be true — good men will generally govern well
with almost any constitution: but why in laying the foundation of the social
system, need we unnecessarily leave a door open to improper regulations? —
This is a very general and unguarded clause, and many evils may flow from that

--- chunk_id: chunk-0252
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 440
content_hash: 889a5e86d231bfb7
prev_chunk_id: chunk-0251
next_chunk_id: chunk-0253
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

part which authorises the congress to regulate elections — Were it
omitted, the regulations of elections would be solely in the respective states,
where the people are substantially represented; and where the elections ought
to be regulated, otherwise to secure a representation from all parts of the
community, in making the constitution, we ought to provide for dividing each
state into a proper number of districts, and for confining the electors in each
district to the choice of some men, who shall have a permanent interest and
residence in it; and also for this essential object, that the representative
elected shall have a majority of the votes of those electors who shall attend
and give their votes. In considering the practicability of having a full and equal representation
of the people from all parts of the union, not only distances and different
opinions, customs, and views, common in extensive tracts of country, are to be
taken into view, but many differences peculiar to Eastern, Middle, and Southern
states. These differences are not so perceivable among the members of congress,
and men of general information in the states, as among the men who would
properly form the democratic branch. The Eastern states are very democratic,
and composed chiefly of moderate freeholders; they have but few rich men and no
slaves; the Southern states are composed chiefly of rich planters and slaves;
they have but few moderate freeholders, and the prevailing influence, in them,
is generally a dissipated aristocracy: The Middle states partake partly of the
Eastern, and partly of the Southern character. Perhaps, nothing could be more disjointed, unweildly and incompetent to
doing business with harmony and dispatch, than a federal house of
representatives properly numerous for the great objects of taxation, et cetera
collected from the several states; whether such men would ever act in concert;
whether they would not worry along a few years, and then be the means of
separating the parts of the union, is very problematical?

--- chunk_id: chunk-0253
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 374
content_hash: b60e156b11dc02da
prev_chunk_id: chunk-0252
next_chunk_id: chunk-0254
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

The Eastern states are very democratic,
and composed chiefly of moderate freeholders; they have but few rich men and no
slaves; the Southern states are composed chiefly of rich planters and slaves;
they have but few moderate freeholders, and the prevailing influence, in them,
is generally a dissipated aristocracy: The Middle states partake partly of the
Eastern, and partly of the Southern character. Perhaps, nothing could be more disjointed, unweildly and incompetent to
doing business with harmony and dispatch, than a federal house of
representatives properly numerous for the great objects of taxation, et cetera
collected from the several states; whether such men would ever act in concert;
whether they would not worry along a few years, and then be the means of
separating the parts of the union, is very problematical? — View this
system in whatever form we can, propriety brings us still to this point, a
federal government possessed of general and complete powers, as to those
national objects which cannot well come under the cognizance of the internal
laws of the respective states, and this federal government, accordingly,
consisting of branches not very numerous. The house of representatives is on the plan of consolidation, but the senate
is intirely on the federal plan; and Delaware will have as much constitutional
influence in the senate, as the largest state in the union: and in this senate
are lodged legislative, executive and judicial powers: Ten states in this union
urge that they are small states, nine of which were present in the convention. — They were interested in collecting large powers into the hands of the
senate, in which each state still will have its equal share of power.

--- chunk_id: chunk-0254
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: 57c0878e6e00c1fa
prev_chunk_id: chunk-0253
next_chunk_id: chunk-0255
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

The house of representatives is on the plan of consolidation, but the senate
is intirely on the federal plan; and Delaware will have as much constitutional
influence in the senate, as the largest state in the union: and in this senate
are lodged legislative, executive and judicial powers: Ten states in this union
urge that they are small states, nine of which were present in the convention. — They were interested in collecting large powers into the hands of the
senate, in which each state still will have its equal share of power. I suppose
it was impracticable for the three large states, as they were called, to get
the senate formed on any other principles: But this only proves, that we cannot
form one general government on equal and just principles — and proves,
that we ought not to lodge in it such extensive powers before we are convinced
of the practicability of organizing it on just and equal principles. The senate
will consist of two members from each state, chosen by the state legislatures,
every sixth year. The clause referred to, respecting the elections of
representatives, empowers the general legislature to regulate the elections of
senators also, "except as to the places of chusing senators." —
There is, therefore, but little more security in the elections than in those of
representatives: Fourteen senators make a quorum for business, and a majority
of the senators present give the vote of the senate, except in giving judgment
upon an impeachment, or in making treaties, or in expelling a member, when
two-thirds of the senators present must agree — The members of the
legislature are not excluded from being elected to any military offices, or any
civil offices, except those created, or the emoluments of which shall be
increased by themselves: two-thirds of the members present, of either house,
may expel a member at pleasure.

--- chunk_id: chunk-0255
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 380
content_hash: 37f632499d853342
prev_chunk_id: chunk-0254
next_chunk_id: chunk-0256
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

The senate
will consist of two members from each state, chosen by the state legislatures,
every sixth year. The clause referred to, respecting the elections of
representatives, empowers the general legislature to regulate the elections of
senators also, "except as to the places of chusing senators." —
There is, therefore, but little more security in the elections than in those of
representatives: Fourteen senators make a quorum for business, and a majority
of the senators present give the vote of the senate, except in giving judgment
upon an impeachment, or in making treaties, or in expelling a member, when
two-thirds of the senators present must agree — The members of the
legislature are not excluded from being elected to any military offices, or any
civil offices, except those created, or the emoluments of which shall be
increased by themselves: two-thirds of the members present, of either house,
may expel a member at pleasure. The senate is an independant branch of the
legislature, a court for trying impeachments, and also a part of the executive,
having a negative in the making of all treaties, and in appointing almost all
officers. The vice president is not a very important, if not an unncessary part of the
system — he may be a part of the senate at one period, and act as the
supreme executive magistrate at another — The election of this officer, as
well as of the president of the United States seems to be properly secured; but
when we examine the powers of the president, and the forms of the executive, we
shall perceive that the general government, in this part, will have a strong
tendency to aristocracy, or the government of the few.

--- chunk_id: chunk-0256
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 362
content_hash: f52e5a39d786955e
prev_chunk_id: chunk-0255
next_chunk_id: chunk-0257
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

The senate is an independant branch of the
legislature, a court for trying impeachments, and also a part of the executive,
having a negative in the making of all treaties, and in appointing almost all
officers. The vice president is not a very important, if not an unncessary part of the
system — he may be a part of the senate at one period, and act as the
supreme executive magistrate at another — The election of this officer, as
well as of the president of the United States seems to be properly secured; but
when we examine the powers of the president, and the forms of the executive, we
shall perceive that the general government, in this part, will have a strong
tendency to aristocracy, or the government of the few. The executive is, in
fact, the president and senate in all transactions of any importance; the
president is connected with, or tied to the senate; he may always act with the
senate, but never can effectually counteract its views: The president can
appoint no officer, civil or military, who shall not be agreeable to the
senate; and the presumption is, that the will of so important a body will not
be very easily controuled, and that it will exercise its powers with great
address. In the judicial department, powers ever kept distinct in well balanced
governments, are no less improperly blended in the hands of the same men —
in the judges of the supreme court is lodged, the law, the equity and the fact. It is not necessary to pursue the minute organical parts of the general
government proposed.

--- chunk_id: chunk-0257
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 390
content_hash: 26cc1454502fa8be
prev_chunk_id: chunk-0256
next_chunk_id: chunk-0258
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

In the judicial department, powers ever kept distinct in well balanced
governments, are no less improperly blended in the hands of the same men —
in the judges of the supreme court is lodged, the law, the equity and the fact. It is not necessary to pursue the minute organical parts of the general
government proposed. — There were various interests in the convention, to
be reconciled, especially of large and small states; of carrying and
non-carrying states; and of states more and states less democratic — vast
labour and attention were by the convention bestowed on the organization of the
parts of the constitution offered; still it is acknowledged there are many
things radically wrong in the essential parts of this constitution — but
it is said that these are the result of our situation: On a full examination of
the subject, I believe it; but what do the laborious inquiries and
determinations of the convention prove? If they prove any thing, they prove
that we cannot consolidate the states on proper principles: The organization of
the government presented proves, that we cannot form a general government in
which all power can be safely lodged; and a little attention to the parts of
the one proposed will make it appear very evident, that all the powers proposed
to be lodged in it, will not be then well deposited, either for the purposes of
government, or the preservation of liberty. I will suppose no abuse of powers
in those cases, in which the abuse of it is not well guarded against — I
will suppose the words authorising the general government to regulate the
elections of its own members struck out of the plan, or free district
elections, in each state, amply secured.

--- chunk_id: chunk-0258
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 433
content_hash: f463f4e5afa1cda8
prev_chunk_id: chunk-0257
next_chunk_id: chunk-0259
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

If they prove any thing, they prove
that we cannot consolidate the states on proper principles: The organization of
the government presented proves, that we cannot form a general government in
which all power can be safely lodged; and a little attention to the parts of
the one proposed will make it appear very evident, that all the powers proposed
to be lodged in it, will not be then well deposited, either for the purposes of
government, or the preservation of liberty. I will suppose no abuse of powers
in those cases, in which the abuse of it is not well guarded against — I
will suppose the words authorising the general government to regulate the
elections of its own members struck out of the plan, or free district
elections, in each state, amply secured. — That the small representation
provided for shall be as fair and equal as it is capable of being made — I
will suppose the judicial department regulated on pure principles, by future
laws, as far as it can be by the constitution, and consistent] with the
situation of the country — still there will be an unreasonable
accumulation of powers in the general government, if all be granted, enumerated
in the plan proposed. The plan does not present a well balanced government. The
senatorial branch of the legislative and the executive are substantially
united, and the president, or the first executive magistrate, may aid the
senatorial interest when weakest, but never can effectually support the
democratic[,] however it may be oppressed; — the excellency, in my mind,
of a well balanced government is that it consists of distinct branches, each
sufficiently strong and in-dependant to keep its own station, and to aid either
of the other branches which may occasionally want aid. The convention found that any but a small house of representatives would be
expensive, and that it would be impracticable to assemble a large number of
representatives.

--- chunk_id: chunk-0259
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 422
content_hash: 37329237f69c8a04
prev_chunk_id: chunk-0258
next_chunk_id: chunk-0260
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

The
senatorial branch of the legislative and the executive are substantially
united, and the president, or the first executive magistrate, may aid the
senatorial interest when weakest, but never can effectually support the
democratic[,] however it may be oppressed; — the excellency, in my mind,
of a well balanced government is that it consists of distinct branches, each
sufficiently strong and in-dependant to keep its own station, and to aid either
of the other branches which may occasionally want aid. The convention found that any but a small house of representatives would be
expensive, and that it would be impracticable to assemble a large number of
representatives. Not only the determination of the convention in this case, but
the situation of the states, proves the impracticability of collecting, in any
one point, a proper representation. The formation of the senate, and the smallness of the house, being,
therefore, the result of our situation, and the actual state of things, the
evils which may attend the exercise of many powers in this national government
may be considered as without a remedy. All officers are impeachable before the senate only — before the men by
whom they are appointed, or who are consenting to the appointment of these
officers. No judgment of conviction, on an impeachment, can be given unless two
thirds of the senators agree. Under these circumstances the right of
impeachment, in the house, can be of but little importance; the house cannot
expect often to convict the offender; and, therefore, probably, will but seldom
or never exercise the right. In addition to the insecurity and inconveniences
attending this organization beforementioned, it may be observed, that it is
extremely difficult to secure the people against the fatal effects of
corruption and influence. The power of making any law will be in the president,
eight senators, and seventeen representatives, relative to the important
objects enumerated in the constitution.

--- chunk_id: chunk-0260
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 436
content_hash: 8657f3f8154078e0
prev_chunk_id: chunk-0259
next_chunk_id: chunk-0261
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

In addition to the insecurity and inconveniences
attending this organization beforementioned, it may be observed, that it is
extremely difficult to secure the people against the fatal effects of
corruption and influence. The power of making any law will be in the president,
eight senators, and seventeen representatives, relative to the important
objects enumerated in the constitution. Where there is a small representation a
sufficient number to carry any measure, may, with ease, be influenced by
bribes, offices and civilities; they may easily form private juntoes, and out
door meetings, agree on measures, and carry them by silent votes. Impressed, as I am, with a sense of the difficulties there are in the way of
forming the parts of a federal government on proper principles, and seeing a
government so unsubstantially organized, after so arduous an attempt has been
made, I am led to believe, that powers ought to be given to it with great care
and caution. In the second place it is necessary, therefore, to examine the extent, and
the probable operations of some of those extensive powers proposed to be vested
in this government. These powers, legislative, executive, and judicial, respect
internal as well as external objects. Those respecting external objects, as all
foreign concerns, commerce, imposts, all causes arising on the seas, peace and
war, and Indian affairs, can be lodged no where else, with any propriety, but
in this government. Many powers that respect internal objects ought clearly to
be lodged in it; as those to regulate trade between the states, weights and
measures, the coin or current monies, post-offices, naturalization, etc. These
powers may be exercised without essentially effecting the internal police of
the respective states: But powers to lay and collect internal taxes, to form
the militia, to make bankrupt laws, and to decide on appeals, questions arising
on the internal laws of the respective states, are of a very serious nature,
and carry with them almost all other powers.

--- chunk_id: chunk-0261
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 450
content_hash: 4be25998825bcbe3
prev_chunk_id: chunk-0260
next_chunk_id: chunk-0262
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

Many powers that respect internal objects ought clearly to
be lodged in it; as those to regulate trade between the states, weights and
measures, the coin or current monies, post-offices, naturalization, etc. These
powers may be exercised without essentially effecting the internal police of
the respective states: But powers to lay and collect internal taxes, to form
the militia, to make bankrupt laws, and to decide on appeals, questions arising
on the internal laws of the respective states, are of a very serious nature,
and carry with them almost all other powers. These taken in connection with the
others, and powers to raise armies and build navies, proposed to be lodged in
this government, appear to me to comprehend all the essential powers in the
community, and those which will be left to the states will be of no great
importance. A power to lay and collect taxes at discretion, is, in itself, of very great
importance. By means of taxes, the government may command the whole or any part
of the subject's property. Taxes may be of various kinds; but there is a strong
distinction between external and internal taxes. External taxes are impost
duties, which are laid on imported goods; they may usually be collected in a
few seaport towns, and of a few individuals, though ultimately paid by the
consumer; a few officers can collect them, and they can be carried no higher
than trade will bear, or smuggling permit — that in the very nature of
commerce, bounds are set to them. But internal taxes, as poll and land taxes,
excises, duties on all written instruments, etc. may fix themselves on every
person and species of property in the community; they may be carried to any
lengths, and in proportion as they are extended, numerous officers must be
employed to assess them, and to enforce the collection of them. In the United
Netherlands the general government has compleat powers, as to external
taxation; but as to internal taxes, it makes requisitions on the provinces.

--- chunk_id: chunk-0262
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 406
content_hash: df31b86739bf19a1
prev_chunk_id: chunk-0261
next_chunk_id: chunk-0263
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

may fix themselves on every
person and species of property in the community; they may be carried to any
lengths, and in proportion as they are extended, numerous officers must be
employed to assess them, and to enforce the collection of them. In the United
Netherlands the general government has compleat powers, as to external
taxation; but as to internal taxes, it makes requisitions on the provinces. Internal taxation in this country is more important, as the country is so very
extensive. As many assessors and collectors of federal taxes will be above
three hundred miles from the seat of the federal government as will be less. Besides, to lay and collect internal taxes, in this extensive country, must
require a great number of congressional ordinances, immediately operating upon
the body of the people; these must continually interfere with the state laws,
and thereby produce disorder and general dissatisfaction, till the one system
of laws or the other, operating upon the same subjects, shall be abolished. These ordinances alone, to say nothing of those respecting the militia, coin,
commerce, federal judiciary, etc. etc. will probably soon defeat the operations
of the state laws and governments. Should the general government think it politic, as some administrations (if
not all) probably will, to look for a support in a system of influence, the
government will take every occasion to multiply laws, and officers to execute
them, considering these as so many necessary props for its own support. Should
this system of policy be adopted, taxes more productive than the impost duties
will, probably, be wanted to support the government, and to discharge foreign
demands, without leaving any thing for the domestic creditors. The internal
sources of taxation then must be called into operation, and internal tax laws
and federal assessors and collectors spread over this immense country.

--- chunk_id: chunk-0263
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 438
content_hash: e85636c8cb668dd1
prev_chunk_id: chunk-0262
next_chunk_id: chunk-0264
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

Should
this system of policy be adopted, taxes more productive than the impost duties
will, probably, be wanted to support the government, and to discharge foreign
demands, without leaving any thing for the domestic creditors. The internal
sources of taxation then must be called into operation, and internal tax laws
and federal assessors and collectors spread over this immense country. All
these circumstances considered, is it wise, prudent, or safe, to vest the
powers of laying and collecting internal taxes in the general government, while
imperfectly organized and inadequate; and to trust to amending it hereafter,
and making it adequate to this purpose? It is not only unsafe but absurd to
lodge power in a government before it is fitted to receive it? [Sic.] It
is confessed that this power and representation ought to go together. Why give
the power first? Why give the power to the few, who, when possessed of it, may
have address enough to prevent the increase of representation? Why not keep the
power, and, when necessary, amend the constitution, and add to its other parts
this power, and a proper increase of representation at the same time? Then men
who may want the power will be under strong inducements to let in the people,
by their representatives, into the government, to hold their due proportion of
this power. If a proper representation be impracticable, then we shall see this
power resting in the states, where it at present ought to be, and not
inconsiderately given up. When I recollect how lately congress, conventions, legislatures, and people
contended in the cause of liberty, and carefully weighed the importance of
taxation, I can scarcely believe we are serious in proposing to vest the powers
of laying and collecting internal taxes in a government so imperfectly
organized for such purposes. Should the United States be taxed by a house of
representatives of two hundred members, which would be about fifteen members
for Connecticut, twenty-five for Massachusetts, etc.

--- chunk_id: chunk-0264
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 434
content_hash: e412067ac03aedd8
prev_chunk_id: chunk-0263
next_chunk_id: chunk-0265
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

When I recollect how lately congress, conventions, legislatures, and people
contended in the cause of liberty, and carefully weighed the importance of
taxation, I can scarcely believe we are serious in proposing to vest the powers
of laying and collecting internal taxes in a government so imperfectly
organized for such purposes. Should the United States be taxed by a house of
representatives of two hundred members, which would be about fifteen members
for Connecticut, twenty-five for Massachusetts, etc. still the middle and lower
classes of people could have no great share, in fact, in taxation. I am aware
it is said, that the representation proposed by the new constitution is
sufficiently numerous; it may be for many purposes; but to suppose that this
branch is sufficiently numerous to guard the rights of the people in the
administration of the government, in which the purse and sword is placed, seems
to argue that we have forgot what the true meaning of representation is. I am
sensible also, that it is said that congress will not attempt to lay and
collect internal taxes; that it is necessary for them to have the power, though
it cannot probably be exercised. — I admit that it is not probable that
any prudent congress will attempt to lay and collect internal taxes, especially
direct taxes: but this only proves, that the power would be improperly lodged
in congress, and that it might be abused by imprudent and designing men. I have heard several gentlemen, to get rid of objections to this part of the
constitution, attempt to construe the powers relative to direct taxes, as those
who object to it would have them; as to these, it is said, that congress will
only have power to make requisitions, leaving it to the states to lay and
collect them. I see but very little colour for this construction, and the
attempt only proves that this part of the plan cannot be defended.

--- chunk_id: chunk-0265
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 308
content_hash: 7d3a9bb9262aaf60
prev_chunk_id: chunk-0264
next_chunk_id: chunk-0266
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

I have heard several gentlemen, to get rid of objections to this part of the
constitution, attempt to construe the powers relative to direct taxes, as those
who object to it would have them; as to these, it is said, that congress will
only have power to make requisitions, leaving it to the states to lay and
collect them. I see but very little colour for this construction, and the
attempt only proves that this part of the plan cannot be defended. By this plan
there can be no doubt, but that the powers of congress will be complete as to
all kinds of taxes whatever — Further, as to internal taxes, the state
governments will have concurrent powers with the general government, and both
may tax the same objects in the same year; and the objection that the general
government may suspend a state tax, as a necessary measure for the promoting
the collection of a federal tax, is not without foundation. — As the
states owe large debts, and have large demands upon them individually, there
clearly would be a propriety in leaving in their possession exclusively, some
of the internal sources of taxation, at least until the federal representation
shall be properly encreased: The power in the general government to lay and
collect internal taxes, will render its powers respecting armies, navies and
the militia, the more exceptionable.

--- chunk_id: chunk-0266
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 413
content_hash: f278d61e919c641d
prev_chunk_id: chunk-0265
next_chunk_id: chunk-0267
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

By this plan
there can be no doubt, but that the powers of congress will be complete as to
all kinds of taxes whatever — Further, as to internal taxes, the state
governments will have concurrent powers with the general government, and both
may tax the same objects in the same year; and the objection that the general
government may suspend a state tax, as a necessary measure for the promoting
the collection of a federal tax, is not without foundation. — As the
states owe large debts, and have large demands upon them individually, there
clearly would be a propriety in leaving in their possession exclusively, some
of the internal sources of taxation, at least until the federal representation
shall be properly encreased: The power in the general government to lay and
collect internal taxes, will render its powers respecting armies, navies and
the militia, the more exceptionable. By the constitution it is proposed that
congress shall have power "to raise and support armies, but no
appropriation of money to that use shall be for a longer term than two years;
to provide and maintain a navy; to provide for calling forth the militia to
execute the laws of the union, suppress insurrections, and repel invasions: to
provide for organizing, arming, and disciplining the militia: reserving to the
states the right to appoint the officers, and to train the militia according to
the discipline prescribed by congress; congress will have unlimited power to
raise armies, and to engage officers and men for any number of years; but a
legislative act applying money for their support can have operation for no
longer term than two years, and if a subsequent congress do not within the two
years renew the appropriation, or further appropriate monies for the use of the
army, the army will be left to take care of itself.

--- chunk_id: chunk-0267
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 444
content_hash: a28a92e0415a6923
prev_chunk_id: chunk-0266
next_chunk_id: chunk-0268
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

— As the
states owe large debts, and have large demands upon them individually, there
clearly would be a propriety in leaving in their possession exclusively, some
of the internal sources of taxation, at least until the federal representation
shall be properly encreased: The power in the general government to lay and
collect internal taxes, will render its powers respecting armies, navies and
the militia, the more exceptionable. By the constitution it is proposed that
congress shall have power "to raise and support armies, but no
appropriation of money to that use shall be for a longer term than two years;
to provide and maintain a navy; to provide for calling forth the militia to
execute the laws of the union, suppress insurrections, and repel invasions: to
provide for organizing, arming, and disciplining the militia: reserving to the
states the right to appoint the officers, and to train the militia according to
the discipline prescribed by congress; congress will have unlimited power to
raise armies, and to engage officers and men for any number of years; but a
legislative act applying money for their support can have operation for no
longer term than two years, and if a subsequent congress do not within the two
years renew the appropriation, or further appropriate monies for the use of the
army, the army will be left to take care of itself. When an army shall once be
raised for a number of years, it is not probable that it will find much
difficulty in getting congress to pass laws for applying monies to its support. I see so many men in America fond of a standing army, and especially among
those who probably will have a large share in administering the federal system;
it is very evident to me, that we shall have a large standing army as soon as
the monies to support them can be possibly found. An army is a very agreeable
place of employment for the young gentlemen of many families.

--- chunk_id: chunk-0268
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 442
content_hash: 890ae0ca1cdca047
prev_chunk_id: chunk-0267
next_chunk_id: chunk-0269
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

I see so many men in America fond of a standing army, and especially among
those who probably will have a large share in administering the federal system;
it is very evident to me, that we shall have a large standing army as soon as
the monies to support them can be possibly found. An army is a very agreeable
place of employment for the young gentlemen of many families. A power to raise
armies must be lodged some where; still this will not justify the lodging this
power in a bare majority of so few men without any checks; or in the government
in which the great body of the people, in the nature of things, will be only
nominally represented. In the state governments the great body of the people,
the yeomanry, etc. of the country, are represented: It is true they will chuse
the members of congress, and may now and then chuse a man of their own way of
thinking; but it is impossible for forty, or thirty thousand people in this
country, one time in ten to find a man who can possess similar feelings, views,
and interests with themselves: Powers to lay and collect taxes and to raise
armies are of the greatest moment; for carrying them into effect, laws need not
be frequently made, and the yeomanry, etc of the country ought substantially to
have a check upon the passing of these laws; this check ought to be placed in
the legislatures, or at least, in the few men the common people of the country,
will, probably, have in congress, in the true sense of the word, "from
among themselves." It is true, the yeomanry of the country possess the
lands, the weight of property, possess arms, and are tocr strong a body of men
to be openly offended — and, therefore, it is urged, they will take care
of themselves, that men who shall govern will not dare pay any disrespect to
their opinions.

--- chunk_id: chunk-0269
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 409
content_hash: b27ffdf73cd6dfaf
prev_chunk_id: chunk-0268
next_chunk_id: chunk-0270
section_heading: part which authorises the congress to regulate elections — Were it
document_type: specification

In the state governments the great body of the people,
the yeomanry, etc. of the country, are represented: It is true they will chuse
the members of congress, and may now and then chuse a man of their own way of
thinking; but it is impossible for forty, or thirty thousand people in this
country, one time in ten to find a man who can possess similar feelings, views,
and interests with themselves: Powers to lay and collect taxes and to raise
armies are of the greatest moment; for carrying them into effect, laws need not
be frequently made, and the yeomanry, etc of the country ought substantially to
have a check upon the passing of these laws; this check ought to be placed in
the legislatures, or at least, in the few men the common people of the country,
will, probably, have in congress, in the true sense of the word, "from
among themselves." It is true, the yeomanry of the country possess the
lands, the weight of property, possess arms, and are tocr strong a body of men
to be openly offended — and, therefore, it is urged, they will take care
of themselves, that men who shall govern will not dare pay any disrespect to
their opinions. It is easily perceived, that if they have not their proper
negative upon passing laws in congress, or on the passage of laws relative to
taxes and armies, they may in twenty or thirty years be by means imperceptible
to them, totally deprived of that boasted weight and strength: This may be done
in a great measure by congress, if disposed to do it, by modelling the militia. Should one fifth, or one eighth part of the men capable of bearing arms, be
made a select militia, as has been proposed, and those the young and ardent

--- chunk_id: chunk-0270
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 412
content_hash: ff652721c9693e59
prev_chunk_id: chunk-0269
next_chunk_id: chunk-0271
section_heading: part of the community, possessed of but little or no property, and all the
document_type: specification

part of the community, possessed of but little or no property, and all the
others put upon a plan that will render them of no importance, the former will
answer all the purposes of an army, while the latter will be defenceless. The
state must train the militia in such form and according to such systems and
rules as congress shall prescribe: and the only actual influence the respective
states will have respecting the militia will be in appointing the officers. I
see no provision made for calling out the posse commitatus for executing
the laws of the union, but provision is made for congress to call forth the
militia for the execution of them — and the militia in general, or any
select part of it, may be called out under military officers, instead of the
sheriff to enforce an execution of federal laws, in the first instance and
thereby introduce an entire military execution of the laws. I know that powers
to raise taxes, to regulate the military strength of the community on some
uniform plan, to provide for its defence and internal order, and for duly
executing the laws, must be lodged somewhere; but still we ought not so to
lodge them. as evidently to give one order of men in the community, undue
advantages over others; or commit the many to the mercy, prudence, and
moderation of the few. And so far as it may be necessary to lodge any of the
peculiar powers in the general government, a more safe exercise of them ought
to be secured, by requiring the consent of two-thirds or three-fourths of
congress thereto — until the federal representation can be increased, so
that the democratic members in congress may stand some tolerable chance of a
reasonable negative, in behalf of the numerous, important, and democratic part
of the community.

--- chunk_id: chunk-0271
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 386
content_hash: 825d8544aeacda09
prev_chunk_id: chunk-0270
next_chunk_id: chunk-0272
section_heading: part of the community, possessed of but little or no property, and all the
document_type: specification

as evidently to give one order of men in the community, undue
advantages over others; or commit the many to the mercy, prudence, and
moderation of the few. And so far as it may be necessary to lodge any of the
peculiar powers in the general government, a more safe exercise of them ought
to be secured, by requiring the consent of two-thirds or three-fourths of
congress thereto — until the federal representation can be increased, so
that the democratic members in congress may stand some tolerable chance of a
reasonable negative, in behalf of the numerous, important, and democratic part
of the community. I am not sufficiently acquainted with the laws and internal police of all
the states to discern fully, how general bankrupt laws, made by the union,
would effect them, or promote the public good. I believe the property of
debtors, in the several states, is held responsible for their debts in modes
and forms very different. If uniform bankrupt laws can be made without
producing real and substantial inconveniences, I wish them to be made by
congress. There are some powers proposed to be lodged in the general government in the
judicial department, I think very unnecessarily, I mean powers respecting
questions arising upon the internal laws of the respective states. It is proper
the federal judiciary should have powers co-extensive with the federal
legislature — that is, the power of deciding finally on the laws of the
union. By Art. 3. Sect. 2. the powers of the federal judiciary are extended
(among other things) to all cases between a state and citizens of another state
— between citizens of different states — between a state or the
citizens thereof, and foreign states, citizens or subjects.

--- chunk_id: chunk-0272
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 382
content_hash: fe8f00e18c082bef
prev_chunk_id: chunk-0271
next_chunk_id: chunk-0273
section_heading: part of the community, possessed of but little or no property, and all the
document_type: specification

2. the powers of the federal judiciary are extended
(among other things) to all cases between a state and citizens of another state
— between citizens of different states — between a state or the
citizens thereof, and foreign states, citizens or subjects. Actions in all
these cases, except against a state government, are now brought and finally
determined in the law courts of the states respectively; and as there are no
words to exclude these courts of their jurisdiction in these cases, they will
have concurrent jurisdiction with the inferior federal courts in them; and,
therefore, if the new constitution be adopted without any amendment in this
respect, all those numerous actions, now brought in the state courts between
our citizens and foreigners, between citizens of different states, by state
governments against foreigners, and by state governments against citizens of
other states, may also be brought in the federal courts; and an appeal will lay
in them from the state courts, or federal inferior courts, to the supreme
judicial court of the union. In almost all these cases, either party may have
the trial by jury in the state courts; excepting paper money and tender laws,
which are wisely guarded against in the proposed constitution, justice may be
obtained in these courts on reasonable terms; they must be more competent to
proper decisions on the laws of their respective states, than the federal
courts can possibly be. I do not, in any point of view, see the need of opening
a new jurisdiction to these causes — of opening a new scene of expensive
law suits — of suffering foreigners, and citizens of different states, to
drag each other many hundred miles into the federal courts.

--- chunk_id: chunk-0273
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 430
content_hash: 1de130e623e5a088
prev_chunk_id: chunk-0272
next_chunk_id: chunk-0274
section_heading: part of the community, possessed of but little or no property, and all the
document_type: specification

In almost all these cases, either party may have
the trial by jury in the state courts; excepting paper money and tender laws,
which are wisely guarded against in the proposed constitution, justice may be
obtained in these courts on reasonable terms; they must be more competent to
proper decisions on the laws of their respective states, than the federal
courts can possibly be. I do not, in any point of view, see the need of opening
a new jurisdiction to these causes — of opening a new scene of expensive
law suits — of suffering foreigners, and citizens of different states, to
drag each other many hundred miles into the federal courts. It is true, those
courts may be so organized by a wise and prudent legislature, as to make the
obtaining of justice in them tolerably easy; they may in general be organized
on the common law principles of the country: But this benefit is by no means
secured by the constitution. The trial by jury is secured only in those few
criminal cases, to which the federal laws will extend — as crimes
committed on the seas, against the laws of nations, treason, and counterfeiting
the federal securities and coin: But even in these cases, the jury trial of the
vicinage is not secured — particularly in the large states, a citizen may
be tried for a crime committed in the state, and yet tried in some states 500
miles from the place where it was committed; but the jury trial is not secured
at all in civil causes. Though the convention have not established this trial,
it is to be hoped that congress, in putting the new system into execution, will
do it by a legislative act, in all cases in which it can be done with
propriety. Whether the jury trial is not excluded [from] the supreme judicial
court, is an important question. By Art. 3. Sect. 2.

--- chunk_id: chunk-0274
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 362
content_hash: ec49794b4e69b929
prev_chunk_id: chunk-0273
next_chunk_id: chunk-0275
section_heading: part of the community, possessed of but little or no property, and all the
document_type: specification

Sect. 2. all cases affecting
ambassadors, other public ministers, and consuls, and in those cases in which a
state shall be party, the supreme court shall have jurisdiction. In all the
other cases beforementioned, the supreme court shall have appellate
jurisdiction, both as to law and fact, with such exception, and under
such regulations, as the congress shall make. By court is understood a court
consisting of judges; and the idea of a jury is excluded. This court, or the
judges, are to have jurisdiction on appeals, in all the cases enumerated, as to
law and fact; the judges are to decide the law and try the fact, and the trial
of the fact being assigned to the judges by the constitution, a jury for trying
the fact is excluded; however, under the exceptions and powers to make
regulations, congress may, perhaps introduce the jury, to try the fact in most
necessary cases. There can be but one supreme court in which the final jurisdiction will
centre in all federal causes — except in cases where appeals by law shall
not be allowed: The judicial powers of the federal courts extends in law and
equity to certain cases: and, therefore, the powers to determine on the law, in
equity, and as to the fact, all will concentre in the supreme court: —
These powers, which by this constitution are blended in the same hands, the
same judges, are in Great-Britain deposited in different hands — to wit,
the decision of the law in the law judges, the decision in equity in the
chancellor, and the trial of the fact in the jury.

--- chunk_id: chunk-0275
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 414
content_hash: a1f7706ab1fa83f8
prev_chunk_id: chunk-0274
next_chunk_id: chunk-0276
section_heading: part of the community, possessed of but little or no property, and all the
document_type: specification

This court, or the
judges, are to have jurisdiction on appeals, in all the cases enumerated, as to
law and fact; the judges are to decide the law and try the fact, and the trial
of the fact being assigned to the judges by the constitution, a jury for trying
the fact is excluded; however, under the exceptions and powers to make
regulations, congress may, perhaps introduce the jury, to try the fact in most
necessary cases. There can be but one supreme court in which the final jurisdiction will
centre in all federal causes — except in cases where appeals by law shall
not be allowed: The judicial powers of the federal courts extends in law and
equity to certain cases: and, therefore, the powers to determine on the law, in
equity, and as to the fact, all will concentre in the supreme court: —
These powers, which by this constitution are blended in the same hands, the
same judges, are in Great-Britain deposited in different hands — to wit,
the decision of the law in the law judges, the decision in equity in the
chancellor, and the trial of the fact in the jury. It is a very dangerous thing
to vest in the same judge power to decide on the law, and also general powers
in equity; for if the law restrain him, he is only to step into his shoes of
equity, and give what judgment his reason or opinion may dictate; we have no
precedents in this country, as yet, to regulate the divisions in equity as in
Great Britain; equity, therefore, in the supreme court for many years will be
mere discretion. I confess in the constitution of this supreme court, as left
by the constitution, I do not see a spark of freedom or a shadow of our own or
the British common law.

--- chunk_id: chunk-0276
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 446
content_hash: 693910a8827784c0
prev_chunk_id: chunk-0275
next_chunk_id: chunk-0277
section_heading: part of the community, possessed of but little or no property, and all the
document_type: specification

It is a very dangerous thing
to vest in the same judge power to decide on the law, and also general powers
in equity; for if the law restrain him, he is only to step into his shoes of
equity, and give what judgment his reason or opinion may dictate; we have no
precedents in this country, as yet, to regulate the divisions in equity as in
Great Britain; equity, therefore, in the supreme court for many years will be
mere discretion. I confess in the constitution of this supreme court, as left
by the constitution, I do not see a spark of freedom or a shadow of our own or
the British common law. This court is to have appellate jurisdiction in all the other cases before
mentioned: Many sensible men suppose that cases before mentioned respect, as
well the criminal cases as the civil ones, mentioned antecedently in the
constitution, if so an appeal is allowed in criminal cases — contrary to
the usual sense of law. How far it may be proper to admit a foreigner or the
citizen of another state to bring actions against state governments, which have
failed in performing so many promises made during the war, is doubtful: How far
it may be proper so to humble a state, as to oblige it to answer to an
individual in a court of law, is worthy of consideration; the states are now
subject to no such actions; and this new jurisdiction will subject the states,
and many defendants to actions, and processes, which were not in the
contemplation of the parties, when the contract was made; all engagements
existing between citizens of different states, citizens and foreigners, states
and foreigners; and states and citizens of other states were made the parties
contemplating the remedies then existing on the laws of the states — and
the new remedy proposed to be given in the federal courts, can be founded on no
principle whatever. Your's &c. The Federal Farmer. Text Version

--- chunk_id: chunk-0277
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 16
content_hash: a45409fadd17a0bd
prev_chunk_id: chunk-0276
next_chunk_id: chunk-0278
section_heading: part of the community, possessed of but little or no property, and all the
document_type: specification

The Federal Farmer. Text Version | Next | Previous | Contents |

--- chunk_id: chunk-0278
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 441
content_hash: 5aa0972959ffba94
prev_chunk_id: chunk-0277
next_chunk_id: chunk-0279
section_heading: Agrippa (selections)
document_type: specification

## Agrippa (selections)

*Source file: agrippa.htm (constitution.org AFP collection)*

fall into two distinct sets, the first set (I-XI) were addressed to the people
of Massachusetts, the second (XII-XVI) to the Massachusetts Convention. I


23 November 1787


To the People. Many inconveniencies and difficulties in the new plan of government have
been mentioned by different writers on that subject. Mr Gerry has given the
publick his objections against it, with a manly freedom. The seceding members
from the Pennsylvania Assembly also published theirs. Various anonymous writers
have mentioned reasons of great weight. Among the many objections have been
stated the unlimited right of taxation — a standing army — an
inadequate representation of the people — a right to destroy the
constitution of the separate states, and all the barriers that have been set up
in defence of liberty — the right to try causes between private persons in
many cases without a jury; without trying in the vicinity of either party; and
without any limitation of the value which is to be tried. To none of these or
any other objections has any answer been given, but such as have acknowledged
the truth of the objection while they insulted the objector. This conduct has
much the appearance of trying to force a general sentiment upon the people. The idea of promoting the happiness of the people by opposing all their
habits of business, and by subverting the laws to which they are habituated,
appears to me to be at least a mistaken proceeding. If to this we add the
limitations of trade, restraints on its freedom, and the alteration of its
course, and transfer of the market, all under the pretence of regulation
for federal purposes, we shall not find any additional reason to be
pleased with the plan. It is now conceded on all sides that the laws relating to civil causes were
never better executed than at present. It is confessed by a warm federalist in
answer to mr.

--- chunk_id: chunk-0279
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 454
content_hash: 3c41868d3a207882
prev_chunk_id: chunk-0278
next_chunk_id: chunk-0280
section_heading: Agrippa (selections)
document_type: specification

It is now conceded on all sides that the laws relating to civil causes were
never better executed than at present. It is confessed by a warm federalist in
answer to mr. Gerry's sensible letter, that the courts are so arranged at
present that no inconvenience is found, and that if the new plan takes place
great difficulties may arise. With this confession before him, can any
reasonable man doubt whether he shall exchange a system, found by experience to
be convenient, for one that is in many respects inconvenient, and dangerous? The expense of the new plan is terrifying, if there was no other objection. But
they are multiplied. Let us consider that of the representation. There is to be one representative for every thirty thousand people. Boston
would nearly send one, but with regard to another there is hardly a county in
the state which would have one. The representatives are to be chosen for two
years. In this space, when it is considered that their residence is from two
hundred to five [hundred?] miles from their constituents, it is difficult to
suppose that they will retain any great affection for the welfare of the
people. They will have an army to support them, and may bid defiance to the
clamours of their subjects. Should the people cry aloud the representative may
avail himself of the right to alter the time of election and postpone it
for another year. In truth, the question before the people is, whether they
will have a limited government or an absolute one? It is a fact justified by the experience of all mankind from the earliest
antiquity down to the present time, that freedom is necessary to industry. We
accordingly find that in absolute governments, the people, be the climate what
it may, are [in] general lazy, cowardly, turbulent, and vicious to an extreme. On the other hand, in free countries are found in general, activity, industry,
arts, courage, generosity, and all the manly virtues. Can there be any doubt which to choose?

--- chunk_id: chunk-0280
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 452
content_hash: e61f1ff1b6407300
prev_chunk_id: chunk-0279
next_chunk_id: chunk-0281
section_heading: Agrippa (selections)
document_type: specification

On the other hand, in free countries are found in general, activity, industry,
arts, courage, generosity, and all the manly virtues. Can there be any doubt which to choose? He that hesitates must be base
indeed. A favourite objection against a free government is drawn from the
irregularities of the Greek and Roman republicks. But it is to be considered
that war was the employment which they considered as most becoming freemen. Agriculture, arts, and most domestick employment were committed chiefly to
slaves. But Carthage, the great commercial republick of antiquity, though
resembling Rome in the form of its government, and her rival for power,
retained her freedom longer than Rome, and was never disturbed by sedition
during the long period of her duration. This is a striking proof that the fault
of the Greek and Roman republicks was not owing to the form of their
government, and that the spirit of commerce is the great bond of union among
citizens. This furnishes employment for their activity, supplies their mutual
wants, defends the rights of property, and producing reciprocal dependencies,
renders the whole system harmonious and energetick. Our great object therefore
ought to be to encourage this spirit. If we examine the present state of the
world we shall find that most of the business is done in the freest states, and
that industry decreases in proportion to the rigour of government. Agrippa. II


27 November 1787


To the People of Massachusetts. In the Gazette of the 23d instant, I ascertained from the state of other
countries and the experience of mankind, that free countries are most friendly
to commerce and to the rights of property. This produces greater internal
tranquillity. For every man, finding sufficient employment for his active
powers in the way of trade, agriculture and manufactures, feels no disposition
to quarrel with his neighbour, nor with the government which protects him, and
of which he is a constituent part. Of the truth of these positions we have
abundant evidence in the history of our own country.

--- chunk_id: chunk-0281
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 430
content_hash: 2d12ecbf8edbb4c7
prev_chunk_id: chunk-0280
next_chunk_id: chunk-0282
section_heading: Agrippa (selections)
document_type: specification

For every man, finding sufficient employment for his active
powers in the way of trade, agriculture and manufactures, feels no disposition
to quarrel with his neighbour, nor with the government which protects him, and
of which he is a constituent part. Of the truth of these positions we have
abundant evidence in the history of our own country. Soon after the settlement
of Massachusetts, and its formation into a commonwealth, in the earlier part of
the last century, there was a sedition at Hingham and Weymouth. The governour
passing by at that time with his guard, seized some of the mutineers and
imprisoned them. This was complained of as a violation of their rights, and the
govemour lost his election the next year; but the year afterwards was restored
and continued to be re-elected for several years. The government does not
appear to have been disturbed again till the revocation of the charter in 1686,
being a period of about half a century. Connecticut set out originally on the same principles, and has continued
uniformly to exercise the powers of government to this time. During the last year, we had decisive evidences of the vigour of this kind
of government. In Connecticut, the treason was restrained while it existed only
in the form of conspiracy. In Vermont, the conspirators assembled in arms, but
were suppressed by the exertions of the militia, under the direction of their
sheriffs. In New-Hampshire, the attack was made on the legislature, but the
insurrection was in a very few hours suppressed, and has never been renewed. In
Massachusetts, the danger was, by delay, suffered to increase. One judicial
court after another was stopped, and even the capital trembled. Still, however,
when the supreme executive gave the signal, a force of many thousands of
active, resolute men, took the field, during the severities of winter, and
every difficulty vanished before them. Since that time we have been continually
coalescing.

--- chunk_id: chunk-0282
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: 89382e3f7d4baf87
prev_chunk_id: chunk-0281
next_chunk_id: chunk-0283
section_heading: Agrippa (selections)
document_type: specification

Still, however,
when the supreme executive gave the signal, a force of many thousands of
active, resolute men, took the field, during the severities of winter, and
every difficulty vanished before them. Since that time we have been continually
coalescing. The people have applied with diligence to their several
occupations, and the whole country wears one face of improvement. Agriculture
has been improved, manufactures multiplied, and trade prodigiously enlarged. These are the advantages of freedom in a growing country. While our resources
have been thus rapidly increasing, the courts have set in every part of the
commonwealth, without any guard to defend them; have tried causes of every
kind, whether civil or criminal, and the sheriffs, have in no case been
interrupted in the execution of their office. In those cases indeed, where the
government was more particularly interested, mercy has been extended, but in
civil causes, and in the case of moral offences, the law has been punctually
executed. Damage done to individuals, during the tumults, has been repaired, by
judgment of the courts of law, and the award has been carried into effect. This
is the present state of affairs, when we are asked to relinquish that freedom
which produces such happy effects. The attempt has been made to deprive us of such a beneficial system, and to
substitute a rigid one in its stead, by criminally alarming our fears, exalting
certain characters on one side, and villifying them on the other. I wish to say
nothing of the merits or demerits of individuals; such arguments always do
hurt. But assuredly my countrymen cannot fail to consider and determine who are
the most worthy of confidence in a business of this magnitude. — Whether
they will trust persons, who have, from their cradles, been incapable of
comprehending any other principles of government, than those of absolute power,
and who have, in this very affair, tried to deprive them of their
constitutional liberty, by a pitiful trick.

--- chunk_id: chunk-0283
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 441
content_hash: ef4217718d2e1fdc
prev_chunk_id: chunk-0282
next_chunk_id: chunk-0284
section_heading: Agrippa (selections)
document_type: specification

But assuredly my countrymen cannot fail to consider and determine who are
the most worthy of confidence in a business of this magnitude. — Whether
they will trust persons, who have, from their cradles, been incapable of
comprehending any other principles of government, than those of absolute power,
and who have, in this very affair, tried to deprive them of their
constitutional liberty, by a pitiful trick. They cannot avoid prefering those
who have uniformly exerted themselves to establish a limited government, and to
secure to individuals all the liberty that is consistent with justice, between
man and man, and whose efforts, by the smiles of Providence, have hitherto been
crowned with the most splendid success. After the treatment we have received,
we have a right to be jealous, and to guard our present constitution with the
strictest care. It is the right of the people to judge, and they will do wisely
to give an explicit instruction to their delegates in the proposed convention,
not to agree to any proposition that will, in any degree, militate with that
happy system of government under which Heaven has placed them. Agrippa. November 24, 1787. III


30 November 1787


To the People. It has been proved, from the clearest evidence, in two former papers, that a
free government, I mean one in which the power frequently returns to the body
of the people, is in principle the most stable and efficient of any kind; that
such a government affords the most ready and effectual remedy for all injuries
done to persons and the rights of property. It is true we have had a tender
act. But what government has not some law in favour of debtors? The difficulty
consists in finding one that is not more unfriendly to the creditors than ours. I am far from justifying such things. On the contrary I believe that it is
universally true, that acts made to favour a part of the community are wrong in
principle.

--- chunk_id: chunk-0284
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 448
content_hash: 544cf45b2890fc9b
prev_chunk_id: chunk-0283
next_chunk_id: chunk-0285
section_heading: Agrippa (selections)
document_type: specification

I am far from justifying such things. On the contrary I believe that it is
universally true, that acts made to favour a part of the community are wrong in
principle. All that is now intended is, to remark that we are not worse than
other people in that respect which we most condemn. Probably the inquiry will
be made, whence the complaints arise. This is easily answered. Let any man look
round his own neighbourhood, and see if the people are not, with a very few
exceptions, peaceable and attached to the government; if the country had ever
within their knowledge more appearance of industry, improvement and
tranquillity; if there was ever more of the produce of all kinds together for
the market; if their stock does not rapidly increase; if there was ever a more
ready vent for their surplus; and if the average of prices is not about as high
as was usual in a plentiful year before the war. These circumstances all denote
a general prosperity. Some classes of citizens indeed suffer greatly. Two
descriptions I at present recollect. The publick creditors form the first of
these classes and they ought to, and will be provided for. Let us for a moment
consider their situation and prospects. The embarrassments consequent upon a
war, and the usual reduction of prices immediately after a war, necessarily
occasioned a want of punctuality in publick payments. Still however the publick
debt has been very considerably reduced, not by the dirty and delusive scheme
of depreciation, but the nominal sum. Applications are continually making for
purchases in our eastern and western lands. Great exertions are making for
clearing off the arrears of outstanding taxes, so that the certificates for
interest on the state debt have considerably increased in value. This is a
certain indication of returning credit. Congress this year disposed of a large
tract of their lands towards paying the principal of their debt. Pennsylvania
has discharged the whole of their part of the continental debt.

--- chunk_id: chunk-0285
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 441
content_hash: 4e96bfc46a547d5b
prev_chunk_id: chunk-0284
next_chunk_id: chunk-0286
section_heading: Agrippa (selections)
document_type: specification

Congress this year disposed of a large
tract of their lands towards paying the principal of their debt. Pennsylvania
has discharged the whole of their part of the continental debt. New-York has
nearly cleared its state debt, and has located a large part of their new lands
towards paying the continental demands. Other states have made considerable
payments. Every day from these considerations the publick ability and
inclination to satisfy their creditors increases. The exertions of last winter
were as much to support publick as private credit. The prospect therefore of
the publick creditors is brightening under the present system. If the new
system should take effect without amendments, which however is hardly probable,
the increase of expense will be death to the hopes of all creditors both of the
continental and of the state. With respect however to our publick delays of
payment we have the precedent of the best established countries in Europe. The other class of citizens to which I alluded was the ship-carpenters. All
agree that their business is dull; but as nobody objects against a system of
commercial regulations for the whole continent, that business may be relieved
without subverting all the ancient foundations and laws which have the respect
of the people. It is a very serious question whether giving to Congress the
unlimited right to regulate trade would not injure them still further. It is
evidently for the interest of the state to encourage our own trade as much as
possible. But in a very large empire, as the whole states consolidated must be,
there will always be a desire of the government to increase the trade of the
capital, and to weaken the extremes. We should in that case be one of the
extremes, and should feel all the impoverishment incident to that situation. Besides, a jealousy of our enterprising spirit, would always be an inducement
to cramp our exertions. We must then be impoverished or we must rebel. The
alternative is dreadful.

--- chunk_id: chunk-0286
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 454
content_hash: 063341ca3aea79da
prev_chunk_id: chunk-0285
next_chunk_id: chunk-0287
section_heading: Agrippa (selections)
document_type: specification

We must then be impoverished or we must rebel. The
alternative is dreadful. At present this state is one of the most respectable and one of the most
influential in the union. If we alone should object to receiving the system
without amendments, there is no doubt but it would be amended. But the case is
not quite so bad. New-York appears to have no disposition even to call a
convention. If they should neglect, are we to lend our assistance to compel
them by arms, and thus to kindle a civil war without any provocation on their
part. Virginia has put off their convention till May, and appears to have no
disposition to receive the new plan without amendments. Pennsylvania does not
seem to be disposed to receive it as it is. The same objections are made in all
the states, that the civil government which they have adopted and which secures
their rights will be subverted. All the defenders of this system undertake to
prove that the rights of the states and of the citizens are kept safe. The
opposers of it agree that they will receive the least burdensome system which
shall defend those rights. Both parties therefore found their arguments on the idea that these rights
ought to be held sacred. With this disposition is it not in every man's mind
better to recommit it to a new convention, or to Congress, which is a regular
convention for the purpose, and to instruct our delegates to confine the system
to the general purposes of the union, than to endeavour to force it
through in its present form, and with so many opposers as it must have in every
state on the continent. The case is not of such pressing necessity as some have
represented. Europe is engaged and we are tranquil. Never therefore was an
happier time for deliberation. The supporters of the measure are by no means
afraid of insurrections taking place, but they are afraid that the present
government will prove superiour to their assaults.

--- chunk_id: chunk-0287
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 397
content_hash: d5b32d6e9957209f
prev_chunk_id: chunk-0286
next_chunk_id: chunk-0288
section_heading: Agrippa (selections)
document_type: specification

Never therefore was an
happier time for deliberation. The supporters of the measure are by no means
afraid of insurrections taking place, but they are afraid that the present
government will prove superiour to their assaults. Agrippa. IV


3 December 1787


To the People. Having considered some of the principal advantages of the happy form of
government under which it is our peculiar good fortune to live, we find by
experience, that it is the best calculated of any form hitherto invented, to
secure to us the rights of our persons and of our property, and that the
general circumstances of the people shew an advanced state of improvement never
before known. We have found the shock given by the war in a great measure
obliterated, and the publick debt contracted at that time to be considerably
reduced in the nominal sum. The Congress lands are fully adequate to the
redemption of the principal of their debt, and are selling and populating very
fast. The lands of this state, at the west, are, at the moderate price of
eighteen pence an acre, worth near half a million pounds in our money. They
ought, therefore, to be sold as quick as possible. An application was made
lately for a large tract at that price, and continual applications are made for
other lands in the eastern part of the state. Our resources are daily
augmenting. We find, then, that after the experience of near two centuries our separate
governments are in full vigour. They discover, for all the purposes of internal
regulation, every symptom of strength, and none of decay. The new system is,
therefore, for such purposes, useless and burdensome. Let us now consider how far it is practicable consistent with the happiness
of the people and their freedom.

--- chunk_id: chunk-0288
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 441
content_hash: 01b675ab5ecb7afe
prev_chunk_id: chunk-0287
next_chunk_id: chunk-0289
section_heading: Agrippa (selections)
document_type: specification

The new system is,
therefore, for such purposes, useless and burdensome. Let us now consider how far it is practicable consistent with the happiness
of the people and their freedom. It is the opinion of the ablest writers on the
subject, that no extensive empire can be governed upon republican principles,
and that such a government will degenerate to a despotism, unless it be made up
of a confederacy of smaller states, each having the full powers of internal
regulation. This is precisely the principle which has hitherto preserved our
freedom. No instance can be found of any free government of considerable extent
which has been supported upon any other plan. Large and consolidated empires
may indeed dazzle the eyes of a distant spectator with their splendour, but if
examined more nearly are always found to be full of misery. The reason is
obvious. In large states the same principles of legislation will not apply to
all the parts. The inhabitants of warmer climates are more dissolute in their
manners, and less industrious, than in colder countries. A degree of severity
is, therefore, necessary with one which would cramp the spirit of the other. We
accordingly find that the very great empires have always been despotick. They
have indeed tried to remedy the inconveniences to which the people were exposed
by local regulations; but these contrivances have never answered the end. The
laws not being made by the people, who felt the inconveniences, did not suit
their circumstances. It is under such tyranny that the Spanish provinces
languish, and such would be our misfortune and degradation, if we should submit
to have the concerns of the whole empire managed by one legislature. To promote
the happiness of the people it is necessary that there should be local laws;
and it is necessary that those laws should be made by the representatives of
those who are immediately subject to the want of them. By endeavouring to suit
both extremes, both are injured.

--- chunk_id: chunk-0289
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: eace55de7b7ed257
prev_chunk_id: chunk-0288
next_chunk_id: chunk-0290
section_heading: Agrippa (selections)
document_type: specification

To promote
the happiness of the people it is necessary that there should be local laws;
and it is necessary that those laws should be made by the representatives of
those who are immediately subject to the want of them. By endeavouring to suit
both extremes, both are injured. It is impossible for one code of laws to suit Georgia and Massachusetts. They must, therefore, legislate for themselves. Yet there is, I believe, not
one point of legislation that is not surrendered in the proposed plan. Questions of every kind respecting property are determinable in a continental
court, and so are all kinds of criminal causes. The continental legislature
has, therefore, a right to make rules in all cases by which their
judicial courts shall proceed and decide causes. No rights are reserved to the
citizens. The laws of Congress are in all cases to be the supreme law of the
land, and paramount to the constitutions of the individual states. The Congress
may institute what modes of trial they please, and no plea drawn from the
constitution of any state can avail. This new system is, therefore, a
consolidation of all the states into one large mass, however diverse the parts
may be of which it is to be composed. The idea of an uncompounded republick, on
an average, one thousand miles in length, and eight hundred in breadth, and
containing six millions of white inhabitants all reduced to the same standard
of morals, or habits, and of laws, is in itself an absurdity, and contrary to
the whole experience of mankind. The attempt made by Great-Britain to introduce
such a system, struck us with horrour, and when it was proposed by some
theorist that we should be represented in parliament, we uniformly declared
that one legislature could not represent so many different interests for the
purposes of legislation and taxation. This was the leading principle of the
revolution, and makes an essential article in our creed.

--- chunk_id: chunk-0290
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 448
content_hash: 0100d0f0a266a8a3
prev_chunk_id: chunk-0289
next_chunk_id: chunk-0291
section_heading: Agrippa (selections)
document_type: specification

The attempt made by Great-Britain to introduce
such a system, struck us with horrour, and when it was proposed by some
theorist that we should be represented in parliament, we uniformly declared
that one legislature could not represent so many different interests for the
purposes of legislation and taxation. This was the leading principle of the
revolution, and makes an essential article in our creed. All that part,
therefore, of the new system, which relates to the internal government of the
states, ought at once to be rejected. Agrippa. V


11 December 1787


To the People. In the course of inquiry it has appeared, that for the purposes of internal
regulation and domestick tranquillity, our small and separate governments are
not only admirably suited in theory, but have been remarkably successful in
practice. It is also found, that the direct tendency of the proposed system, is
to consolidate the whole empire into one mass, and, like the tyrant's bed, to
reduce all to one standard. Though this idea has been stated in different parts
of the continent, and is the most important trait of this draft, the reasoning
ought to be extensively understood. I therefore hope to be indulged in a
particular statement of it. Causes of all kinds, between citizens of different states, are to be tried
before a continental court. This court is not bound to try it according to the
local laws where the controversies happen; for in that case it may as well be
tried in a state court. The rule which is to govern the new courts, must,
therefore, be made by the court itself, or by its employers, the Congress. If
by the former, the legislative and judicial departments will be blended; and if
by the Congress, though these departments will be kept separate, still the
power of legislation departs from the state in all those cases. The Congress,
therefore, have the right to make rules for trying all kinds of
questions relating to property between citizens of different states.

--- chunk_id: chunk-0291
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 446
content_hash: fa2c396dfbcef0b5
prev_chunk_id: chunk-0290
next_chunk_id: chunk-0292
section_heading: Agrippa (selections)
document_type: specification

If
by the former, the legislative and judicial departments will be blended; and if
by the Congress, though these departments will be kept separate, still the
power of legislation departs from the state in all those cases. The Congress,
therefore, have the right to make rules for trying all kinds of
questions relating to property between citizens of different states. The
sixth article of the new constitution provides, that the continental laws shall
be the supreme law of the land, and that all judges in the separate states
shall be bound thereby, any thing in the constitution or laws of any state to
the contrary notwithstanding. All the state officers are also bound by oath to
support this constitution. These provisions cannot be understood otherwise than
as binding the state judges and other officers, to execute the continental laws
in their own proper departments within the state. For all questions, other than
those between citizens of the same state, are at once put within the
jurisdiction of the continental courts. As no authority remains to the state
judges, but to decide questions between citizens of the same state, and those
judges are to be bound by the laws of Congress, it clearly follows, that all
questions between citizens of the same state are to be decided by the general
laws and not by the local ones. Authority is also given to the continental courts, to try all causes between
a state and its own citizens. A question of property between these parties
rarely occurs. But if such questions were more frequent than they are, the
proper process is not to sue the state before an higher authority; but to apply
to the supreme authority of the state, by way of petition. This is the
universal practice of all states, and any other mode of redress destroys the
sovereignty of the state over its own subjects. The only case of the kind in
which the state would probably be sued, would be upon the state notes.

--- chunk_id: chunk-0292
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: ecbaa8e6dba4d266
prev_chunk_id: chunk-0291
next_chunk_id: chunk-0293
section_heading: Agrippa (selections)
document_type: specification

This is the
universal practice of all states, and any other mode of redress destroys the
sovereignty of the state over its own subjects. The only case of the kind in
which the state would probably be sued, would be upon the state notes. The
endless confusion that would arise from making the estates of individuals
answerable, must be obvious to every one. There is another sense in which the clause relating to causes between the
state and individuals is to be understood, and it is more probable than the
other, as it will be eternal in its duration, and increasing in its extent. This is the whole branch of the law relating to criminal prosecutions. In all
such cases the state is plaintiff, and the person accused is defendant. The
process, therefore, will be, for the attorney-general of the state to commence
his suit before a continental court. Considering the state as a party, the
cause must be tried in another, and all the expense of the transporting
witnesses incurred. The individual is to take his trial among strangers,
friendless and unsupported, without its being known whether he is habitually a
good or a bad man; and consequently with one essential circumstance wanting by
which to determine whether the action was performed maliciously or
accidentally. All these inconveniences are avoided by the present important
restriction, that the cause shall be tried by a jury of the vicinity, and tried
in the county where the offence was commited. But by the proposed
derangement, I can call it by no softer name, a man must be ruined to
prove his innocence. This is far from being a forced construction of the
proposed form. The words appear to me not intelligible, upon the idea that it
is to be a system of government, unless the construction now given, both
for civil and criminal processes, be admitted.

--- chunk_id: chunk-0293
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 432
content_hash: 9c101226834a6591
prev_chunk_id: chunk-0292
next_chunk_id: chunk-0294
section_heading: Agrippa (selections)
document_type: specification

This is far from being a forced construction of the
proposed form. The words appear to me not intelligible, upon the idea that it
is to be a system of government, unless the construction now given, both
for civil and criminal processes, be admitted. I do not say that it is intended
that all these changes should take place within one year, but they probably
will in the course of a half a dozen years, if this system is adopted. In the
mean time we shall be subject to all the horrors of a divided sovereignty, not
knowing whether to obey the Congress or the state. We shall find it impossible
to please two masters. In such a state frequent broils will ensue. Advantage
will be taken of a popular commotion, and even the venerable forms of the state
be done away, while the new system will be enforced in its utmost rigour by an
army. I am the more apprehensive of a standing army, on account of a clause in
the new constitution which empowers Congress to keep one at all times; but this
constitution is evidently such that it cannot stand any considerable time
without an army. Upon this principle one is very wisely provided. Our present
government knows of no such thing. Agrippa. VI


14 December 1787


To the People. To prevent any mistakes, or misapprehensions of the argument, stated in my
last paper, to prove that the proposed constitution is an actual consolidation
of the separate states into one extensive commonwealth, the reader is desired
to observe, that in the course of the argument, the new plan is considered as
an intire system. It is not dependent on any other book for an explanation, and
contains no references to any other book. All the defences of it, therefore, so
far as they are drawn from the state constitutions, or from maxims of the
common law, are foreign to the purpose.

--- chunk_id: chunk-0294
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 446
content_hash: 0c0c776b180c14e2
prev_chunk_id: chunk-0293
next_chunk_id: chunk-0295
section_heading: Agrippa (selections)
document_type: specification

It is not dependent on any other book for an explanation, and
contains no references to any other book. All the defences of it, therefore, so
far as they are drawn from the state constitutions, or from maxims of the
common law, are foreign to the purpose. It is only by comparing the different
parts of it together, that the meaning of the whole is to be understood. For
instance —


We find in it, that there is to be a legislative assembly, with authority to
constitute courts for the trial of all kinds of civil causes, between citizens
of different states. The right to appoint such courts necessarily involves in
it the right of defining their powers, and determining the rules by which their
judgment shall be regulated; and the grant of the former of those rights is
nugatory without the latter. It is vain to tell us, that a maxim of common law
requires contracts to be determined by the law existing where the contract was
made: for it is also a maxim, that the legislature has a right to alter the
common law. Such a power forms an essential part of legislation. Here, then a
declaration of rights is of inestimable value. It contains those principles
which the government never can invade without an open violation of the compact
between them and the citizens. Such a declaration ought to have come to the new
constitution in favour of the legislative rights of the several states, by
which their sovereignty over their own citizens within the state should be
secured. Without such an express declaration the states are annihilated in
reality upon receiving this constitution — the forms will be preserved
only during the pleasure of Congress. The idea of consolidation is further kept up in the right given to regulate
trade. Though this power under certain limitations would be a proper one for
the department of Congress; it is in this system carried much too far, and much
farther than is necessary.

--- chunk_id: chunk-0295
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 450
content_hash: 6482c2c5daf12cc6
prev_chunk_id: chunk-0294
next_chunk_id: chunk-0296
section_heading: Agrippa (selections)
document_type: specification

The idea of consolidation is further kept up in the right given to regulate
trade. Though this power under certain limitations would be a proper one for
the department of Congress; it is in this system carried much too far, and much
farther than is necessary. This is, without exception, the most commercial
state upon the continent. Our extensive coasts, cold climate, small estates,
and equality of rights, with a variety of subordinate and concurring
circumstances, place us in this respect at the head of the union. We must,
therefore, be indulged if a point which so nearly relates to our welfare be
rigidly examined. The new constitution not only prohibits vessels, bound from
one state to another, from paying any duties, but even from entering and
clearing. The only use of such a regulation is, to keep each state in complete
ignorance of its own resources. It certainly is no hardship to enter and clear
at the custom house, and the expense is too small to be an object. The unlimitted right to regulate trade, includes the right of granting
exclusive charters. This, in all old countries, is considered as one principal
branch of prerogative. We find hardly a country in Europe which has not felt
the ill effects of such a power. Holland has carried the exercise of it farther
than any other state; and the reason why that country has felt less evil from
it is, that the territory is very small, and they have drawn large revenues
from their colonies in the East and West Indies. In this respect, the whole
country is to be considered as a trading company, having exclusive privileges. The colonies are large in proportion to the parent state; so that, upon the
whole, the latter may gain by such a system. We are also to take into
consideration the industry which the genius of a free government inspires. But
in the British islands all these circumstances together have not prevented them
from being injured by the monopolies created there.

--- chunk_id: chunk-0296
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: 5ef53b7ee7235867
prev_chunk_id: chunk-0295
next_chunk_id: chunk-0297
section_heading: Agrippa (selections)
document_type: specification

We are also to take into
consideration the industry which the genius of a free government inspires. But
in the British islands all these circumstances together have not prevented them
from being injured by the monopolies created there. Individuals have been
enriched, but the country at large has been hurt. Some valuable branches of
trade being granted to companies, who transact their business in London, that
city is, perhaps, the place of the greatest trade in the world. But Ireland,
under such influence, suffers exceedingly, and is impoverished; and Scotland is
a mere bye-word. Bristol, the second city in England, ranks not much above this
town in population. These things must be accounted for by the incorporation of
trading companies; and if they are felt so severely in countries of small
extent, they will operate with tenfold severity upon us, who inhabit an immense
tract; and living towards one extreme of an extensive empire, shall feel the
evil, without retaining that influence in government, which may enable us to
procure redress. There ought, then, to have been inserted a restraining clause
which might prevent the Congress from making any such grant, because they
consequentially defeat the trade of the out-ports, and are also injurious to
the general commerce, by enhancing prices and destroying that rivalship which
is the great stimulus to industry. Agrippa. VII


18 December 1787


To the People. There cannot be a doubt, that, while the trade of this continent remains
free, the activity of our countrymen will secure their full share. All the
estimates for the present year, let them be made by what party they may,
suppose the balance of trade to be largely in our favour. The credit of our
merchants is, therefore, fully established in foreign countries. This is a
sufficient proof, that when business is unshackled, it will find out that
channel which is most friendly to its course. We ought, therefore, to be
exceedingly cautious about diverting or restraining it.

--- chunk_id: chunk-0297
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 452
content_hash: 6cb131e37c95179a
prev_chunk_id: chunk-0296
next_chunk_id: chunk-0298
section_heading: Agrippa (selections)
document_type: specification

This is a
sufficient proof, that when business is unshackled, it will find out that
channel which is most friendly to its course. We ought, therefore, to be
exceedingly cautious about diverting or restraining it. Every day produces
fresh proofs, that people, under the immediate pressure of difficulties, do
not, at first glance, discover the proper relief. The last year, a desire to
get rid of embarrassments induced many honest people to agree to a tender-act,
and many others, of a different description, to obstruct the courts of justice. Both these methods only increased the evil they were intended to cure. Experience has since shewn, that, instead of trying to lessen an evil by
altering the present course of things, every endeavour should have been applied
to facilitate the course of law, and thus to encourage a mutual confidence
among the citizens, which increases the resources of them all, and renders easy
the payment of debts. By this means one does not grow rich at the expense of
another, but all are benefited. The case is the same with the states. Pennsylvania, with one port and a large territory, is less favourably situated
for trade than the Massachusetts, which has an extensive coast in proportion to
its limits of jurisdiction. Accordingly a much larger proportion of our people
are engaged in maritime affairs. We ought therefore to be particularly
attentive to securing so great an interest. It is vain to tell us that we ought
to overlook local interests. It is only by protecting local concerns, that the
interest of the whole is preserved. No man when he enters into society, does it
from a view to promote the good of others, but he does it for his own good. All
men having the same view are bound equally to promote the welfare of the whole. To recur then to such a principle as that local interests must be disregarded,
is requiring of one man to do more than another, and is subverting the
foundation of a free government.

--- chunk_id: chunk-0298
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 434
content_hash: 1cdc938dc4f55bcc
prev_chunk_id: chunk-0297
next_chunk_id: chunk-0299
section_heading: Agrippa (selections)
document_type: specification

All
men having the same view are bound equally to promote the welfare of the whole. To recur then to such a principle as that local interests must be disregarded,
is requiring of one man to do more than another, and is subverting the
foundation of a free government. The Philadelphians would be shocked with a
proposition to place the seat of general government and the unlimited right to
regulate trade in the Massachusetts. There can be no greater reason for our
surrendering the preference to them. Such sacrifices, however we may delude
ourselves with the form of words, always originate in folly, and not in
generosity. Let me now request your attention a little while to the actual state of
publick credit, that we may see whether it has not been as much misrepresented
as the state of our trade. At the beginning of the present year, the whole continental debt was about
twelve millions of pounds in our money. About one quarter part of this sum was
due to our foreign creditors. Of these France was the principal, and called for
the arrears of interest. A new loan of one hundred and twenty thousand pounds
was negotiated in Holland, at five per cent. to pay the arrears due to France. At first sight this has the appearance of bad economy, and has been used for
the villainous purpose of disaffecting the people. But in the course of this
same year. Congress have negotiated the sale of as much of their western lands
on the Ohio and Missisippi, as amount nearly to the whole sum of the foreign
debt; and instead of a dead loss by borrowing money at five per cent. to the
amount of an hundred and twenty thousand pounds, in one sum, they make a saving
of the interest at six per cent. on three millions of their domestick debt,
which is an annual saving of an hundred and eighty thousand pounds.

--- chunk_id: chunk-0299
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 446
content_hash: f3ed7a41401746b4
prev_chunk_id: chunk-0298
next_chunk_id: chunk-0300
section_heading: Agrippa (selections)
document_type: specification

to the
amount of an hundred and twenty thousand pounds, in one sum, they make a saving
of the interest at six per cent. on three millions of their domestick debt,
which is an annual saving of an hundred and eighty thousand pounds. It is easy
to see how such an immense fund as the western territory may be applied to the
payment of the foreign debt. Purchasers of the land would as willingly procure
any kind of the produce of the United States as they would buy loan office
certificates to pay for the land. The produce thus procured would easily be
negotiated for the benefit of our foreign creditors. I do not mean to insinuate
that no other provision should be made for our creditors, but only to shew that
our credit is not so bad in other countries as has been represented, and that
our resources are fully equal to the pressure. The perfection of government depends on the equality of its operation, as
far as human affairs will admit, upon all parts of the empire, and upon all the
citizens. Some inequalities indeed will necessarily take place. One man will be
obliged to travel a few miles further than another man to procure justice. But
when he has travelled, the poor man ought to have the same measure of justice
as the rich one. Small inequalities may be easily compensated. There ought,
however, to be no inequality in the law itself, and the government ought to
have the same authority in one place as in another. Evident as this truth is,
the most plausible argument in favour of the new plan is drawn from the
inequality of its operation in different states. In Connecticut, they have been
told that the bulk of the revenue will be raised by impost and excise, and
therefore they need not be afraid to trust Congress with the power of levying a
dry tax at pleasure. New-York, and Massachusetts, are both more commercial
states than Connecticut.

--- chunk_id: chunk-0300
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 428
content_hash: d9cc7dfb198c3079
prev_chunk_id: chunk-0299
next_chunk_id: chunk-0301
section_heading: Agrippa (selections)
document_type: specification

In Connecticut, they have been
told that the bulk of the revenue will be raised by impost and excise, and
therefore they need not be afraid to trust Congress with the power of levying a
dry tax at pleasure. New-York, and Massachusetts, are both more commercial
states than Connecticut. The latter, therefore, hopes that the other two will
pay the bulk of the continental expense. The argument is in itself delusive. If
the trade is not over-taxed, the consumer pays it. If the trade is over-taxed,
it languishes, and by the ruin of trade the farmer loses his market. The farmer
has in truth no other advantage from imposts than that they save him the
trouble of collecting money for the government. He neither gets or loses money
by changing the mode of taxation. The government indeed finds it the easiest
way to raise the revenue; and the reason is that the tax is by this means
collected where the money circulates most freely. But if the argument was not
delusive, it ought to conclude against the plan, because it would prove the
unequal operation of it, and if any saving is to be made by the mode of taxing,
the saving should be applied towards our own debt, and not to the payment of
the part of a continental burden which Connecticut ought to discharge. It would
be impossible to refute in writing all the delusions made use of to force this
system through. Those respecting the publick debt, and the benefit of imposts,
are the most important, and these I have taken pains to explain. In one
instance indeed, the impost does raise money at the direct expense of the
seaports. This is when goods are imported subject to a duty, and re-exported
without a drawback. Whatever benefit is derived from this source, surely should
not be transferred to another state, at least till our own debts are cleared.

--- chunk_id: chunk-0301
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 438
content_hash: c8963e62250656ac
prev_chunk_id: chunk-0300
next_chunk_id: chunk-0302
section_heading: Agrippa (selections)
document_type: specification

This is when goods are imported subject to a duty, and re-exported
without a drawback. Whatever benefit is derived from this source, surely should
not be transferred to another state, at least till our own debts are cleared. Another instance of unequal operation is, that it establishes different
degrees of authority in different states, and thus creates different interests. The lands in New-Hampshire having been formerly granted by this state, and
afterwards by that state, to private persons, the whole authority of trying
titles becomes vested in a continental court, and that state loses a branch of
authority, which the others retain, over their own citizens. I have now gone through two parts of my argument, and have proved the
efficiency of the state governments for internal regulation, and the
disadvantages of the new system, at least some of the principal. The argument
has been much longer than I at first apprehended, or, possibly, I should have
been deterred from it. The importance of the question has, however, prevented
me from relinquishing it. Agrippa. VIII


25 December 1787


To the People. It has been proved, by indisputable evidence, that power is not the grand
principle of union among the parts of a very extensive empire; and that when
this principle is pushed beyond the degree necessary for rendering justice
between man and man, it debases the character of individuals, and renders them
less secure in their persons and property. Civil liberty consists in the
consciousness of that security, and is best guarded by political liberty, which
is the share that every citizen has in the government. Accordingly all our
accounts agree, that in those empires which are commonly called despotick, and
which comprehend by far the greatest part of the world, the government is most
fluctuating, and property least secure. In those countries insults are borne by
the sovereign, which, if offered to one of our governours, would fill us with
horrour, and we should think the government dissolving.

--- chunk_id: chunk-0302
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 357
content_hash: 9fa36ca24df4a47a
prev_chunk_id: chunk-0301
next_chunk_id: chunk-0303
section_heading: Agrippa (selections)
document_type: specification

Accordingly all our
accounts agree, that in those empires which are commonly called despotick, and
which comprehend by far the greatest part of the world, the government is most
fluctuating, and property least secure. In those countries insults are borne by
the sovereign, which, if offered to one of our governours, would fill us with
horrour, and we should think the government dissolving. The common conclusion from this reasoning is an exceedingly unfair one, that
we must then separate, and form distinct confederacies. This would be true if
there was no principle to substitute in the room of power. Fortunately there is
one. This is commerce. All the states have local advantages, and in a
considerable degree separate interests. They are, therefore, in a situation to
supply each other's wants. Carolina, for instance, is inhabited by planters,
while the Massachusetts is more engaged in commerce and manufactures. Congress
has the power of deciding their differences. The most friendly intercourse may
therefore be established between them. A diversity of produce, wants and
interests, produces commerce, and commerce, where there is a common, equal and
moderate authority to preside, produces friendship. The same principles apply to the connection with the new settlers in the
west. Many supplies they want, for which they must look to the older
settlements, and the greatness of their crops enables them to make payments. Here, then, we have a bond of union which applies to all parts of the empire,
and would continue to operate if the empire comprehended all America. We are now, in the strictest sense of the terms, a federal republick. Each

--- chunk_id: chunk-0303
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 440
content_hash: 96017f3186b1a308
prev_chunk_id: chunk-0302
next_chunk_id: chunk-0304
section_heading: part has within its own limits the sovereignty over its citizens, while some of
document_type: specification

part has within its own limits the sovereignty over its citizens, while some of
the general concerns are committed to Congress. The complaints of the
deficiency of the Congressional powers are confined to two articles. They are
not able to raise a revenue by taxation, and they have not a complete
regulation of the intercourse between us and foreigners. For each of these
complaints there is some foundation, but not enough to justify the clamour
which has been raised. Congress, it is true, owes a debt which ought to be
paid. A considerable part of it has been paid. Our share of what remains would
annually amount to about sixty or seventy thousand pounds. If, therefore. Congress were put in possession of such branches of the impost as would raise
this sum in our state, we should fairly be considered as having done our part
towards their debt; and our remaining resources, whether arising from impost,
excise, or dry tax, might be applied to the reduction of our own debt. The
principal of this last amounts to about thirteen hundred thousand pounds, and
the interest to between seventy or eighty thousand. This is, surely, too much
property to be sacrificed; and it is as reasonable that it should be paid as
the continental debt. But if the new system should be adopted, the whole
impost, with an unlimited claim to excise and dry tax, will be given to
Congress. There will remain no adequate fund for the state debt, and the state
will still be subject to be sued on their notes. — This is, then, an
article which ought to be limited. We can, without difficulty, pay as much
annually as shall clear the interest of our state debt, and our share of the
interest on the continental one. But if we surrender the impost, we shall
still, by this new constitution, be held to pay our full proportion of the
remaining debt, as if nothing had been done.

--- chunk_id: chunk-0304
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 434
content_hash: 69ad7c2dc00b1844
prev_chunk_id: chunk-0303
next_chunk_id: chunk-0305
section_heading: part has within its own limits the sovereignty over its citizens, while some of
document_type: specification

We can, without difficulty, pay as much
annually as shall clear the interest of our state debt, and our share of the
interest on the continental one. But if we surrender the impost, we shall
still, by this new constitution, be held to pay our full proportion of the
remaining debt, as if nothing had been done. The impost will not be considered
as being paid by this state, but by the continent. The federalists, indeed,
tell us, that the state debts will all be incorporated with the continental
debt, and all paid out of one fund. In this, as in all other instances, they
endeavour to support their scheme of consolidation by delusion. Not one word is
said in the book in favour of such a scheme, and there is no reason to think it
true. Assurances of that sort are easily given, and as easily forgotten. There
is an interest in forgetting what is false. No man can expect town debts to be
united with that of the state; and there will be as little reason to expect,
that the state and continental debts will be united together. Agrippa. IX


28 December 1787


To the People. We come now to the second and last article of complaint against the present
confederation, which is, that Congress has not the sole power to regulate the
intercourse between us and foreigners. Such a power extends not only to war and
peace, but to trade and naturalization. This last article ought never to be
given them; for though most of the states may be willing for certain reasons to
receive foreigners as citizens, yet reasons of equal weight may induce other
states, differently circumstanced, to keep their blood pure. Pennsylvania has
chosen to receive all that would come there. Let any indifferent person judge
whether that state in point of morals, education, energy is equal to any of the
eastern states; the small state of Rhode-Island only excepted.

--- chunk_id: chunk-0305
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 280
content_hash: 2dd1f1729c9f1745
prev_chunk_id: chunk-0304
next_chunk_id: chunk-0306
section_heading: part has within its own limits the sovereignty over its citizens, while some of
document_type: specification

Pennsylvania has
chosen to receive all that would come there. Let any indifferent person judge
whether that state in point of morals, education, energy is equal to any of the
eastern states; the small state of Rhode-Island only excepted. Pennsylvania in
the course of a century has acquired her present extent and population at the
expense of religion and good morals. The eastern states have, by keeping
separate from the foreign mixtures, acquired, their present greatness in the
course of a century and an half, and have preserved their religion and morals. They have also preserved that manly virtue which is equally fitted for
rendering them respectable in war, and industrious in peace. The remaining power for peace and trade might perhaps be safely enough
lodged with Congress under some limitations. Three restrictions appear to me to
be essentially necessary to preserve the equality of rights to the states,
which it is the object of the state governments to secure to each citizen, ist. It ought not to be in the power of Congress either by treaty or otherwise to
alienate part of any state without the consent of the legislature. 2d. They
ought not to be able by treaty or other law to give any legal preference to one

--- chunk_id: chunk-0306
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 430
content_hash: a2a4298db8a86212
prev_chunk_id: chunk-0305
next_chunk_id: chunk-0307
section_heading: part above another. 3d. They ought to be restrained from creating any
document_type: specification

part above another. 3d. They ought to be restrained from creating any
monopolies. Perhaps others may propose different regulations and restrictions. One of these is to be found in the old confederation, and another in the newly
proposed plan. The third seems to be equally necessary. After all that has been said and written on this subject, and on the
difficulty of amending our old constitution so as to render it adequate to
national purposes, it does not appear that any thing more was necessary to be
done, than framing two new articles. By one a limited revenue would be given to
Congress with a right to collect it, and by the other a limited right to
regulate our intercourse with foreign nations. By such an addition we should
have preserved to each state its power to defend the rights of the citizens,
and the whole empire would be capable of expanding, and receiving additions
without altering its former constitution. Congress, at the same time, by the
extent of their jurisdiction, and the number of their officers, would have
acquired more respectability at home, and a sufficient influence abroad. If any
state was in such a case to invade the rights of the Union, the other states
would join in defence of those rights, and it would be in the power of Congress
to direct the national force to that object. But it is certain that the powers
of Congress over the citizens should be small in proportion as the empire is
extended; that, in order to preserve the balance, each state may supply by
energy what is wanting in numbers. Congress would be able by such a system as
we have proposed to regulate trade with foreigners by such duties as should
effectually give the preference to the produce and manufactures of our own
country. We should then have a friendly intercourse established between the
states, upon the principles of mutual interest.

--- chunk_id: chunk-0307
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 405
content_hash: c95db61de5bf2881
prev_chunk_id: chunk-0306
next_chunk_id: chunk-0308
section_heading: part above another. 3d. They ought to be restrained from creating any
document_type: specification

Congress would be able by such a system as
we have proposed to regulate trade with foreigners by such duties as should
effectually give the preference to the produce and manufactures of our own
country. We should then have a friendly intercourse established between the
states, upon the principles of mutual interest. A moderate duty upon foreign
vessels would give an advantage to our own people, while it would avoid all the
[dis]advantages arising from a prohibition, and the consequent deficiency of
vessels to transport the produce of the southern states. Our country is at present upon an average a thousand miles long from north
to south, and eight hundred broad from the Missisippi to the Ocean. We have at
least six millions of white inhabitants, and the annual increase is about two
hundred and fifty thousand souls, exclusive of emigrants from Europe. The
greater part of our increase is employed in settling the new lands, while the
older settlements are entering largely into manufactures of various kinds. It
is probable, that the extraordinary exertions of this state in the way of
industry for the present year only, exceed in value five hundred thousand
pounds. The new settlements, if all made in the same tract of country, would
form a large state annually; and the time seems to be literally accomplished
when a nation shall be born in a day. Such an immense country is not only
capable of yielding all the produce of Europe, but actually does produce by far
the greater part of the raw materials. The restrictions on our trade in Europe,
necessarily oblige us to make use of those materials, and the high price of
labour operates as an encouragement to mechanical improvements. In this way we
daily make rapid advancements towards independence in resources as well as in
empire.

--- chunk_id: chunk-0308
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 438
content_hash: a02034a9c29f0759
prev_chunk_id: chunk-0307
next_chunk_id: chunk-0309
section_heading: part above another. 3d. They ought to be restrained from creating any
document_type: specification

The restrictions on our trade in Europe,
necessarily oblige us to make use of those materials, and the high price of
labour operates as an encouragement to mechanical improvements. In this way we
daily make rapid advancements towards independence in resources as well as in
empire. If we adopt the new system of government we shall by one rash vote lose
the fruit of the toil and expense of thirteen years, at the time when the
benefits of that toil and expense are rapidly increasing. Though the imposts of
Congress on foreign trade may tend to encourage manufactures, the excise and
dry tax will destroy all the beneficial effects of the impost, at the same time
that they diminish our capital. Be careful then to give only a limited revenue,
and the limited power of managing foreign concerns. Once surrender the rights
of internal legislation and taxation, and instead of being respected abroad,
foreigners will laugh at us, and posterity will lament our folly. Agrippa. X


1 January 1788


To the People. Friends and Brethren,


It is a duty incumbent on every man, who has had opportunities for inquiry,
to lay the result of his researches on any matter of publick importance before
the publick eye. No further apology will be necessary with the generality of my
readers, for having so often appeared before them on the subject of the lately
proposed form of government. It has been treated with that freedom which is
necessary for the investigation of truth, and with no greater freedom. On such
a subject, extensive in its nature, and important in its consequences, the
examination has necessarily been long, and the topicks treated of have been
various. We have been obliged to take a cursory, but not inaccurate view of the
circumstances of mankind under the different forms of government to support the
different parts of our argument. Permit me now to bring into one view the
principal propositions on which the reasoning depends.

--- chunk_id: chunk-0309
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 420
content_hash: ffb9c56b82c60a87
prev_chunk_id: chunk-0308
next_chunk_id: chunk-0310
section_heading: part above another. 3d. They ought to be restrained from creating any
document_type: specification

We have been obliged to take a cursory, but not inaccurate view of the
circumstances of mankind under the different forms of government to support the
different parts of our argument. Permit me now to bring into one view the
principal propositions on which the reasoning depends. It is shewn from the example of the most commercial republick of antiquity,
which was never disturbed by a sedition for above seven hundred years, and at
last yielded after a violent struggle to a foreign enemy, as well as from the
experience of our own country for a century and an half; that the republican,
more than any other form of government is made of durable materials. It is
shewn from a variety of proof, that one consolidated government is inapplicable
to a great extent of country; is unfriendly to the rights both of persons and
property, which rights always adhere together; and that being contrary to the
interest of the extreme of an empire, such a government can be supported only
by power, and that commerce is the true bond of union for a free state. It is
shewn from a comparison of the different parts of the proposed plan, that it is
such a consolidated government. By article 3, section 2, Congress are empowered to appoint courts with
authority to try civil causes of every kind, and even offences against
particular states; by the last clause of article 1, section 8, which defines
their legislative powers, they are authorized to make laws for carrying into
execution all the "powers vested by this constitution in the government of
the United States, or in any department or officer thereof;" and by
article 6, the judges in every state are to be bound by the laws of Congress. It is therefore a complete consolidation of all the states into one, however
diverse the parts of it may be.

--- chunk_id: chunk-0310
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 448
content_hash: eef540ae894f39f1
prev_chunk_id: chunk-0309
next_chunk_id: chunk-0311
section_heading: part above another. 3d. They ought to be restrained from creating any
document_type: specification

By article 3, section 2, Congress are empowered to appoint courts with
authority to try civil causes of every kind, and even offences against
particular states; by the last clause of article 1, section 8, which defines
their legislative powers, they are authorized to make laws for carrying into
execution all the "powers vested by this constitution in the government of
the United States, or in any department or officer thereof;" and by
article 6, the judges in every state are to be bound by the laws of Congress. It is therefore a complete consolidation of all the states into one, however
diverse the parts of it may be. It is also shewn that it will operate unequally
in the different states, taking from some of them a greater share of wealth;
that in this last respect it will operate more to the injury of this
commonwealth than of any state in the union; and that by reason of its
inequality it is subversive of the principles of a free government, which
requires every part to contribute an equal proportion. For all these reasons
this system ought to be rejected, even if no better plan was proposed in the
room of it. In case of a rejection we must remain as we are, with trade
extending, resources opening, settlements enlarging, manufactures increasing,
and publick debts diminishing by fair payment. These are mighty blessings, and
not to be lost by the hasty adoption of a new system. But great as these
benefits are, which we derive from our present system, it has been shewn, that
they may be increased by giving Congress a limited power to regulate trade, and
assigning to them those branches of the impost on our foreign trade only, which
shall be equal to our proportion of their present annual demands. While the
interest is thus provided for, the sale of our lands in a very few years will
pay the principal, and the other resources of the state will pay our own debt.

--- chunk_id: chunk-0311
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 437
content_hash: 5ee29aa0e9b0c52e
prev_chunk_id: chunk-0310
next_chunk_id: chunk-0312
section_heading: part above another. 3d. They ought to be restrained from creating any
document_type: specification

But great as these
benefits are, which we derive from our present system, it has been shewn, that
they may be increased by giving Congress a limited power to regulate trade, and
assigning to them those branches of the impost on our foreign trade only, which
shall be equal to our proportion of their present annual demands. While the
interest is thus provided for, the sale of our lands in a very few years will
pay the principal, and the other resources of the state will pay our own debt. The present mode of assessing the continental tax is regulated by the extent of
landed property in each state. By this rule the Massachusetts has to pay one
eighth. If we adopt the new system, we shall surrender the whole of our impost
and excise, which probably amount to a third of those duties of the whole
continent, and must come in for about a sixth part of the remaining debt. By
this means we shall be deprived of the benefit arising from the largeness of
our loans to the continent, shall lose our ability to satisfy the just demands
on the state. Under the limitations of revenue and commercial regulation
contained in these papers, the balance will be largely in our favour; the
importance of the great states will be preserved, and the publick creditors
both of the continent and state will be satisfied without burdening the people. For a more concise view of my proposal, I have thrown it into the form of a
resolve supposed to be passed by the convention which is shortly to set in this
town. "Commonwealth of Massachusetts. Resolved, That the form of government lately proposed by a federal
convention, held in the city of Philadelphia, is so far injurious to the
interests of this commonwealth, that we are constrained by fidelity to our
constituents to reject it; and we do hereby reject the said proposed form and
every part thereof.

--- chunk_id: chunk-0312
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 434
content_hash: cd6848160609954c
prev_chunk_id: chunk-0311
next_chunk_id: chunk-0313
section_heading: part above another. 3d. They ought to be restrained from creating any
document_type: specification

"Commonwealth of Massachusetts. Resolved, That the form of government lately proposed by a federal
convention, held in the city of Philadelphia, is so far injurious to the
interests of this commonwealth, that we are constrained by fidelity to our
constituents to reject it; and we do hereby reject the said proposed form and
every part thereof. But in order that the union of these states may, as far as
possible, be promoted, and the federal business as little obstructed as may be,
we do agree on the part of this commonwealth, that the following addition be
made to the present articles of confederation. "XIV. The United States shall have power to regulate the intercourse
between these states and foreign dominions, under the following restrictions;
viz ist. No treaty, ordinance, or law shall alienate the whole or part of any
state, without the consent of the legislature of such state. 2d. The United
States shall not by treaty or otherwise give a preference to the ports of one
state over those of another; Nor, 3d create any monopolies or exclusive
companies; Nor, 4th, extend the privileges of citizenship to any foreigner. And
for the more convenient exercise of the powers hereby and by the former
articles given, the United S[t]ates shall have authority to constitute
judicatories, whether supreme or subordinate, with power to try all piracies
and felonies done on the high seas, and also all civil causes in which a
foreign state, or subject thereof actually resident in a foreign country and
not being British absentees, shall be one of the parties. They shall also have
authority to try all causes in which ambassadours shall be concerned. All these
trials shall be by jury and in some sea-port town. All imposts levied by
Congress on trade shall be confined to foreign produce or foreign manufactures
imported, and to foreign ships trading in our harbours, and all their absolute
prohibitions shall be confined to the same articles.

--- chunk_id: chunk-0313
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 197
content_hash: 315c1e1a1e8b5ebd
prev_chunk_id: chunk-0312
next_chunk_id: chunk-0314
section_heading: part above another. 3d. They ought to be restrained from creating any
document_type: specification

All these
trials shall be by jury and in some sea-port town. All imposts levied by
Congress on trade shall be confined to foreign produce or foreign manufactures
imported, and to foreign ships trading in our harbours, and all their absolute
prohibitions shall be confined to the same articles. All imposts and
confiscations shall be to the use of the state in which they shall accrue,
excepting in such branches as shall be assigned by any state as a fund for
defraying their proportion of the continental. And no powers shall be exercised
by Congress but such as are expressly given by this and the former articles. And we hereby authorize our delegates in Congress to sign and ratify an article
in the foregoing form and words, without any further act of this state for that
purpose, provided the other states shall accede to this proposition on their

--- chunk_id: chunk-0314
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 449
content_hash: 394de92de12ef110
prev_chunk_id: chunk-0313
next_chunk_id: chunk-0315
section_heading: part on or before the first day of January, which will be in the year of our
document_type: specification

part on or before the first day of January, which will be in the year of our
Lord 1790. All matters of revenue being underthe controul of the legislature,
we reccommend to the general court of this commonwealth, to devise, as early as
may be, such funds arising from such branches of foreign commerce, as shall be
equal to our part of the current charges of the continent, and to put Congress
in possession of the revenue arising therefrom, with a right to collect it,
during such term as shall appear to be necessary for the payment of the
principal of their debt, by the sale of the western lands."



By such an explicit declaration of the powers given to Congress, we shall
provide for all federal purposes, and shall at the same time secure our rights. It is easier to amend the old confederation, defective as it has been
represented, than it is to correct the new form. For with what ever view it was
framed, truth constrains me to say, that it is insiduous in its form, and
ruinous in its tendency. Under the pretence of different branches of the
legislature, the members will in fact be chosen from the same general
description of citizens. The advantages of a check will be lost, while we shall
be continually exposed to the cabals and corruption of a British election. There cannot be a more eligible mode than the present, for appointing members
of Congress, nor more effectual checks provided than our separate state
governments, nor any system so little expensive, in case of our adopting the
resolve just stated, or even continuing as we are. We shall in that case avoid
all the inconvenience of concurrent jurisdictions, we shall avoid the expensive
and useless establishments of the Philadelphia proposition, we shall preserve
our constitution and liberty, and we shall provide for all such institutions as
will be useful. Surely then you cannot hesitate, whether you will chuse freedom
or servitude. The object is now well defined.

--- chunk_id: chunk-0315
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 441
content_hash: 906fff9ca6833aaa
prev_chunk_id: chunk-0314
next_chunk_id: chunk-0316
section_heading: part on or before the first day of January, which will be in the year of our
document_type: specification

Surely then you cannot hesitate, whether you will chuse freedom
or servitude. The object is now well defined. By adopting the form proposed by
the convention, you will have the derision of foreigners, internal misery, and
the anathemas of posterity. By amending the present confederation, and granting
limited powers to Congress, you secure the admiration of strangers, internal
happiness, and the blessings and prosperity of all succeeding generations. Be
wise then, and by preserving your freedom, prove, that Heaven bestowed it not
in vain. Many will be the efforts to delude the convention. The mode of judging
is itself suspicious, as being contrary to the antient and established usage of
the commonwealth. But since this mode is adopted, we trust, that the numbers
[members?] of that venerable assembly will not so much regard the greatness of
their power, as the sense and interest of their constituents. And they will do
well to remember that even a mistake in adopting it, will be destructive, while
no evils can arise from a total, and much less, probably, from such a partial
rejection as we have proposed. I have now gone through my reasonings on this momentous subject, and have
stated the facts and deductions from them, which you will verify for
yourselves. Personal interest was not my object, or I should have pursued a
different line of conduct. Though I conceived that a man who owes allegiance to
the state is bound, on all important occasions, to propose such inquiries as
tend to promote the publick good; yet I did not imagine it to be any pan of my
duty to present myself to the fury of those, who appear to have other ends in
view. For this cause, and for this only, I have chosen a feigned signature. At
present all the reports concerning the writer of these papers are merely
conjectural. I should have been ashamed of my system if it had needed such
feeble support as the character of individuals.

--- chunk_id: chunk-0316
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 442
content_hash: 850627c6dcbce1ac
prev_chunk_id: chunk-0315
next_chunk_id: chunk-0317
section_heading: part on or before the first day of January, which will be in the year of our
document_type: specification

At
present all the reports concerning the writer of these papers are merely
conjectural. I should have been ashamed of my system if it had needed such
feeble support as the character of individuals. It stands on the firm ground of
the experience of mankind. I cannot conclude this long disquisition better than
with a caution derived from the words of inspiration. Discern the things of
your peace now in the days thereof, before they be hidden from your eyes. Agrippa. XI


8 January 1788


To the People. My last Address contained the outlines of a system fully adequate to all the
useful purposes of the union. Its object is to raise a sufficient revenue from
the foreign trade, and the sale of our publick lands, to satisfy all the
publick exigencies, and to encourage, at the same time, our internal industry
and manufactures. It also secures each state in its own separate rights, while
the continental concerns are thrown into the general department. The only
deficiencies that I have been able to discover in the plan, and in the view of
federalists they are very great ones, are, that it does not allow the
interference of Congress in the domestick concerns of the state, and that it
does not render our national councils so liable to foreign influence. The first
of these articles tends to guard us from that infinite multiplication of
officers which the report of the Convention of Philadelphia proposes. With
regard to the second, it is evidently not of much importance to any foreign
nation to purchase, at a very high price, a majority of votes in an assembly,
whose members are continually exposed to a recall. But give those members a
right to sit six, or even two, years, with such extensive powers as the new
system proposes, and their friendship will be well worth a purchase. This is
the only sense in which the Philadelphia system will render us more respectable
in the eyes of foreigners.

--- chunk_id: chunk-0317
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 446
content_hash: c9a220938905a39f
prev_chunk_id: chunk-0316
next_chunk_id: chunk-0318
section_heading: part on or before the first day of January, which will be in the year of our
document_type: specification

But give those members a
right to sit six, or even two, years, with such extensive powers as the new
system proposes, and their friendship will be well worth a purchase. This is
the only sense in which the Philadelphia system will render us more respectable
in the eyes of foreigners. In every other view they lose their respect for us,
as it will render us more like their own degraded models. It is a maxim with
them, that every man has his price. If, therefore we were to judge of what
passes in the hearts of the federalists when they urge us, as they continually
do, to be like other nations, and when they assign mercenary motives to
the opposers of their plan, we should conclude very fairly, that themselves
wish to be provided for at the publick expense. However that may be, if we look
upon the men we shall find some of their leaders to have formed pretty strong
attachments to foreign nations. Whether those attachments arose from their
being educated under a royal government, from a former unfortunate mistake in
politicks, or from the agencies for foreigners, or any other cause, is not in
my province to determine. But certain it is. that some of the principal
fomenters of this plan have never shewn themselves capable of that generous
system of policy which is founded in the affections of freemen. Power and high
life are their idols, and national funds are necessary to support them. Some of the principal powers of Europe have already entered into treaties
with us, and that some of the rest have not done it, is not owing, as is
falsely pretended, to the want of power in Congress. Holland never found any
difficulty of this kind from the multitude of sovereignties in that country,
which must all be consulted on such an occasion. The resentment of Great
Britain for our victories in the late war has induced that power to restrain
our intercourse with their subjects.

--- chunk_id: chunk-0318
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 428
content_hash: 2f1f5a801ecbf19c
prev_chunk_id: chunk-0317
next_chunk_id: chunk-0319
section_heading: part on or before the first day of January, which will be in the year of our
document_type: specification

Holland never found any
difficulty of this kind from the multitude of sovereignties in that country,
which must all be consulted on such an occasion. The resentment of Great
Britain for our victories in the late war has induced that power to restrain
our intercourse with their subjects. Probably an hope, the only solace of the
wretched, that their affairs would take a more favourable turn on this
continent, has had some influence on their proceedings. All their restrictions
have answered the end of securing our independence by driving us into many
valuable manufactures. Their own colonies in the mean time have languished for
want of an intercourse with these states. The new settlement in Nova Scotia has
miserably decayed, and the West India Islands have suffered for want of our
supplies, and by the loss of our market. This has affected the revenue; and
however contemptuously some men may affect to speak of our trade, the supply of
six millions of people is an object worth the attention of any nation upon
earth. Interest in such a nation as Britain will surmount their resentment. However their pride may be stung, they will pursue after wealth. Increase of
revenue to a nation overwhelmed with a debt of near two hundred and ninety
millions sterling is an object to which little piques must give way; and
there is no doubt that their interest consists in securing as much of our trade
as they can. These are topicks from which are drawn some of the most plausible reasons
that have been given by the federalists in favour of their plan, as derived
from the sentiments of foreigners. We have weighed them and found them wanting. That they had not themselves full confidence in their own reasons at
Philadelphia is evident from the method they took to bias the state Convention. Mess'rs Wilson and M'Kean, two Scottish names, were repeatedly worsted in the
argument.

--- chunk_id: chunk-0319
source_document: Anti_Federalist_Selections.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 157
content_hash: a59c4a9dca8c4f9e
prev_chunk_id: chunk-0318
next_chunk_id: null
section_heading: part on or before the first day of January, which will be in the year of our
document_type: specification

That they had not themselves full confidence in their own reasons at
Philadelphia is evident from the method they took to bias the state Convention. Mess'rs Wilson and M'Kean, two Scottish names, were repeatedly worsted in the
argument. To make amends for their own incapacity, the gallery was filled with
a rabble, who shouted their applause, and these heroes of aristocracy were not
ashamed, though modesty is their national virtue, to vindicate such a violation
of decency: Means not less criminal, but not so flagrantly indecent, have been
frequently mentioned among us to secure a majority. But those who vote for a
price, can never sanctify wrong, and treason will still retain its deformity. Agrippa. Text Version |
