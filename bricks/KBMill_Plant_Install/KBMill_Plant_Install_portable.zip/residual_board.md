# Residual board — KBMill_Plant_Install

Status: **success**

## Counts
- in kb: 13  |  muted / off RAG: 0  |  on RAG path: 13
- embedded rows: 13
- reconciled: True

## Quality score (if present)
- avg_extraction_quality: **1.0**
- measures: text-layer coverage / extractability (pages that produced usable text), not character-level OCR accuracy

## Limits / open items
- (none recorded)

