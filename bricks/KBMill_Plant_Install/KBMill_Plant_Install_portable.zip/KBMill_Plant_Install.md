--- chunk_id: chunk-0000
source_document: SPEC.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 21
content_hash: f8b299768ed11fd0
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: KBMill plant
document_type: specification

# KBMill plant

Spec sheet for the Linux image that ran. Carroll Miller, d/b/a KBMill. 2026-10-10.

--- chunk_id: chunk-0001
source_document: SPEC.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 284
content_hash: 5a35385547d26199
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
section_heading: Names
document_type: specification

## Names

This image is the plant. The package inside the image is `vectorforge_pro`. KBMill and that package are the same vendor. The image file is `kbmill-plant.tar`. The tag is `kbmill-plant:0.1.0`. The file is 3378268160 bytes. A single-layer DVD-5 holds 4707319808 bytes, so this file fits one DVD. No disc has been burned. This file has not been written as an ISO. ### What the image contains
The image mills a pile into a brick. It includes the local door, the readers, and the weights the mill uses. No chat model is in the image. A customer job does not call a model. The local door listens on `127.0.0.1:8771`. The drop page takes a pile. `POST /tool/run` takes a name and a path already on the host. One job runs at a time. A second job waits. A finished job can be downloaded from that session. The drop page does not link to the config page. The license marker `/usr/local/share/kbmill/license.required` is inside the image. The image mills only when a signed plant license names this host. The variable is `VF_PLANT_LICENSE`. When that variable is unset, the file is `/var/lib/kbmill/license.json`. Docker and Podman both load this file. Nothing is pulled. Podman 3.4 shows the tag as `localhost/kbmill-plant:0.1.0`. The container runs with the network off.

--- chunk_id: chunk-0002
source_document: SPEC.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 178
content_hash: 3e85aba2cd761469
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: What the image does not contain
document_type: specification

## What the image does not contain

The image does not run the public door, the shelf, or the desk. It does not charge a card. The license private key is not in the image. The operating manual is not in this image. The drop page does not show a Dealt with list. ### The host
One purchase is one host. The host is the fingerprint the image prints, not the hostname. A shelf license does not start the plant. A license for another fingerprint does not start the plant. A missing file does not start the plant. The fingerprint command, run inside the plant container, is `python3 -m vectorforge_pro.plant_license`. That command prints one line and does not read the license. The buyer sends that line through Contact operator. There is no download URL.

--- chunk_id: chunk-0003
source_document: SPEC.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 200
content_hash: 19b27651e788154e
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: The brick
document_type: specification

## The brick

The brick file is the handoff. This plant writes it. The desk reads it. The shelf searches it. An unsigned brick still belongs on the shelf. A stale signature still belongs on the shelf. ### What was run
A Linux guest with no copy of the repository loaded this file. Docker and Podman each printed the same fingerprint, with the network off. With no license, both refused. With a shelf license, the plant refused. With a plant license for that guest, Docker took two drops. The second drop waited, and both became bricks. A tool call on Docker milled a brick. A tool call on Podman milled a brick. Each receipt showed no model turn. Nothing was fetched. The private key was not on that guest. The guest's older plant door was left running. That door is a different image. Loading this file did not replace it.

--- chunk_id: chunk-0004
source_document: LICENSE.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 66
content_hash: 039854bab27d5547
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: KBMill plant license
document_type: technical_reference

# KBMill plant license

This file is the agreement. It is between Carroll Miller, doing business as KBMill, and the person or organization that receives a signed license file for the KBMill plant. A summary of this file, including a summary written by a model, is not the agreement. 2026-10-10.

--- chunk_id: chunk-0005
source_document: LICENSE.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 240
content_hash: c4aceba8f89a8625
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
section_heading: The grant
document_type: technical_reference

## The grant

KBMill grants the right to run the KBMill plant image on one host. The package inside the image is `vectorforge_pro`. KBMill and that package are the same vendor. One purchase is one host. The host is the fingerprint the image prints. The host is not the hostname. The buyer does not edit that line and does not compute it by hand. ### The signed file
KBMill signs a file that names that fingerprint. The private key that signs it stays with KBMill. The key is not in the image, and it is not part of the file the buyer receives. The buyer runs this command inside the plant container:

`python3 -m vectorforge_pro.plant_license`

It prints one line. The buyer sends that line through Contact operator on kbmill.com, or by email to carroll@kbmill.com. KBMill sends the signed file back. There is no download URL. The buyer points `VF_PLANT_LICENSE` at that file. If the variable is unset, the image reads `/var/lib/kbmill/license.json`. The installed image contains `/usr/local/share/kbmill/license.required`, so it asks for this file. A machine without that marker does not ask.

--- chunk_id: chunk-0006
source_document: LICENSE.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 196
content_hash: 57a6bf710558c35d
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: What the host may do
document_type: technical_reference

## What the host may do

On the named host, the plant may mill a pile into a brick. The brick file is the handoff. The buyer keeps the brick. A drop and a tool call use the same mill. One job runs at a time. A second job waits. ### What this license does not grant
A shelf license does not start the plant. A file that names another fingerprint does not start the plant. A missing file does not start the plant. This license does not run the desk, does not run the shelf, and does not include a chat model. Copying the image to another machine does not move the right to run it. Copying a brick does not move that right. The brick does not contain this license. This license does not charge a card. Payment for the public trial stays on kbmill.com.

--- chunk_id: chunk-0007
source_document: LICENSE.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 134
content_hash: 2d553ad33b04dd98
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: The shelf
document_type: technical_reference

## The shelf

An unsigned brick still belongs on the shelf. A brick with a stale signature still belongs on the shelf. Milling a brick does not put it on the shelf. The shelf has its own license. A plant license does not start the shelf. ### End
KBMill may end this license in writing if the image is run on a host the file does not name. The buyer may stop using the image on that host. Ending the license does not take the buyer's brick. Questions and failures go to Contact operator, or to carroll@kbmill.com. Carroll Miller, d/b/a KBMill.

--- chunk_id: chunk-0008
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 41
content_hash: 39d3c30466c0c545
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: KBMill plant install and troubleshooting
document_type: technical_reference

# KBMill plant install and troubleshooting

This is the install and troubleshooting guide for the plant image. It is not the operating manual. This image does not carry the manual. 2026-10-10.

--- chunk_id: chunk-0009
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 218
content_hash: 37e7f338aef27628
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
section_heading: Load the file
document_type: technical_reference

## Load the file

The file is `kbmill-plant.tar`. The tag is `kbmill-plant:0.1.0`. The file is 3378268160 bytes. It fits one single-layer DVD. Load it with the container engine the machine already allows. Docker or Podman. Do not pull an image. The network can stay off. Podman 3.4 loads this tag as `localhost/kbmill-plant:0.1.0`. Use that name on Podman 3.4. Docker uses `kbmill-plant:0.1.0`. The package inside the image is `vectorforge_pro`. ### Show the fingerprint
Run this inside the plant container. Do not install a package to get it. `python3 -m vectorforge_pro.plant_license`

It prints one line. That line is the fingerprint. It is not the hostname. The command does not read the license. Send that line through Contact operator on kbmill.com, or email it to carroll@kbmill.com. KBMill sends a signed file back. There is no download URL. If the command prints `FINGERPRINT_UNAVAILABLE`, the container cannot see an id. Mount the machine's `/etc/machine-id` at `/host/machine-id`, read-only, and run the command again. A virtual machine usually needs that mount.

--- chunk_id: chunk-0010
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 217
content_hash: f92ce47c9539739c
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
section_heading: Put the license where the plant reads it
document_type: technical_reference

## Put the license where the plant reads it

Point `VF_PLANT_LICENSE` at the file KBMill sent. If you do not set the variable, the image reads `/var/lib/kbmill/license.json`. Use the plant file only. A shelf license does not start the plant. The image listens on `127.0.0.1:8771` when the door is the command. A missing license does not stop the fingerprint command. A missing license does stop a mill. ### Mill a pile
The drop page takes files and a brick name. It shows the job this session started. It does not link to the config page. One job runs at a time. A second job waits. When the job is a brick, that session can download the package. `POST /tool/run` takes a name and a path already on the host. A path with `://` is refused. The call returns `success` or `refused`, plus the job id and a path. No chat model is in the image. A customer job does not call a model.

--- chunk_id: chunk-0011
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 254
content_hash: cc94d386eefca361
prev_chunk_id: chunk-0010
next_chunk_id: chunk-0012
section_heading: When the plant refuses
document_type: technical_reference

## When the plant refuses

Use the line in front of you. | What you see | What to do |
|---|---|
| `plant license missing` | Point `VF_PLANT_LICENSE` at the plant file KBMill sent, or place that file at `/var/lib/kbmill/license.json`. |
| `plant license does not name this host` | The file names another machine. Send this machine's fingerprint. Do not send the hostname. |
| `plant license signature refused` | The file is not a signed plant license. A shelf license does not start the plant. Use the file KBMill sent. |
| `host fingerprint unavailable` | Mount `/etc/machine-id` at `/host/machine-id`, read-only, and print the fingerprint again. | A missing license does not mill a brick. It does not stop the fingerprint command. ### The shelf
Milling a brick does not put it on the shelf. Copy the brick into the library folder, then build the catalog from inside the shelf image. An unsigned brick still belongs on the shelf. A stale signature still belongs on the shelf. The shelf has its own license. This brick is named KBMill_Plant_Install. That is the name for the next KBMill plant disc.

--- chunk_id: chunk-0012
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 46
content_hash: 1ff8f29ac9bf1a4f
prev_chunk_id: chunk-0011
next_chunk_id: null
section_heading: Complaints
document_type: technical_reference

## Complaints

There is one path back to the operator. Use Contact operator on kbmill.com, or email carroll@kbmill.com. An air-gapped machine still has this guide. Send the note from a machine that can reach them.
