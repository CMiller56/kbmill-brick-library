# Residual board — S4214_AI_Data_Center_Moratorium_119IS

Status: **success**

## Counts
- in kb: 10  |  muted / off RAG: 0  |  on RAG path: 10
- embedded rows: 10
- reconciled: True

## Quality score (if present)
- avg_extraction_quality: **1.0**
- measures: text-layer coverage / extractability (pages that produced usable text), not character-level OCR accuracy

## Limits / open items
- (none recorded)

