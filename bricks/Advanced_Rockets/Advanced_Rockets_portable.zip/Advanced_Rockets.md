---
kb_id: advancerocketenginesen-avt-150-06
title: AdvanceRocketEnginesEN AVT 150 06
author: Unknown Author
created_date: 2026-07-03
classification: Internal
confidence_level: Medium
domain_tags: ["propulsion", "rocket", "aerospace", "reference", "engineering"]
entity_mentions: ["system and", "SYSTEM BASICS"]
document_type: Technical Reference
primary_subject: Advanced Rocket Engines 
Oskar J. Haidn 
Institute of Space Propulsion, German Aerospace Center (DLR) 
74239 Lampoldshausen 
Germany 
oskar.haidn@dlr.de 
SUMMARY  
Starting with some basics about space transportation systems such as the thrust equation and some 
mission requirements, the paper expla
intended_audience: Engineers
sources: [{"filename": "AdvanceRocketEnginesEN-AVT-150-06.pdf", "path": "kbs/Advanced_Rockets/.pro/upload_staging/AdvanceRocketEnginesEN-AVT-150-06.pdf", "page_count": 40}]
ingest_provenance: {"captured_at": "2026-07-03T12:30:44.221268", "page_count": 40, "extraction_methods": {"pymupdf": 32, "docling+ocr_context": 8}, "avg_extraction_quality": 0.9685, "docling_triage_pages": 8, "docling_triage_rate": 0.2, "extraction_stats": {"page_count": 40, "total_document_pages": 40, "page_range": null, "docling_triage_count": 8, "docling_executed_count": 8, "docling_page_count": 8, "docling_triage_rate": 0.2, "pass1_ms": 271.53, "pass2_ms": 12799.14, "total_ms": 13070.69, "pages_per_sec": 3.06}}
dark_data_inferred_fields: ["document_type", "document_type_confidence", "document_type_inferred", "domain_tags", "ingest_provenance", "sources"]
date: 2026-07-03
tags: ["propulsion", "rocket", "aerospace"]
audience: Engineers
summary: Advanced Rocket Engines 
Oskar J. Haidn 
Institute of Space Propulsion, German Aerospace Center (DLR) 
74239 Lampoldshausen 
Germany 
oskar.haidn@dlr.de 
SUMMARY  
Starting with some basics about space transportation systems such as the thrust equation and some 
mission requirements, the paper expla
document_type_inferred: True
document_type_confidence: 1.0
kb_name: Advanced_Rockets
created: 2026-07-03T12:30:44.221356
kb_version: 2
schema_version: vectorforge_kb_v1
change_summary: "Timeline commit \u2014 Advanced_Rockets (1 ops)"
total_chunks: 67
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-07-03T12:46:25.694779
  chunk_count: 67
  strict_air_gapped: true
---

--- chunk_id: chunk-0000
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 1
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 489
content_hash: f4ec50582589bb82
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: Advanced Rocket Engines
document_type: technical_reference

## Advanced Rocket Engines

RTO-EN-AVT-150 
6 - 1 
 
 
Advanced Rocket Engines 
Oskar J. Haidn 
Institute of Space Propulsion, German Aerospace Center (DLR) 
74239 Lampoldshausen 
Germany 
oskar.haidn@dlr.de 
SUMMARY  
Starting with some basics about space transportation systems such as the thrust equation and some 
mission requirements, the paper explains the underlying physical and technical challenges every rocket 
engine design engineer faces at the beginning of a project. A brief overview about the main subsystems of 
a liquid rocket engine such as turbopumps and gas generators is followed by a more detailed description 
of the thrust chamber assembly, the injector head, the ignition system and the combustion chamber liner 
which includes the first part of the nozzle and finally the nozzle extension. The technological challenges of 
these components are presented which result from the severe operating conditions and their current 
design principles and production technologies. Finally, a series of new concepts and techniques for propellant injection, ignition, combustion chamber 
liners and nozzles are proposed. The major challenges of new materials and production technologies lay 
in the still missing detailed knowledge about the behaviour of these materials under operating conditions, 
material-related crack initiation and propagation laws and reliable life prediction tools. INTRODUCTION 
Rocket engines may either work with solid or liquid propellants or as a combination of both, hybrid 
propulsion systems, such as the one for the SpaceShipOne project. Liquid rocket engines can be 
subdivided into mono-propellant or bi-propellant systems. Mono-propellant engines operate either as a 
simple cold gas system or apply a catalyst for an exothermal decomposition of the propellant, such as 
hydrazine (N2H4) or laughing gas (N2O). Generally these type of engines are only in use for low thrust 
satellite propulsion systems. Typical bi-propellant engines use either earth storable propellants, generally 
combinations of nitric acid or its anhydride with derivates of hydrazine, i.e. asymmetric di-methyl-
hydrazine (UDMH) or mono-methyl-hydrazine (MMH), mixtures of storable and cryogenic propellants, 
liquid oxygen and kerosene or fully cryogenic, liquid oxygen and liquid hydrogen. Although rocket 
engines show large differences depending on mission profile and staging of the launcher it is possible 
useful to separate them in four major classes. Booster, main stage and upper stage engines and satellite 
propulsion and attitude control systems [1,2].

--- chunk_id: chunk-0001
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 1
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 214
content_hash: d49b57c007f1dcdf
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
document_type: technical_reference

Although rocket 
engines show large differences depending on mission profile and staging of the launcher it is possible 
useful to separate them in four major classes. Booster, main stage and upper stage engines and satellite 
propulsion and attitude control systems [1,2]. Rocket engines are energy conversions systems with a heat release in the combustion chamber which 
exceed by far typical values of nuclear power plants (~ 3-4 GW). While solid rocket engines may even 
reach power levels of more than 30 GW, the most powerful liquid rocket engines have peak power values 
of up to 20 GW but the majority works with values of less than 10 GW. Obviously such power levels are 
only possible with high combustion chamber pressures and even higher propellant mass flow rates which 
may exceed 1000 kg/s. Haidn, O.J. (2008) Advanced Rocket Engines. In Advances on Propulsion Technology for High-Speed Aircraft (pp. 6-1 – 6-40). Educational 
Notes RTO-EN-AVT-150, Paper 6. Neuilly-sur-Seine, France: RTO. Available from: http://www.rto.nato.int.

--- chunk_id: chunk-0002
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 2
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 466
content_hash: e62973d27d09df44
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: 1.CHEMICAL PROPULSION SYSTEM BASICS
document_type: technical_reference

### 1.CHEMICAL PROPULSION SYSTEM BASICS

The basic concept of a rocket engine relays on the release of the internal energy of the propellant molecules in the combustion chamber, the acceleration of the reaction product and finally the release of

### 1.1 Thrust equation

The thrust equation which describes the basic relations of a chemical rocket was first given in 1903 by the Russian Konstantin Tsiolkovskiy. Assuming a frictionless, 1-D flow of an ideal gas with negligible entry velocity and the heat release in the combustion chamber at constant pressure with adiabatic walls, see Fig. 1, the thrust equation can be written as:

Figure 1: Schematic of an ideal rocket engine

<!-- image -->

<!-- formula-not-decoded -->

ue, the exhaust gas velocity at the exit area Ae, Pe, the exit and p。 the ambient pressure, respectively. The first term in eqn. (1) is the momentum and the second, the pressure part of the thrust and replacing C =ue +(pe - P)Ae / m or c =C c* finally yields:

<!-- formula-not-decoded -->

C is commonly known as the thrust coefficient, c, the effective exit velocity and c* the characteristic velocity. It is useful to examine these coefficients in more detail since they give valuable hints about the relevance of fluid properties and operational parameters. The characteristic velocity relates the combustion chamber pressure to the burned propellants and thus represents the energy content of the propellant and the combustion efficiency. The widely used term "specific impulse" is available with the gravitational constant go. <!-- formula-not-decoded -->

with ε , the ratio of cross section of nozzle exit and combustion chamber throat. As equation (3) shows, the characteristic velocity increases with increasing combustion temperature T,, but decreases with growing molecular weight M and isentropic coefficient k of the exhaust gases. This the ratio between exit pressure and chamber pressure and, in the second term the difference of exit and ambient pressure. Although large exit velocities are quite favourable, the corresponding expansion in the nozzle may depending of the height during ascent result in exit pressures smaller than the ambient

<!-- image -->

ORGANIZATION

--- chunk_id: chunk-0003
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 3
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 488
content_hash: 928047f9e579f51c
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: 1.CHEMICAL PROPULSION SYSTEM BASICS
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 3 
 
 
pressure which finally yields a smaller thrust coefficient. Typical values of these characteristic properties 
for a wide range of rocket engines are summarized in the following table 1 [3]. Table 1: Typical values of characteristic properties of rocket engines 
 
A rather interesting aspect about the impact of the combustion chamber pressure on the performance 
of the engine is demonstrated in figure 2 which shows the vacuum specific impulse as a function of the 
area ratio. While variations in the chamber pressure itself have only a minor influence, i.e. an increase by a 
factor of six yields only a marginal (about 0.1 %) performance increase, an only minor increase of the 
combustion efficiency (by 1% from 0.96 to 0.97) yields already an increase of the performance of about 
1%. 4250
4300
4350
4400
4450
4500
4550
4600
4650
50
100
150
200
250
300
350
400
N ozzle A rea R atio A e/A t
Vacuum Specific Impulse / m/s
pc = 200 bar, ηIsp = 0,97
pc = 200 bar, ηIsp = 0,96
pc = 35 bar, ηIsp = 0,96
4250
4300
4350
4400
4450
4500
4550
4600
4650
50
100
150
200
250
300
350
400
N ozzle A rea R atio A e/A t
Vacuum Specific Impulse / m/s
pc = 200 bar, ηIsp = 0,97
pc = 200 bar, ηIsp = 0,96
pc = 35 bar, ηIsp = 0,96
 
Figure 2: Vacuum specific impulse as a function of the area ratio  
with chamber pressure and combustion efficiency 
1.2 
Propellants 
Following the previous chapter on characteristic properties allows a classification of typical 
propellants for rocket engines. Key requirements are high combustion chamber temperatures, usually 
achievable with a high energy content of the molecules, a small isentropic coefficient and the smallest 
possible molecular weight of the exhaust gas mixture. Depending on the specific launcher system, rocket 
engine cycle or mission requirements, values such as propellant density or temperature may become even 
more important. Generally, the propellant combination H2/O2 is favourable for upper stage engines while 
Tc [K] 
Pc [MPa] 
M [kmol/kg] 
c* [m/s] 
Ɛ [-] 
K [-] 
CF [-] 
Isp[-] 
2000-3900 
1-26 
2-30 
900-2500 
15-280 
1,1-1,6 
1,3-2,9 
150-480

--- chunk_id: chunk-0004
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 4
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 453
content_hash: e0e9e0effb1dd26c
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: 1.CHEMICAL PROPULSION SYSTEM BASICS
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 4 
RTO-EN-AVT-150 
 
 
booster engines either apply kerosene / oxygen or solid propellants and as such quite often a combination 
of ammonia per-chlorate (AP), hydroxy-terminated poly-butadien (HTPB) and some ingredients which 
have the function of either a binder or a moderator to control the heat regression rate and thus the overall 
booster performance. In the early days of rocketry hypergolic propellant combinations of nitrogen-tetroxide (N2O4) and 
mixtures of N2H4 and UDMH or MMH have been used for almost any engine application although they 
have a comparatively small specific impulse, are toxic and cause due to their aggressiveness problems 
during storage and handling but nowadays they are very common only for upper stages and satellite 
propulsion systems. The main reason for this wide-spread usage is based on their chemical reactivity; they 
don’t require an ignition system and are storable at room temperature. Nowadays booster engines using 
kerosene / O2 are commonly used and the most impressing examples are the Energomash engines of the 
RD-170 family which power the first stages of the Zenit (RD-171) and the ATLAS (RD-180) launchers. Table 2 shows frequently used propellant combinations, their mixture ratios, specific impulse and 
densities. For further information see i.e. [3, 4] 
Table 2: Characteristic data of typical liquid propellants 
Oxidizer 
Fuel 
rof 
[-] 
Isp 
[s] 
ρ 
[kg/m3] 
kerosene 
2,77 
358 
820 
LH2 
4,83 
455 
700 
LO2 
LCH4 
3,45 
369 
430 
UDMH 
1,95 
342 
791 
MMH 
2,37 
341 
880 
N2O4 
UH25 
2,15 
340 
850 
 
The influence of the propellant combination and the mixture ratio on the specific impulse is shown in 
Figure 3. Three different classes of propellants can easily be detected. H2/O2 is by far (~30%) the most 
efficient propellant pair followed by combinations of O2 and hydrocarbons and interestingly the specific 
impulse decreases with increasing carbon content. Fuels which already contain oxygen atoms, alcohols, 
follow by another 10% margin and have an almost similar specific impulse as storable propellant 
combinations. For comparison reasons figure 3 includes as well propellant combinations of which use 
hydrogen-peroxide H2O2 as oxidizer.

--- chunk_id: chunk-0005
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 5
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 448
content_hash: 78eb12349f5e2963
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
section_heading: 1.CHEMICAL PROPULSION SYSTEM BASICS
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 5 
 
 
2500
2700
2900
3100
3300
3500
3700
3900
4100
4300
4500
0
1
2
3
4
5
6
7
8
9
Propellant Mixture Ratio O/F  [-]
Ideal Specific Vacuum Impulse Ivac  [N·s/kg]
Ideal Specific Vacuum 
Impulse 
pc = 100 bar,  Ae/At = 45,  CET93
90%-H2O2-Kerosene
LOX-Methane
LOX-Methanol
LOX-Ethanol
LOX-Kerosene
LOX-Propane
90%-H2O2-Ethanol
LOX-LH2
N2O4-MMH
 
Figure 3: Ideal specific impulse of various propellant combinations 
A possibility to combine the advantages of high propellant density at low altitude operation with high 
specific impulse at high altitudes is a combination of three propellants. So-called tri-propellant 
combinations of LOX, kerosene, LH2 or LOX, CH4, LH2 burn in the same engine LOX / kerosene at low 
altitudes and switch to LOX / LH2 operation at high altitudes have been investigated in the past but have 
never reached the level of flight hardware. The RD – 701 engine (LOX / kerosene which has been 
designed for the air-launch MAKS concept reached at least development level [1]. 1.3 
Engine feed systems 
The easiest way to distinguish different engine types is to classify them according to their method of 
propellant pressurization and transport. While only small and low pressure engines apply pressurized tanks 
for propellant delivery, the majority uses turbo pumps in order to bring the propellants to the desired 
pressure level. 1.3.1 
Pressure-fed engines 
Principally there are two types of pressure-fed systems, self-pressurization and pressurization by 
foreign high pressure gas. Self-pressurization is typically applied by mono-propellant engines and is 
achieved either by vaporization of the liquid propellant or thermal decomposition caused external heat 
addition or catalytic decomposition. Pressure-fed bi-propellant engines typically apply high pressure (up to 
30 MPa) helium bottles. In any case, the thrust level of pressure-fed engines is limited by the available 
tank technology. An example of such a system is the AESTUS engine of ARIANE 5G. A flow schematic 
of a pressure-fed engine is shown on the right hand side of figure 4 together with a gas generator cycle and 
a staged combustion cycle.

--- chunk_id: chunk-0006
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 6
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 506
content_hash: 5f06c0ebd016a179
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: 1.CHEMICAL PROPULSION SYSTEM BASICS
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 6 
RTO-EN-AVT-150 
 
 
LOX
Fuel
gas generator 
expander
Fuel
OX
Pressure-fed system
Pump-fed systems
LOX
Fuel
LOX
Fuel
staged combustion 
LOX
Fuel
gas generator 
expander
Fuel
OX
Pressure-fed system
Pump-fed systems
LOX
Fuel
LOX
Fuel
LOX
Fuel
gas generator 
expander
Fuel
OX
Pressure-fed system
Fuel
OX
Fuel
OX
Pressure-fed system
Pump-fed systems
LOX
Fuel
LOX
Fuel
LOX
Fuel
LOX
Fuel
staged combustion 
 
Figure 4: Common Engine Cycles 
1.3.2 Pump-fed engines 
In contrast to pressure-fed systems, pump-fed engines use the principle of a turbo-charger to 
pressurize the propellants. Parts of the propellants are fed into a separate combustion chamber called gas 
generator or pre-burner which usually operates at a sufficiently high pressure level and with a mixture 
ratio such that the exhaust gas temperature reaches values around 850 K. These gases are then fed to a 
turbine which drives the propellants pumps. Depending on the pathway of the turbine exhaust gases one 
distinguishes between different engines cycles. The cycle schematics in figure 3 show that the case 
characterized by the direct release of the turbine exhaust gases into the ambient is called “Gas Generator 
Cycle”. In the case that they are fed together with the remainder of the propellants into the main 
combustion chamber, this cycle is called „Staged Combustion Cycle“. The differences between those two 
options are first, much higher system pressures since the gas generator has to operate at a pressure 
sufficiently high to compensate the pressure losses in the turbine, the cooling channels and the injector 
head and second a better performance since all the propellants go through the main chamber and thus 
produce both a higher mass flow rate and allow so for a larger nozzle expansion ratio and finally for an 
equivalent increase in the specific impulse. With the exception of Russian LOX/kerosene stage combustion engines which run oxygen-rich, all 
other gas generator or staged combustion systems operate in a fuel-rich mode. As part of the Integrated 
High Payoff Rocket Propulsion Technology (IHPRP) program [5], the US aims at the development of an 
integrated power-head which focuses on the most critical sub-components of this cycle, the oxygen-rich 
pre-burner and turbine as well as the injection system of the main chamber. China as well works towards 
the development of staged combustion technology [6].

--- chunk_id: chunk-0007
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 6
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 158
content_hash: 27eabc3a48f8bb40
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: 1.CHEMICAL PROPULSION SYSTEM BASICS
document_type: technical_reference

As part of the Integrated 
High Payoff Rocket Propulsion Technology (IHPRP) program [5], the US aims at the development of an 
integrated power-head which focuses on the most critical sub-components of this cycle, the oxygen-rich 
pre-burner and turbine as well as the injection system of the main chamber. China as well works towards 
the development of staged combustion technology [6]. The attractiveness of a full flow cycle engine 
results from a higher overall system performance and the elimination of critical inter-propellant seals [7]. Nevertheless, there has been only one rocket engine to date, the Russian RD-270, which had an ox-rich 
and a fuel-rich pre-burner which made it full scale to the test facility but unfortunately never into flight 
[1].

--- chunk_id: chunk-0008
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 7
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 465
content_hash: fa334e6044d260b7
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: 1.CHEMICAL PROPULSION SYSTEM BASICS
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 7 
 
 
1.4 
Engine applications 
Typically the propulsion systems and thus the rocket engines are tailored to the specific requirements 
of the launching concept. This has consequences insofar as any improvement or modification of the engine 
has significant impact on the entire launch system and, even more important, an improvement of the 
engine, i.e. engine performance, may not necessarily improve the overall efficiency of the launcher. The 
currently operational space transportation systems can be divided into two major types: Launchers with 
large strap-on boosters with core and upper stages such as the European ARIANE, the Japanese HII, the 
Russian Soyuz or the American Space Shuttle and launchers with a booster, an optional sustainer and an 
upper stage such as the American ATLAS and Delta, the Russian PROTON, the Chinese Long March or 
the international Sea Launch Vehicle [2]. Typical booster engines provide a high lift-off thrust (i.e. 3000 – 8000 kN) over a short burning time 
(i.e. < 150 s). Table 3 shows characteristic values of booster engines. Engines with a thrust level smaller 
than 3 MN are clustered together to provide the necessary lift-off thrust. For example, the Soyuz boost 
system consists of an ensemble of four RD-107 engines, the YF-21 boost stage comes with 4 YF-20 
engines and the ARIANE 4 L40 configuration was made up by 4 Viking 6 engines. Core engines provide 
a comparable lower lift-off thrust (i.e. 1000 - 2000 kN) but with a higher specific impulse and with 
operating times in the range of about 600 sec. The thrust levels of upper stage engines vary between 30 – 
150 kN with operating times varying between 600 – 1100 sec. Typical representatives of booster, main 
stage and upper stage engines are summarized in table 3, table 4 and table 5. Unsurprisingly, almost all of 
the booster engines shown in table 3 are fueled with relatively high density propellants and only one, the 
RS-68 operates with the unfavorable density combination LOX/LH2. Table 3: Characteristic data of liquid booster engines [2, 8] 
Rocket 
Engine 
Engine 
Cycle 
Propellant 
combination 
Thrust 
[MN] 
spec.

--- chunk_id: chunk-0009
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 7
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 172
content_hash: bbd75ea8bd2042d4
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
section_heading: 1.CHEMICAL PROPULSION SYSTEM BASICS
document_type: technical_reference

Unsurprisingly, almost all of 
the booster engines shown in table 3 are fueled with relatively high density propellants and only one, the 
RS-68 operates with the unfavorable density combination LOX/LH2. Table 3: Characteristic data of liquid booster engines [2, 8] 
Rocket 
Engine 
Engine 
Cycle 
Propellant 
combination 
Thrust 
[MN] 
spec. impulse 
(sl) [s] 
Chamber 
pressure 
[MPa]  
Burn 
time [s] 
RD-170 
SC 
LO2/Kerosene 
7,65 
310 
25,1 
150 
RD-180 
SC 
LO2/Kerosene 
3,82 
311 
25,5 
150 
RD-107 
SC 
LO2/Kerosene 
0,81 
257 
5,9 
119 
F-1 
GG 
LO2/RP1 
6,91 
264 
6,6 
161 
MA-5A 
GG 
LO2/RP1 
1,84 
263 
4,4 
263 
RS-27 
GG 
LO2/RP1 
0,91 
263 
4,8 
265 
RD-253 
SC 
N2O4/UDMH 
1,47 
285 
15,2 
130 
YF-20 
GG 
N2O4/UDMH 
0,76 
259 
7,4 
170 
Viking 6 
GG 
N2O4/UH25 
0,68 
249 
5,9 
142 
RS-68 
GG 
LO2/LH2 
2,89 
360 
9,7 
249

--- chunk_id: chunk-0010
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 8
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 476
content_hash: 95b050de6ae977c1
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
section_heading: 1.CHEMICAL PROPULSION SYSTEM BASICS
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 8 
RTO-EN-AVT-150 
 
 
Table 4: Characteristic data of core and main stage engines [2, 8] 
Rocket 
Engine 
Engine 
Cycle 
Propellant 
combination 
Thrust 
(sl) 
[MN] 
Thrust 
(vac.) 
[MN] 
Spec. impulse 
(sl) [s] 
Spec. impulse 
(vac.) [s] 
Chamber 
pressure 
[MPa] 
Burn 
Time 
[s] 
RD-108 
SC 
LO2/Kerosene 
0.78 
1.01 
252 
319 
5.1 
290 
Viking 5C  
GG 
N2O4/UH25 
0.68 
0.75 
249 
278 
5.9 
142 
YF-20B 
GG 
N2O4/UDMH 
0.73 
0.81 
259 
289 
7.4 
170 
RS-68 
GG 
LO2/LH2 
2.89 
3.31 
360 
420 
9.7 
249 
SSME 
SC 
LO2/ LH2 
1.82 
2.28 
364 
453 
20.5 
480 
RD-0120 
SC 
LO2/ LH2 
1.51 
1.96 
359 
455 
21.8 
600 
LE-7A 
SC 
LO2/ LH2 
0.84 
1.10 
338 
438 
121 
390 
Vulcain 2 
GG 
LO2/ LH2 
0.94 
1.35 
320 
434 
11.6 
600 
 
Table 5: Characteristic data of upper stage engines [2, 8] 
Rocket 
Engine 
Engine 
Cycle 
Propellant 
combination 
Thrust 
(vac.) 
[ kN ] 
Spec. impulse 
(vac.) [s] 
Chamber 
pressure 
[MPa] 
Burn 
Time 
[s] 
11D58M 
SC 
LO2/Kerosene 
79.5 
353 
7,6 
680 
RD-0210 
SC 
N2O4/UDMH 
582 
327 
14.8 
230 
AESTUS 
PF 
N2O4/MMH 
30 
325 
1,0 
1100 
J-2 
GG 
LO2/ LH2 
890 
426 
4.4 
 
YF-75 
GG 
LO2/ LH2 
79 
440 
3.7 
470 
LE-5B 
EC 
LO2/ LH2 
137 
447 
3.6 
534 
HM7-B 
GG 
LO2/ LH2 
70 
447 
3.5 
731 
VINCI 
EC 
LO2/ LH2 
180 
465 
6.1 
 
RL-10B 
EC 
LO2/ LH2 
110 
462 
4.3 
700 
 
Main stage engines operate as booster engines right from the start and generally have thrust levels 
similar to clustered booster engines somewhere in the range between 800 kN to 2000 kN. The burn times 
however are much longer and may reach 400 s to 600 s. An analysis of the data presented in table 4 in 
more detail reveals some interesting features. Similar thrust levels and burning times of the SSME and the 
RD-0120 are no longer surprising, knowing that engines were developed to serve a similar purpose: 
provision of sufficient thrust for a manned vehicle in low earth orbit. The LOX/LH2 fired LE-7A and 
Vulcain 2, show comparable thrust levels and operating times and are applied as core engines in a 
launchers with two large thrust boosters each, the HII and the ARIANE 5, respectively.

--- chunk_id: chunk-0011
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 8
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 186
content_hash: 3b7dd310e7d483a3
prev_chunk_id: chunk-0010
next_chunk_id: chunk-0012
section_heading: 1.CHEMICAL PROPULSION SYSTEM BASICS
document_type: technical_reference

Similar thrust levels and burning times of the SSME and the 
RD-0120 are no longer surprising, knowing that engines were developed to serve a similar purpose: 
provision of sufficient thrust for a manned vehicle in low earth orbit. The LOX/LH2 fired LE-7A and 
Vulcain 2, show comparable thrust levels and operating times and are applied as core engines in a 
launchers with two large thrust boosters each, the HII and the ARIANE 5, respectively. A comparison of 
the data for the RD-108, Viking 5C, and YF-20B reveals similar parameters and again, these engines are 
all applied as clusters of engines in the first stage of launcher without large boosters. The key characteristic feature of an upper stage engine is the vacuum ignition capability. The broad 
differences in propellant combination, engine cycle, and thrust level are explainable only by the different

--- chunk_id: chunk-0012
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 9
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 512
content_hash: 589350a94ca24b45
prev_chunk_id: chunk-0011
next_chunk_id: chunk-0013
section_heading: 2.COMPONENTS OF LIQUID ROCKET ENGINES
document_type: technical_reference

<!-- image -->

applications. The main mission of the J-2, the second and third stage engine of the Saturn V, was to enable the spacecraft to leave the earth for the moon. The engine with the second-largest thrust level, the RD0210, has a considerably shorter burn time and brings the Block M of the Proton into GTO. All the other engines have thrust values below 200 kN and operating times between roughly 500s and up to 1100s. The thrust requirement for apogee engines and satellite thrusters for attitude control is much smaller than for any other engine. While the thrust levels of the first may reach up to 60o N, the latter first may have peak values in the order of less than 1oo N. Generally, attitude control thrusters are monopropellant years) and reliable functioning and the very high cyclic loads due to the pulse operation mode. Hence, a satellite engines is optimized towards aspects of long-life valve operation such as seals and leakage and corrosion. ### 2.COMPONENTS OF LIQUID ROCKET ENGINES

The key components of a liquid propellant rocket engine are the devices for propellant delivery, the turbines and pumps as well as the generators of the driving gases, i.e. gas generator or pre-burner, the propellant injection system, the thrust chamber which combines the combustion chamber and a short part of the diverging section of the nozzle which typically ends with a distribution manifold for the propellants used as coolant for the thrustchamber liner,and,finally the thrust nozzle.Each of these devices has its own design problems and criteria and the optimum of one component not necessarily leads to the optimum of the entire system. The following section will touch briefly the key issues of each of the components but will finally focus on the thrust chamber. ### 2.1 Gasgenerator andpreburner

The main requirement for any gas generator or preburner is the delivery of a sufficient amount of driver gas a designed pressure and temperature which guarantees a continuous propellant supply of the thrust chamber. A quick glance at equation (4), yields that the necessary turbine power depends aside of the desired the ratio of exit to entry pressure and the mass flow rate of the gases, solely on thermodynamic properties, temperature, heat capacity and isentropic coefficient, and ，of course the efficiency of the device.

--- chunk_id: chunk-0013
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 9
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 344
content_hash: 5bf13e361042b3ec
prev_chunk_id: chunk-0012
next_chunk_id: chunk-0014
section_heading: 2.COMPONENTS OF LIQUID ROCKET ENGINES
document_type: technical_reference

### 2.1 Gasgenerator andpreburner

The main requirement for any gas generator or preburner is the delivery of a sufficient amount of driver gas a designed pressure and temperature which guarantees a continuous propellant supply of the thrust chamber. A quick glance at equation (4), yields that the necessary turbine power depends aside of the desired the ratio of exit to entry pressure and the mass flow rate of the gases, solely on thermodynamic properties, temperature, heat capacity and isentropic coefficient, and ，of course the efficiency of the device. <!-- formula-not-decoded -->

As already mentioned previously, the turbine exit pressure in gas generator cycle engine is independent of the pressure in the thrust chamber. This is entirely different for staged combustion engines where the exhaust gases are fed to the chamber. While the combustion pressure in the gas generator lay frequently below the one in the thrust chamber, the pressures in the pre-burners are typically a factor of two or three higher, see table 6 which summarizes characteristic data of sample gas generators and preburners. A high turbine power may be achieved by appropriate mass flow rates and pre-burner exhaust gas temperatures. Due to the extremely high dynamic loads of the turbines, the entry temperature of the gas is limited to about 850 K to ensure sufficient turbine life which leaves only gas generator mass flow rate and pressure to adjust to the power needs. Extremely important is a homogenous temperature distribution at the entrance to the turbine to avoid local overheat at the turbine blades through hot spots.

--- chunk_id: chunk-0014
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 10
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 493
content_hash: fde72dde6631fc27
prev_chunk_id: chunk-0013
next_chunk_id: chunk-0015
section_heading: 2.COMPONENTS OF LIQUID ROCKET ENGINES
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 10 
RTO-EN-AVT-150 
 
 
Table 6: Characteristic data of sample gas generators and pre-burners [10] 
 
Vulcain 2 
SSME 
LE-7 
RD-0120
RF-1 
RD-180 
Propellant 
Combination 
LOX/H2 
LOX/H2 
LOX/H2
LOX/H2 
LOX/RP1 LOX/RP1 
T     [ K ] 
875 
940 / 870 
810 
846 
816 
820 
pGG [ MPa] 
10.1 
35 / 36 
21.0 
42.4 
 
55.6 
rof    [ - ] 
0.9 
0.89 / 0.8 
0.55 
0.81 
~55 
54 
m [ kg/s ] 
9.7 
80 / 30 
53 
78.6 
? 887 
P  [ MW ] 
5 / 14 
56 / 21 
4.5 / 19 
62 
44 
93.5 
pc  [ MPa ] 
11.6 
20.6 
12.7 
21.8 
6.6 
25.7 
 
An analysis of all the gas generator engines shows that cryogenic engines such as SSME, LE-7, RD-
0120, Vulcain 2, operate independently of the cycle, the gas generator or pre-burner in a fuel-rich mode. Taking into account that all liquid rocket engines operate fuel-rich and that the stoichiometric mixture is 
for any propellant combination always larger than 2, reveals that the amount of oxidizer outnumbers that 
of the fuel significantly. Hence, oxidizer-rich operation allows for a sufficient reduction of the turbine 
entry temperature since the mass flow rates are available. Although there has been considerable effort in 
the US to develop an oxidizer-rich cycle, only Russia seems to have mastered the problem of material 
compatibility of pre-burner, piping system and turbine as well as the injector head with high temperature 
(T > 800 K) oxygen-rich turbine gas since all Russian LOX/Kerosene engines operate oxygen-rich [9]. None of the American Lox/Kerosene engines, neither the old F1, nor the RS-27 and the MA-5A which are 
all gas generator cycle engines are running oxygen-rich although a fuel-rich operation will have problems 
with soot formation in the gas generator and subsequently soot deposition along the flow lines [1]. The 
only explanation might be that for the relatively short operation times of less than 200 s and rather small 
pressures in the gas generator soot deposition in the turbine might still be tolerable while for even shorter 
times of 150 s or shorter, either soot formation and deposition in the turbine is increased drastically or the 
key problem is soot deposition in the injection system and especially in the injectors.

--- chunk_id: chunk-0015
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 10
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 460
content_hash: 69827c77aab071be
prev_chunk_id: chunk-0014
next_chunk_id: chunk-0016
section_heading: 2.COMPONENTS OF LIQUID ROCKET ENGINES
document_type: technical_reference

None of the American Lox/Kerosene engines, neither the old F1, nor the RS-27 and the MA-5A which are 
all gas generator cycle engines are running oxygen-rich although a fuel-rich operation will have problems 
with soot formation in the gas generator and subsequently soot deposition along the flow lines [1]. The 
only explanation might be that for the relatively short operation times of less than 200 s and rather small 
pressures in the gas generator soot deposition in the turbine might still be tolerable while for even shorter 
times of 150 s or shorter, either soot formation and deposition in the turbine is increased drastically or the 
key problem is soot deposition in the injection system and especially in the injectors. In order to emphasize the difference between LOX/H2 and LOX/Kerosene as well as gas generator 
cycle and staged combustion cycle engines, table 5 summarizes typical data such as operating temperature, 
pressure and mixture ratio of the gas generator or pre-burner, the propellant mass flow rate, the power 
requirement of the turbine and the pressure in the thrust chamber. For comparison reasons an American, 
European, Japanese and Russian LOX/H2 engine are shown together with two, American and Russian 
LOX/Kerosene engine. Typically all cryogenic engines have for each propellant a turbine and a pump. Only the RD-180 has one single preburner which delivers the necessary driving gas to a one single stage 
turbine which again provides for the thrust requirements of the two propellant pumps, a single stage 
oxygen pump and a two stage fuel pump. 2.2 
Turbopumps 
The function of the turbopump system of a rocket engine is to receive the liquid propellants from the 
vehicle tanks at low pressure and supply them to the combustion chamber at the required flow rate and 
injection pressure. The energy to power the turbine itself is provided by the expansion of high pressure 
gases, which are usually mixtures of the propellants being pumped. Radial pumps and axial turbines are of 
common use. Figure 5 basic elements of a turbopump and their main function as well as the flow passages.

--- chunk_id: chunk-0016
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 11
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 164
content_hash: 40fd0dbfe743c135
prev_chunk_id: chunk-0015
next_chunk_id: chunk-0017
section_heading: 2.COMPONENTS OF LIQUID ROCKET ENGINES
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 11 
 
 
cycle
cycle
 
Figure 5: Basic elements of a turbopump and their functional description [11] 
2.2.1 Turbopump design considerations 
Turbomachinery design is an iterative process which requires the interaction of many disciplines, such 
as hydrodynamics, aerodynamics, mechanics, materials and processes, structural mechanics and analysis, 
rotor dynamics, thermodynamics and last but not least instrumentation and testing. The set of 
requirements, pump discharge pressure and flow rate, pump suction pressure, turbine drive cycle and 
efficiency, fluid properties, throttling range, life, reliability, weight and size, and cost are often 
contradictive and the final design is at best a compromise optimum for a specific application. The SSME 
powerhead shown in Figure 6 demonstrates the compact design of a liquid rocket engine.

--- chunk_id: chunk-0017
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 12
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 462
content_hash: 2be37207a462b957
prev_chunk_id: chunk-0016
next_chunk_id: chunk-0018
section_heading: 2.COMPONENTS OF LIQUID ROCKET ENGINES
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 12 
RTO-EN-AVT-150 
 
 
 
Figure 6: SSME Powerhead with preburners, turbopumps and thrust chamber assembly [11] 
2.2.2 
Pumps 
Pumps for engines with similar density fuel and oxidizer propellants such as RP-1/LOX and similar 
discharge pressure requirements will typically be optimum at approximately the same speed. This permits 
the fuel and oxidizer pumps to be placed on a common shaft and driven by a common turbine which is the 
case for the F1, RS-27 or the RD-180. Maximum pump speed is generally limited by the suction 
performance requirements to avoid cavitation to occur. Due to the large density difference between liquid 
hydrogen and liquid oxygen and the pressure drop required for regenerative cooling cryogenic engines 
usually have two separate pumps since the hydrogen pump has to operate at much higher speed to provide 
the necessary high exit pressures. Vehicle weight reductions achieved by thinner propellant tank walls result in lower pump inlet 
pressures and as a consequence the pump speed has to be reduced. Lower fluid velocities would in turn 
result in a larger inlet diameter and increased size and weight of the pump. Furthermore, typical high 
performance staged combustion engines require very high pump discharge pressures. A typical way to 
overcome these weight and size constrains of the power pack and still maintain sufficient margin for a safe 
operation are additional low pressure boost pumps which are applied in the SSME or RD-180 engine. The inducer diameter (inlet area) is selected to limit the fluid velocity so that the available inlet 
pressure is considerably higher than the dynamic pressure of the fluid, typically 200% for LOX and 100% 
for LH2. Once the inlet conditions are fixed, the shaft speed will be set such that cavitation at the blade 
tips is avoided. Increasing blade thickness to react pressure and centrifugal forces sets another constraint 
for tip speed since it decreases flow passage area and thus reduces the suction performance. Small flow 
rate pumps are generally less efficient than large flow rare pumps because the clearance and surface finish 
related losses cannot be scaled with size.

--- chunk_id: chunk-0018
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 13
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 418
content_hash: 0e76cd351b5f6fd9
prev_chunk_id: chunk-0017
next_chunk_id: chunk-0019
section_heading: 2.2.3 Turbines
document_type: technical_reference

<!-- image -->

### 2.2.3 Turbines

Optimum turbine efficiency requires a certain pitchline velocity which is a product of the shaft speed and the turbine diameter. The minimum weight turbine has the highest speed and smallest diameter within thestructural andmechanical arrangementlimitations. There are two types of turbines, impulse and reaction turbines which in rocketry may have one or more stages. Each stage consists of a stator part where the flow expands and accelerates and a rotor part where the impulse on the blades sets the rotor in motion thus transforming kinetic in mechanic energy. The impulse turbine is a constant pressure device since the area ratio between the blades is constant and ideally the only the direction of the flow changes. This type is usually applied in cases characterized by a high pressure drop and a small mass flow rate, i.e, gas generator cycle engine. Turbines with more stages may be further distinguished in velocity compound, expansion only the first stator, or pressure compound, expansion inevery stator stage. Reaction turbines distribute the expansion between stator and rotor and hence, the fluid passages between the blades have a converging cross section. This type of turbine is usually applied in expander or staged combustion cycle systems, typical reaction grade of 50% meaning half of the power of comes from the expansion, where a minimum pressure loss between pump and combustion chamber is almost which relates circumferential velocity at the mean diameter to the fluid velocity for an isentropic expansion between turbine entry and exit pressure. <!-- formula-not-decoded -->

Figure 7 shows the turbine efficiency as a function of the velocity ratio and reveals that the type of turbine too has an impact on the efficiency. Practical turbines have an about 5 and 10% smaller efficiency since the relations given above do not account for losses due to tip clearance. 1

Figure7:Singlestage turbine efficiency[12]

<!-- image -->

--- chunk_id: chunk-0019
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 14
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 516
content_hash: 8fa2ba9035faeb4d
prev_chunk_id: chunk-0018
next_chunk_id: chunk-0020
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 14 
RTO-EN-AVT-150 
 
 
2.2.4 
Materials for turbomachinery components 
In the design of turbomachinery various materials, Aluminium alloys, stainless steels, high strength 
steels, nickel base alloys, cobalt base alloys and titanium alloys are in use. Low pressure components are 
typically cast from Aluminium to avoid welds. Nickel-base superalloys such as Inconel 718 are applied 
used to cast pressure vessels where higher strength is required. The high strength-to-weight ratio of 
titanium is utilized to obtain the high tip speeds required for LH2 impellers and inducers. The high 
pressure high temperature hydrogen-rich steam may cause hydrogen embrittlement and thus requires the 
protection of high-strength superalloys with appropriate copper or gold plating. Turbine blades are often 
directionally solidified and thermally coated to cope with the extremely high heat fluxes. LO2 pumps 
where contact with the inducer or impeller could result in ignition are coated i.e. with silver. Similar 
materials and techniques are also used for potential contact with titanium impellers to preclude the 
formation of titanium hydrides due to heat generation. The LOX turbopump of the Vulcain 2 engine 
shown in figure 8 is a rather new example of an entire turbopump set, turbine plus pump, which 
demonstrates again the compactness of the design. Figure 8: LOX turbopump of the Vulcain 2 engine [12] 
2.2.5 
Bearings and seals 
Aside pump and turbine any turbopump requires components such as bearings, seals, gears and the 
suction and discharge ducts. There are two kind of bearings, rolling elements and fluid film ones and they 
have to perform three primary functions, radial control of the rotor to prevent rubs and to maintain 
clearance, axial control of the rotor to maintain rotor control during transient mechanic and thermal loads 
and to react residual thrust loads and third, control of rotordynamics to provide for adequate radial 
stiffness and damping. They are usually cooled by the fluid which quite often doesn’t provide for 
lubrication, operate at high speeds and are exposed to high transient radial and axial loads. While static 
seal design in rocketry generally doesn’t exceed standard procedures, dynamic seals which separate 
stationary and rotating parts are critical. Dynamic seals just must not fail. There are different types of 
seals, labyrinth, face contact or shaft contacting, floating ring or hydrodynamic face seals. Major design 
problems are fluid compatibility, thermal gradients and dynamic loads.

--- chunk_id: chunk-0020
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 15
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 316
content_hash: dc64a108c4d864bf
prev_chunk_id: chunk-0019
next_chunk_id: chunk-0021
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 15 
 
 
2.3 
Thrust chamber assembly  
In a liquid propellant rocket engine, the function of the thrust chamber assembly is to generate thrust 
by efficiently converting the propellant chemical energy into hot gas kinetic energy. That conversion is 
accomplished by the combustion of the propellants in the combustion chamber, followed by acceleration 
of the hot gas through a convergent/divergent nozzle to achieve high gas velocities and thrust. The basic 
elements of the thrust chamber assembly of a rocket engine consists of the following components which 
are closely coupled in their functioning and therefore have to be designed in parallel: the cardan, welded to 
the injector head which is which holds the propellant distribution manifolds and the ignition system and 
the combustion chamber liner including the throat section and the first part of the nozzle to which the inlet 
manifold for the coolant is welded. Looking at figure 9, a sketch of the Vulcain thrust chamber, simplifies 
the explanation of these parts. Figure 9: Cut through the Vulcain thrust chamber [12] 
The cardan on top of the LOX dome which allows thrust vector control through gimballing, connects 
the engine with the launcher. The injector head has various functions, it distributes the incoming 
propellants according to the needs of the injectors, holds the ignition system and the propellant injectors 
which decouple the combustion chamber from the fluid supply system. The liquid oxygen enters directly

--- chunk_id: chunk-0021
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 16
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 510
content_hash: c708d310cfa7c474
prev_chunk_id: chunk-0020
next_chunk_id: chunk-0022
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 16 
RTO-EN-AVT-150 
 
 
from the turbopump while the hydrogen has already passed the cooling channels and the outlet manifold. At the lower end of the regenerative cooled liner the distribution manifold of the fuel is welded and which 
acts also partially as a mount for the nozzle extension. 2.3.1 
Ignition system 
A successful ignition is the outcome of matching conditions of propellant mass flow rates and mixture 
ratio and initiation energy in time and in space. However, the ignition of a rocket engine has also to be 
smooth with negligible pressure peaks to reduce the risk of triggering combustion instabilities or 
damaging the cooling channels. Combustion chamber pressure peaks may cause a partial blockage of the 
propellant flow inside the chamber yielding extinction or damage the turbopumps. Hence, exact timing of 
ignition initiation and propellants valve opening is essential. Furthermore, the local mixture ratio of the 
propellants has to be sufficiently far inside the flammability limits, the energy provided by the ignition 
system has be high enough to vaporize and preheat the gaseous propellants above the ignition temperature. Once a chemical reaction has started, the local heat release has to be sufficiently high to overcome the 
losses. With propellant temperatures below 100 K the process of vaporization and heating especially 
during the start-up transient may exceed a couple of milliseconds and hence flame extinction may occur 
locally. In combination with the high propellant mass flow rates even a few milliseconds may locally yield 
a sufficient amount of premixed propellants which may have catastrophic consequences. Therefore a 
coupled development of injection and ignition system is mandatory for a successful design. There are 
quite a large number of ignition devices which either use pyrotechnical propellant charges, hypergolic lead 
or a torch ignition system with gaseous propellants. An example of a solid propellant based system, the 
pyrotechnical ignitor of the Vulcain engine is shown in Figure 10. Figure 10: Pyrotechnic ignition system of the Vulcain engine 
The methodology aims at a prediction of the propellant mass flow rates in order to establish a mixture 
ratio map. Second, the hot exhaust gases from the ignition system are injected and mixed with the 
propellants without a prediction of the chemical reaction. The main aim is to establish a temperature map 
inside the combustion chamber.

--- chunk_id: chunk-0022
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 16
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 141
content_hash: 000fb4af25e35931
prev_chunk_id: chunk-0021
next_chunk_id: chunk-0023
section_heading: 2.2.3 Turbines
document_type: technical_reference

Second, the hot exhaust gases from the ignition system are injected and mixed with the 
propellants without a prediction of the chemical reaction. The main aim is to establish a temperature map 
inside the combustion chamber. Based on the results of mixture ratio and temperature distributions a map 
of local ignition probabilities is predicted and successful ignition is assumed when the area where ignition 
probability exceed a predefined limit is sufficiently high. 2.3.2 
Injector head 
As part of the thrust chamber assembly, the essential function of the injector head assembly is to 
uniformly inject liquid propellants into the combustion chamber at the proper oxidizer/fuel mixture ratio.

--- chunk_id: chunk-0023
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 17
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 470
content_hash: a8657bbed89b1609
prev_chunk_id: chunk-0022
next_chunk_id: chunk-0024
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 17 
 
 
The geometry of the propellant distribution manifolds should dampen secondary flows resulting from the 
turbopump or piping systems. Injector heads in engines which work with storable or very cold cryogenic 
propellants are frequently equipped with baffles or cavities which work as damping devices. Furthermore, 
injection elements have a significant pressure loss, about 15-20% of the combustion pressure, work as 
damping elements and at least partially decouple dynamically the propellant feed system from the 
combustion chamber. There are four different basic concepts of propellant injection: impinging injection, swirl injection, 
parallel injection in form of a showerhead, and shear coax injection and combinations of these concepts, 
i.e. a swirl coax injector which can be found in the HM-7B engines or a swirl and impinging as in the 
AESTUS engine. Any injector has to introduce the propellants into the combustion chamber in a manner 
to promote propellant mixing and droplet atomization by either impinging propellant streams, swirling, 
shear mixing or other mechanical means of achieving maximum atomization. Within the combustion 
chamber, ignition is achieved and vaporization of the atomized droplet is initiated by heat transfer from 
the surrounding 3500 K hot gas. The size and velocity of the droplets change continuously during their 
entrainment and acceleration in the hot gas combustion flow. As the combustion process progresses, the 
vaporized propellants are mixed rapidly, heated and react, thereby increasing the gas phase flow rate 
within the combustion chamber. Typically, a well-designed injector atomizes a large population of 
propellant droplets to less than 100 microns in diameter. Therefore, with proper injector and combustion 
chamber design, all droplet vaporization and combustion is completed before the combustion gas enters 
the chamber's narrow throat area. A major concern of any injector is the injector/wall interaction. In the vicinity of the face plate where 
propellant mixing is poor oxidizer-rich gases mixed with cryogenic droplets may get in contact with the 
combustion chamber walls. The result of this process, a combined physical and chemical attack, clearly 
visible on the wall of the combustion chamber liner of the Vulcain engine shown in figure 11, is called 
“blanching”.

--- chunk_id: chunk-0024
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 17
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 164
content_hash: 020dad4c60692512
prev_chunk_id: chunk-0023
next_chunk_id: chunk-0025
section_heading: 2.2.3 Turbines
document_type: technical_reference

In the vicinity of the face plate where 
propellant mixing is poor oxidizer-rich gases mixed with cryogenic droplets may get in contact with the 
combustion chamber walls. The result of this process, a combined physical and chemical attack, clearly 
visible on the wall of the combustion chamber liner of the Vulcain engine shown in figure 11, is called 
“blanching”. There are two methods to cope with this problem, first, injector trimming where the outmost 
row of the injectors operates with a smaller mixture ratio to reduce gas temperature and avoid oxidizer-
rich gas hit the surface, and, second, injection of a coolant film which has a similar effect. Figure 11: Footprint of ”Injector/Wall Interaction” on the combustion  
chamber liner of the Vulcain engine

--- chunk_id: chunk-0025
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 18
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 509
content_hash: a2b2c2983ae468b9
prev_chunk_id: chunk-0024
next_chunk_id: chunk-0026
section_heading: 2.2.3 Turbines
document_type: technical_reference

<!-- image -->

ORGANIZATION

In cases where both propellants enter the injector in a liquid state the injector of choice would be anyone of a kind of an impinging injector. An injector is called like-on-like if propellants of the same kind impinge on one another and like-on-unlike if fuel and oxidizer jets impinge. The working principle of an impinging injector is as follows: once the jets impinge on one another they form a liquid sheet which either decomposes into smaller fragments and atomizes and, in case of hypergolic propellants, reacts simultaneously (like-on-unlike) or interacts with another liquid sheet and the atomizes and reacts (like-onlike). The establishment of a lifted flame and a considerably large volume of partially premixed propellants is a major drawback of any impinging injector. The typical high mass flow rates establish within milliseconds a large enough amount of propellants which when they react suddenly may lead to pressure peaks which in turn may trigger combustion instabilities. small thrusters are often some type of coax injector. They usually create due to the numerous small recirculation zones in the vicinity of the face plate a very good mixing and combustion performance and allow as well for a simple establishment of a cooling film. The major drawbacks are the comparatively large pressure drop, the coupling between performance and thermal loads to the chamber walls and the very stringent precision requirements for production. Nevertheless, there are large engine applications as well such as the RD-170 engine family where this kind of elements are used among others to actively control combustion stability by locally introducing via a this different kind of atomization a different proplet size distribution of the liquid thus altering the propellant mixing and breaking any symmetry establishedinthecombustionchamberotherwise. Shear coax injectors with or without swirl are the element of choice when one of the propellant is in its liquid phase. The dominating physical phenomena in a shear injector are the destabilizing aerodynamic forceswhich actontheliquid jetwhichmaybe characterized bydimensionlessnumbers suchasvelocity ratio of the propellants, the appropriate Reynolds and Weber numbers, and, finally the momentum flux ratio. <!-- formula-not-decoded -->

It is important to note that the liquid oxygen is injected below its critical temperature but above its critical pressure, and, as a consequence, atomization in the near injector region is additionally influenced by thermodynamiceffects.

--- chunk_id: chunk-0026
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 18
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 318
content_hash: 91347f19588ecb86
prev_chunk_id: chunk-0025
next_chunk_id: chunk-0027
section_heading: 2.2.3 Turbines
document_type: technical_reference

The dominating physical phenomena in a shear injector are the destabilizing aerodynamic forceswhich actontheliquid jetwhichmaybe characterized bydimensionlessnumbers suchasvelocity ratio of the propellants, the appropriate Reynolds and Weber numbers, and, finally the momentum flux ratio. <!-- formula-not-decoded -->

It is important to note that the liquid oxygen is injected below its critical temperature but above its critical pressure, and, as a consequence, atomization in the near injector region is additionally influenced by thermodynamiceffects. The basic functional principles of a shear coax injector can be explained using figure 12. The area constriction at the entrance of the liquid oxygen guarantees a homogenous mass flow rate for every element and is the main decoupling mechanism. The restriction and the expansion afterwards introduce large scale turbulences in the liquid which support the atomization. Prior to the exit some of the gaseous hydrogen is injected into the liquid which has two effects. First, it increases the pressure drop and thus introduces engine throttling capabilities without jeopardizing the combustion performance and second it improves atomization and mixing. The final exit cone has two further specifics, a tapering angle which lays somewhere between 5 and 10° and a recess of a few millimetres. Both measures will again support atomization and mixing. Typical exit velocities of liquid propellants range between 10 m/s - 20 m/s. The gaseous hydrogen enters the injector and is finally accelerated at the edge to velocities in the range of 250 m/s-350 m/s.

--- chunk_id: chunk-0027
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 19
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 220
content_hash: 42535bda91464b40
prev_chunk_id: chunk-0026
next_chunk_id: chunk-0028
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 19 
 
 
LO2
GH2
GH2
LO2
GH2
GH2
 
Figure 12: Schematic of a shear coax injector element 
Figure 13 offers a view inside the fuel dome of the Vulcain 2 engine. A dense package of more than 
550 injection elements homogenizes the hydrogen supply. Obviously precision mounting of all these 
elements is a time consuming and costly process. The exit of the ignition gas is visible in the centre. Figure 13: Row of LOX injection elements inside the hydrogen distribution dome 
Finally, a comparison of different injectors is given in table 6 which summarizes some characteristic 
data of large liquid propellant rocket engines, F-1, RD-170, SSME, RD-0120, LE-7A, RS-68, and Vulcain 
2. This offers interesting comparison since the first two engines are LOX/ kerosene one gas generator and the 
other staged combustion cycle, the following three staged combustion engines are working with LOX/ 
LH2 and the final two work both the same propellants but are both gas generator cycle engines.

--- chunk_id: chunk-0028
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 20
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 509
content_hash: 4c4fdad7819813e3
prev_chunk_id: chunk-0027
next_chunk_id: chunk-0029
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 20 
RTO-EN-AVT-150 
 
 
Table 7: Characteristic data of sample injectors [10] 
Engine 
F-1 
RD-170 
SSME 
RD-0120 
LE-7A 
RS-68 
Vulcain 2 
Thrust (sl)  
[MN] 
6.9 
7.6 
1.8 
1.52 
0.86 
2.9 
0.94 
Propellant 
combination 
LOX / 
RP-1 
LOX / 
kerosene 
LOX / 
LH2 
LOX / 
LH2 
LOX / 
LH2 
LOX / 
LH2 
LOX / 
LH2 
Injector type 
Imping- 
ing 
Swirl 
coax 
Shear 
coax 
Shear 
coax 
Shear 
coax 
Shear 
coax 
Shear 
coax 
Flow rate /  
element  [kg/s] 
1.7 
1.8 
0.9 
~1 
0.85 
~0.9 
0.55 
Thrust /  
element  [kN] 
4.6 
5.5 
3.8 
3.4 
3.1 
~ 3.2 
1.6 
 
2.3.3 
Combustion chamber  
As an integral and may be the most important component of the thrust chamber assembly, the 
combustion chamber must be specifically designed to satisfy the operating requirements of engine. The 
basic components of a combustion chamber are the coolant inlet and discharge manifolds, a cooled 
internal liner consisting of tubes or channels and an external structural assembly which is capable to carry 
all structural and flight loads such as thrust, pressure, and vibrations. The contour of the inner liner is 
aerodynamically designed to provide maximum performance and thrust for the engine operating 
conditions. 2.3.3.1 
Combustion chamber cooling techniques 
Combustion chambers are generally categorized by the cooling method or the configuration of the 
coolant passages, where the coolant pressure inside may be as high as 30 MPa. The high combustion 
temperatures which may exceed 3600 K and the high heat transfer rates, peak values may reach 100 
MW/m2 encountered in a combustion chamber present a formidable challenge to the designer. To meet 
this challenge, several chamber cooling techniques have been utilized successfully. Regenerative cooling is the most widely used method of cooling a combustion chamber and is 
accomplished by flowing high-velocity coolant over the back side of the chamber hot gas wall to 
convectively cool the hot gas liner. The coolant with the heat input from cooling the liner is then 
discharged into the injector and utilized as a propellant. Quite a large number of engines have a "tubular 
wall" combustion chamber design, i.e. H-1, J-2, F-1 and RS-27 [1]. The primary advantage of the design is 
its light weight and the large experience base that has accrued however this method exceed its application 
limits at pressures in the range of 10 MPa.

--- chunk_id: chunk-0029
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 20
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 142
content_hash: 6bc58bdf4883955b
prev_chunk_id: chunk-0028
next_chunk_id: chunk-0030
section_heading: 2.2.3 Turbines
document_type: technical_reference

H-1, J-2, F-1 and RS-27 [1]. The primary advantage of the design is 
its light weight and the large experience base that has accrued however this method exceed its application 
limits at pressures in the range of 10 MPa. The best solution to date is the "channel wall" design, so named 
because the hot gas wall cooling is accomplished by flowing coolant through rectangular channels, which 
are machined or formed into a hot gas liner fabricated from a high-conductivity material, i.e. oxygen-free 
copper or copper alloys such as Narloy Z (CuAgZr), see figure 14 which shows a cut through the 
combustion chamber wall of the Vulcain engine.

--- chunk_id: chunk-0030
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 21
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 352
content_hash: ce22b91e911c2e04
prev_chunk_id: chunk-0029
next_chunk_id: chunk-0031
section_heading: 2.2.3 Turbines
document_type: technical_reference

Figure14:Cut throughacombustionchamberwall withCuAgZr linerand galvanicdepositedNioutershell

<!-- image -->

<!-- image -->

Thrust chamber liner design is a complex process and necessitates a coupled solution of the hot gas n n  s  s n n  s  n thermal gradients plastic deformation occurs which has to be taken into account for an analysis of the cyclic life of the liner. Cooling channel geometry design has to account for the thermal blockage caused by the high heat fluxes and the comparatively drastic change in the fluid properties, heat capacity, density and viscosity, which take place at cryogenic temperature and high pressures. All the design bureaus and companies apply Nusselt-type correlations to describe the heat transfer since a fully numerical solution of the coupled problems is far to complex. Major hurdles are the large differences inthelength and timescales,chemical non-equilibrium orfiniterate chemistry,the continuous transformation from sub- to supersonic velocities, and still missing models which describe satisfactorily dominating phenomena such as fluid atomization, near critical fluid behaviour. Additionally, effects such as dissociation due to high temperatures in the combustion chamber and recombination with appropriate heat release in the cooler wallboundarylayer and,finally catalytic effects attheliner surface arefar too complex and time consuming to allow for a coupled numerical solution. Usually the hot gas side heat transfer is described in form of a Bartz-type correlation [13]:

<!-- formula-not-decoded -->

There are various modifications around, almost every company works with their one correlation, which try to account for local effects such as curvatures of liner and throat, area ratio, Mach number which all have aninfluence on theheattransfer:

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

--- chunk_id: chunk-0031
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 22
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 517
content_hash: 4a013615ac5e8531
prev_chunk_id: chunk-0030
next_chunk_id: chunk-0032
section_heading: 2.2.3 Turbines
document_type: technical_reference

or a little bit more complex

<!-- formula-not-decoded -->

Table 8 below summarizes the coefficients of the correlation (eqn. 10) for different combustion chamber pressures, temperatures, cooling channel velocities, heat fluxes and propellant type. Table 8: Coefficients for Nusselt-correlations coolant side heat transfer | Uch m/s   | Fuel Pc b Tb MPa MW/m2 K         | Tw K K                                          | D     |   b | C            |    d |     e |    f | g             |   m |     n |
|-----------|----------------------------------|-------------------------------------------------|-------|-----|--------------|------|-------|------|---------------|-----|-------|
| 6-30      | C,H 13.7 420-810                 | 0.00538 0.80 0.4                                |       |     | -0.125 0.242 |      | 0.193 |      | 30.395 -0.024 |   1 |     0 |
|           | 3-12.4 15-45 0.3-16.4 120-395    | 0.00545 0.90(                                   |       | 0.4 | -1.1         | 0.23 |  0.27 | 0.53 | 0             |   1 |     0 |
|           |                                  | 7-13.8 30-60 3.1-18.2 230-300 230-810 0.0280(   | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 |
|           |                                  | 0.00696 0.88                                    |       | 0.5 | 0            |    0 |     0 |    0 | 0             |   0 |  -1.0 |
|           | CH4 27-34 55-238 2.6-139 146-275 | 0.0220                                          | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 | -0.45 |
|           | 27-34 55-238 2.6-139146-275      | 0.0230                                          | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 | -0.57 |
|           |                                  | 7-13.8 30-60 3.1-18.2 230-300 230-810 0.0230    | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 |
|           |                                  | 0.0230                                          | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 | -0.80 |
|           |                                  | 0.0230                                          | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 |
|           |                                  | RP-1 7-13.8 30-603.1-18.2 230-300230-810 0.0440 | 0.76  | 0.4 | 0            |    0 |     0 |    0 | 0             |   1 |     0 |
|           |                                  | 7-13.8 30-603.1-18.2 230-300 230-810 0.0068     | 0.94  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 |
|           |                                  | 0.0056                                          | 0.90（ | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 |

--- chunk_id: chunk-0032
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 22
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 530
content_hash: 0cd33df6bdc0f5ea
prev_chunk_id: chunk-0031
next_chunk_id: chunk-0033
section_heading: 2.2.3 Turbines
document_type: technical_reference

Table 8: Coefficients for Nusselt-correlations coolant side heat transfer | Uch m/s   | Fuel Pc b Tb MPa MW/m2 K         | Tw K K                                          | D     |   b | C            |    d |     e |    f | g             |   m |     n |
|-----------|----------------------------------|-------------------------------------------------|-------|-----|--------------|------|-------|------|---------------|-----|-------|
| 6-30      | C,H 13.7 420-810                 | 0.00538 0.80 0.4                                |       |     | -0.125 0.242 |      | 0.193 |      | 30.395 -0.024 |   1 |     0 |
|           | 3-12.4 15-45 0.3-16.4 120-395    | 0.00545 0.90(                                   |       | 0.4 | -1.1         | 0.23 |  0.27 | 0.53 | 0             |   1 |     0 |
|           |                                  | 7-13.8 30-60 3.1-18.2 230-300 230-810 0.0280(   | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 |
|           |                                  | 0.00696 0.88                                    |       | 0.5 | 0            |    0 |     0 |    0 | 0             |   0 |  -1.0 |
|           | CH4 27-34 55-238 2.6-139 146-275 | 0.0220                                          | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 | -0.45 |
|           | 27-34 55-238 2.6-139146-275      | 0.0230                                          | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 | -0.57 |
|           |                                  | 7-13.8 30-60 3.1-18.2 230-300 230-810 0.0230    | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 |
|           |                                  | 0.0230                                          | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 | -0.80 |
|           |                                  | 0.0230                                          | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 |
|           |                                  | RP-1 7-13.8 30-603.1-18.2 230-300230-810 0.0440 | 0.76  | 0.4 | 0            |    0 |     0 |    0 | 0             |   1 |     0 |
|           |                                  | 7-13.8 30-603.1-18.2 230-300 230-810 0.0068     | 0.94  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 |
|           |                                  | 0.0056                                          | 0.90（ | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 | These coefficients shoulddescribe theinfluence of the entryconditions of theflow,coolingchannel geomery and any changes, curvature effects, catalytic surface reactions, influence of the strucutral heat flow, thermodynamic (real gas, cryogenic conditions, vicinity to the critical point, varying fluid properties), fluid mechanic (turbulence, stratification) or chemistry (pyrolysis).

--- chunk_id: chunk-0033
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 22
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 562
content_hash: 20c8f1be03f27513
prev_chunk_id: chunk-0032
next_chunk_id: chunk-0034
section_heading: 2.2.3 Turbines
document_type: technical_reference

| Uch m/s   | Fuel Pc b Tb MPa MW/m2 K         | Tw K K                                          | D     |   b | C            |    d |     e |    f | g             |   m |     n |
|-----------|----------------------------------|-------------------------------------------------|-------|-----|--------------|------|-------|------|---------------|-----|-------|
| 6-30      | C,H 13.7 420-810                 | 0.00538 0.80 0.4                                |       |     | -0.125 0.242 |      | 0.193 |      | 30.395 -0.024 |   1 |     0 |
|           | 3-12.4 15-45 0.3-16.4 120-395    | 0.00545 0.90(                                   |       | 0.4 | -1.1         | 0.23 |  0.27 | 0.53 | 0             |   1 |     0 |
|           |                                  | 7-13.8 30-60 3.1-18.2 230-300 230-810 0.0280(   | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 |
|           |                                  | 0.00696 0.88                                    |       | 0.5 | 0            |    0 |     0 |    0 | 0             |   0 |  -1.0 |
|           | CH4 27-34 55-238 2.6-139 146-275 | 0.0220                                          | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 | -0.45 |
|           | 27-34 55-238 2.6-139146-275      | 0.0230                                          | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 | -0.57 |
|           |                                  | 7-13.8 30-60 3.1-18.2 230-300 230-810 0.0230    | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 |
|           |                                  | 0.0230                                          | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 | -0.80 |
|           |                                  | 0.0230                                          | 0.80  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 |
|           |                                  | RP-1 7-13.8 30-603.1-18.2 230-300230-810 0.0440 | 0.76  | 0.4 | 0            |    0 |     0 |    0 | 0             |   1 |     0 |
|           |                                  | 7-13.8 30-603.1-18.2 230-300 230-810 0.0068     | 0.94  | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 |
|           |                                  | 0.0056                                          | 0.90（ | 0.4 | 0            |    0 |     0 |    0 | 0             |   0 |     0 | These coefficients shoulddescribe theinfluence of the entryconditions of theflow,coolingchannel geomery and any changes, curvature effects, catalytic surface reactions, influence of the strucutral heat flow, thermodynamic (real gas, cryogenic conditions, vicinity to the critical point, varying fluid properties), fluid mechanic (turbulence, stratification) or chemistry (pyrolysis). It worth mentioning that all these coefficients are the result of experiments which surely are influenced by the experimental setup, the sensors applied and the general operating conditions of the test [13, 14].

--- chunk_id: chunk-0034
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 22
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 372
content_hash: 34fce12336ba3bfa
prev_chunk_id: chunk-0033
next_chunk_id: chunk-0035
section_heading: 2.2.3 Turbines
document_type: technical_reference

These coefficients shoulddescribe theinfluence of the entryconditions of theflow,coolingchannel geomery and any changes, curvature effects, catalytic surface reactions, influence of the strucutral heat flow, thermodynamic (real gas, cryogenic conditions, vicinity to the critical point, varying fluid properties), fluid mechanic (turbulence, stratification) or chemistry (pyrolysis). It worth mentioning that all these coefficients are the result of experiments which surely are influenced by the experimental setup, the sensors applied and the general operating conditions of the test [13, 14]. Film cooling provides protection from excessive heat by introducing a thin film of coolant or propellant through orifices around the injector periphery or in the chamber wall near the injector or chamber throat region. This method is typically used in high heat flux regions and in combination with regenerative cooling. A sample correlation for film cooling prediction is given below:

<!-- image -->

Nusselt-type correlations are as well applied for the prediction of the coolant side heat transfer. These are usually verified nowadays by 3D CFD calculations which are still very demanding due to the operating conditions. Especially the continuous but varying asymmetric heat input which results in drastic changes of the local fluid properties (10-30% in density, heat capacity or viscosity are possible). Such variations will have an influence on the pressure loss distribution along the cooling channel and thus also on the local heat pickup. In order to minimize the pressure drop necessary for cooling the cross section of the cooling channels is adjusted to the local heat loads on the hot gas side. Obviously only a coupled iterative approach may yield the final solution of the appropriate liner and cooling channel design. A rather simple exampleofsuchacorrelationmayreadas:

<!-- formula-not-decoded -->

--- chunk_id: chunk-0035
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 23
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 498
content_hash: d46bb8e8355b257d
prev_chunk_id: chunk-0034
next_chunk_id: chunk-0036
section_heading: 2.2.3 Turbines
document_type: technical_reference

<!-- image -->

<!-- formula-not-decoded -->

Sample engines where film cooling is applied are the SSME, F-1, J-2, RS-27, Vulcain 2, and the RD171 and RD-180 with the latter two being the only ones where an additional cooling film is generated near the throat [3]. Transpiration cooling, which is considered a special case of film cooling provides gaseous or liquid coolant through the porous chamber liner wall at a rate sufficient to maintain the chamber hot gas wall to the desired temperature. A typical correlation to determine the chamber wall is given in equation (12) [3]:

<!-- formula-not-decoded -->

This technique was applied to cool the injector faces of the J-2 and the RS-44, as well the SSME. However, the method has to date never been used to cool the chamber liner. The major reason might be that transpiration cooling in combination with a metallic porous structure doesn't offer a big advantage compared to conventional cooling since the maximum wall temperature will not change much and the continuous adjustment of the coolant mass flow rate to the local thermal loads is difficult to achieve. With ablative cooling, combustion gas-side wall material is successively sacrificed by melting, vaporization and chemical changes to dissipate heat. As a result, relatively cool gases flow over the wall surface, thus lowering the boundary-layer temperature and assisting the cooling process. Ablative cooling may be applied either to the entire combustion chamber liner or to the throat section alone. Typically all solid rocket boosters have ablative cooled nozzles.Sample chambers with partially ablative cooled throat sections are the Viking or more recent the RS-68. Although successfully applied this cooling method has a major drawback since it doesn't allow for modifications of the engine burn time. A radiation cooled chamber transmits the heat from its outer surface, chamber or nozzle extension. Radiation cooling is typically used for small thrust chambers with a high-temperature wall material (refractory) and in low-heat flux regions, such as a nozzle extension. An example of an entirely radiation cooled thrusters is the RS-21 Mariner/Viking Orbiter spacecraft, RL 10B or similar upper stage engines have radiation cooled ceramic nozzles [1, 3]. ### 2.3.3.2Combustionchamberlife

Cyclic fatigue of the liner material is one of the life limiting factors for a rocket engine.

--- chunk_id: chunk-0036
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 23
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 258
content_hash: 9b4d95c4883183a1
prev_chunk_id: chunk-0035
next_chunk_id: chunk-0037
section_heading: 2.2.3 Turbines
document_type: technical_reference

An example of an entirely radiation cooled thrusters is the RS-21 Mariner/Viking Orbiter spacecraft, RL 10B or similar upper stage engines have radiation cooled ceramic nozzles [1, 3]. ### 2.3.3.2Combustionchamberlife

Cyclic fatigue of the liner material is one of the life limiting factors for a rocket engine. During the start-up process the liner is first exposed to liquid hydrogen which causes the material to shrink and, since the inner copper alloy liner cools down faster than the outer nickel shell, the fins of the cooling channels areexposedtoseverethermal stresses.At theend of thecool-down theentire chamberinner shrinks about half the size of the cooling channel wall (Vulcain dimensions). After successful ignition, the temperature and pressure in the combustion chamber increase very fast and the copper wall will expand accordingly. Now, the nickel closeout is cooling by the liquid hydrogen and thus still at cryogenic temperatures. Hence, the copper has to react to the thermal expansion alone which poses additional thermal stresses to the material. With plastic deformation exceeding 3-4% a typical chamber has a life of less than 20 cycles. Figure 15 shows the liner of the Vulcain engine with its typical failures at the cooling channels.

--- chunk_id: chunk-0037
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 24
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 369
content_hash: dbb6d1a6e5a8da68
prev_chunk_id: chunk-0036
next_chunk_id: chunk-0038
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 24 
RTO-EN-AVT-150 
 
 
 
Figure 15: Chamber liner with typical longitudinal failure 
The methods available to predict cyclic life of a combustion chamber are highly based on experience 
and experimental data. One reason is still missing detailed enough initial material properties and their 
behaviour under operating conditions. Aside the above mentioned thermal stresses the liner material is 
exposed to additional loads which will have an impact on material properties. First, mechanical loads such 
as static pressure or pressure fluctuations or mechanical vibrations of various sources, second, material 
weakening by hydrogen embrittlement, third, high temperature fatigue or creep, and last but not least a 
chemical attack at the surface by OH or other radicals or a simple oxidation through exposure to oxygen-
rich gases. Anyone of these phenomena is difficult to access quantitatively in separate experiments and, 
even more important there is no clear understanding about the interaction of these phenomena. A typical approach for cyclic life prediction would be to determine the hot gas side and coolant side 
heat transfer and then calculate the thermal field and the resulting stresses and strains in the material 
iteratively. Then, based on the predicted strains coming from one cyclic load case the number of cycles to 
failure is determined applying typical material failure relations derived from experiments, see figure 16 
[15]. 0,01
0,1
1
0,1
1
10
100
1000
10000
Cycles number N to rupture
 Normalized plastic strain
disk
flexion
compr.-tension
Manson-Coffin
 
Figure 16: Cyclic material failure law 
Quite often the thermal and mechanical analyses are performed in 2D and for a stationary thermal 
field, however recent investigations have shown that 3D calculations and especially transient thermal

--- chunk_id: chunk-0038
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 25
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 477
content_hash: ceaf1af59a1ae967
prev_chunk_id: chunk-0037
next_chunk_id: chunk-0039
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 25 
 
 
analyses are important for reliable cyclic life predictions. The numerical prediction of total number of 
cycles to failure is and will be for quite a while still out of reach for practical applications. 2.3.4 
Nozzle 
The nozzle uses the pressure generated in the combustion chamber to increase thrust by accelerating 
the combustion gas to a high supersonic velocity. Commonly used nozzles are bell-shaped with a 
parabolic contour which is either a truncated ideal or a thrust optimized one, see figure 17. While all 
Russian rocket engines have nozzles with an ideal contour, American, European and Japanese engines fly 
a thrust optimized nozzle design. The latter has a cross-sectional nozzle area which expands much faster 
near the throat and thus results in a shorter nozzle at the same expansion ratio compared to an ideal nozzle. This expansion however causes the formation of an internal shock and at certain stages during transient 
start-up and shutdown a flow phenomenon develops which is described as restricted shock separation 
since the flow separates but reattaches almost immediately again. Aside severe side loads, this 
reattachment of a high speed hot jet poses high heat loads to the nozzles, too [16]. Figure 17: Typical bell-shaped nozzle 
Nozzle extensions are seldom regenerative cooled more often the much simpler dump cooling is 
applied. The most frequent method however is ablative or radiation cooling. Materials suited for these 
applications are C/C or SiC structures, which infiltrated with poly-aromatic hydrocarbons and additionally 
incorporated additives are decomposed in an endothermic reaction route. Radiation cooling requires appropriate high temperature materials which often have a protective 
coating to prevent oxidation. Only small thrusters for satellite applications have metallic nozzles build 
from refractory metals such as Tungsten, Rhenium or other refractory metals. A design follows based on: 
4
 
 
wg
T
q
σ
ε
=
 
 
 
 
 
(13) 
with ε , the emission coefficient, σ , the Stefan-Boltzmann radiation constant and Twg , the maximum hot 
gas side wall temperature. It is worth mentioning that in case of radiation cooling, the engine itself, its 
supply lines and especially sensors and cables have to be protected against high heat loads.

--- chunk_id: chunk-0039
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 25
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 184
content_hash: ab72caf78edf404f
prev_chunk_id: chunk-0038
next_chunk_id: chunk-0040
section_heading: 2.2.3 Turbines
document_type: technical_reference

A design follows based on: 
4
 
 
wg
T
q
σ
ε
=
 
 
 
 
 
(13) 
with ε , the emission coefficient, σ , the Stefan-Boltzmann radiation constant and Twg , the maximum hot 
gas side wall temperature. It is worth mentioning that in case of radiation cooling, the engine itself, its 
supply lines and especially sensors and cables have to be protected against high heat loads. The key problem of main stage engines with long burn times is illustrated demonstrated in figure 18 
which shows the change in specific impulse as a function of flight altitude for an engine with two different 
expansion ratios ε1 and ε2. In order to avoid flow separation and induced heavy side loads during the first 
flight phase engine 1 is designed with a short nozzle and thus has a relatively high impulse then. However,

--- chunk_id: chunk-0040
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 26
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 493
content_hash: e1de051c974ed155
prev_chunk_id: chunk-0039
next_chunk_id: chunk-0041
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 26 
RTO-EN-AVT-150 
 
 
this advantage wears out soon and in the later phases of the launch the impulse penalty may exceed 15%. Engine 2 is designed for high impulse in the later flight phase and thus suffers from an impulse penalty 
during the first flight phase. Anyhow, however the nozzle design may be sooner or later the impulse will 
be less than possible. altitude [km]
Spec. Impulse  Isp [s]
ε 2
ε 1
Ideally adapted 
nozzle
250
350
450
10
30
50
altitude [km]
Spec. Impulse  Isp [s]
ε 2
ε 1
Ideally adapted 
nozzle
250
350
450
10
30
50
ε 2
ε 1
Ideally adapted 
nozzle
250
350
450
10
30
50
 
Figure 18: Potential Isp penalty of main stage engines 
2.3.5 
Design Methodology 
Current engines design techniques are based on a design methodology with load factors and safety 
factors determined on more than four decades of experience, and are commonly gathered under the 
heading of deterministic design. A deterministic structural analysis means that first, a load or condition is 
solely based on a set of design points and load factors which account for some variability in the specific 
load in order to be sure that the maximum load ever before will be accounted for, second, that values for 
minimum material strength or allowable fatigue are taken that ensures variations in material properties are 
taken into account, and, third, a safety factor is worked into the design which will cover all the remaining 
unknowns in analysis, loads, fabrication or even human error. Finally, the product of the design load, 
limiting factors, and safety factors must always be less than the strength or allowable fatigue to assure safe 
operation. Usually, designs have to meet different conditions such as strength, fatigue, creep, deflection, 
buckling or burst and therefore a typical design approach applies during the analysis maximum loads and 
minimum strength conditions [17]. In typical design analyses, load factors are based on previous hardware failures that were initially, 
analyzed by this same method - with factors that specified that none of the hardware was to fail. Taken all 
component and sub-systems of an engine this approach is conservative one and usually yields part which 
are over-designed.

--- chunk_id: chunk-0041
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 26
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 212
content_hash: 218f83ab0823fef8
prev_chunk_id: chunk-0040
next_chunk_id: chunk-0042
section_heading: 2.2.3 Turbines
document_type: technical_reference

In typical design analyses, load factors are based on previous hardware failures that were initially, 
analyzed by this same method - with factors that specified that none of the hardware was to fail. Taken all 
component and sub-systems of an engine this approach is conservative one and usually yields part which 
are over-designed. However, since the methodology aims at a no-failure design, there is no way to avoid a 
partial over-design. Numerous design reviews, audits and quality checks during the entire process of 
development are aimed at identifying analysis or manufacturing mistakes or integration, operation or load 
conditions errors. However, extensive ground testing is still necessary since any new design may yield 
load conditions and resulting failures that were unknown until the test [17, 18]. 3. ADVANCED CONCEPTS  
Any new concept or design has to show the capability to improve reliability, performance or cost 
effectiveness of the system or component and in recent years reliability and cost became dominating.

--- chunk_id: chunk-0042
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 27
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 493
content_hash: 2996e0b286dd89d5
prev_chunk_id: chunk-0041
next_chunk_id: chunk-0043
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 27 
 
 
Hence, current developments deal with low cost approaches such as the RS-68 or the more recent 
European Vulcain X design studies. Within this chapter a series of new concepts and a novel design 
methodology approach are discussed and their potential contribution to the above mentioned drivers will 
be shown. 3.1 
Advanced ignition devices 
An ignition system is designed to meet the requirements of the mission, sea level, vacuum or multiple 
ignitions and accounts for further boundary conditions such as propellant phase and temperature as well as 
geometric and power constraints. Any improvement will have to account for these conditions and will 
most likely be mission specific as well. The simplest form of system improvement is a reduction of complexity by reducing the number of 
parts. This may be combined with a reduction of component weight. An example could be to use the 
original propellants instead of additional ones. For re-ignitable engines a simple pyrotechnic system isn’t 
sufficient and another form has to be used. Quite often gaseous pressurized propellants are applied which 
are send to an ignition chamber at the appropriate mixture ratio and than injected into the combustion 
chamber. Multiple ignitions require a sufficient amount of propellant and thus large enough tanks. The 
entire system including valves ignition chamber a.s.o. may be omitted if another system with similar 
reliability becomes available. Although not yet used in cars yet, the automotive industry currently 
develops igniters for their internal combustion engines which apply semi-conductor lasers as we already 
use in our MP3 or CD players [19]. A change from continuous wave to pulse mode operation allows for a 
considerable increase in optical power. A laser-based ignition system offers the capability of distributed 
ignition, the energy for ignition initiation can be delivered almost everywhere. This allows for an ignition 
at places where unburned premixed propellants may accumulate, i.e. lifted flames, recirculation areas 
within injectors. Hence, this method offers a potential for risk reduction towards initiation of combustion 
instabilities. Nowadays, glass fibres are common for optical signal transmission. The combination of pulse 
mode semi-conductor lasers optical fibres allows for a safer placement of the more sensitive parts of the 
lasers and the above mentioned distributed ignition.

--- chunk_id: chunk-0043
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 27
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 356
content_hash: 8bf61f890b7644cf
prev_chunk_id: chunk-0042
next_chunk_id: chunk-0044
section_heading: 2.2.3 Turbines
document_type: technical_reference

Nowadays, glass fibres are common for optical signal transmission. The combination of pulse 
mode semi-conductor lasers optical fibres allows for a safer placement of the more sensitive parts of the 
lasers and the above mentioned distributed ignition. This development seems worth considering since the 
operating conditions in a car are demanding and the required reliability is extremely high. There has been some effort at various places to develop this ignition technique. NASA has considered 
laser-based ignition as the appropriate ignition method for the individual thrust cells of the XRS-2200, the 
engine for the X-31 vehicle. Laser-based plasma generation and ignition of single injector cryogenic 
propellants was investigated for example at DLR Lampoldshausen [20]. Figure 19 shows on its left side 
on top the OH emission and below a Schlieren image with the dark spot just above the dark jet the resul 
thigh temperature foot print of the generated plasma directly fter the laser shot. On its right side, the top 
picture shows 800 microseconds later the OH emission of the developing flame front and below the 
corresponding Schlieren image. It can be seen that the flame develops within the shear layer around the 
oxygen jet before moving towards the injector face plate. At JAXA studies are underway which apply a 
laser to heat a target in the chamber sufficiently fast so that the target glows and initiates ignition of the 
propellant. The system might be improved if the surface of the target is activated to act as a catalyst or the 
target is infiltrated with a liquid which when evaporated reacts hypergolic with one of the propellants.

--- chunk_id: chunk-0044
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 28
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 401
content_hash: cb0bb4b60bdb59ee
prev_chunk_id: chunk-0043
next_chunk_id: chunk-0045
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 28 
RTO-EN-AVT-150 
 
 
 
Figure 19: Laser-based ignition of a LOX/H2/ spray 
3.2 
Advanced injection techniques 
High precision fabrication, qualification inspection and testing, high precision mounting and quality 
assurance procedures for injector are time consuming and costly. There are two possible ways to alter the 
procedures mentioned above, first, a reduction of the precision requirements through a simpler injector 
design or, second, a reduction of the number of injection elements through an increase in the injector mass 
flow rate. 3.2.1 
High thrust/element injectors 
An increase of the thrust per injection element requires improved atomization and mixing in order to 
maintain similar combustion performance. In order to achieve a better atomization the area of interaction 
between the gas and the liquid has to be increased. An improvement of the shear coax injector with the 
liquid in the centre is the tri-coax injector which has a gas jet in the centre, an annual gap for the liquid and 
another annular gap for the remaining part of the gas. The RD-170 and RD-180 already have the hot 
oxygen-rich pre-burner gases in the centre and the kerosene in the annual gap around it. Examples of high 
thrust elements, a cross coax and tri-coax injector, which are presently under investigation at Astrium are 
shown in figure 20 [21]. A closer look at the thrust per element figures for different engines, see table 6, 
reveals that engines such as the SSME reach a thrust/element of 3.8 kN out of a mass flow rate per 
element of 0.9 kg/s compared to 1.6 kN out of 0.53 kg/s of the Vulcain 2 engine. Maintaining the 
performance and increase the flow rate per element to SSME values would cut down the number of 
elements by about 40%. Figure 20: High thrust elements  a) cross coax b) tri-coax

--- chunk_id: chunk-0045
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 29
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 508
content_hash: eaa2ef88dc886d6e
prev_chunk_id: chunk-0044
next_chunk_id: chunk-0046
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 29 
 
 
3.2.2 
Low precision injectors 
An entirely different approach compared to the high precision requirement coax or tri-coax injectors is 
an approach with a porous face plate through which all the gaseous propellants are fed into the combustion 
chamber and large number of small LOX injectors. The advantage of this approach is that the dimensions 
of each element are so small that deviations from the required dimensions are tolerable since each element 
delivers something in the order of 0.1% of the total oxygen mass flow rate to the chamber and deviations 
affect only negligible parts of the combustion chamber volume. It is worth mentioning that the atomization process with this kind of injector is different compared to 
the one with conventional shear coax injectors. Distribution of the gaseous fuel all over the face plate 
considerably lowers the hydrogen velocity which in turn reduces the available aerodynamic forces 
available for atomization which makes this approach less attractive. However, a closer look at the local 
conditions reveals that these are not that far away from typical atomization conditions in an internal 
combustion engine where the liquid is injected at high speeds into an almost stagnant air. Porous face 
plates have already been considered for the HM7B and have been tested in the J2 and SSME engines and 
have been flight proven with the RD-0120 although the face plate might not be consider porous since it 
has more than 15000 holes of less than half a millimetre in diameter. However, all these engines still have 
conventional shear coax injectors. Recently, DLR performed a series of sub-scale test campaigns with LOX/GH2 and LOX/GCH4 
applying a porous sintered metallic (copper as well as stainless steel) and a rigimesh face plate, see figure 
21, with a large number of LOX posts made of cheep pipe material. The holes for the LOX posts were 
simply drilled into the porous plate and the LOX posts itself were electron beam welded into the LOX 
dome. Figure 21: Sub-scale injector head with porous rigimesh face plate 
The results were promising insofar as combustion efficiency determined by chamber pressure 
measurements turned out to be almost negligible. Furthermore, heat transfer data indicates a more uniform 
heat release without any heat transfer problems to the face plate itself.

--- chunk_id: chunk-0046
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 29
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 145
content_hash: 721ce4cf5cc775ec
prev_chunk_id: chunk-0045
next_chunk_id: chunk-0047
section_heading: 2.2.3 Turbines
document_type: technical_reference

Figure 21: Sub-scale injector head with porous rigimesh face plate 
The results were promising insofar as combustion efficiency determined by chamber pressure 
measurements turned out to be almost negligible. Furthermore, heat transfer data indicates a more uniform 
heat release without any heat transfer problems to the face plate itself. Currently, investigations are 
underway with aim to replace both the metallic face plate and the metallic LOX post with ceramic 
materials and have an entire ceramic injector head. 3.3 
Advanced thrust chamber technologies 
As already stated earlier, the two approaches to improve current technologies, one driven by cost 
reduction constraints and the other driven by performance considerations. Improvements which increase

--- chunk_id: chunk-0047
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 30
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 484
content_hash: 3fc838751c10d848
prev_chunk_id: chunk-0046
next_chunk_id: chunk-0048
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 30 
RTO-EN-AVT-150 
 
 
engine reliability may be considered as cost reduction related. Any advanced thrust chamber technology 
will be related to heat load management, i.e. protective coatings, improved cooling, new materials or 
fabrication techniques with increased cyclic life behaviour, high temperature heat transfer, cooling and 
related component life [22-24]. It is also worth mentioning that regenerative cooling reaches its 
application limits when local heat fluxes exceed 80 MW/m2. Typical high pressure engines apply as 
already mentioned a combination of regenerative and film cooling. Another method to reduce the 
temperature gradient across the chamber wall is deposit a thin thermal barrier coating, usually Y2O3-
stabilized ZrO2 on the hot gas side surface. In any case, the implementation of new materials and concepts 
requires the adaptation of existing design rules and tools, the determination of material properties and 
behaviour laws, appropriate failure detection techniques and predictive tools for failure propagation, and, 
first of all, reliable and reproducible material production itself. Among the different methods which are proposed in order to meet the cooling and life requirements 
three approaches are worthwhile to be considered in more detail. Two more conservative approaches 
which maintain the concept of regenerative cooling, one which still keeps the standard combustion 
chamber liner material CuAgZr but protects this liner with a thermal barrier coating employing extreme 
thin ceramic top layers combined with appropriate metallic bond coats and another one which replaces 
both the conventional liner material and fabrication method by forming the liner via vacuum plasma 
spraying of CuCrNb powder and a more advanced approach which combines the advantages of a high 
temperature, low density and porous carbon-fibre reinforced carbon (C/C) based combustion chamber 
liner with the concept of transpiration cooling using liquid hydrogen without regenerative cooling [25-33]. While the first two techniques allow for a reduction of the thermal loads of the chamber liner and therefore 
aim at an increase of chamber life, which may always be traded if necessary in reduced requirements for 
the turbopump by a reduction of the necessary cooling pressure drop, the latter approach has almost three 
goals in parallel, increase of cyclic life, considerable reduction of engine weight and improved production 
cost.

--- chunk_id: chunk-0048
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 30
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 492
content_hash: c59a451b1371eb99
prev_chunk_id: chunk-0047
next_chunk_id: chunk-0049
section_heading: 2.2.3 Turbines
document_type: technical_reference

Two more conservative approaches 
which maintain the concept of regenerative cooling, one which still keeps the standard combustion 
chamber liner material CuAgZr but protects this liner with a thermal barrier coating employing extreme 
thin ceramic top layers combined with appropriate metallic bond coats and another one which replaces 
both the conventional liner material and fabrication method by forming the liner via vacuum plasma 
spraying of CuCrNb powder and a more advanced approach which combines the advantages of a high 
temperature, low density and porous carbon-fibre reinforced carbon (C/C) based combustion chamber 
liner with the concept of transpiration cooling using liquid hydrogen without regenerative cooling [25-33]. While the first two techniques allow for a reduction of the thermal loads of the chamber liner and therefore 
aim at an increase of chamber life, which may always be traded if necessary in reduced requirements for 
the turbopump by a reduction of the necessary cooling pressure drop, the latter approach has almost three 
goals in parallel, increase of cyclic life, considerable reduction of engine weight and improved production 
cost. An intermediate approach where conventional regenerative cooling is combined with non-
conventional fabricated hybrid liner structure, fibre reinforced ceramic matrix composites such as C/C or 
SiC/SiC, were coated applying different deposition techniques with thin metallic layers (copper, rhenium 
coated with tantalum) are already under investigation [25]. As has been shown earlier, main stage engines with long burn times usually suffer from an almost 
continuous mismatch of the nozzle expansion ratio to ambient pressure. Taking into account that none of 
the various plug nozzle concepts which aim at a continuous adaptation of the expansion ratio to altitude 
has made it from development into flight qualification [34, 35] the only remaining concept is that of a dual 
bell, an extendable nozzle exit cone or an expendable nozzle insert [36]. 3.3.1 
C/C Thrust chamber liner with effusion (transpiration) cooling  
In order to fully realize the potentials of CMC materials the final development goal would be an 
integral thrust chamber with a CMC liner with an outer load bearing carbon-fibre reinforced polymer 
(CFRP) and a CMC injection head. The main challenge of transpiration cooling is the continuous 
adaptation of the local coolant supply to the varying heat fluxes.

--- chunk_id: chunk-0049
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 30
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 254
content_hash: e8608fd516d819d9
prev_chunk_id: chunk-0048
next_chunk_id: chunk-0050
section_heading: 2.2.3 Turbines
document_type: technical_reference

3.3.1 
C/C Thrust chamber liner with effusion (transpiration) cooling  
In order to fully realize the potentials of CMC materials the final development goal would be an 
integral thrust chamber with a CMC liner with an outer load bearing carbon-fibre reinforced polymer 
(CFRP) and a CMC injection head. The main challenge of transpiration cooling is the continuous 
adaptation of the local coolant supply to the varying heat fluxes. At each surface element of the liner static 
and dynamic pressure of both coolant and hot gas have to be balanced to prevent entrainment of hot gases 
into the porous C/C structure. A further key element will be the injector head including the injector 
elements which have to be different in design since the heat pickup of the propellant in the cooling 
channels will be missing. Especially the near injector region of the liner may need additional protection 
against a potential chemical attack by oxygen molecules or OH radicals. The principle of effusion cooling bases on the following two mechanisms: Passing through the porous 
wall the coolant absorbs the heat conducted into the solid material of the wall. In this way, the porous wall

--- chunk_id: chunk-0050
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 31
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 476
content_hash: 04c7805f9cb3d5eb
prev_chunk_id: chunk-0049
next_chunk_id: chunk-0051
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 31 
 
 
may be considered as a counter flow heat exchanger. Heat conducted into the wall from the hot gas side is 
transported backwards into the hot gas. The coolant having passed through the porous wall forms a fluid 
film on the hot gas side wall surface and will act as a typical cooling film. Hence, a part of the convective 
wall heat flux is absorbed by this film. The heated coolant at the film surface is transported downstream by 
the momentum of the hot gas flow, partially entrained into the main flow and continuously replaced with 
new coolant coming out of the wall. The porous CMC is a carbon-fibre reinforced carbon (C/C) which has a high temperature resistance of 
about 2500 K. The porosity can be adjusted to the application needs altering either the fabrication 
procedure or the raw material. Another advantage of C/C is its almost negligible thermal expansion which 
makes it resistive to thermal shocks or thermal cyclic fatigue. Typical high pressure rocket engines require 
a sufficient high Reynolds number in the cooling channels to assure the necessary cooling efficiency and 
to keep the wall temperatures below critical values. Pressure losses to assure sufficient cooling typically 
may even exceed 10 MPa while for an effusion cooled liner less than 0.5 MPa will typically be sufficient 
to keep the inner liner wall at tolerable temperatures. This possible pressure potential can be traded within 
the system for a reduced turbopump discharge pressure, lower gas generator mass flow rates, an increased 
engines performance or reliability or simply to enlarge the system margins. DLR has been active for years to develop the fundamental and technological basis for this approach 
[37]. Material and cooling technology have been verified in different test campaigns. Key objectives were 
thermal cyclic fatigue tests at typical temperatures and pressure levels between 0.5 and 1 MPa, high 
temperature failure tests which exceeded 2500 K and sub-scale tests at P8 with typical mixture ratios and 
chamber pressures up to 10 MPa. One of the development goals was to overcome a potential disadvantage 
of this cooling concept, the loss in specific impulse.

--- chunk_id: chunk-0051
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 31
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 292
content_hash: fa18ce8ff992a090
prev_chunk_id: chunk-0050
next_chunk_id: chunk-0052
section_heading: 2.2.3 Turbines
document_type: technical_reference

Key objectives were 
thermal cyclic fatigue tests at typical temperatures and pressure levels between 0.5 and 1 MPa, high 
temperature failure tests which exceeded 2500 K and sub-scale tests at P8 with typical mixture ratios and 
chamber pressures up to 10 MPa. One of the development goals was to overcome a potential disadvantage 
of this cooling concept, the loss in specific impulse. The part of the propellant which is used as coolant 
will enter the combustion chamber along the liner to the throat with continuously decreasing pressure and 
subsequently will contribute less and less to the overall thrust. Although the boundary layer of a typical conventional regenerative cooled liner has quite lower 
temperatures compared to a effusion cooled C/C liner the resulting loss in specific impulse is still non-
negligible. A combined analysis of the problem however yielded a promising result. The specific impulse 
may be omitted as long as the coolant flow rates can be kept below a limit of 0.7% of the total mass flow 
rate. Figure 22 shows the surface temperature of the C/C as a function of the coolant mass flow rate and 
reveals that the material allows even for flow as low as 0.5 % and still keeping the temperature threshold 
of 2500 K. Figure 22: Operating regime of a transpiration cooled C/C liner

--- chunk_id: chunk-0052
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 32
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 476
content_hash: 927c843a03e1a602
prev_chunk_id: chunk-0051
next_chunk_id: chunk-0053
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 32 
RTO-EN-AVT-150 
 
 
3.3.2 
Thermal Barrier Coating (TBC) 
There exist various methods to build up protective layers for thermal protection. Among them the 
following techniques have been demonstrated successfully that they are suited for copper alloy substrates 
typical for liquid rocket engine applications: electron beam physical vapour deposition (EB-PVD), 
vacuum plasma spraying (VPS) and solution plasma spraying (SPS) [38-41]. A segmented sub-scale 
model combustor with a EB-PVD zirconia TBC was tested successfully under representative operating 
conditions at DLR [42]. The functional principle of a TBC, illustrated in figure 23, is to increase the hot gas side wall 
temperature TW. This is achieved by applying a ceramic top layer, i.e. partially Yttrium stabilized Zirconia 
(PYSZ), onto the copper wall. The PYSZ ceramic offers a thermal conductivity λ of about 1.5 W/(m K). In order to prevent a coating overheat (> 1500 K) coating thicknesses of less than 50 µm are required. These high hot gas side wall temperatures compared to the 800 K maximum temperature of the uncoated 
copper wall the convective wall heat flux is reduced remarkably. Figure 23: Functional principle of a thermal barrier coating 
There are several reasons for an application of a TBC to the liner of a combustion chamber, to provide 
a protective layer against chemical attack of oxygen or OH radicals and hydrogen embrittlement and to 
protect the copper liner from high temperatures and thermal shocks. With such a protective layer, the 
application range of existing regenerative cooling thrust chambers can be enlarged towards higher 
combustion chamber pressures or an increased thrust chamber life. In general a TBC acts as an insulator to 
the inner liner, reducing the wall heat flux into the copper base material. 3.3.3 
New materials and processes for conventional regenerative cooled chamber lines 
Within the last years near net-shape formation of thrust chamber liners or nozzle throat sections has 
been discussed intensively in the literature. Aside tungsten or rhenium which were proposed for satellite or 
apogee application only recently high temperature [43, 44] high strength alloys such as CuCrNb are 
proposed and developed which seem to be able to replace the standard CuAgZr material.

--- chunk_id: chunk-0053
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 32
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 254
content_hash: 25211c5da08adb5e
prev_chunk_id: chunk-0052
next_chunk_id: chunk-0054
section_heading: 2.2.3 Turbines
document_type: technical_reference

3.3.3 
New materials and processes for conventional regenerative cooled chamber lines 
Within the last years near net-shape formation of thrust chamber liners or nozzle throat sections has 
been discussed intensively in the literature. Aside tungsten or rhenium which were proposed for satellite or 
apogee application only recently high temperature [43, 44] high strength alloys such as CuCrNb are 
proposed and developed which seem to be able to replace the standard CuAgZr material. This material 
attracted increasing interest all over the world and in the meanwhile the technology and the material seem 
to be ready to be applied for thrust chamber applications [45, 46]. However, as far as the open literature 
shows only sub-scale level or component level testing of thermal spray formed hardware have been 
performed yet [47, 48]. Results about test campaigns of high thrust engines are not available in open 
literature. One of the reasons may be that the problems of identification, quantification and detailed 
control of all the process parameters which may have an impact on key material properties such as 
elasticity and strength, resistance to annealing or creep may not be solved yet. Furthermore, most of the

--- chunk_id: chunk-0054
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 33
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 504
content_hash: 9c4f9e56d004e6bf
prev_chunk_id: chunk-0053
next_chunk_id: chunk-0055
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 33 
 
 
engineering design tools which are used to predict the low cycle fatigue and failure of thrust chamber 
liners have to be adjusted to this new material. 3.3.4 
High area ratio cooling channels 
The basic idea behind high aspect ratio cooling channels is to enhance the heat transfer and thus 
influence the temperature gradients [49, 50]. A reduction in channel width will allow a larger number of 
channels and longer fins and both effects will increase the heat transfer area. Furthermore, narrower 
cooling channels allow for thinner liner walls, see figure 24. The limits for the liner walls thickness are 
given by the finite non-homogeneities of the liner material and by the requirements of conventional 
milling tools. To date thicknesses of less than 0.6 mm are hardly achievable. Low aspect ratio design  
 
 
           High aspect ratio design 
Figure 24: Sketch of a conventional and high aspect ratio cooling channel 
DLR recently build and hot-fire tested a modular, sub-scale combustion chamber which had 
incorporated in one segment with four different aspect ratios of cooling channels to determine the 
effect of different aspect ratios on the heat transfer and especially on the temperature of the hot 
gas side liner [51]. 3.3.5 
Advanced nozzles concepts 
As already mentioned in chapter 2.3.4, any rocket engine with a burn time considerably higher than 
that of a standard booster engine (~150 s) will suffer from an off design penalty of its nozzle due to the 
changing ambient pressure conditions during ascent. The dual bell nozzle concept, see figure 25, aims at a 
reduction of this performance losses. During sea level pressure conditions the flow separates at the contour 
inflection of the nozzle and only the first part of it, the base nozzle experience fully attached flow 
conditions. During accent of the launcher, the ambient pressure decreases and at a certain altitude the flow 
jumps from the end of the first bell to the end of the nozzle extension, the second bell. The full flowing 
dual bell nozzle now works under high altitude conditions. The period of transition is sensitive to outer 
pressure field fluctuations and therefore of special interest. Figure 26 below demonstrates the advantage of 
a dual bell in comparison with conventional bell nozzles with different expansion ratios.

--- chunk_id: chunk-0055
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 33
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 174
content_hash: 13eea06a86224de6
prev_chunk_id: chunk-0054
next_chunk_id: chunk-0056
section_heading: 2.2.3 Turbines
document_type: technical_reference

The period of transition is sensitive to outer 
pressure field fluctuations and therefore of special interest. Figure 26 below demonstrates the advantage of 
a dual bell in comparison with conventional bell nozzles with different expansion ratios. The light blue 
curve shows the specific impulse of a booster engine with an expansion ratio of 32, while the green, black 
and red curves show that of engines with expansion ratios of 45, Vulcain 2 (60), and 100, respectively. In 
dark blue the specific impulse of a dual bell nozzle, designed with an expansion ratio of 45 for the first 
bell and of 100 for the second bell are shown. Although the specific impulse drops considerably due to the 
jump from first to the second bell this drawback is overcome later into the flight.

--- chunk_id: chunk-0056
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 34
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 360
content_hash: beb73aca9f25f0fc
prev_chunk_id: chunk-0055
next_chunk_id: chunk-0057
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 34 
RTO-EN-AVT-150 
 
 
 
Figure 25: Dual bell nozzle 
300
320
340
360
380
400
420
440
0
10
20
30
40
50
Altitude [km]
Specific Impulse [s]
Vulcain 2
Area Ratio = 45
Area Ratio = 100
Area Ratio = 32
Specific Impulse Dual Bell
 
Figure 26: Specific impulse of nozzles with different expansion ratios 
The experiments performed so far with cold gas facilities revealed that the jump and back-jump from 
the first to the second bell and back are very fast, typically less than 10 ms. The separation from the first 
bell is usually not entirely symmetric however, this asymmetry is limited to angles of less than 10° which 
effectively limits the resulting side loads, too. Additionally, there is a hysteresis occurs effect insofar as 
jump and back-jump don’t occur at the same nozzle pressure ratio. While the jump with increasing 
pressure ratio at a certain value, the back-jump at decreasing pressure ratios is delayed to a considerably 
lower value [52]. This stabilizing effect increases the sensitivity of the nozzle against ambient pressure 
fluctuations and thus enlarges the design margins of the nozzle and the nozzle operating conditions. However, the establishment of safe jump conditions during ascent require an active control of the nozzle 
pressure ratio by throttling of the engine. Within the last 10 years the European FSCD consortium which features CNES, DLR, EADS, ESA, 
ONERA, SNECMA, Volvo Aero Corp. investigated various nozzle contours in order to identify and 
quantify the physical sources of flow separation and side-loads and to establish reliable criteria and models 
to be implemented in engineering design tools [53, 54].

--- chunk_id: chunk-0057
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 35
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 500
content_hash: 97cf1176b272ef1a
prev_chunk_id: chunk-0056
next_chunk_id: chunk-0058
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 35 
 
 
3.3.6 
Advanced design methodology 
A clear alternative to the deterministic approach briefly described in chapter 2.3.5, is a probabilistic 
design approach which considers the uncertainties of material properties, operating conditions and loads in 
a more structured manner. In the probabilistic approach, design variables are neither seen as single values 
nor are they weighed to an upper or lower bounds. They are instead represented by the actual distribution 
or variation of the parameters. A distribution is a histogram of discrete values of the parameters or a 
mathematical model that represents a smooth description of the variation. When the area under the 
histogram or curve is normalized to a value of one, the function is called the probability density function. The parameters are termed random variables. The distribution functions, then, are used to determine the 
probability of occurrence of a given value of the random variable. A typical structural model for both 
static and dynamic analyses bases on nominal hardware geometry. Resulting displacements, loads and 
stresses are then compared to the material data, i.e. cyclic fatigue or ultimate strength. The material data 
are taken as lower bound values of the available material test data. The ratios between the data and the 
predicted values have to be within the specified safety margin. The predicted distributions show the 
probability for a failure and not a value or safety. The sensitivity of each variable to failure which is part 
of the result and this information helps the designer to get a better feeling for the impact of a variable. It is 
essential to become knowledgeable of inherent risk of failure and assess it, identify the mayor causes and 
minimize them within the design constraints. A typical design process can be divided into conceptual design, preliminary design, detailed design 
and development testing. The conceptual design process is performed in the classical deterministic way 
and includes defining operating characteristics and configurations and the use of simplistic design 
guidelines for definition of configuration. Initial sizing is based on deterministic analysis for primary loads 
and the design features incorporate the essence of the load-carrying features of the hardware. Many details 
are ignored at this stage and will be handled later and whenever appropriate, simple approximations are 
utilized.

--- chunk_id: chunk-0058
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 35
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 516
content_hash: 4e86d17dd46acee6
prev_chunk_id: chunk-0057
next_chunk_id: chunk-0059
section_heading: 2.2.3 Turbines
document_type: technical_reference

Initial sizing is based on deterministic analysis for primary loads 
and the design features incorporate the essence of the load-carrying features of the hardware. Many details 
are ignored at this stage and will be handled later and whenever appropriate, simple approximations are 
utilized. The preliminary design typically entails a deterministic design analysis, analyses of failure modes 
and a list of critical items. In a probabilistic design methodology, it is at this point that the initial decisions 
are made as to which variables are crucial; an initial quantification of uncertainty is also determined. In 
addition, the design must be critically reviewed to define possible failure modes and how they relate to the 
uncertainty of variables. Typically the detailed design will still make use of deterministic analysis with 
maximum loads, minimum properties and associated deterministic models and failure techniques. Each 
element of a design requires a reliability estimate. Non-critical items where reliability is easily obtained, a 
simple reliability estimator will be utilized. Critical items however require a detailed probabilistic analysis 
which considers component load distributions, geometric tolerances and variations, material property 
unknown or uncertainties, failure model characterization such as ultimate load, buckling or fatigue, and 
allowances for human error, model error, fabrication and assembly. Using this detailed evaluation, loads, 
responses and damage assessment will be quantified as a component reliability that has considered the 
sensitivities of the hardware and uncertainties. Generally, all probabilistic methods are approximate and the most common of the approximate 
methods is the Monte Carlo simulation or a variation of it. Repeated numerical experiments are performed 
that represent the total spectrum of the population of the problem. The method has an accuracy problem 
when small probabilities are involved. The mean value is adequately represented with a reasonable 
number of simulations. Sufficiently accurate solutions are with increasing numbers of simulations (less 
then 10,000) and the method delivers perfect answers when 20,000 to 100,000 simulations can be done in 
a reasonable amount of computer time. Obviously, the method has problems if each takes too time 
consuming which quite often happens for large finite-element analysis. Finally, important results from probabilistic analysis are the sensitivity responses which allow for a 
quantitative ranking of different design variables relative to the deviation in the response of the structure. The probabilistic approach identifies areas where tolerances might be loosened with negligible effect on

--- chunk_id: chunk-0059
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 36
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 409
content_hash: 71176f205bb29891
prev_chunk_id: chunk-0058
next_chunk_id: chunk-0060
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 36 
RTO-EN-AVT-150 
 
 
reliability as well as areas where additional data is required to improve reliability. Although probabilistic 
analysis requires more computational effort, the method provides much more information than 
deterministic design and it is better suited to include uncertainties such as scatter in material data, 
variations in thermal, mechanical, chemical static or dynamic loads tolerance in production precision. Furthermore, it is a tool which allows for risk identification. 4. CONCLUSIONS  
Based on a description of the basic components and features of rocket engines areas have been 
identified and the physical and technological limitations given in order to pave the way for a discussion of 
possible improvements. The topics of gas generator or pre-burner as well as were not included in the areas 
where potential advancements were proposed although some of the techniques proposed for thrust 
chambers, ignition systems or injector should be applicable as well for other combustion devices. The concept of an advanced laser-based ignition system was discussed and the current status given. Additionally, an injection system design which aims at a much cheaper design with negligible impact on 
performance with simple LOX posts and a porous face plate was proposed and sample results were given. Various possibilities to improve thrust chamber cooling techniques involving new materials such as 
CuCrNb, ceramic matrix composites or effusion cooling were explained, the different aspects shown. Additionally, the advantages and the basic features of an advanced nozzle concept for a main stage engine, 
the dual bell nozzle was described and the current statues of technology explained. Finally, a novel design 
methodology, the probabilistic design approach was briefly described. 5 
REFERENCES 
[1] Sutton, G.P., History of Liquid Propellant Rocket Engines, ISBN 1-56347-649-5, American Institute 
of Aeronautics and Astronautics, 2006 
[2] Isakovic, S.J., Hopkins Jr., J.P., Hopkins, J.B., International Reference Guide to Space Launch 
Systems, 3rd Ed.

--- chunk_id: chunk-0060
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 36
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 240
content_hash: 4f70d65335280d94
prev_chunk_id: chunk-0059
next_chunk_id: chunk-0061
section_heading: 2.2.3 Turbines
document_type: technical_reference

Finally, a novel design 
methodology, the probabilistic design approach was briefly described. 5 
REFERENCES 
[1] Sutton, G.P., History of Liquid Propellant Rocket Engines, ISBN 1-56347-649-5, American Institute 
of Aeronautics and Astronautics, 2006 
[2] Isakovic, S.J., Hopkins Jr., J.P., Hopkins, J.B., International Reference Guide to Space Launch 
Systems, 3rd Ed. AIAA, 1999 
[3] Huzel, D.K., Hwang, D.H., Modern Engineering for Design of Liquid Rocket Engines, ISBN 1-
56347-013-6, American Institute of Aeronautics and Astronautics, 1992 
[4] Sutton, J.P., Rocket Propulsion Elements, 3rd Edition, Wiley and Sons, New York, London, 1963 
[5] NASA Facts, Next Generation Propulsion Technology: Integrated Powerhead Demonstrator, 
Technology, FS-2005-01-05-MSFC, Pub 8-40355, 2005 
[6] Cai, C., Jin, P., Yang, L., Du, Z., Xu, K., Experimental and Numerical Investigation of Gas-Gas 
Injectors for Full Flow Stage Combustion Cycle Engine, AIAA-2005-3745, 2005. [7] Davis, J.A., Campell, R.L., Advantages of a full-flow staged combustion cycle engine system, AIAA-
1997-3318, 1997 
[8] M. Wade, Encyclopedia Astronautica, www.astronautix.com 
[9] Farhangi, S., Hunt, K., Tuegel, L., Matthews, D., Fisher, S., Oxidizer-Rich Pre-burner for Advanced 
Rocket Engine Application, AIAA 94-3260, 1994 
[10] D. Haeseler, private communication

--- chunk_id: chunk-0061
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 37
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: 4d7ff0fdd80201c6
prev_chunk_id: chunk-0060
next_chunk_id: chunk-0062
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 37 
 
 
[11] Cannon, J.L., Turbomachinery for Liquid Rocket Engines, “Liquid Propulsion Systems - Evolution 
and Advancements, American Institute of Aeronautics and Astronautics Professional Development Short 
Course, 2003 
[12] Albat, R., Langel, G., Haidn, O.J., “Antriebssysteme”, in Ley, Wittmann, Hallmann (Eds.) 
“Handbuch der Raumfahrttechnik“, Hanser Verlag, to be published 2007  
[13] Fisher, S.C., Popp, M., Quentmeyer, R.J., Thrust Chamber Cooling and Heat Transfer, in M. Habiballah, M. Popp, V. Yang (Eds., LIQUID ROCKET COMBUSTION DEVICES Aspects of 
Modeling, Analysis and Design, proceedings of he 2nd Int. Symposium on Liquid Rocket Propulsion, 
Chatillon, 1995 
[14] Liang, K., Yang, B., Zhang, Z., Investigation of heat transfer and coking characteristics of 
hydrocarbons fuels, Journal of Propulsion and Power, Vol. 14, No. 5, 1998 
[15] Riccius, J.R., Haidn, O.J., Zametaev, E.B., Influence of Time Dependent Effects on the Estimated Life 
Time of Liquid Rocket Engines, Int. Symposium on Space Propulsion, Shanghai, Sept. 25-28, 2004, China  
[16] Frey, M., Rydén, R., Alziary de Roquefort, Th., Hagemann, G., James, Ph., Kachler, Th., Reijasse, 
Ph., Schwane, R., Stark, R.: European Cooperation on Flow Separation Control, 4th International 
Conference on Launcher Technology, Liege, 2002. [17] Hammond, W., Space Transportation: A System Approach to Analysis and Design, ISBN 1-56347-
032-2, American Institute of Aeronautics and Astronautics, 1999 
[18] Newell, J.F., Rajagopal, K.R., Probabilistic Methodology – A Design Tool for the Future, 
www.engineeringatboeing.com/articles/probabalistic.htm, 1999 
[19] Gerlinger, B., et al., Direkteinspritzender Ottomotor und Laserzündung, 5. Dresdner 
Motorenkolloquium, 2003 
[20] Gurliat O., Schmidt V., Haidn O.J., Oschwald M., Ignition of Cryogenic H2/LOX Sprays, Aerospace 
Science and Technology, Vol. 7, Issue 7, pp. 517-531, 2003  
[21] Haeseler, D., Mäding, C., Rubinski, V., Khrissanfov, S., Kosmacheva, High Flow Rate Injection 
Elements, 4th Int. Conference on Launcher Technology, Liege, 2002 
[22] Popp, M., Schmidt, G., Rocket engine combustion chamber design concepts for enhanced life, AIAA-
1996-3303, 1996. [23] Kindermann, R., Beyer, S., Sebald, T., Hollmann, C., Denkena, B., Friemuth, T., Kaufeld, M., Kolb, 
U., Advanced Production and Process Technologies for current and future Thrust Chambers of Liquid 
Rocket Engines, 4th International Conference on Launcher Technology, Liege, 2002. [24] Quentmeyer, R.J., Rocket Combustion Chamber Life-Enhancing Design Concepts, AIAA-1990-2116, 
1990. [25] Elam, S., Effinger, M., Holmes, R., Lee, J., Jaskowiak, M., Lightweight Chambers Thrust Cell 
Applications, AIAA 2000-3131, 2000.

--- chunk_id: chunk-0062
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 37
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 68
content_hash: 75e0e93211a3b055
prev_chunk_id: chunk-0061
next_chunk_id: chunk-0063
section_heading: 2.2.3 Turbines
document_type: technical_reference

[24] Quentmeyer, R.J., Rocket Combustion Chamber Life-Enhancing Design Concepts, AIAA-1990-2116, 
1990. [25] Elam, S., Effinger, M., Holmes, R., Lee, J., Jaskowiak, M., Lightweight Chambers Thrust Cell 
Applications, AIAA 2000-3131, 2000. [26] Shelley, J.S., LeClaire, R., Nichols, J., Metal-Matrix Composites for Liquid Rocket Engines, JOM, 
Vol. 53 No. 4, pp. 18-21, 2001.

--- chunk_id: chunk-0063
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 38
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 490
content_hash: 39f40548f1e1971e
prev_chunk_id: chunk-0062
next_chunk_id: chunk-0064
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
 
6 - 38 
RTO-EN-AVT-150 
 
 
[27] Dembinski, L., Grosdidier, T., Coddet, C., On the microstructure of vacuum plasma sprayed Cu-3% 
Ag alloys, ITSC 2001 - Singapour - éditée par C.C. Berndt - K.A. Khor et E.F. Lugscheider - ASM-TSS - 
Materials park - OH-USA, p.633-637. [28] Leonhardt, T., Hamister, M., Carlén, J.C., Biaglow, J., Reed,B., Near-Net Shape Powder Metallurgy 
Thruster, NASA TM-2001-210373, 2001 
[29] May, L., Burkhardt, W.M., Transpiration Cooled Throat for hydrocarbon Rocket Engines, NASA 
KEE6-FR, 1991 
[30] Haeseler, D., Maeding, C., Rubinskiy, V., Gorokhov, V., Khrisanfov, S., Experimental Investigation 
of Transpiration Cooled Hydrogen-Oxygen Subscale Combustion Chambers, AIAA 98-3364, 1998 
[31] Meinert, J., Huhn, J., Serbest, E., Haidn, O.J.: Turbulent Boundary Layers with Foreign Gas 
Transpiration, Journal of Spacecraft and Rockets, 2001, volume 38, number 2, pp. 191-198. [32] Keener, D., Lenertz, J., Bowerson, R., Bowman, J., Transpiration Cooling Effects on Nozzle Heat 
Transfer and Performance, Journal of Spacecraft and Rockets, Vol. 32, No. 6, 1995, pp. 981 – 985. [33] Serbest, E., Haidn, O.J., Hald, H., Korger, G., Winkelmann, P., Fritscher, K., Advanced Technologies 
and Materials for Future Liquid Rocket Engines, 12th European Aerospace Conference, Paris, 1999 
[34] Hagemann, G., Immich, H., Nguyen TV., Dumnov, G.E., Advanced Rocket Nozzles, Journal of 
Propulsion and Power, Vol. 14, No.5, pp. 620-634, 1998 
[35] Korte, J.J., Salas, A.O., Dun, H.J., Alexandrov, N.M., Follet, W.W., Orient, G.E., Hadid, A.H., 
Multidisciplinary Approach to Aerospike Nozzle Design, NASA TM 110326, 1997. [36] Frey, M., Hagemann, G., Critical Assessment of Dual-Bell Nozzles, Journal of Propulsion and Power, 
Vol. 15, No. 1, pp. 137-143, 1999. [37] Haidn O.J., Greuel, Herbertz, A., Ortelt, M., Hald, H., Application of Fiber Reinforced C/C Ceramic 
Structures in Liquid Rocket Engines, SPACE CHALLENGE IN XXI CENTURY, Assovskiy I., Haidn OJ, 
(Eds), ISBN 5-94588-036-1, Moscow 2005, pp. 46-72. [38] Sebald, T., Beyer, S., Gawlitza, P., Mai, H., Pompe, W., Advanced Thermal Barrier Coatings for 
High Heat Fluxes in Thrust Chambers of Liquid Rocket Engines, 4th International Conference on Launcher 
Technology Space Launcher Propulsion, 2002, Liège. [39] Gell, M., Xie, L., Ma, X., Jordan, E.H., Padture, N.P., Highly durable thermal barrier coatings made 
by the solution precursor plasma spray process, Surface & Coatings Technology, 177-178 (2004) pp. 97-
102.

--- chunk_id: chunk-0064
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 38
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 176
content_hash: f3ffc1907718811a
prev_chunk_id: chunk-0063
next_chunk_id: chunk-0065
section_heading: 2.2.3 Turbines
document_type: technical_reference

[39] Gell, M., Xie, L., Ma, X., Jordan, E.H., Padture, N.P., Highly durable thermal barrier coatings made 
by the solution precursor plasma spray process, Surface & Coatings Technology, 177-178 (2004) pp. 97-
102. [40] Azzopardi, A., Mévrel, R., Saint-Ramond, B., Olson, E., Stiller, K., Influence of aging on structure 
and thermal conductivity of Y-PSZ and Y-FSZ EB-PVD coatings, Surface and Coatings Technology 177-
178 (2004), pp. 131-139. [41] Faraoun, H., Aourag, H., Grosdidier, T., Klein, D., Coddet, C., Development of modified embedded 
atom potentials for the Cu-Ag system, Superlattices and Microstructures, Vol. 30, (5), pp. 261-271, 2001. [42] Schulz, U., Fritscher, K., Peters, M., Greuel, D., Haidn O.J., Fabrication of TBC- armoured rocket 
combustion chambers by EB-PVD methods and TLP, Science and Technology of Advanced Materials, 6, 
2005, pp. 101 – 110.

--- chunk_id: chunk-0065
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 39
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 353
content_hash: 534f3b197825deff
prev_chunk_id: chunk-0064
next_chunk_id: chunk-0066
section_heading: 2.2.3 Turbines
document_type: technical_reference

Advanced Rocket Engines 
RTO-EN-AVT-150 
6 - 39 
 
 
[43] Leonhardt, T., Hamister, M., Cerlén, J.C., Biaglow, J., Reed, B., Near-Net Shape Powder Metallurgy 
Rhenium Thruster, NASA/TM-2001-210373, 2001 
[44] Flinn, E., Tough Coating for a Smoother Rocket Cone, Aerospace America, August 2004, pp. 24-25. [45] Thomas-Ogbuji, L., Humphrey, D.L., Setlock, J.A., Oxidation-Reduction Resistance of Advanced 
Copper Alloys, NASA/CR-2003-212549, 2003. [46] Hickmann, R., McKechnie, T., Holmes, R., Elam, S., Material Properties of Net Shape, Vacuum 
Plasma Sprayed GRCop-84, AIAA 2003-4612, 2003 
[47] Ellis, D.L., GRCop-84: A High-Temperature Copper Alloy for High-Heat-Flux Applications, 
NASA/TM-2005-213566. [48] Verdy, C., Coddet, C., Thomas, J.-L., Cornu, D., Choulat, M., Highly Thickness Components for 
Liquid Rocket Engine Produced by Low Pressure Plasma Spraying, International Thermal Spray 
Conference, Seattle, 2006. [49] Carlile, J.A, Quentmeyer, R.J., An Experimental Investigation of High-Aspect-Ratio Cooling 
Passages, AIAA 92-3154, 1992 
[50] Wadle, M.F., Comparison of High Aspect Ratio Cooling Channel Designs for a Rocket Combustion 
Chamber with Development of an Optimum Design, NASA/TM-1998-206313, 1998 
[51] Woschnak, A., Suslov, D., Oschwald, M., Experimental and Numerical Investigations of Thermal 
Stratification Effects, AIAA 2003-4615, 2003. [52] Stark, R., Haidn, O.J., Böhm, C., Zimmermann, H., Cold Flow Testing of Dual-Bell Nozzles in 
Altitude Simulation Chambers, Proc. of EUCASS European Conference for Aerospace Sciences, Moscow, 
2005. [53] Frey, M., Rydén, R., Alziary de Roquefort, Th., Hagemann, G., James, Ph., Kachler, Th., Reijasse, 
Ph., Schwane, R., Stark, R.: European Cooperation on Flow Separation Control, 4th International 
Conference on Launcher Technology, Liege, 2002. [54] Winterfeldt, L. Laumert, B., Tano, R., James, P, Geneau, F., Blasi, R., Hageman, G., Redesign of the 
Vulcain 2 Nozzle Extension, AIAA-2005-4536, 2005

--- chunk_id: chunk-0066
source_document: AdvanceRocketEnginesEN-AVT-150-06.pdf
page: 40
quality: 0.72
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 5
content_hash: b1d3a7f48a7b90af
prev_chunk_id: chunk-0065
next_chunk_id: null
section_heading: 2.2.3 Turbines
document_type: technical_reference

<!-- image -->

ORGANIZATION
