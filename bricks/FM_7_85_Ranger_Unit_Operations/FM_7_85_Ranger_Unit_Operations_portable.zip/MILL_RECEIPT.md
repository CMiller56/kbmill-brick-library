# Mill receipt — FM_7_85_Ranger_Unit_Operations

KBMill · VectorForge plant
When: 2026-08-17T23:55:18Z

## Charge (for your books)

- Job id: `not recorded`
- Job class: **Hard**
- List price: **$999 USD**
- Pay policy: **pay on success only** — this ZIP is the success artifact. Fail = no charge.
- This is a **mill receipt**, not a tax invoice. File it with the ZIP to track spend.

This package was **manufactured**. It is not a chat export and not a file conversion. Something serious happened under the hood.

## What you are holding
- Portable brick — Markdown, `kb.json`, chunks, embeddings
- Residual board — what is muted, what is still open
- Security report — what we scanned, and what we did not
- Craft brief — how to load this brick and who sits next to it

## Plant gauges
- in kb: 420  ·  muted: 6  ·  on RAG: 414
- embedded rows: 420
- ship cue: see residual board
- avg_extraction_quality: 0.9746 — text-layer coverage / extractability (pages that produced usable text), not character-level OCR accuracy

## Adjacent bricks
- `Ranger_Handbook_SH_21_76`
- `Ranger_Handbook_TC_3_21_76`
- `FM_3_90_Tactics`

## Security
See `SECURITY_REPORT.md` in this package.
Heuristic plant pass. Not a clearance. Does not absolve your system. What to upload, and whether you may share it, is still your trusted people.

## What this is not
- Not a hosted library — download window, then we purge
- Not permission to skip your own controls
- Not one melted mega-KB if this job was a shelf (siblings stay siblings)

Manufactured by the plant. The magazine is not a customer control.
