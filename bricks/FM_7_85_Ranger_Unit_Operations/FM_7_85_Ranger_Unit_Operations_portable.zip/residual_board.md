# Residual board — FM_7_85_Ranger_Unit_Operations

Status: **success**

## Counts
- in kb: 420  |  muted / off RAG: 6  |  on RAG path: 414
- embedded rows: 420
- reconciled: True

## Quality score (if present)
- avg_extraction_quality: **0.9746**
- measures: text-layer coverage / extractability (pages that produced usable text), not character-level OCR accuracy

## Limits / open items
- (none recorded)

