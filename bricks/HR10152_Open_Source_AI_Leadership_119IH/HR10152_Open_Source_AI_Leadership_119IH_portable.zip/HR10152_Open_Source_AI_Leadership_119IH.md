---
kb_id: hr-10152-introduced-in-house-ih
title: H.R. 10152 Introduced in House (IH)
author: Unknown Author
created_date: 2026-09-16
classification: Internal
confidence_level: High
domain_tags: ["security", "rmf", "ato", "software", "api", "mcp", "reference", "engineering"]
entity_mentions: ["system that"]
document_type: Technical Reference
primary_subject: Be it enacted by the Senate and House of Representatives of the
United States of America in Congress assembled,
sources: [{"filename": "BILLS-119hr10152ih.md", "path": "kbs/_ingest_jobs/HR10152_Open_Source_AI_Leadership_119IH/md_clean/BILLS-119hr10152ih.md", "page_count": 1}]
ingest_provenance: {"captured_at": "2026-09-16T10:57:36.973480", "page_count": 1, "extraction_methods": {"txt": 1}, "avg_extraction_quality": 1.0, "docling_triage_pages": 0, "docling_triage_rate": 0.0, "extraction_stats": null}
dark_data_inferred_fields: ["author", "classification", "confidence_level", "created_date", "document_type", "document_type_confidence", "document_type_inferred", "domain_tags", "entity_mentions", "ingest_provenance", "kb_id", "primary_subject", "sources", "title"]
kb_name: HR10152_Open_Source_AI_Leadership_119IH
document_type_inferred: True
document_type_confidence: 0.678
kb_name: HR10152_Open_Source_AI_Leadership_119IH
created: 2026-09-16T10:57:36.973565
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 5
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-09-16T10:57:42.291804
  chunk_count: 5
  strict_air_gapped: true
---

--- chunk_id: chunk-0000
source_document: BILLS-119hr10152ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 344
content_hash: da89f1d861beb41f
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: H.R. 10152 Introduced in House (IH)
document_type: technical_reference

## H.R. 10152 Introduced in House (IH)

Be it enacted by the Senate and House of Representatives of the
United States of America in Congress assembled,

### SECTION 1. Short Title. This Act may be cited as the ``Open-Source AI Leadership Act''. ### SEC. 2. Adoption And Use Of Qualified Open Models. The Secretary shall take any of the following actions as
appropriate to support the adoption and use of qualified open models in
interstate and foreign commerce:
            (1) Designate a single point of contact to coordinate any
        effort between the Department of Commerce, any relevant private
        sector entity, and any other relevant stakeholder to support
        the adoption and use of qualified open models. (2) Review any relevant program or power of the Secretary
        related to the adoption and use of qualified open models and
        direct the head of any such program, as appropriate, to support
        such adoption and use. (3) Identify any barrier to the adoption and use of
        qualified open models and take any action as appropriate to
        address any such barrier. (4) Enter into agreements, as appropriate, to support the
        adoption and use of qualified open models with any of the
        following:
                    (A) A private sector entity, including a startup. (B) An agency. (C) A State. (D) A qualified foreign partner. (5) Develop policy and recommendations to facilitate the
        adoption and use of qualified open models. (6) Identify any relevant evidence-based approach, best
        practice, framework, benchmark, or other method, as
        appropriate, to monitor the adoption and use of qualified open
        models and foreign adversary models.

--- chunk_id: chunk-0001
source_document: BILLS-119hr10152ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 462
content_hash: cf233640c020ca70
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
section_heading: SEC. 3. Assessment Of Foreign Adversary Models.
document_type: technical_reference

## SEC. 3. Assessment Of Foreign Adversary Models. (a) In General.--The Secretary shall identify, assess, and make
publicly known, as appropriate, any risk related to the adoption and
use of foreign adversary models, including any risk related to the
following:
            (1) The training of a foreign adversary model, including
        any risk related to a covered nation, or an entity or
        individual that is subject to the control of a covered nation,
        conducting any such training through any unauthorized use of an
        artificial intelligence model. (2) The confidentiality, integrity, and accessibility of
        personal and proprietary information, including any risk of
        access to such information by a covered nation or an entity or
        individual that is subject to the control of a covered nation. (3) The security and resiliency of any organization that
        uses or adopts a foreign adversary model and any risk that may
        result to the supply chain of such organization as a result of
        any such use or adoption. (4) Any output of a foreign adversary model, including with
        respect to historical accuracy, scientific inquiry, and freedom
        of expression. (5) The efficacy, or lack thereof, of any feature of a
        foreign adversary model intended to prevent misuse or
        exploitation of such model, including any safety or security
        feature intended to prevent any such misuse or exploitation. (6) The development and use of chemical, biological,
        radiological, or nuclear capabilities, or any other similar
        risk related to the national security and economic security of
        the United States. (b) Publication.--Not later than 18 months after the date of the
enactment of this Act, and annually thereafter, the Secretary shall
publish on a publicly facing website a report that assesses any risk
related to a foreign adversary model identified and assessed under
subsection (a) and information relating to the following:
            (1) An overview of the adoption and use of leading foreign
        adversary models. (2) The cost, capability, and performance of foreign
        adversary models. (3) A comparison between the information required by
        paragraphs (1) and (2) relating to foreign adversary models and
        such information, as available, relating to qualified open
        models.

--- chunk_id: chunk-0002
source_document: BILLS-119hr10152ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 146
content_hash: 79390583e1e81be0
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: SEC. 3. Assessment Of Foreign Adversary Models.
document_type: technical_reference

(2) The cost, capability, and performance of foreign
        adversary models. (3) A comparison between the information required by
        paragraphs (1) and (2) relating to foreign adversary models and
        such information, as available, relating to qualified open
        models. (c) Report to Congress.--Not later than 30 days after the
publication of a report under subsection (b), the Secretary shall
submit to the Committee on Energy and Commerce of the House of
Representatives and the Committee on Commerce, Science, and
Transportation of the Senate the report. (d) Sunset.--The requirement described in subsection (b) does not
apply beginning on the date that is 10 years after the date of the
enactment of this Act.

--- chunk_id: chunk-0003
source_document: BILLS-119hr10152ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 490
content_hash: cba0850f0a7b09c7
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: SEC. 4. Rule Of Construction.
document_type: technical_reference

## SEC. 4. Rule Of Construction. Nothing in this Act may be construed to authorize the Secretary to
ban, restrict, or otherwise make unavailable an open artificial
intelligence model in interstate or foreign commerce. ### SEC. 5. Definitions. In this Act:
            (1) Agency.--The term ``agency'' has the meaning given that
        term in section 551 of title 5, United States Code. (2) Artificial intelligence.--The term ``artificial
        intelligence'' has the meaning given that term in section 5002
        of the National Artificial Intelligence Initiative Act of 2020
        (15 U.S.C. 9401). (3) Artificial intelligence model.--The term ``artificial
        intelligence model'' means a software component of an
        information system that incorporates artificial intelligence
        and uses computational, statistical, or machine-learning
        techniques to produce outputs from a defined set of inputs. (4) Covered nation.--The term ``covered nation'' has the
        meaning given that term in section 4872(f) of title 10, United
        States Code. (5) Foreign adversary model.--The term ``foreign adversary
        model'' means an open artificial intelligence model that is
        developed or made available in interstate or foreign commerce
        by--
                    (A) a covered nation; or
                    (B) an entity or individual that is subject to the
                control of a covered nation. (6) Open artificial intelligence model.--The term ``open
        artificial intelligence model'' means an artificial
        intelligence model--
                    (A) with model weights that are publicly released
                for download or distribution; or
                    (B) that is distributed under an open license that
                permits use, modification, and redistribution of the
                source code and model weights of the model. (7) Qualified foreign partner.--The term ``qualified
        foreign partner'' means a foreign country or foreign political
        and economic union that is not a covered nation. (8) Qualified open model.--The term ``qualified open
        model'' means an open artificial intelligence model that is--
                    (A) developed and made available by a U.S. person
                in interstate or foreign commerce; and
                    (B) not developed or made available by--
                            (i) a covered nation; or
                            (ii) an entity or individual that is
                        subject to the control of a covered nation. (9) Secretary.--The term ``Secretary'' means the Secretary
        of Commerce. (10) State.--The term ``State'' means each State of the
        United States, the District of Columbia, each commonwealth,
        territory, or possession of the United States, and each
        federally recognized Indian Tribe. (11) U.S. person.--The term ``U.S.

--- chunk_id: chunk-0004
source_document: BILLS-119hr10152ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 46
content_hash: 70e551e840fbd88b
prev_chunk_id: chunk-0003
next_chunk_id: null
section_heading: SEC. 4. Rule Of Construction.
document_type: technical_reference

(11) U.S. person.--The term ``U.S. person'' means a person
        that--
                    (A) is domiciled in the United States;
                    (B) is headquartered in the United States; and
                    (C) is organized under the laws of the United
                States.
