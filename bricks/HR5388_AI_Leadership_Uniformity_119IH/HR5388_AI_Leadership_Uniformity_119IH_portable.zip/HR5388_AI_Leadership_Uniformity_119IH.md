---
kb_id: hr-5388-introduced-in-house-ih
title: H.R. 5388 Introduced in House (IH)
author: Unknown Author
created_date: 2026-09-16
classification: Internal
confidence_level: High
domain_tags: ["security", "rmf", "ato", "software", "api", "mcp", "reference", "engineering"]
entity_mentions: ["system that"]
document_type: Technical Reference
primary_subject: Be it enacted by the Senate and House of Representatives of the
United States of America in Congress assembled,
sources: [{"filename": "BILLS-119hr5388ih.md", "path": "kbs/_ingest_jobs/HR5388_AI_Uniformity_119IH/md_clean/BILLS-119hr5388ih.md", "page_count": 1}]
ingest_provenance: {"captured_at": "2026-09-16T11:12:51.537051", "page_count": 1, "extraction_methods": {"txt": 1}, "avg_extraction_quality": 1.0, "docling_triage_pages": 0, "docling_triage_rate": 0.0, "extraction_stats": null}
dark_data_inferred_fields: ["author", "classification", "confidence_level", "created_date", "document_type", "document_type_confidence", "document_type_inferred", "domain_tags", "entity_mentions", "ingest_provenance", "kb_id", "primary_subject", "sources", "title"]
kb_name: HR5388_AI_Leadership_Uniformity_119IH
document_type_inferred: True
document_type_confidence: 0.631
kb_name: HR5388_AI_Leadership_Uniformity_119IH
created: 2026-09-16T11:12:51.537137
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 10
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-09-16T11:12:58.214709
  chunk_count: 10
  strict_air_gapped: true
---

--- chunk_id: chunk-0000
source_document: BILLS-119hr5388ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 249
content_hash: 66bfbccc7298d191
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: H.R. 5388 Introduced in House (IH)
document_type: technical_reference

## H.R. 5388 Introduced in House (IH)

Be it enacted by the Senate and House of Representatives of the
United States of America in Congress assembled,

### SECTION 1. Short Title. This Act may be cited as the ``American Artificial Intelligence
Leadership and Uniformity Act''. ### SEC. 2. Definitions. In this Act:
            (1) Artificial intelligence or ``ai''.--The term
        ``artificial intelligence'' has the meaning given such term in
        section 5002 of the National Artificial Intelligence Initiative Act of 2020 (15 U.S.C. 9401 note). (2) Artificial intelligence model.--The term ``artificial
        intelligence model'' means a software component of an
        information system that implements artificial intelligence
        technology and uses computational, statistical, or machine-
        learning techniques to produce outputs from a defined set of
        inputs. (3) Artificial intelligence system.--The term ``artificial
        intelligence system'' means any data system, hardware, tool, or
        utility that operates, in whole or in part, using artificial
        intelligence. (4) Automated decision system.--The term ``automated
        decision system'' means any computational process derived from
        machine learning, statistical modeling, data analytics, or
        artificial intelligence that issues a simplified output,
        including a score, classification, or recommendation, to
        materially influence or replace human decision-making.

--- chunk_id: chunk-0001
source_document: BILLS-119hr5388ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 274
content_hash: c908f78ce013b48e
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
section_heading: SEC. 3. Findings.
document_type: technical_reference

## SEC. 3. Findings. The Congress finds the following:
            (1) The United States stands at a new frontier of
        scientific discovery driven by transformative technologies such
        as artificial intelligence. (2) Breakthroughs in these fields have the potential to
        reshape the global balance of power, spark entirely new
        industries, and revolutionize the way Americans live and work. (3) Global competitors are racing to develop and deploy
        these technologies to gain strategic advantage. (4) Securing that future requires harnessing the full power
        of American innovation across the private sector, academia, and
        government. (5) The United States leads the world in AI due to a
        thriving innovation, investment, and development environment;
        and a flexible, sector-specific regulatory framework. (6) A patchwork of divergent State AI rules creates
        conflicting requirements, forces firms to navigate multiple
        agencies, and can deter investment. (7) Small businesses face disproportionate compliance
        burdens from unclear or fragmented AI rules; clarity and
        sector-specific guidance are needed. (8) There is no universal legal definition of ``artificial
        intelligence''; any Federal action that preempts State AI laws
        should precisely define its scope. (9) AI governance standards are still maturing (including
        the National Institute of Standards and Technology's AI Risk
        Management Framework); a uniform national approach during this
        build-out supports responsible adoption.

--- chunk_id: chunk-0002
source_document: BILLS-119hr5388ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 214
content_hash: c67adc29c7b332a0
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: SEC. 4. Policy.
document_type: technical_reference

## SEC. 4. Policy. It is the policy of the United States that--
            (1) Sustaining and enhancing America's global AI dominance
        is necessary to promote human flourishing and economic
        competitiveness. (2) It is a national security imperative for the United
        States to achieve and maintain unquestioned and unchallenged
        global technological dominance. (3) Federal AI governance should affirm a sectoral,
        technology-neutral, incremental approach that leverages primary
        regulators' expertise. (4) A permissive national framework should enable the
        development of AI models and systems in interstate commerce for
        a defined period to prevent state-by-state regulatory
        uncertainty while national guardrails are developed. (5) Federal policy should anchor AI risk management in
        nationally recognized principles and guidance to promote
        consistent, predictable compliance. (6) Regulations should minimize disproportionate burdens on
        small businesses and support their ability to adopt AI tools
        and compete. (7) Federal preemption of State AI laws should use precise
        definitions, be time limited and be clear in scope to avoid
        ambiguity and unnecessary litigation.

--- chunk_id: chunk-0003
source_document: BILLS-119hr5388ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 454
content_hash: 49a116407d662dc3
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: SEC. 5. National Artificial Intelligence Action Plan.
document_type: technical_reference

## SEC. 5. National Artificial Intelligence Action Plan. (a) Action Plan Required.--Not later than 30 days after the date of
enactment of this Act, the President, acting through the Assistant to
the President for Science and Technology (or the Director of the Office
of Science and Technology Policy), the Special Advisor for Artificial
Intelligence and Crypto (or such official as the President may
designate with substantially similar responsibilities), and the
Assistant to the President for National Security Affairs, in
coordination with the Assistant to the President for Economic Policy,
the Assistant to the President for Domestic Policy, the Director of the
Office of Management and Budget (OMB Director), and the heads of such
executive departments and agencies as appropriate, shall develop and
submit to Congress a National Artificial Intelligence Action Plan (in
this section, the ``Action Plan'') to carry out the policy in section
4. (b) Annual Updates.--Not later than 1 year after the submission
required by subsection (a), and annually thereafter, the President
shall submit to Congress an update on implementation of, and any
revisions to, the Action Plan. (c) Contents of the Action Plan.--The Action Plan shall, at a
minimum--
            (1) identify actions to remove barriers to American AI
        innovation across the Federal Government, and at the State and
        local level, including procurement, licensing, permitting,
        routing, zoning, and reporting processes;
            (2) set measurable goals, timelines, and agency roles for
        advancing AI research and development; testing, evaluation,
        verification, and validation; and adoption of safe, secure, and
        trustworthy AI in Federal missions;
            (3) align Federal risk management and governance with
        nationally recognized standards and guidance, including
        frameworks and profiles developed by the National Institute of
        Standards and Technology, and identify any additional standards
        work needed;
            (4) outline steps to strengthen critical-infrastructure
        security, national-security applications, supply-chain
        resilience, and incident reporting relevant to AI;
            (5) include measures to reduce disproportionate compliance
        burdens on small businesses and expand access to foundation
        models, computing resources, datasets, and technical
        assistance; and
            (6) set metrics to evaluate progress and a cadence for
        interagency coordination and public reporting.

--- chunk_id: chunk-0004
source_document: BILLS-119hr5388ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 476
content_hash: af6060b199b3734e
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: SEC. 5. National Artificial Intelligence Action Plan.
document_type: technical_reference

(b) Annual Updates.--Not later than 1 year after the submission
required by subsection (a), and annually thereafter, the President
shall submit to Congress an update on implementation of, and any
revisions to, the Action Plan. (c) Contents of the Action Plan.--The Action Plan shall, at a
minimum--
            (1) identify actions to remove barriers to American AI
        innovation across the Federal Government, and at the State and
        local level, including procurement, licensing, permitting,
        routing, zoning, and reporting processes;
            (2) set measurable goals, timelines, and agency roles for
        advancing AI research and development; testing, evaluation,
        verification, and validation; and adoption of safe, secure, and
        trustworthy AI in Federal missions;
            (3) align Federal risk management and governance with
        nationally recognized standards and guidance, including
        frameworks and profiles developed by the National Institute of
        Standards and Technology, and identify any additional standards
        work needed;
            (4) outline steps to strengthen critical-infrastructure
        security, national-security applications, supply-chain
        resilience, and incident reporting relevant to AI;
            (5) include measures to reduce disproportionate compliance
        burdens on small businesses and expand access to foundation
        models, computing resources, datasets, and technical
        assistance; and
            (6) set metrics to evaluate progress and a cadence for
        interagency coordination and public reporting. (d) Review of Executive Actions; Conformity.--As part of the Action
Plan, the officials identified in subsection (a), in coordination with
the heads of relevant agencies--
            (1) shall review all policies, directives, regulations,
        orders, guidance, and other actions taken pursuant to Executive
        Order 14110 of October 30, 2023 (Safe, Secure, and Trustworthy
        Development and Use of Artificial Intelligence), and provide a
        status update on actions taken pursuant to Executive Order
        14179 of January 23, 2025 (Removing Barriers to American
        Leadership in Artificial Intelligence); and identify any such
        actions under either Executive Order that are or may be
        inconsistent with the policy in section 4; and,
            (2) for any action identified under paragraph (1), the head
        of the relevant agency shall, as appropriate and consistent
        with applicable law, suspend, revise, or rescind such action,
        or propose doing so. If immediate final action is not possible,
        the agency shall, to the extent permitted by law, provide
        available exemptions until such action can be finalized.

--- chunk_id: chunk-0005
source_document: BILLS-119hr5388ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 344
content_hash: 4fa9338c5041c4d1
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
section_heading: SEC. 5. National Artificial Intelligence Action Plan.
document_type: technical_reference

(d) Review of Executive Actions; Conformity.--As part of the Action
Plan, the officials identified in subsection (a), in coordination with
the heads of relevant agencies--
            (1) shall review all policies, directives, regulations,
        orders, guidance, and other actions taken pursuant to Executive
        Order 14110 of October 30, 2023 (Safe, Secure, and Trustworthy
        Development and Use of Artificial Intelligence), and provide a
        status update on actions taken pursuant to Executive Order
        14179 of January 23, 2025 (Removing Barriers to American
        Leadership in Artificial Intelligence); and identify any such
        actions under either Executive Order that are or may be
        inconsistent with the policy in section 4; and,
            (2) for any action identified under paragraph (1), the head
        of the relevant agency shall, as appropriate and consistent
        with applicable law, suspend, revise, or rescind such action,
        or propose doing so. If immediate final action is not possible,
        the agency shall, to the extent permitted by law, provide
        available exemptions until such action can be finalized. (e) Review of Conflicting State Law; Recommendation on Preemption
Scope and Duration.--The Action Plan shall--
            (1) identify State and local laws, regulations, or policies
        that conflict with, or unduly burden, the achievement of the
        policy in section 4 or implementation of the Action Plan; and,
            (2) provide recommendations to Congress on whether to
        adjust the scope or length of the State-law preemption in
        section 6, including options such as extension of the five-year moratorium, clarifications to covered systems or activities,
        safe harbors, or other refinements, with a statement of
        rationale. (f) Submission; Committees.--Each submission required under this

--- chunk_id: chunk-0006
source_document: BILLS-119hr5388ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 96
content_hash: f930000a43ec6447
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: section shall be transmitted to the Speaker of the House of
document_type: technical_reference

section shall be transmitted to the Speaker of the House of
Representatives and the President of the Senate and, at a minimum, to
the Committees on Energy and Commerce; Judiciary; Education and the
Workforce; Science, Space, and Technology; and Oversight and Government
Reform of the House of Representatives; and to the Committees on
Commerce, Science, and Transportation; Judiciary; Health, Education,
Labor, and Pensions; and Homeland Security and Governmental Affairs of
the Senate.

--- chunk_id: chunk-0007
source_document: BILLS-119hr5388ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 454
content_hash: d9f4d891cb52e751
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: SEC. 6. State Law Preemption; Temporary Moratorium.
document_type: technical_reference

## SEC. 6. State Law Preemption; Temporary Moratorium. (a) Moratorium.--
            (1) In general.--Except as provided in paragraph (2), no
        State or political subdivision thereof may enforce, during the
        5-year period beginning on the date of the enactment of this
        Act, any law or regulation of that State or a political
        subdivision thereof limiting, restricting, or otherwise
        regulating artificial intelligence models, artificial
        intelligence systems, or automated decision systems entered
        into interstate commerce. (2) Rule of construction.--Paragraph (1) may not be
        construed to prohibit the enforcement of--
                    (A) any law or regulation that--
                            (i) the primary purpose and effect of which
                        is to--
                                    (I) remove legal impediments to, or
                                facilitate the deployment or operation
                                of, an artificial intelligence model,
                                artificial intelligence system, or
                                automated decision system; or
                                    (II) streamline licensing,
                                permitting, routing, zoning,
                                procurement, or reporting procedures in
                                a manner that facilitates the adoption
                                of artificial intelligence models,
                                artificial intelligence systems, or
                                automated decision systems;
                            (ii) does not impose any substantive
                        design, performance, data-handling,
                        documentation, civil liability, taxation, fee,
                        or other requirement on artificial intelligence
                        models, artificial intelligence systems, or
                        automated decision systems unless such
                        requirement--
                                    (I) is imposed under Federal law;
                                or
                                    (II) in the case of a requirement
                                imposed under a generally applicable
                                law, is imposed in the same manner on
                                models and systems, other than
                                artificial intelligence models,
                                artificial intelligence systems, and
                                automated decision systems, that
                                provide comparable functions to
                                artificial intelligence models,
                                artificial intelligence systems, or
                                automated decision systems; and
                            (iii) does not impose a fee or bond
                        unless--
                                    (I) such fee or bond is reasonable
                                and cost-based; and
                                    (II) under such fee or bond,
                                artificial intelligence models,
                                artificial intelligence systems, and
                                automated decision systems are treated
                                in the same manner as other models and
                                systems that perform comparable
                                functions; or
                    (B) any provision of a law or regulation to the
                extent that the violation of such provision carries a
                criminal penalty. (b) No Preemption of Generally Applicable Criminal Law.--Nothing in
this section shall be construed to preempt generally applicable
criminal laws of a State or political subdivision thereof.

--- chunk_id: chunk-0008
source_document: BILLS-119hr5388ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 438
content_hash: 598b7440ecb776b2
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: SEC. 6. State Law Preemption; Temporary Moratorium.
document_type: technical_reference

(2) Rule of construction.--Paragraph (1) may not be
        construed to prohibit the enforcement of--
                    (A) any law or regulation that--
                            (i) the primary purpose and effect of which
                        is to--
                                    (I) remove legal impediments to, or
                                facilitate the deployment or operation
                                of, an artificial intelligence model,
                                artificial intelligence system, or
                                automated decision system; or
                                    (II) streamline licensing,
                                permitting, routing, zoning,
                                procurement, or reporting procedures in
                                a manner that facilitates the adoption
                                of artificial intelligence models,
                                artificial intelligence systems, or
                                automated decision systems;
                            (ii) does not impose any substantive
                        design, performance, data-handling,
                        documentation, civil liability, taxation, fee,
                        or other requirement on artificial intelligence
                        models, artificial intelligence systems, or
                        automated decision systems unless such
                        requirement--
                                    (I) is imposed under Federal law;
                                or
                                    (II) in the case of a requirement
                                imposed under a generally applicable
                                law, is imposed in the same manner on
                                models and systems, other than
                                artificial intelligence models,
                                artificial intelligence systems, and
                                automated decision systems, that
                                provide comparable functions to
                                artificial intelligence models,
                                artificial intelligence systems, or
                                automated decision systems; and
                            (iii) does not impose a fee or bond
                        unless--
                                    (I) such fee or bond is reasonable
                                and cost-based; and
                                    (II) under such fee or bond,
                                artificial intelligence models,
                                artificial intelligence systems, and
                                automated decision systems are treated
                                in the same manner as other models and
                                systems that perform comparable
                                functions; or
                    (B) any provision of a law or regulation to the
                extent that the violation of such provision carries a
                criminal penalty. (b) No Preemption of Generally Applicable Criminal Law.--Nothing in
this section shall be construed to preempt generally applicable
criminal laws of a State or political subdivision thereof. (c) No Effect on Contracting by the State.--Nothing in this section
shall be construed to limit a State or political subdivision from
setting performance, security, or other requirements for its own
procurement or use of artificial intelligence systems, provided such
requirements do not operate as de facto regulations of private parties
beyond the government's role as a market participant.

--- chunk_id: chunk-0009
source_document: BILLS-119hr5388ih.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 94
content_hash: 0aa652cbba06a8d9
prev_chunk_id: chunk-0008
next_chunk_id: null
section_heading: SEC. 7. General Rule Of Construction.
document_type: technical_reference

## SEC. 7. General Rule Of Construction. Except as expressly provided in section 6 (State-law preemption),
nothing in this Act shall be construed--
            (1) to authorize any Federal agency to impose substantive
        design, performance, data-handling, documentation, or civil-
        liability requirements on artificial intelligence models or
        systems beyond authority otherwise provided by law; or
            (2) to limit the enforcement of generally applicable,
        technology-neutral criminal laws or other authorities otherwise
        provided by law.
