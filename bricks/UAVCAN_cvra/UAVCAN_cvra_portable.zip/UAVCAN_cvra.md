---
kb_id: uavcan-cvralibuavcan-protocol-stack-dsdl
title: UAVCAN (cvra/libuavcan) — Protocol stack & DSDL
author: Unknown Author
created_date: 2026-07-18
classification: Internal
confidence_level: High
domain_tags: ["uavcan", "can", "dsdl", "libuavcan", "cvra", "dronecan"]
entity_mentions: ["system globally", "system-wide", "system supports"]
document_type: Technical Reference
primary_subject: UAVCAN v0 CAN bus protocol types and libuavcan C++ stack
intended_audience: UAV / robotics integrators, ArduPilot DroneCAN users
sources: [{"filename": "00_README_libuavcan.md", "path": "docs/corpus/uavcan_cvra/structured_md/00_README_libuavcan.md", "page_count": 1}, {"filename": "dsdl_equipment.md", "path": "docs/corpus/uavcan_cvra/structured_md/dsdl_equipment.md", "page_count": 1}, {"filename": "dsdl_navigation.md", "path": "docs/corpus/uavcan_cvra/structured_md/dsdl_navigation.md", "page_count": 1}, {"filename": "dsdl_other.md", "path": "docs/corpus/uavcan_cvra/structured_md/dsdl_other.md", "page_count": 1}, {"filename": "dsdl_protocol.md", "path": "docs/corpus/uavcan_cvra/structured_md/dsdl_protocol.md", "page_count": 1}, {"filename": "dsdl_tunnel.md", "path": "docs/corpus/uavcan_cvra/structured_md/dsdl_tunnel.md", "page_count": 1}, {"filename": "driver_stm32_driver_README.md", "path": "docs/corpus/uavcan_cvra/structured_md/driver_stm32_driver_README.md", "page_count": 1}]
ingest_provenance: {"captured_at": "2026-07-18T17:23:23.935601", "page_count": 7, "extraction_methods": {"txt": 7}, "avg_extraction_quality": 1.0, "docling_triage_pages": 0, "docling_triage_rate": 0.0, "extraction_stats": null}
dark_data_inferred_fields: ["author", "confidence_level", "created_date", "entity_mentions", "ingest_provenance", "kb_id", "sources"]
brick_role: uavcan_protocol
out_of_scope: ["live CAN bus control", "Cyphal v1 full modern stack (see OpenCyphal; this brick is cvra/UAVCAN v0 lineage)", "ArduPilot parameter tables"]
usage_notes: From https://github.com/cvra/uavcan (libuavcan + DSDL submodule). Historic UAVCAN v0; related to ArduPilot DroneCAN/UAVCAN peripherals.
routing_policy: For ArduPilot CAN/UAVCAN *setup on the vehicle*, also see ArduPilot common-uavcan pages in Mission Planner / ops corpus. For MAVLink serial protocol use ArduPilot_MAVLink.
adjacent_bricks: [{"brick_id": "ArduPilot_MissionPlanner", "role": "gcs_mission_planner", "when_to_use": ["GCS setup"], "status": "built"}, {"brick_id": "ArduPilot_Plane", "role": "ops_doctrine", "when_to_use": ["vehicle ops"], "status": "built"}, {"brick_id": "ArduPilot_MAVLink", "role": "mavlink_protocol", "when_to_use": ["MAVLink serial GCS protocol (not CAN)"], "status": "built"}]
kb_name: UAVCAN_cvra
created: 2026-07-18T17:23:23.936027
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 41
template: technical_reference
domain: general
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-07-18T17:23:31.316194
  chunk_count: 41
  strict_air_gapped: true
---

--- chunk_id: chunk-0000
source_document: 00_README_libuavcan.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 82
content_hash: 850091825791661c
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: UAVCAN / libuavcan (cvra/uavcan)
document_type: technical_reference

# UAVCAN / libuavcan (cvra/uavcan)

Source: https://github.com/cvra/uavcan (UAVCAN v0 C++ stack). Protocol site historically http://uavcan.org — modern evolution is OpenCyphal/Cyphal. UAVCAN stack in C++
===================

[![Coverity Scan](https://scan.coverity.com/projects/1513/badge.svg)](https://scan.coverity.com/projects/1513)
[![Travis CI](https://travis-ci.org/UAVCAN/libuavcan.svg?branch=master)](https://travis-ci.org/UAVCAN/libuavcan)
[![Gitter](https://img.shields.io/badge/gitter-join%20chat-green.svg)](https://gitter.im/UAVCAN/general)

Portable reference implementation of the [UAVCAN protocol stack](http://uavcan.org) in C++ for embedded systems
and Linux. UAVCAN is a lightweight protocol designed for reliable communication in aerospace and robotic applications via CAN bus.

--- chunk_id: chunk-0001
source_document: 00_README_libuavcan.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 469
content_hash: e7066afdd9f1dfe3
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
section_heading: Documentation
document_type: technical_reference

## Documentation

* [UAVCAN website](http://uavcan.org)
* [UAVCAN forum](https://forum.uavcan.org)
* [Libuavcan overview](http://uavcan.org/Implementations/Libuavcan/)
* [List of platforms officially supported by libuavcan](http://uavcan.org/Implementations/Libuavcan/Platforms/)
* [Libuavcan tutorials](http://uavcan.org/Implementations/Libuavcan/Tutorials/)

### Library usage
### Dependencies

* Python 2.7 or 3.3 or newer

Note that this reporitory includes [Pyuavcan](http://uavcan.org/Implementations/Pyuavcan) as a submodule. Such inclusion enables the library to be built even if pyuavcan is not installed in the system. ### Cloning the repository ```bash
git clone https://github.com/UAVCAN/libuavcan
cd libuavcan
git submodule update --init
``` If this repository is used as a git submodule in your project, make sure to use `--recursive` when updating it. ### Using in a Linux application

Libuavcan can be built as a static library and installed on the system globally as shown below. ```bash
mkdir build
cd build
cmake .. # Default build type is RelWithDebInfo, which can be overriden if needed.
make -j8
sudo make install
``` The following components will be installed:

* Libuavcan headers and the static library
* Generated DSDL headers
* Libuavcan DSDL compiler (a Python script named `libuavcan_dsdlc`)
* Libuavcan DSDL compiler's support library (a Python package named `libuavcan_dsdl_compiler`)

Note that Pyuavcan (an implementation of UAVCAN in Python) will not be installed. You will need to install it separately if you intend to use the Libuavcan's DSDL compiler in your applications. It is also possible to use the library as a submodule rather than installing it system-wide. Please refer to the example applications supplied with the Linux platform driver for more information. ### Using with an embedded system

For ARM targets, it is recommended to use [GCC ARM Embedded](https://launchpad.net/gcc-arm-embedded);
however, any other standard-compliant C++ compiler should also work. #### With Make

Please refer to the [documentation at the UAVCAN website](http://uavcan.org/Implementations/Libuavcan). #### With CMake

In order to cross-compile the library with CMake, please follow the below instructions. You will need to provide a CMake toolchain file, `Toolchain-stm32-cortex-m4.cmake` in this example. If you're not sure what a toolchain file is or how to prepare one, these instructions are probably not for your
use case; please refer to the section about Make instead. ```bash
mkdir build
cd build
cmake .. -DCMAKE_TOOLCHAIN_FILE=../cmake/Toolchain-stm32-cortex-m4.cmake
make -j8
```

--- chunk_id: chunk-0002
source_document: 00_README_libuavcan.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 518
content_hash: 879107ebef675a34
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: Library development
document_type: technical_reference

## Library development

Despite the fact that the library itself can be used on virtually any platform that has a standard-compliant
C++11 compiler, the library development process assumes that the host OS is Linux. Prerequisites:

* Google test library for C++ - gtest (dowloaded as part of the build from [github](https://github.com/google/googletest))
* C++11 capable compiler with GCC-like interface (e.g. GCC, Clang)
* CMake 2.8+
* Optional: static analysis tool for C++ - cppcheck (on Debian/Ubuntu use package `cppcheck`)

Building the debug version and running the unit tests: ```bash
mkdir build
cd build
cmake .. -DCMAKE_BUILD_TYPE=Debug
make -j8
make ARGS=-VV test
``` Test outputs can be found in the build directory under `libuavcan`. > Note that unit tests suffixed with "_RealTime" must be executed in real time, otherwise they may produce false warnings;
this implies that they will likely fail if ran on a virtual machine or on a highly loaded system. Contributors, please follow the [Zubax C++ Coding Conventions](https://kb.zubax.com/x/84Ah). ### Vagrant
Vagrant can be used to setup a compatible Ubuntu virtual image. Follow the instructions on [Vagrantup](https://www.vagrantup.com/) to install virtualbox and vagrant then do: ```bash
vagrant up
vagrant ssh
mkdir build
cd build
mkdir build && cd build && cmake .. -DCMAKE_BUILD_TYPE=Debug -DCONTINUOUS_INTEGRATION_BUILD=1
``` > Note that -DCONTINUOUS_INTEGRATION_BUILD=1 is required for this build as the realtime unit tests will not work on a virt. You can build using commands like: ```bash
vagrant ssh -c "cd /vagrant/build && make -j4 && make test"
``` or to run a single test: ```bash
vagrant ssh -c "cd /vagrant/build && make libuavcan_test && ./libuavcan/libuavcan_test --gtest_filter=Node.Basic"
``` ### Developing with Eclipse

An Eclipse project can be generated like that: ```bash
cmake ../../libuavcan -G"Eclipse CDT4 - Unix Makefiles" \
                      -DCMAKE_ECLIPSE_VERSION=4.3 \
                      -DCMAKE_BUILD_TYPE=Debug \
                      -DCMAKE_CXX_COMPILER_ARG1=-std=c++11
``` Path `../../libuavcan` in the command above points at the directory where the top-level `CMakeLists.txt` is located;
you may need to adjust this per your environment. Note that the directory where Eclipse project is generated must not be a descendant of the source directory. ### Submitting a Coverity Scan build

First, [get the Coverity build tool](https://scan.coverity.com/download?tab=cxx). Then build the library with it: ```bash
export PATH=$PATH:<coverity-build-tool-directory>/bin/
mkdir build && cd build
cmake <uavcan-source-directory> -DCMAKE_BUILD_TYPE=Debug
cov-build --dir cov-int make -j8
tar czvf uavcan.tgz cov-int
``` Then upload the resulting archive to Coverity. Automatic check can be triggered by pushing to the branch `coverity_scan`.

--- chunk_id: chunk-0003
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 193
content_hash: 912c148568a7ec3e
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: UAVCAN DSDL — equipment
document_type: technical_reference

# UAVCAN DSDL — equipment

Types under `dsdl/uavcan/equipment/` (from UAVCAN/dsdl via cvra/uavcan). ### 1010.ArrayCommand

- **Namespace path:** `uavcan/equipment/actuator`
- **Source file:** `uavcan/equipment/actuator/1010.ArrayCommand.uavcan`

### DSDL definition ```
#
# Actuator commands.
# The system supports up to 256 actuators; up to 15 of them can be commanded with one message.
#

Command[<=15] commands
``` ### 1011.Status

- **Namespace path:** `uavcan/equipment/actuator`
- **Source file:** `uavcan/equipment/actuator/1011.Status.uavcan`

### DSDL definition ```
#
# Generic actuator feedback, if available.
# Unknown fields should be set to NAN.
#

uint8 actuator_id

#
# Whether the units are linear or angular depends on the actuator type (refer to the Command data type).
#
float16 position        # meter or radian
float16 force           # Newton or Newton metre
float16 speed           # meter per second or radian per second

void1
uint7 POWER_RATING_PCT_UNKNOWN = 127
uint7 power_rating_pct                # 0 - unloaded, 100 - full load
```

--- chunk_id: chunk-0004
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 641
content_hash: 1ce537f2dc2ae20e
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: Command
document_type: technical_reference

## Command

- **Namespace path:** `uavcan/equipment/actuator`
- **Source file:** `uavcan/equipment/actuator/Command.uavcan`

### DSDL definition ```
#
# Nested type.
# Single actuator command.
#

uint8 actuator_id

#
# Whether the units are linear or angular depends on the actuator type.
#
uint8 COMMAND_TYPE_UNITLESS     = 0     # [-1, 1]
uint8 COMMAND_TYPE_POSITION     = 1     # meter or radian
uint8 COMMAND_TYPE_FORCE        = 2     # Newton or Newton metre
uint8 COMMAND_TYPE_SPEED        = 3     # meter per second or radian per second
uint8 command_type

#
# Value of the above type
#
float16 command_value
``` ### 1000.Solution

- **Namespace path:** `uavcan/equipment/ahrs`
- **Source file:** `uavcan/equipment/ahrs/1000.Solution.uavcan`

### DSDL definition ```
#
# Inertial data and orientation in body frame.
#

uavcan.Timestamp timestamp

#
# Normalized quaternion
#
float16[4] orientation_xyzw
void4
float16[<=9] orientation_covariance

#
# rad/sec
#
float16[3] angular_velocity
void4
float16[<=9] angular_velocity_covariance

#
# m/s^2
#
float16[3] linear_acceleration
float16[<=9] linear_acceleration_covariance
``` ### 1001.MagneticFieldStrength

- **Namespace path:** `uavcan/equipment/ahrs`
- **Source file:** `uavcan/equipment/ahrs/1001.MagneticFieldStrength.uavcan`

### DSDL definition ```
#
# Magnetic field readings, in Gauss, in body frame.
# SI units are avoided because of float16 range limitations.
# This message is deprecated. Use the newer 1002.MagneticFieldStrength2.uavcan message.
#

float16[3] magnetic_field_ga
float16[<=9] magnetic_field_covariance
``` ### 1002.MagneticFieldStrength2

- **Namespace path:** `uavcan/equipment/ahrs`
- **Source file:** `uavcan/equipment/ahrs/1002.MagneticFieldStrength2.uavcan`

### DSDL definition ```
#
# Magnetic field readings, in Gauss, in body frame.
# SI units are avoided because of float16 range limitations.
#

uint8 sensor_id

float16[3] magnetic_field_ga
float16[<=9] magnetic_field_covariance
``` ### 1003.RawIMU

- **Namespace path:** `uavcan/equipment/ahrs`
- **Source file:** `uavcan/equipment/ahrs/1003.RawIMU.uavcan`

### DSDL definition ```
#
# Raw IMU data with timestamps.
#
# THIS DEFINITION MAY BE CHANGED IN A NON-BACKWARD-COMPATIBLE WAY IN THE FUTURE.
#

#
# Data acquisition timestamp in the bus shared time base.
#
uavcan.Timestamp timestamp

#
# Integration interval, seconds.
# Set to a non-positive value if the integrated samples are not available
# (in this case, only the latest point samples will be valid).
#
float32 integration_interval

#
# Angular velocity samples in radian/second.
# The samples are represented in the body frame, the axes are ordered as follows:
#   1. angular velocity around X (roll rate)
#   2. angular velocity around Y (pitch rate)
#   3. angular velocity around Z (yaw rate)
#
float16[3] rate_gyro_latest                 # Latest sample, radian/second
float32[3] rate_gyro_integral               # Integrated samples, radian/second

#
# Linear acceleration samples in meter/(second^2).
# The samples are represented in the body frame, the axes are ordered as follows:
#   1. linear acceleration along X (forward positive)
#   2. linear acceleration along Y (right positive)
#   3. linear acceleration along Z (down positive)
#
float16[3] accelerometer_latest             # Latest sample, meter/(second^2)
float32[3] accelerometer_integral           # Integrated samples, meter/(second^2)

#
# Covariance matrix. The diagonal entries are ordered as follows:
#   1. roll rate                (radian^2)/(second^2)
#   2. pitch rate               (radian^2)/(second^2)
#   3. yaw rate                 (radian^2)/(second^2)
#   4. forward acceleration     (meter^2)/(second^4)
#   5. rightward acceleration   (meter^2)/(second^4)
#   6. downward acceleration    (meter^2)/(second^4)
#
float16[<=36] covariance
```

--- chunk_id: chunk-0005
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 688
content_hash: 590162da8e01b795
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
section_heading: Command
document_type: technical_reference

### 1003.RawIMU

- **Namespace path:** `uavcan/equipment/ahrs`
- **Source file:** `uavcan/equipment/ahrs/1003.RawIMU.uavcan`

### DSDL definition ```
#
# Raw IMU data with timestamps.
#
# THIS DEFINITION MAY BE CHANGED IN A NON-BACKWARD-COMPATIBLE WAY IN THE FUTURE.
#

#
# Data acquisition timestamp in the bus shared time base.
#
uavcan.Timestamp timestamp

#
# Integration interval, seconds.
# Set to a non-positive value if the integrated samples are not available
# (in this case, only the latest point samples will be valid).
#
float32 integration_interval

#
# Angular velocity samples in radian/second.
# The samples are represented in the body frame, the axes are ordered as follows:
#   1. angular velocity around X (roll rate)
#   2. angular velocity around Y (pitch rate)
#   3. angular velocity around Z (yaw rate)
#
float16[3] rate_gyro_latest                 # Latest sample, radian/second
float32[3] rate_gyro_integral               # Integrated samples, radian/second

#
# Linear acceleration samples in meter/(second^2).
# The samples are represented in the body frame, the axes are ordered as follows:
#   1. linear acceleration along X (forward positive)
#   2. linear acceleration along Y (right positive)
#   3. linear acceleration along Z (down positive)
#
float16[3] accelerometer_latest             # Latest sample, meter/(second^2)
float32[3] accelerometer_integral           # Integrated samples, meter/(second^2)

#
# Covariance matrix. The diagonal entries are ordered as follows:
#   1. roll rate                (radian^2)/(second^2)
#   2. pitch rate               (radian^2)/(second^2)
#   3. yaw rate                 (radian^2)/(second^2)
#   4. forward acceleration     (meter^2)/(second^4)
#   5. rightward acceleration   (meter^2)/(second^4)
#   6. downward acceleration    (meter^2)/(second^4)
#
float16[<=36] covariance
``` ### 1020.TrueAirspeed

- **Namespace path:** `uavcan/equipment/air_data`
- **Source file:** `uavcan/equipment/air_data/1020.TrueAirspeed.uavcan`

### DSDL definition ```
#
# TAS.
#

float16 true_airspeed           # m/s
float16 true_airspeed_variance  # (m/s)^2
``` ### 1021.IndicatedAirspeed

- **Namespace path:** `uavcan/equipment/air_data`
- **Source file:** `uavcan/equipment/air_data/1021.IndicatedAirspeed.uavcan`

### DSDL definition ```
#
# IAS.
#

float16 indicated_airspeed              # m/s
float16 indicated_airspeed_variance     # (m/s)^2
``` ### 1025.AngleOfAttack

- **Namespace path:** `uavcan/equipment/air_data`
- **Source file:** `uavcan/equipment/air_data/1025.AngleOfAttack.uavcan`

### DSDL definition ```
#
# Angle of attack.
#

uint8 SENSOR_ID_LEFT = 254
uint8 SENSOR_ID_RIGHT = 255
uint8 sensor_id

float16 aoa             # Radians
float16 aoa_variance    # Radians^2
``` ### 1026.Sideslip

- **Namespace path:** `uavcan/equipment/air_data`
- **Source file:** `uavcan/equipment/air_data/1026.Sideslip.uavcan`

### DSDL definition ```
#
# Body sideslip in radians.
#

float16 sideslip_angle          # Radians
float16 sideslip_angle_variance # Radians^2
``` ### 1027.RawAirData

- **Namespace path:** `uavcan/equipment/air_data`
- **Source file:** `uavcan/equipment/air_data/1027.RawAirData.uavcan`

### DSDL definition ```
#
# Raw Air Data.
#

# Note: unused vars should be assigned NaN

#
# Heater State
# 
uint8 FLAG_HEATER_AVAILABLE      = 1
uint8 FLAG_HEATER_WORKING        = 2
uint8 FLAG_HEATER_OVERCURRENT    = 4
uint8 FLAG_HEATER_OPENCIRCUIT    = 8
uint8 flags

#
# Pressure Data
#
float32 static_pressure                 # Pascal
float32 differential_pressure           # Pascal

#
# Temperature Data
#
float16 static_pressure_sensor_temperature          # Kelvin
float16 differential_pressure_sensor_temperature    # Kelvin

float16 static_air_temperature          # Kelvin
                                        # This field contains the raw temperature reading 
                                        # from the externally mounted temperature sensor or, 
                                        # in absence of one, the raw temperature of the pressure sensor.

float16 pitot_temperature               # Kelvin


float16[<=16] covariance                # order of diagonal elements : 
                                        # static_pressure, differential_pressure,
                                        # static_air_temperature, pitot_temperature
                                        # Pascal^2 for pressure variance and covariance
                                        # Kevin^2 for Temperature variance and covariance
                                        # Pascal*Kelvin for pressure/temperature covariance
```

--- chunk_id: chunk-0006
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 536
content_hash: 9a19f209424814e2
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: Command
document_type: technical_reference

### 1027.RawAirData

- **Namespace path:** `uavcan/equipment/air_data`
- **Source file:** `uavcan/equipment/air_data/1027.RawAirData.uavcan`

### DSDL definition ```
#
# Raw Air Data.
#

# Note: unused vars should be assigned NaN

#
# Heater State
# 
uint8 FLAG_HEATER_AVAILABLE      = 1
uint8 FLAG_HEATER_WORKING        = 2
uint8 FLAG_HEATER_OVERCURRENT    = 4
uint8 FLAG_HEATER_OPENCIRCUIT    = 8
uint8 flags

#
# Pressure Data
#
float32 static_pressure                 # Pascal
float32 differential_pressure           # Pascal

#
# Temperature Data
#
float16 static_pressure_sensor_temperature          # Kelvin
float16 differential_pressure_sensor_temperature    # Kelvin

float16 static_air_temperature          # Kelvin
                                        # This field contains the raw temperature reading 
                                        # from the externally mounted temperature sensor or, 
                                        # in absence of one, the raw temperature of the pressure sensor.

float16 pitot_temperature               # Kelvin


float16[<=16] covariance                # order of diagonal elements : 
                                        # static_pressure, differential_pressure,
                                        # static_air_temperature, pitot_temperature
                                        # Pascal^2 for pressure variance and covariance
                                        # Kevin^2 for Temperature variance and covariance
                                        # Pascal*Kelvin for pressure/temperature covariance
``` ### 1028.StaticPressure

- **Namespace path:** `uavcan/equipment/air_data`
- **Source file:** `uavcan/equipment/air_data/1028.StaticPressure.uavcan`

### DSDL definition ```
#
# Static pressure.
#

float32 static_pressure                 # Pascal
float16 static_pressure_variance        # Pascal^2
``` ### 1029.StaticTemperature

- **Namespace path:** `uavcan/equipment/air_data`
- **Source file:** `uavcan/equipment/air_data/1029.StaticTemperature.uavcan`

### DSDL definition ```
#
# Static temperature.
#

float16 static_temperature              # Kelvin
float16 static_temperature_variance     # Kelvin^2
``` ### 1040.AngularCommand

- **Namespace path:** `uavcan/equipment/camera_gimbal`
- **Source file:** `uavcan/equipment/camera_gimbal/1040.AngularCommand.uavcan`

### DSDL definition ```
#
# Generic camera gimbal control.
#
# This message can only be used in the following modes:
#  - COMMAND_MODE_ANGULAR_VELOCITY
#  - COMMAND_MODE_ORIENTATION_FIXED_FRAME
#  - COMMAND_MODE_ORIENTATION_BODY_FRAME
#

uint8 gimbal_id

#
# Target operation mode - how to handle this message.
# See the list of acceptable modes above.
#
Mode mode

#
# In the angular velocity mode, this field contains a rate quaternion.
# In the orientation mode, this field contains orientation either in fixed frame or in body frame.
#
float16[4] quaternion_xyzw
``` ### 1041.GEOPOICommand

- **Namespace path:** `uavcan/equipment/camera_gimbal`
- **Source file:** `uavcan/equipment/camera_gimbal/1041.GEOPOICommand.uavcan`

### DSDL definition ```
#
# Generic camera gimbal control.
#
# This message can only be used in the following modes:
#  - COMMAND_MODE_GEO_POI
#

uint8 gimbal_id

#
# Target operation mode - how to handle this message.
# See the list of acceptable modes above.
#
Mode mode

#
# Coordinates of the POI (point of interest).
#
int32 longitude_deg_1e7    # 1 LSB = 1e-7 deg
int32 latitude_deg_1e7
int22 height_cm            # 1 LSB = 10 mm

uint2 HEIGHT_REFERENCE_ELLIPSOID = 0
uint2 HEIGHT_REFERENCE_MEAN_SEA_LEVEL = 1
uint2 height_reference
```

--- chunk_id: chunk-0007
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 206
content_hash: 25aeca722a1bf879
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: Command
document_type: technical_reference

### 1041.GEOPOICommand

- **Namespace path:** `uavcan/equipment/camera_gimbal`
- **Source file:** `uavcan/equipment/camera_gimbal/1041.GEOPOICommand.uavcan`

### DSDL definition ```
#
# Generic camera gimbal control.
#
# This message can only be used in the following modes:
#  - COMMAND_MODE_GEO_POI
#

uint8 gimbal_id

#
# Target operation mode - how to handle this message.
# See the list of acceptable modes above.
#
Mode mode

#
# Coordinates of the POI (point of interest).
#
int32 longitude_deg_1e7    # 1 LSB = 1e-7 deg
int32 latitude_deg_1e7
int22 height_cm            # 1 LSB = 10 mm

uint2 HEIGHT_REFERENCE_ELLIPSOID = 0
uint2 HEIGHT_REFERENCE_MEAN_SEA_LEVEL = 1
uint2 height_reference
``` ### 1044.Status

- **Namespace path:** `uavcan/equipment/camera_gimbal`
- **Source file:** `uavcan/equipment/camera_gimbal/1044.Status.uavcan`

### DSDL definition ```
#
# Generic gimbal status.
#

uint8 gimbal_id

Mode mode

#
# Camera axis orientation in body frame (not in fixed frame).
# Please refer to the UAVCAN coordinate frame conventions.
#
float16[4] camera_orientation_in_body_frame_xyzw
float16[<=9] camera_orientation_in_body_frame_covariance   # +inf for non-existent axes
```

--- chunk_id: chunk-0008
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 693
content_hash: fe1e7c1e0a636e88
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: Mode
document_type: technical_reference

## Mode

- **Namespace path:** `uavcan/equipment/camera_gimbal`
- **Source file:** `uavcan/equipment/camera_gimbal/Mode.uavcan`

### DSDL definition ```
#
# Gimbal operating mode
#

uint8 COMMAND_MODE_ANGULAR_VELOCITY        = 0
uint8 COMMAND_MODE_ORIENTATION_FIXED_FRAME = 1
uint8 COMMAND_MODE_ORIENTATION_BODY_FRAME  = 2
uint8 COMMAND_MODE_GEO_POI                 = 3
uint8 command_mode
``` ### 1110.Temperature

- **Namespace path:** `uavcan/equipment/device`
- **Source file:** `uavcan/equipment/device/1110.Temperature.uavcan`

### DSDL definition ```
#
# Generic device temperature
#

uint16 device_id

float16 temperature                  # in kelvin

uint8 ERROR_FLAG_OVERHEATING = 1
uint8 ERROR_FLAG_OVERCOOLING = 2
uint8 error_flags
``` ### 1030.RawCommand

- **Namespace path:** `uavcan/equipment/esc`
- **Source file:** `uavcan/equipment/esc/1030.RawCommand.uavcan`

### DSDL definition ```
#
# Raw ESC command normalized into [-8192, 8191]; negative values indicate reverse rotation.
# The ESC should normalize the setpoint into its effective input range.
# Non-zero setpoint value below minimum should be interpreted as min valid setpoint for the given motor.
#

int14[<=20] cmd
``` ### 1031.RPMCommand

- **Namespace path:** `uavcan/equipment/esc`
- **Source file:** `uavcan/equipment/esc/1031.RPMCommand.uavcan`

### DSDL definition ```
#
# Simple RPM setpoint.
# The ESC should automatically clamp the setpoint according to the minimum and maximum supported RPM;
# for example, given a ESC that operates in the range 100 to 10000 RPM, a setpoint of 1 RPM will be clamped to 100 RPM.
# Negative values indicate reverse rotation.
#

int18[<=20] rpm
``` ### 1034.Status

- **Namespace path:** `uavcan/equipment/esc`
- **Source file:** `uavcan/equipment/esc/1034.Status.uavcan`

### DSDL definition ```
#
# Generic ESC status.
# Unknown fields should be set to NAN.
#

uint32 error_count          # Resets when the motor restarts

float16 voltage             # Volt
float16 current             # Ampere. Can be negative in case of a regenerative braking.
float16 temperature         # Kelvin

int18 rpm                   # Negative value indicates reverse rotation

uint7 power_rating_pct      # Instant demand factor in percent (percent of maximum power); range 0% to 127%.

uint5 esc_index
``` ### 1060.Fix

- **Namespace path:** `uavcan/equipment/gnss`
- **Source file:** `uavcan/equipment/gnss/1060.Fix.uavcan`

### DSDL definition ```
#
# GNSS navigation solution with uncertainty.
# This message is deprecated. Use the newer 1063.Fix2.uavcan message.
#

uavcan.Timestamp timestamp         # Global network-synchronized time, if available, otherwise zero

#
# Time solution.
# Time standard (GPS, UTC, TAI, etc) is defined in the field below.
#
uavcan.Timestamp gnss_timestamp

#
# Time standard used in the GNSS timestamp field.
#
uint3 GNSS_TIME_STANDARD_NONE = 0  # Time is unknown
uint3 GNSS_TIME_STANDARD_TAI  = 1
uint3 GNSS_TIME_STANDARD_UTC  = 2
uint3 GNSS_TIME_STANDARD_GPS  = 3
uint3 gnss_time_standard

void5   # Reserved space

#
# If known, the number of leap seconds allows to perform conversions between some time standards.
#
uint8 NUM_LEAP_SECONDS_UNKNOWN = 0
uint8 num_leap_seconds

#
# Position and velocity solution
#
int37 longitude_deg_1e8            # Longitude degrees multiplied by 1e8 (approx. 1 mm per LSB)
int37 latitude_deg_1e8             # Latitude degrees multiplied by 1e8 (approx. 1 mm per LSB on equator)
int27 height_ellipsoid_mm          # Height above ellipsoid in millimeters
int27 height_msl_mm                # Height above mean sea level in millimeters

float16[3] ned_velocity            # NED frame (north-east-down) in meters per second

#
# Fix status
#
uint6 sats_used

uint2 STATUS_NO_FIX    = 0
uint2 STATUS_TIME_ONLY = 1
uint2 STATUS_2D_FIX    = 2
uint2 STATUS_3D_FIX    = 3
uint2 status

#
# Precision
#
float16 pdop

void4
float16[<=9] position_covariance   # m^2
float16[<=9] velocity_covariance   # (m/s)^2
```

--- chunk_id: chunk-0009
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 490
content_hash: fb170f8a796454a2
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
section_heading: Mode
document_type: technical_reference

### 1060.Fix

- **Namespace path:** `uavcan/equipment/gnss`
- **Source file:** `uavcan/equipment/gnss/1060.Fix.uavcan`

### DSDL definition ```
#
# GNSS navigation solution with uncertainty.
# This message is deprecated. Use the newer 1063.Fix2.uavcan message.
#

uavcan.Timestamp timestamp         # Global network-synchronized time, if available, otherwise zero

#
# Time solution.
# Time standard (GPS, UTC, TAI, etc) is defined in the field below.
#
uavcan.Timestamp gnss_timestamp

#
# Time standard used in the GNSS timestamp field.
#
uint3 GNSS_TIME_STANDARD_NONE = 0  # Time is unknown
uint3 GNSS_TIME_STANDARD_TAI  = 1
uint3 GNSS_TIME_STANDARD_UTC  = 2
uint3 GNSS_TIME_STANDARD_GPS  = 3
uint3 gnss_time_standard

void5   # Reserved space

#
# If known, the number of leap seconds allows to perform conversions between some time standards.
#
uint8 NUM_LEAP_SECONDS_UNKNOWN = 0
uint8 num_leap_seconds

#
# Position and velocity solution
#
int37 longitude_deg_1e8            # Longitude degrees multiplied by 1e8 (approx. 1 mm per LSB)
int37 latitude_deg_1e8             # Latitude degrees multiplied by 1e8 (approx. 1 mm per LSB on equator)
int27 height_ellipsoid_mm          # Height above ellipsoid in millimeters
int27 height_msl_mm                # Height above mean sea level in millimeters

float16[3] ned_velocity            # NED frame (north-east-down) in meters per second

#
# Fix status
#
uint6 sats_used

uint2 STATUS_NO_FIX    = 0
uint2 STATUS_TIME_ONLY = 1
uint2 STATUS_2D_FIX    = 2
uint2 STATUS_3D_FIX    = 3
uint2 status

#
# Precision
#
float16 pdop

void4
float16[<=9] position_covariance   # m^2
float16[<=9] velocity_covariance   # (m/s)^2
``` ### 1061.Auxiliary

- **Namespace path:** `uavcan/equipment/gnss`
- **Source file:** `uavcan/equipment/gnss/1061.Auxiliary.uavcan`

### DSDL definition ```
#
# GNSS low priority auxiliary info.
# Unknown DOP parameters should be set to NAN.
#

float16 gdop
float16 pdop
float16 hdop
float16 vdop
float16 tdop
float16 ndop
float16 edop

uint7 sats_visible                    # All visible sats of all available GNSS (e.g. GPS, GLONASS, etc)
uint6 sats_used                       # All used sats of all available GNSS
``` ### 1062.RTCMStream

- **Namespace path:** `uavcan/equipment/gnss`
- **Source file:** `uavcan/equipment/gnss/1062.RTCMStream.uavcan`

### DSDL definition ```
#
# GNSS RTCM SC-104 protocol raw stream container.
# RTCM messages that are longer than max data size can be split over multiple consecutive messages.
#

uint8 PROTOCOL_ID_UNKNOWN = 0
uint8 PROTOCOL_ID_RTCM2   = 2
uint8 PROTOCOL_ID_RTCM3   = 3
uint8 protocol_id

uint8[<=128] data
``` ### 1063.Fix2

- **Namespace path:** `uavcan/equipment/gnss`
- **Source file:** `uavcan/equipment/gnss/1063.Fix2.uavcan`

### DSDL definition

--- chunk_id: chunk-0010
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 637
content_hash: c0c0ca4a7424063c
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
section_heading: Mode
document_type: technical_reference

#
# GNSS ECEF and LLA navigation solution with uncertainty.
#

#
# Global network-synchronized time, if available, otherwise zero.
#
uavcan.Timestamp timestamp

#
# Time solution.
# The method and number of leap seconds which were in use for deriving the timestamp are
# defined in the fields below.
#
uavcan.Timestamp gnss_timestamp

#
# Method used for deriving the GNSS timestamp field.
# This data type relies on the following definitions:
#
#   Leap seconds  - Accumulated one-second adjustments applied to UTC since 1972.
#                   For reference, on May 2017, the number of leap seconds was equal 27.
#                   The number of leap seconds is taken from the field num_leap_seconds.
#                   Refer to https://en.wikipedia.org/wiki/Leap_second for a general overview.
#
#   TAI timestamp - The number of microseconds between the current TAI time and
#                   the TAI time at UTC 1970-01-01T00:00:00.
#
#   UTC timestamp - The number of microseconds between the current UTC time and
#                   UTC 1970-01-01T00:00:00.
#                   UTC can be expressed via TAI as follows (in seconds):
#                       UTC = TAI - num_leap_seconds - 10
#                   And via GPS (in seconds):
#                       UTC = GPS - num_leap_seconds + 9
#
#   GPS timestamp - The number of microseconds between the current GPS time and
#                   the GPS time at UTC 1970-01-01T00:00:00.
#                   GPS time can be expressed via TAI as follows (in seconds):
#                       GPS = TAI - 19
#
uint3 GNSS_TIME_STANDARD_NONE = 0  # Time is unknown
uint3 GNSS_TIME_STANDARD_TAI  = 1
uint3 GNSS_TIME_STANDARD_UTC  = 2
uint3 GNSS_TIME_STANDARD_GPS  = 3
uint3 gnss_time_standard

void13   # Reserved space

#
# Accumulated one-second adjustments applied to UTC since 1972.
# The number must agree with the currently correct number of UTC leap seconds. If this cannot
# be garanteed, the field must be set to NUM_LEAP_SECONDS_UNKNOWN.
#
uint8 NUM_LEAP_SECONDS_UNKNOWN = 0
uint8 num_leap_seconds

#
# Position and velocity solution
#
int37 longitude_deg_1e8            # Longitude degrees multiplied by 1e8 (approx. 1 mm per LSB)
int37 latitude_deg_1e8             # Latitude degrees multiplied by 1e8 (approx. 1 mm per LSB on equator)
int27 height_ellipsoid_mm          # Height above ellipsoid in millimeters
int27 height_msl_mm                # Height above mean sea level in millimeters

float32[3] ned_velocity            # NED frame (north-east-down) in meters per second

#
# Fix status
#
uint6 sats_used

uint2 STATUS_NO_FIX    = 0
uint2 STATUS_TIME_ONLY = 1
uint2 STATUS_2D_FIX    = 2
uint2 STATUS_3D_FIX    = 3
uint2 status

#
# GNSS Mode
#
uint4 MODE_SINGLE      = 0
uint4 MODE_DGPS        = 1
uint4 MODE_RTK         = 2
uint4 MODE_PPP         = 3
uint4 mode

#
# GNSS Sub mode
#
uint6 SUB_MODE_DGPS_OTHER    = 0
uint6 SUB_MODE_DGPS_SBAS     = 1

uint6 SUB_MODE_RTK_FLOAT     = 0
uint6 SUB_MODE_RTK_FIXED     = 1

uint6 sub_mode

#
# Precision
#
float16[<=36] covariance    # Position and velocity covariance. Units are
                            # m^2 for position, (m/s)^2 for velocity and
                            # m^2/s for position/velocity.

float16 pdop

#
# Position and velocity solution in ECEF, if available
#
ECEFPositionVelocity[<=1] ecef_position_velocity

--- chunk_id: chunk-0011
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 577
content_hash: 296c5881eaddefe8
prev_chunk_id: chunk-0010
next_chunk_id: chunk-0012
section_heading: ECEFPositionVelocity
document_type: technical_reference

## ECEFPositionVelocity

- **Namespace path:** `uavcan/equipment/gnss`
- **Source file:** `uavcan/equipment/gnss/ECEFPositionVelocity.uavcan`

### DSDL definition ```
#
# Nested type.
# GNSS ECEF high resolution position and velocity.
#
# ECEF is an acronym for Earth-Centered-Earth-Fixed, which is a cartesian
# coordinate system which rotates with the earth. The origin (0,0,0) is
# located at the center of the earth. The x-axis is a vector pointing from
# the origin with positive direction towards 0 degrees latitude and
# longitude (equator, at the prime meridian). The z-axis is a vector
# pointing from the origin towards the north-pole. The y-axis completes a
# right-handed coordinate system.
#

float32[3] velocity_xyz            # XYZ velocity in m/s

int36[3] position_xyz_mm           # XYZ-axis coordinates in mm

void6                              # Aligns the following array at byte boundary

float16[<=36] covariance           # Position and velocity covariance in the ECEF frame. Units are m^2 for position,
                                   # (m/s)^2 for velocity, and m^2/s for position/velocity.
``` ### 1070.Command

- **Namespace path:** `uavcan/equipment/hardpoint`
- **Source file:** `uavcan/equipment/hardpoint/1070.Command.uavcan`

### DSDL definition ```
#
# Generic cargo holder/hardpoint command.
#

uint8 hardpoint_id

#
# Either a binary command (0 - release, 1+ - hold) or bitmask
#
uint16 command
``` ### 1071.Status

- **Namespace path:** `uavcan/equipment/hardpoint`
- **Source file:** `uavcan/equipment/hardpoint/1071.Status.uavcan`

### DSDL definition ```
#
# Generic cargo holder/hardpoint status.
#

uint8 hardpoint_id

float16 payload_weight           # Newton
float16 payload_weight_variance

#
# Meaning is the same as for the command field in the Command message
#
uint16 status
``` ### 1129.FuelTankStatus

- **Namespace path:** `uavcan/equipment/ice`
- **Source file:** `uavcan/equipment/ice/1129.FuelTankStatus.uavcan`

### DSDL definition ```
#
# Generic fuel tank status message.
# All fields are required unless stated otherwise. Unpopulated optional fields should be set to NaN.
#

#
# Reserved for future use.
#
void9

#
# The estimated amount of fuel.
# The reported values can be either measured directly using appropriate sensors,
# or they can be estimated by fusing the data provided by various sensors.
# For example, a Kalman filter can be used to fuse the data from fuel level sensors and flow sensors.
# All fields are required.
#
uint7 available_fuel_volume_percent     # Unit: percent, from 0% to 100%
float32 available_fuel_volume_cm3       # Unit: centimeter^3

#
# Estimate of the current fuel consumption rate.
# The flow can be negative if the fuel is being transferred between the tanks or during refueling.
# This field is required.
# Unit: (centimeter^3)/minute
#
float32 fuel_consumption_rate_cm3pm

#
# Fuel temperature.
# This field is optional, set to NaN if not provided.
# Unit: kelvin
#
float16 fuel_temperature

#
# The ID of the current fuel tank.
#
uint8 fuel_tank_id
```

--- chunk_id: chunk-0012
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 272
content_hash: 0c23b9357989c32a
prev_chunk_id: chunk-0011
next_chunk_id: chunk-0013
section_heading: ECEFPositionVelocity
document_type: technical_reference

### 1129.FuelTankStatus

- **Namespace path:** `uavcan/equipment/ice`
- **Source file:** `uavcan/equipment/ice/1129.FuelTankStatus.uavcan`

### DSDL definition ```
#
# Generic fuel tank status message.
# All fields are required unless stated otherwise. Unpopulated optional fields should be set to NaN.
#

#
# Reserved for future use.
#
void9

#
# The estimated amount of fuel.
# The reported values can be either measured directly using appropriate sensors,
# or they can be estimated by fusing the data provided by various sensors.
# For example, a Kalman filter can be used to fuse the data from fuel level sensors and flow sensors.
# All fields are required.
#
uint7 available_fuel_volume_percent     # Unit: percent, from 0% to 100%
float32 available_fuel_volume_cm3       # Unit: centimeter^3

#
# Estimate of the current fuel consumption rate.
# The flow can be negative if the fuel is being transferred between the tanks or during refueling.
# This field is required.
# Unit: (centimeter^3)/minute
#
float32 fuel_consumption_rate_cm3pm

#
# Fuel temperature.
# This field is optional, set to NaN if not provided.
# Unit: kelvin
#
float16 fuel_temperature

#
# The ID of the current fuel tank.
#
uint8 fuel_tank_id
``` ### 1120.Status

- **Namespace path:** `uavcan/equipment/ice/reciprocating`
- **Source file:** `uavcan/equipment/ice/reciprocating/1120.Status.uavcan`

### DSDL definition

--- chunk_id: chunk-0013
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 1040
content_hash: 32018fbde06b8560
prev_chunk_id: chunk-0012
next_chunk_id: chunk-0014
section_heading: ECEFPositionVelocity
document_type: technical_reference

#
# Generic status message of a piston engine control system.
#
# All integer fields are required unless stated otherwise.
# All floating point fields are optional unless stated otherwise; unknown/unapplicable fields should be set to NaN.
#

#
# Abstract engine state. The flags defined below can provide further elaboration.
# This is a required field.
#
uint2 state
#
# The engine is not running. This is the default state.
# Next states: STARTING, FAULT
#
uint2 STATE_STOPPED = 0
#
# The engine is starting. This is a transient state.
# Next states: STOPPED, RUNNING, FAULT
#
uint2 STATE_STARTING = 1
#
# The engine is running normally.
# Some error flags may be set to indicate non-fatal issues, e.g. overheating.
# Next states: STOPPED, FAULT
#
uint2 STATE_RUNNING = 2
#
# The engine can no longer function.
# The error flags may contain additional information about the nature of the fault.
# Next states: STOPPED.
#
uint2 STATE_FAULT = 3

#
# General status flags.
# Note that not all flags are required. Those that aren't are prepended with a validity flag, which is, obviously,
# always required; when the validity flag is set, it is assumed that the relevant flags are set correctly.
# If the validity flag is cleared, then the state of the relevant flags should be ignored.
# All unused bits must be cleared.
#
uint30 flags
#
# General error. This flag is required, and it can be used to indicate an error condition
# that does not fit any of the other flags.
# Note that the vendor may also report additional status information via the vendor specific status code
# field of the NodeStatus message.
#
uint30 FLAG_GENERAL_ERROR                       = 1
#
# Error of the crankshaft sensor. This flag is optional.
#
uint30 FLAG_CRANKSHAFT_SENSOR_ERROR_SUPPORTED   = 2
uint30 FLAG_CRANKSHAFT_SENSOR_ERROR             = 4
#
# Temperature levels. These flags are optional; either none of them or all of them are supported.
#
uint30 FLAG_TEMPERATURE_SUPPORTED               = 8
uint30 FLAG_TEMPERATURE_BELOW_NOMINAL           = 16      # Under-temperature warning
uint30 FLAG_TEMPERATURE_ABOVE_NOMINAL           = 32      # Over-temperature warning
uint30 FLAG_TEMPERATURE_OVERHEATING             = 64      # Critical overheating
uint30 FLAG_TEMPERATURE_EGT_ABOVE_NOMINAL       = 128     # Exhaust gas over-temperature warning
#
# Fuel pressure. These flags are optional; either none of them or all of them are supported.
#
uint30 FLAG_FUEL_PRESSURE_SUPPORTED             = 256
uint30 FLAG_FUEL_PRESSURE_BELOW_NOMINAL         = 512     # Under-pressure warning
uint30 FLAG_FUEL_PRESSURE_ABOVE_NOMINAL         = 1024    # Over-pressure warning
#
# Detonation warning. This flag is optional.
# This warning is cleared immediately after broadcasting is done if detonation is no longer happening.
#
uint30 FLAG_DETONATION_SUPPORTED                = 2048
uint30 FLAG_DETONATION_OBSERVED                 = 4096    # Detonation condition observed warning
#
# Misfire warning. This flag is optional.
# This warning is cleared immediately after broadcasting is done if misfire is no longer happening.
#
uint30 FLAG_MISFIRE_SUPPORTED                   = 8192
uint30 FLAG_MISFIRE_OBSERVED                    = 16384   # Misfire condition observed warning
#
# Oil pressure. These flags are optional; either none of them or all of them are supported.
#
uint30 FLAG_OIL_PRESSURE_SUPPORTED              = 32768
uint30 FLAG_OIL_PRESSURE_BELOW_NOMINAL          = 65536   # Under-pressure warning
uint30 FLAG_OIL_PRESSURE_ABOVE_NOMINAL          = 131072  # Over-pressure warning
#
# Debris warning. This flag is optional.
#
uint30 FLAG_DEBRIS_SUPPORTED                    = 262144
uint30 FLAG_DEBRIS_DETECTED                     = 524288  # Detection of debris warning

#
# Reserved space
#
void16

#
# Engine load estimate.
# Unit: percent.
# Range: [0, 127].
#
uint7 engine_load_percent

#
# Engine speed.
# Unit: revolutions per minute.
#
uint17 engine_speed_rpm

#
# Spark dwell time.
# Unit: millisecond.
#
float16 spark_dwell_time_ms

#
# Atmospheric (barometric) pressure.
# Unit: kilopascal.
#
float16 atmospheric_pressure_kpa

#
# Engine intake manifold pressure.
# Unit: kilopascal.
#
float16 intake_manifold_pressure_kpa

#
# Engine intake manifold temperature.
# Unit: kelvin.
#
float16 intake_manifold_temperature

#
# Engine coolant temperature.
# Unit: kelvin.
#
float16 coolant_temperature

#
# Oil pressure.
# Unit: kilopascal.
#
float16 oil_pressure

#
# Oil temperature.
# Unit: kelvin.
#
float16 oil_temperature

#
# Fuel pressure.
# Unit: kilopascal.
#
float16 fuel_pressure

#
# Instant fuel consumption estimate.
# The estimated value should be low-pass filtered in order to prevent aliasing effects.
# Unit: (centimeter^3)/minute.
#
float32 fuel_consumption_rate_cm3pm

#
# Estimate of the consumed fuel since the start of the engine.
# This variable MUST be reset when the engine is stopped.
# Unit: centimeter^3.
#
float32 estimated_consumed_fuel_volume_cm3

#
# Throttle position.
# Unit: percent.
#
uint7 throttle_position_percent

#
# The index of the publishing ECU.
#
uint6 ecu_index

#
# Spark plug activity report.
# Can be used during pre-flight tests of the spark subsystem.
#
uint3 spark_plug_usage
#
uint3 SPARK_PLUG_SINGLE         = 0
uint3 SPARK_PLUG_FIRST_ACTIVE   = 1
uint3 SPARK_PLUG_SECOND_ACTIVE  = 2
uint3 SPARK_PLUG_BOTH_ACTIVE    = 3

#
# Per-cylinder status information.
#
CylinderStatus[<=16] cylinder_status

--- chunk_id: chunk-0014
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 269
content_hash: 85f7114169e68cc2
prev_chunk_id: chunk-0013
next_chunk_id: chunk-0015
section_heading: CylinderStatus
document_type: technical_reference

## CylinderStatus

- **Namespace path:** `uavcan/equipment/ice/reciprocating`
- **Source file:** `uavcan/equipment/ice/reciprocating/CylinderStatus.uavcan`

### DSDL definition ```
#
# Cylinder state information.
# This is a nested data type.
#
# All unknown parameters should be set to NaN.
#

#
# Cylinder ignition timing.
# Units: angular degrees of the crankshaft.
#
float16 ignition_timing_deg

#
# Fuel injection time.
# Units: millisecond.
#
float16 injection_time_ms

#
# Cylinder head temperature (CHT).
# Units: kelvin.
#
float16 cylinder_head_temperature

#
# Exhaust gas temperature (EGT).
# Set to NaN if this cylinder is not equipped with an EGT sensor.
# Set this field to the same value for all cylinders if there is a single shared EGT sensor.
# Units: kelvin.
#
float16 exhaust_gas_temperature

#
# Estimated lambda coefficient.
# This parameter is mostly useful for monitoring and tuning purposes.
# Unit: dimensionless ratio
#
float16 lambda_coefficient
``` ### 1080.BeepCommand

- **Namespace path:** `uavcan/equipment/indication`
- **Source file:** `uavcan/equipment/indication/1080.BeepCommand.uavcan`

### DSDL definition ```
#
# Nodes that are capable of producing sounds should obey.
#

float16 frequency  # Hz
float16 duration   # Sec
``` ### 1081.LightsCommand

- **Namespace path:** `uavcan/equipment/indication`
- **Source file:** `uavcan/equipment/indication/1081.LightsCommand.uavcan`

### DSDL definition ```
#
# Lights control command.
#

SingleLightCommand[<=20] commands
```

--- chunk_id: chunk-0015
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 624
content_hash: aaa87dbac24a3a28
prev_chunk_id: chunk-0014
next_chunk_id: chunk-0016
section_heading: RGB565
document_type: technical_reference

## RGB565

- **Namespace path:** `uavcan/equipment/indication`
- **Source file:** `uavcan/equipment/indication/RGB565.uavcan`

### DSDL definition ```
#
# Nested type.
# RGB color in the standard 5-6-5 16-bit palette.
# Monocolor lights should interpret this as brightness setpoint: from zero (0, 0, 0) to full brightness (31, 63, 31).
#

uint5 red
uint6 green
uint5 blue
``` ### SingleLightCommand
- **Namespace path:** `uavcan/equipment/indication`
- **Source file:** `uavcan/equipment/indication/SingleLightCommand.uavcan`

### DSDL definition ```
#
# Nested type.
# Controls single light source, color or monochrome.
#

#
# Common aircraft lights IDs
#

# inform the crew working on the apron around noisy airplanes, wearing hearing protection,
# that the engines are turned on. Also called beacon light
uint8 LIGHT_ID_ANTI_COLLISION = 246

# a red light is mounted on the left, or port, side of the craft and a green on the right,
# or starboard, side both 110 degree, and tail white light of 140 degree. Also called navigation lights
uint8 LIGHT_ID_RIGHT_OF_WAY   = 247

# high-intensity burst of white light, to help other pilots recognize the
# aircraft's position in low-visibility conditions
uint8 LIGHT_ID_STROBE         = 248

# positioned on the outer side just in front of the engine cowlings on the fuselage
uint8 LIGHT_ID_WING           = 249

# lights that highlite on the logo painted on the tail or other visible surface.
# Also called vertical tail flood lights
uint8 LIGHT_ID_LOGO           = 250

# help the pilots see the area in front of them and also shows other traffic that they're on the move
uint8 LIGHT_ID_TAXI           = 251

# light up the area in front of the airplane a bit more towards the side, easier for turns
uint8 LIGHT_ID_TURN_OFF       = 252

# very bright, lights up the area in front but a lot more than the taxi light
uint8 LIGHT_ID_TAKE_OFF       = 253

# very bright lights on the wings to help the pilots during landing by
# lighting up the area where they're going to touch down
uint8 LIGHT_ID_LANDING        = 254

# usually yellow electroluminescent lightstrips designed to use
# during formation flying at night or under low visibility conditions
uint8 LIGHT_ID_FORMATION      = 255

uint8 light_id

RGB565 color      # Monocolor lights should interpret this as brightness
``` ### 1090.PrimaryPowerSupplyStatus

- **Namespace path:** `uavcan/equipment/power`
- **Source file:** `uavcan/equipment/power/1090.PrimaryPowerSupplyStatus.uavcan`

### DSDL definition ```
#
# Primary power supply status.
# Typical publishing rate should be around 1~2 Hz.
#

#
# How many hours left to full discharge at average load over the last 10 seconds.
#
float16 hours_to_empty_at_10sec_avg_power               # [Hours]
float16 hours_to_empty_at_10sec_avg_power_variance      # [Hours^2]

#
# True if the publishing node senses that an external power source can be used, e.g. to charge batteries.
#
bool external_power_available

#
# Remaining energy estimate in percent.
#
uint7 remaining_energy_pct              # [Percent]     Required
uint7 remaining_energy_pct_stdev        # [Percent]     Error standard deviation. Use best guess if unknown.
```

--- chunk_id: chunk-0016
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 829
content_hash: d603cfeea49a15ab
prev_chunk_id: chunk-0015
next_chunk_id: chunk-0017
section_heading: RGB565
document_type: technical_reference

### 1090.PrimaryPowerSupplyStatus

- **Namespace path:** `uavcan/equipment/power`
- **Source file:** `uavcan/equipment/power/1090.PrimaryPowerSupplyStatus.uavcan`

### DSDL definition ```
#
# Primary power supply status.
# Typical publishing rate should be around 1~2 Hz.
#

#
# How many hours left to full discharge at average load over the last 10 seconds.
#
float16 hours_to_empty_at_10sec_avg_power               # [Hours]
float16 hours_to_empty_at_10sec_avg_power_variance      # [Hours^2]

#
# True if the publishing node senses that an external power source can be used, e.g. to charge batteries.
#
bool external_power_available

#
# Remaining energy estimate in percent.
#
uint7 remaining_energy_pct              # [Percent]     Required
uint7 remaining_energy_pct_stdev        # [Percent]     Error standard deviation. Use best guess if unknown.
``` ### 1091.CircuitStatus

- **Namespace path:** `uavcan/equipment/power`
- **Source file:** `uavcan/equipment/power/1091.CircuitStatus.uavcan`

### DSDL definition ```
#
# Generic electrical circuit info.
#

uint16 circuit_id

float16 voltage
float16 current

uint8 ERROR_FLAG_OVERVOLTAGE  = 1
uint8 ERROR_FLAG_UNDERVOLTAGE = 2
uint8 ERROR_FLAG_OVERCURRENT  = 4
uint8 ERROR_FLAG_UNDERCURRENT = 8
uint8 error_flags
``` ### 1092.BatteryInfo

- **Namespace path:** `uavcan/equipment/power`
- **Source file:** `uavcan/equipment/power/1092.BatteryInfo.uavcan`

### DSDL definition ```
#
# Single battery info.
#
# Typical publishing rate should be around 0.2~1 Hz.
#
# Please refer to the Smart Battery data specification for some elaboration.
#

#
# Primary parameters.
# Some fields can be set to NAN if their values are unknown.
# Full charge capacity is expected to slowly reduce as the battery is aging. Normally its estimate is updated after
# every charging cycle.
#
float16 temperature             # [Kelvin]
float16 voltage                 # [Volt]
float16 current                 # [Ampere]
float16 average_power_10sec     # [Watt]        Average power consumption over the last 10 seconds
float16 remaining_capacity_wh   # [Watt hours]  Will be increasing during charging
float16 full_charge_capacity_wh # [Watt hours]  Predicted battery capacity when it is fully charged. Falls with aging
float16 hours_to_full_charge    # [Hours]       Charging is expected to complete in this time; zero if not charging

#
# Status flags.
# Notes:
#  - CHARGING must be always set as long as the battery is connected to a charger, even if the charging is complete.
#  - CHARGED must be cleared immediately when the charger is disconnected.
#
uint11 STATUS_FLAG_IN_USE       = 1     # The battery is currently used as a power supply
uint11 STATUS_FLAG_CHARGING     = 2     # Charger is active
uint11 STATUS_FLAG_CHARGED      = 4     # Charging complete, but the charger is still active
uint11 STATUS_FLAG_TEMP_HOT     = 8     # Battery temperature is above normal
uint11 STATUS_FLAG_TEMP_COLD    = 16    # Battery temperature is below normal
uint11 STATUS_FLAG_OVERLOAD     = 32    # Safe operating area violation
uint11 STATUS_FLAG_BAD_BATTERY  = 64    # This battery should not be used anymore (e.g. low SOH)
uint11 STATUS_FLAG_NEED_SERVICE = 128   # This battery requires maintenance (e.g. balancing, full recharge)
uint11 STATUS_FLAG_BMS_ERROR    = 256   # Battery management system/controller error, smart battery interface error
uint11 STATUS_FLAG_RESERVED_A   = 512   # Keep zero
uint11 STATUS_FLAG_RESERVED_B   = 1024  # Keep zero
uint11 status_flags

#
# State of Health (SOH) estimate, in percent.
# http://en.wikipedia.org/wiki/State_of_health
#
uint7 STATE_OF_HEALTH_UNKNOWN = 127     # Use this constant if SOH cannot be estimated
uint7 state_of_health_pct               # Health of the battery, in percent, optional

#
# Relative State of Charge (SOC) estimate, in percent.
# http://en.wikipedia.org/wiki/State_of_charge
#
uint7 state_of_charge_pct               # Percent of the full charge [0, 100]. This field is required
uint7 state_of_charge_pct_stdev         # SOC error standard deviation; use best guess if unknown

#
# Battery identification.
# Model instance ID must be unique within the same battery model name.
# Model name is a human-readable string that normally should include the vendor name, model name, and chemistry
# type of this battery. This field should be assumed case-insensitive. Example: "Zubax Smart Battery v1.1 LiPo".
#
uint8 battery_id                        # Identifies the battery within this vehicle, e.g. 0 - primary battery
uint32 model_instance_id                # Set to zero if not applicable
uint8[<32] model_name                   # Battery model name
```

--- chunk_id: chunk-0017
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 762
content_hash: 1f75ab88c20c4ebc
prev_chunk_id: chunk-0016
next_chunk_id: chunk-0018
section_heading: RGB565
document_type: technical_reference

### 1092.BatteryInfo

- **Namespace path:** `uavcan/equipment/power`
- **Source file:** `uavcan/equipment/power/1092.BatteryInfo.uavcan`

### DSDL definition ```
#
# Single battery info.
#
# Typical publishing rate should be around 0.2~1 Hz.
#
# Please refer to the Smart Battery data specification for some elaboration.
#

#
# Primary parameters.
# Some fields can be set to NAN if their values are unknown.
# Full charge capacity is expected to slowly reduce as the battery is aging. Normally its estimate is updated after
# every charging cycle.
#
float16 temperature             # [Kelvin]
float16 voltage                 # [Volt]
float16 current                 # [Ampere]
float16 average_power_10sec     # [Watt]        Average power consumption over the last 10 seconds
float16 remaining_capacity_wh   # [Watt hours]  Will be increasing during charging
float16 full_charge_capacity_wh # [Watt hours]  Predicted battery capacity when it is fully charged. Falls with aging
float16 hours_to_full_charge    # [Hours]       Charging is expected to complete in this time; zero if not charging

#
# Status flags.
# Notes:
#  - CHARGING must be always set as long as the battery is connected to a charger, even if the charging is complete.
#  - CHARGED must be cleared immediately when the charger is disconnected.
#
uint11 STATUS_FLAG_IN_USE       = 1     # The battery is currently used as a power supply
uint11 STATUS_FLAG_CHARGING     = 2     # Charger is active
uint11 STATUS_FLAG_CHARGED      = 4     # Charging complete, but the charger is still active
uint11 STATUS_FLAG_TEMP_HOT     = 8     # Battery temperature is above normal
uint11 STATUS_FLAG_TEMP_COLD    = 16    # Battery temperature is below normal
uint11 STATUS_FLAG_OVERLOAD     = 32    # Safe operating area violation
uint11 STATUS_FLAG_BAD_BATTERY  = 64    # This battery should not be used anymore (e.g. low SOH)
uint11 STATUS_FLAG_NEED_SERVICE = 128   # This battery requires maintenance (e.g. balancing, full recharge)
uint11 STATUS_FLAG_BMS_ERROR    = 256   # Battery management system/controller error, smart battery interface error
uint11 STATUS_FLAG_RESERVED_A   = 512   # Keep zero
uint11 STATUS_FLAG_RESERVED_B   = 1024  # Keep zero
uint11 status_flags

#
# State of Health (SOH) estimate, in percent.
# http://en.wikipedia.org/wiki/State_of_health
#
uint7 STATE_OF_HEALTH_UNKNOWN = 127     # Use this constant if SOH cannot be estimated
uint7 state_of_health_pct               # Health of the battery, in percent, optional

#
# Relative State of Charge (SOC) estimate, in percent.
# http://en.wikipedia.org/wiki/State_of_charge
#
uint7 state_of_charge_pct               # Percent of the full charge [0, 100]. This field is required
uint7 state_of_charge_pct_stdev         # SOC error standard deviation; use best guess if unknown

#
# Battery identification.
# Model instance ID must be unique within the same battery model name.
# Model name is a human-readable string that normally should include the vendor name, model name, and chemistry
# type of this battery. This field should be assumed case-insensitive. Example: "Zubax Smart Battery v1.1 LiPo".
#
uint8 battery_id                        # Identifies the battery within this vehicle, e.g. 0 - primary battery
uint32 model_instance_id                # Set to zero if not applicable
uint8[<32] model_name                   # Battery model name
``` ### 1050.Measurement

- **Namespace path:** `uavcan/equipment/range_sensor`
- **Source file:** `uavcan/equipment/range_sensor/1050.Measurement.uavcan`

### DSDL definition ```
#
# Generic narrow-beam range sensor data.
#

uavcan.Timestamp timestamp

uint8 sensor_id

uavcan.CoarseOrientation beam_orientation_in_body_frame

float16 field_of_view                # Radians

uint5 SENSOR_TYPE_UNDEFINED = 0
uint5 SENSOR_TYPE_SONAR     = 1
uint5 SENSOR_TYPE_LIDAR     = 2
uint5 SENSOR_TYPE_RADAR     = 3
uint5 sensor_type

uint3 READING_TYPE_UNDEFINED   = 0   # Range is unknown
uint3 READING_TYPE_VALID_RANGE = 1   # Range field contains valid distance
uint3 READING_TYPE_TOO_CLOSE   = 2   # Range field contains min range for the sensor
uint3 READING_TYPE_TOO_FAR     = 3   # Range field contains max range for the sensor
uint3 reading_type

float16 range                        # Meters
```

--- chunk_id: chunk-0018
source_document: dsdl_equipment.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 198
content_hash: 9bcf559235341c4e
prev_chunk_id: chunk-0017
next_chunk_id: chunk-0019
section_heading: RGB565
document_type: technical_reference

### 1050.Measurement

- **Namespace path:** `uavcan/equipment/range_sensor`
- **Source file:** `uavcan/equipment/range_sensor/1050.Measurement.uavcan`

### DSDL definition ```
#
# Generic narrow-beam range sensor data.
#

uavcan.Timestamp timestamp

uint8 sensor_id

uavcan.CoarseOrientation beam_orientation_in_body_frame

float16 field_of_view                # Radians

uint5 SENSOR_TYPE_UNDEFINED = 0
uint5 SENSOR_TYPE_SONAR     = 1
uint5 SENSOR_TYPE_LIDAR     = 2
uint5 SENSOR_TYPE_RADAR     = 3
uint5 sensor_type

uint3 READING_TYPE_UNDEFINED   = 0   # Range is unknown
uint3 READING_TYPE_VALID_RANGE = 1   # Range field contains valid distance
uint3 READING_TYPE_TOO_CLOSE   = 2   # Range field contains min range for the sensor
uint3 READING_TYPE_TOO_FAR     = 3   # Range field contains max range for the sensor
uint3 reading_type

float16 range                        # Meters
``` ### 1100.ArmingStatus

- **Namespace path:** `uavcan/equipment/safety`
- **Source file:** `uavcan/equipment/safety/1100.ArmingStatus.uavcan`

### DSDL definition ```
#
# This message represents the system arming status.
# Some nodes may refuse to operate unless the system is fully armed.
#

uint8 STATUS_DISARMED           = 0
uint8 STATUS_FULLY_ARMED        = 255

uint8 status
```

--- chunk_id: chunk-0019
source_document: dsdl_navigation.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 402
content_hash: 97f509083b0c6bb0
prev_chunk_id: chunk-0018
next_chunk_id: chunk-0020
section_heading: UAVCAN DSDL — navigation
document_type: technical_reference

# UAVCAN DSDL — navigation

Types under `dsdl/uavcan/navigation/` (from UAVCAN/dsdl via cvra/uavcan). ### 2000.GlobalNavigationSolution

- **Namespace path:** `uavcan/navigation`
- **Source file:** `uavcan/navigation/2000.GlobalNavigationSolution.uavcan`

### DSDL definition ```
#
# Inertial data and orientation in body frame with fused location.
#
# Fields marked as optional should be set to NaN if the corresponding value is unknown.
#

#
# Global network synchronized timestamp, if known.
# Set to zero if the timestamp is not known.
#
uavcan.Timestamp timestamp

#
# Geo location [angular degree].
#
float64 longitude                   # required
float64 latitude                    # required

#
# Height estimates [meter].
#
float32 height_ellipsoid            # Above ellipsoid (required)
float32 height_msl                  # Above the mean sea level (required)
float32 height_agl                  # Above ground level (provided by radar altimeter or LIDAR) (optional)
float32 height_baro                 # Barometric height (optional)

#
# Atmospheric pressure adjusted to sea level [hectopascal].
#
float16 qnh_hpa                     # optional

#
# Rotation quaternion between the NED frame and the body frame.
# Zero rotation corresponds to the following orientation:
#   X facing north
#   Y facing east
#   Z facing down
#
float32[4] orientation_xyzw

#
# Column order:
#   longitude                                   [meter^2]
#   latitude                                    [meter^2]
#   height (MSL or ellipsoid, whichever worse)  [meter^2]
#   roll angle                                  [radian^2]
#   pitch angle                                 [radian^2]
#   yaw angle                                   [radian^2]
#
float16[<=36] pose_covariance

#
# Linear velocity in the body frame, X-Y-Z [meter/second].
#
float32[3] linear_velocity_body

#
# Angular velocity in the body frame, roll-pitch-yaw [radian/second].
#
float32[3] angular_velocity_body

#
# Low resolution estimate of the linear acceleration in the body frame [(meter/second)^2].
# This estimate should be properly downsampled in order to avoid aliasing effects.
#
float16[3] linear_acceleration_body

#
# Column order:
#   X velocity      [(meter/second)^2]
#   Y velocity      [(meter/second)^2]
#   Z velocity      [(meter/second)^2]
#   roll velocity   [(radian/second)^2]
#   pitch velocity  [(radian/second)^2]
#   yaw velocity    [(radian/second)^2]
#
float16[<=36] velocity_covariance
```

--- chunk_id: chunk-0020
source_document: dsdl_other.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 16
content_hash: 26283cedab3f2791
prev_chunk_id: chunk-0019
next_chunk_id: chunk-0021
section_heading: UAVCAN DSDL — other
document_type: technical_reference

# UAVCAN DSDL — other

Types under `dsdl/uavcan/other/` (from UAVCAN/dsdl via cvra/uavcan).

--- chunk_id: chunk-0021
source_document: dsdl_other.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 230
content_hash: 52fd294c497cb5d7
prev_chunk_id: chunk-0020
next_chunk_id: chunk-0022
section_heading: CoarseOrientation
document_type: technical_reference

## CoarseOrientation

- **Namespace path:** `uavcan`
- **Source file:** `uavcan/CoarseOrientation.uavcan`

### DSDL definition ```
#
# Nested type.
# Coarse, low-resolution 3D orientation represented as fixed axes in 16 bit.
#
# Roll, pitch, yaw angles in radians should be multiplied by
# ANGLE_MULTIPLIER in order to convert them to the coarse representation.
#
# ANGLE_MULTIPLIER = NORM / PI
#
# Where NORM is 12, because it:
#  - Fits the maximum range of a signed 5 bit integer
#  - Allows to exactly represent the following angles:
#    0, 15, 30, 45, 60, 75, 90, 105, 120, 135, 150, 165, 180, and negatives
#

float32 ANGLE_MULTIPLIER = 4.7746482927568605

int5[3] fixed_axis_roll_pitch_yaw

bool orientation_defined    # False if the orientation is actually not defined
``` ### Timestamp
- **Namespace path:** `uavcan`
- **Source file:** `uavcan/Timestamp.uavcan`

### DSDL definition ```
#
# Global timestamp in microseconds, 7 bytes.
#
# Use this data type for timestamp fields in messages, like follows:
#   uavcan.Timestamp timestamp
#

uint56 UNKNOWN = 0
truncated uint56 usec     # Microseconds
```

--- chunk_id: chunk-0022
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 874
content_hash: 296ce1605a9bcf2e
prev_chunk_id: chunk-0021
next_chunk_id: chunk-0023
section_heading: UAVCAN DSDL — protocol
document_type: technical_reference

# UAVCAN DSDL — protocol

Types under `dsdl/uavcan/protocol/` (from UAVCAN/dsdl via cvra/uavcan). ### 1.GetNodeInfo

- **Namespace path:** `uavcan/protocol`
- **Source file:** `uavcan/protocol/1.GetNodeInfo.uavcan`

### DSDL definition ```
#
# Full node info request.
# Note that all fields of the response section are byte-aligned.
#

---

#
# Current node status
#
NodeStatus status

#
# Version information shall not be changed while the node is running.
#
SoftwareVersion software_version
HardwareVersion hardware_version

#
# Human readable non-empty ASCII node name.
# Node name shall not be changed while the node is running.
# Empty string is not a valid node name.
# Allowed characters are: a-z (lowercase ASCII letters) 0-9 (decimal digits) . (dot) - (dash) _ (underscore).
# Node name is a reversed internet domain name (like Java packages), e.g. "com.manufacturer.project.product".
#
uint8[<=80] name
``` ### 2.GetDataTypeInfo

- **Namespace path:** `uavcan/protocol`
- **Source file:** `uavcan/protocol/2.GetDataTypeInfo.uavcan`

### DSDL definition ```
#
# Get the implementation details of a given data type.
#
# Request is interpreted as follows:
#  - If the field 'name' is empty, the fields 'kind' and 'id' will be used to identify the data type.
#  - If the field 'name' is non-empty, it will be used to identify the data type; the
#    fields 'kind' and 'id' will be ignored.
#

uint16 id                   # Ignored if 'name' is non-empty
DataTypeKind kind           # Ignored if 'name' is non-empty

uint8[<=80] name            # Full data type name, e.g. "uavcan.protocol.GetDataTypeInfo"

---

uint64 signature            # Data type signature; valid only if the data type is known (see FLAG_KNOWN)

uint16 id                   # Valid only if the data type is known (see FLAG_KNOWN)
DataTypeKind kind           # Ditto

uint8 FLAG_KNOWN      = 1   # This data type is defined
uint8 FLAG_SUBSCRIBED = 2   # Subscribed to messages of this type
uint8 FLAG_PUBLISHING = 4   # Publishing messages of this type
uint8 FLAG_SERVING    = 8   # Providing service of this type
uint8 flags

uint8[<=80] name            # Full data type name
``` ### 341.NodeStatus

- **Namespace path:** `uavcan/protocol`
- **Source file:** `uavcan/protocol/341.NodeStatus.uavcan`

### DSDL definition ```
#
# Abstract node status information.
#
# All UAVCAN nodes are required to publish this message periodically.
#

#
# Publication period may vary within these limits.
# It is NOT recommended to change it at run time.
#
uint16 MAX_BROADCASTING_PERIOD_MS = 1000
uint16 MIN_BROADCASTING_PERIOD_MS = 2

#
# If a node fails to publish this message in this amount of time, it should be considered offline.
#
uint16 OFFLINE_TIMEOUT_MS = 3000

#
# Uptime counter should never overflow.
# Other nodes may detect that a remote node has restarted when this value goes backwards.
#
uint32 uptime_sec

#
# Abstract node health.
#
uint2 HEALTH_OK         = 0     # The node is functioning properly.
uint2 HEALTH_WARNING    = 1     # A critical parameter went out of range or the node encountered a minor failure.
uint2 HEALTH_ERROR      = 2     # The node encountered a major failure.
uint2 HEALTH_CRITICAL   = 3     # The node suffered a fatal malfunction.
uint2 health

#
# Current mode.
#
# Mode OFFLINE can be actually reported by the node to explicitly inform other network
# participants that the sending node is about to shutdown. In this case other nodes will not
# have to wait OFFLINE_TIMEOUT_MS before they detect that the node is no longer available.
#
# Reserved values can be used in future revisions of the specification.
#
uint3 MODE_OPERATIONAL      = 0         # Normal operating mode.
uint3 MODE_INITIALIZATION   = 1         # Initialization is in progress; this mode is entered immediately after startup.
uint3 MODE_MAINTENANCE      = 2         # E.g. calibration, the bootloader is running, etc.
uint3 MODE_SOFTWARE_UPDATE  = 3         # New software/firmware is being loaded.
uint3 MODE_OFFLINE          = 7         # The node is no longer available.
uint3 mode

#
# Not used currently, keep zero when publishing, ignore when receiving.
#
uint3 sub_mode

#
# Optional, vendor-specific node status code, e.g. a fault code or a status bitmask.
#
uint16 vendor_specific_status_code
```

--- chunk_id: chunk-0023
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 530
content_hash: e08d52d217079edc
prev_chunk_id: chunk-0022
next_chunk_id: chunk-0024
section_heading: UAVCAN DSDL — protocol
document_type: technical_reference

### 341.NodeStatus

- **Namespace path:** `uavcan/protocol`
- **Source file:** `uavcan/protocol/341.NodeStatus.uavcan`

### DSDL definition ```
#
# Abstract node status information.
#
# All UAVCAN nodes are required to publish this message periodically.
#

#
# Publication period may vary within these limits.
# It is NOT recommended to change it at run time.
#
uint16 MAX_BROADCASTING_PERIOD_MS = 1000
uint16 MIN_BROADCASTING_PERIOD_MS = 2

#
# If a node fails to publish this message in this amount of time, it should be considered offline.
#
uint16 OFFLINE_TIMEOUT_MS = 3000

#
# Uptime counter should never overflow.
# Other nodes may detect that a remote node has restarted when this value goes backwards.
#
uint32 uptime_sec

#
# Abstract node health.
#
uint2 HEALTH_OK         = 0     # The node is functioning properly.
uint2 HEALTH_WARNING    = 1     # A critical parameter went out of range or the node encountered a minor failure.
uint2 HEALTH_ERROR      = 2     # The node encountered a major failure.
uint2 HEALTH_CRITICAL   = 3     # The node suffered a fatal malfunction.
uint2 health

#
# Current mode.
#
# Mode OFFLINE can be actually reported by the node to explicitly inform other network
# participants that the sending node is about to shutdown. In this case other nodes will not
# have to wait OFFLINE_TIMEOUT_MS before they detect that the node is no longer available.
#
# Reserved values can be used in future revisions of the specification.
#
uint3 MODE_OPERATIONAL      = 0         # Normal operating mode.
uint3 MODE_INITIALIZATION   = 1         # Initialization is in progress; this mode is entered immediately after startup.
uint3 MODE_MAINTENANCE      = 2         # E.g. calibration, the bootloader is running, etc.
uint3 MODE_SOFTWARE_UPDATE  = 3         # New software/firmware is being loaded.
uint3 MODE_OFFLINE          = 7         # The node is no longer available.
uint3 mode

#
# Not used currently, keep zero when publishing, ignore when receiving.
#
uint3 sub_mode

#
# Optional, vendor-specific node status code, e.g. a fault code or a status bitmask.
#
uint16 vendor_specific_status_code
``` ### 4.GetTransportStats

- **Namespace path:** `uavcan/protocol`
- **Source file:** `uavcan/protocol/4.GetTransportStats.uavcan`

### DSDL definition ```
#
# Get transport statistics.
#

---

#
# UAVCAN transport layer statistics.
#
uint48 transfers_tx             # Number of transmitted transfers.
uint48 transfers_rx             # Number of received transfers.
uint48 transfer_errors          # Number of errors detected in the UAVCAN transport layer.

#
# CAN bus statistics, for each interface independently.
#
CANIfaceStats[<=3] can_iface_stats
```

--- chunk_id: chunk-0024
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 494
content_hash: 20bacef8cb74780d
prev_chunk_id: chunk-0023
next_chunk_id: chunk-0025
section_heading: UAVCAN DSDL — protocol
document_type: technical_reference

### 4.GetTransportStats

- **Namespace path:** `uavcan/protocol`
- **Source file:** `uavcan/protocol/4.GetTransportStats.uavcan`

### DSDL definition ```
#
# Get transport statistics.
#

---

#
# UAVCAN transport layer statistics.
#
uint48 transfers_tx             # Number of transmitted transfers.
uint48 transfers_rx             # Number of received transfers.
uint48 transfer_errors          # Number of errors detected in the UAVCAN transport layer.

#
# CAN bus statistics, for each interface independently.
#
CANIfaceStats[<=3] can_iface_stats
``` ### 4.GlobalTimeSync

- **Namespace path:** `uavcan/protocol`
- **Source file:** `uavcan/protocol/4.GlobalTimeSync.uavcan`

### DSDL definition ```
#
# Global time synchronization.
# Any node that publishes timestamped data must use this time reference.
#
# Please refer to the specification to learn about the synchronization algorithm.
#

#
# Broadcasting period must be within this range.
#
uint16 MAX_BROADCASTING_PERIOD_MS = 1100            # Milliseconds
uint16 MIN_BROADCASTING_PERIOD_MS = 40              # Milliseconds

#
# Synchronization slaves may switch to a new source if the current master was silent for this amount of time.
#
uint16 RECOMMENDED_BROADCASTER_TIMEOUT_MS = 2200    # Milliseconds

#
# Time in microseconds when the PREVIOUS GlobalTimeSync message was transmitted.
# If this message is the first one, this field must be zero.
#
truncated uint56 previous_transmission_timestamp_usec # Microseconds
``` ### 5.Panic

- **Namespace path:** `uavcan/protocol`
- **Source file:** `uavcan/protocol/5.Panic.uavcan`

### DSDL definition ```
#
# This message may be published periodically to inform network participants that the system has encountered
# an unrecoverable fault and is not capable of further operation.
#
# Nodes that are expected to react to this message should wait for at least MIN_MESSAGES subsequent messages
# with any reason text from any sender published with the interval no higher than MAX_INTERVAL_MS before
# undertaking any emergency actions.
#

uint8 MIN_MESSAGES = 3

uint16 MAX_INTERVAL_MS = 500

#
# Short description that would fit a single CAN frame.
#
uint8[<=7] reason_text
``` ### 5.RestartNode

- **Namespace path:** `uavcan/protocol`
- **Source file:** `uavcan/protocol/5.RestartNode.uavcan`

### DSDL definition ```
#
# Restart the node.
#
# Some nodes may require restart before the new configuration will be applied.
#
# The request should be rejected if magic_number does not equal MAGIC_NUMBER.
#

uint40 MAGIC_NUMBER = 0xACCE551B1E
uint40 magic_number

---

bool ok
``` ### 6.AccessCommandShell

- **Namespace path:** `uavcan/protocol`
- **Source file:** `uavcan/protocol/6.AccessCommandShell.uavcan`

### DSDL definition

--- chunk_id: chunk-0025
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 665
content_hash: ab51db17f0d82b28
prev_chunk_id: chunk-0024
next_chunk_id: chunk-0026
section_heading: UAVCAN DSDL — protocol
document_type: technical_reference

#
# THIS DEFINITION IS SUBJECT TO CHANGE.
#
# This service allows to execute arbitrary commands on the remote node's internal system shell.
#
# Essentially, this service mimics a typical terminal emulator, with one text input (stdin) and two text
# outputs (stdout and stderr). When there's no process running, the input is directed into the terminal
# handler itself, which interprets it. If there's a process running, the input will be directed into
# stdin of the running process. It is possible to forcefully return the terminal into a known state by
# means of setting the reset flag (see below), in which case the terminal will kill all of the child
# processes, if any, and return into the initial idle state.
#
# The server is assumed to allocate one independent terminal instance per client, so that different clients
# can execute commands without interfering with each other.
#

#
# Input and output should use this newline character.
#
uint8 NEWLINE = '\n'

#
# The server is required to keep the result of the last executed command for at least this time.
# When this time expires, the server may remove the results in order to reclaim the memory, but it
# is not guaranteed. Hence, the clients must retrieve the results in this amount of time.
#
uint8 MIN_OUTPUT_LIFETIME_SEC = 10

#
# These flags control the shell and command execution.
#
uint8 FLAG_RESET_SHELL          = 1     # Restarts the shell instance anew; may or may not imply CLEAR_OUTPUT_BUFFERS
uint8 FLAG_CLEAR_OUTPUT_BUFFERS = 2     # Makes stdout and stderr buffers empty
uint8 FLAG_READ_STDOUT          = 64    # Output will contain stdout
uint8 FLAG_READ_STDERR          = 128   # Output will be extended with stderr
uint8 flags

#
# If the shell is idle, it will interpret this string.
# If there's a process running, this string will be piped into its stdin.
#
# If RESET_SHELL is set, new input will be interpreted by the shell immediately.
#
uint8[<=128] input

---

#
# Exit status of the last executed process, or error code of the shell itself.
# Default value is zero.
#
int32 last_exit_status

#
# These flags indicate the status of the shell.
#
uint8 FLAG_RUNNING              = 1     # The shell is currently running a process; stdin/out/err are piped to it
uint8 FLAG_SHELL_ERROR          = 2     # Exit status contains error code, output contains text (e.g. no such command)
uint8 FLAG_HAS_PENDING_STDOUT   = 64    # There is more stdout to read
uint8 FLAG_HAS_PENDING_STDERR   = 128   # There is more stderr to read
uint8 flags

#
# In case of a shell error, this string may contain ASCII string explaining the nature of the error.
# Otherwise, if stdout read is requested, this string will contain stdout data. If stderr read is requested,
# this string will contain stderr data. If both stdout and stderr read is requested, this string will start
# with stdout and end with stderr, with no separator in between.
#
uint8[<=256] output

--- chunk_id: chunk-0026
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 241
content_hash: 9cbc7a30cec40b21
prev_chunk_id: chunk-0025
next_chunk_id: chunk-0027
section_heading: CANIfaceStats
document_type: technical_reference

## CANIfaceStats

- **Namespace path:** `uavcan/protocol`
- **Source file:** `uavcan/protocol/CANIfaceStats.uavcan`

### DSDL definition ```
#
# Single CAN iface statistics.
#

uint48 frames_tx        # Number of transmitted CAN frames.
uint48 frames_rx        # Number of received CAN frames.
uint48 errors           # Number of errors in the CAN layer.
``` ### DataTypeKind
- **Namespace path:** `uavcan/protocol`
- **Source file:** `uavcan/protocol/DataTypeKind.uavcan`

### DSDL definition ```
#
# Data type kind (message or service).
#

uint8 SERVICE = 0
uint8 MESSAGE = 1
uint8 value
``` ### HardwareVersion
- **Namespace path:** `uavcan/protocol`
- **Source file:** `uavcan/protocol/HardwareVersion.uavcan`

### DSDL definition ```
#
# Nested type.
# Generic hardware version information.
# These values should remain unchanged for the device's lifetime.
#

#
# Hardware version code.
#
uint8 major
uint8 minor

#
# Unique ID is a 128 bit long sequence that is globally unique for each node.
# All zeros is not a valid UID.
# If filled with zeros, assume that the value is undefined.
#
uint8[16] unique_id

#
# Certificate of authenticity (COA) of the hardware, 255 bytes max.
#
uint8[<=255] certificate_of_authenticity
```

--- chunk_id: chunk-0027
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 514
content_hash: fa452cad15188f55
prev_chunk_id: chunk-0026
next_chunk_id: chunk-0028
section_heading: SoftwareVersion
document_type: technical_reference

## SoftwareVersion

- **Namespace path:** `uavcan/protocol`
- **Source file:** `uavcan/protocol/SoftwareVersion.uavcan`

### DSDL definition ```
#
# Nested type.
# Generic software version information.
#

#
# Primary version numbers.
# If both fields are set to zero, the version is considered unknown.
#
uint8 major
uint8 minor

#
# This mask indicates which optional fields (see below) are set.
#
uint8 OPTIONAL_FIELD_FLAG_VCS_COMMIT = 1
uint8 OPTIONAL_FIELD_FLAG_IMAGE_CRC  = 2
uint8 optional_field_flags

#
# VCS commit hash or revision number, e.g. git short commit hash. Optional.
#
uint32 vcs_commit

#
# The value of an arbitrary hash function applied to the firmware image.
# This field is used to detect whether the firmware running on the node is EXACTLY THE SAME
# as a certain specific revision. This field provides the absolute identity guarantee, unlike
# the version fields above, which can be the same for different builds of the firmware.
#
# The exact hash function and the methods of its application are implementation defined.
# However, implementations are recommended to adhere to the following guidelines,
# fully or partially:
#
#   - The hash function should be CRC-64-WE, the same that is used for computing DSDL signatures.
#
#   - The hash function should be applied to the entire application image padded to 8 bytes.
#
#   - If the computed image CRC is stored within the firmware image itself, the value of
#     the hash function becomes ill-defined, because it becomes recursively dependent on itself.
#     In order to circumvent this issue, while computing or checking the CRC, its value stored
#     within the image should be zeroed out.
#
uint64 image_crc
``` ### 16370.KeyValue

- **Namespace path:** `uavcan/protocol/debug`
- **Source file:** `uavcan/protocol/debug/16370.KeyValue.uavcan`

### DSDL definition ```
#
# Generic named parameter (key/value pair).
#

#
# Integers are exactly representable in the range (-2^24, 2^24) which is (-16'777'216, 16'777'216).
#
float32 value

#
# Tail array optimization is enabled, so if key length does not exceed 3 characters, the whole
# message can fit into one CAN frame. The message always fits into one CAN FD frame.
#
uint8[<=58] key
``` ### 16383.LogMessage

- **Namespace path:** `uavcan/protocol/debug`
- **Source file:** `uavcan/protocol/debug/16383.LogMessage.uavcan`

### DSDL definition ```
#
# Generic log message.
# All items are byte aligned.
#

LogLevel level
uint8[<=31] source
uint8[<=90] text
```

--- chunk_id: chunk-0028
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 69
content_hash: ba2cd44395e0fd2a
prev_chunk_id: chunk-0027
next_chunk_id: chunk-0029
section_heading: LogLevel
document_type: technical_reference

## LogLevel

- **Namespace path:** `uavcan/protocol/debug`
- **Source file:** `uavcan/protocol/debug/LogLevel.uavcan`

### DSDL definition ```
#
# Log message severity
#

uint3 DEBUG    = 0
uint3 INFO     = 1
uint3 WARNING  = 2
uint3 ERROR    = 3
uint3 value
``` ### 1.Allocation

- **Namespace path:** `uavcan/protocol/dynamic_node_id`
- **Source file:** `uavcan/protocol/dynamic_node_id/1.Allocation.uavcan`

### DSDL definition

--- chunk_id: chunk-0029
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 1521
content_hash: 597b2d476744cdc8
prev_chunk_id: chunk-0028
next_chunk_id: chunk-0030
section_heading: LogLevel
document_type: technical_reference

#
# This message is used for dynamic Node ID allocation.
#
# When a node needs to request a node ID dynamically, it will transmit an anonymous message transfer of this type.
# In order to reduce probability of CAN ID collisions when multiple nodes are publishing this request, the CAN ID
# field of anonymous message transfer includes a Discriminator, which is a special field that has to be filled with
# random data by the transmitting node. Since Discriminator collisions are likely to happen (probability approx.
# 0.006%), nodes that are requesting dynamic allocations need to be able to handle them correctly. Hence, a collision
# resolution protocol is defined (alike CSMA/CD). The collision resolution protocol is based on two randomized
# transmission intervals:
#
# - Request period - Trequest.
# - Follow up delay - Tfollowup.
#
# Recommended randomization ranges for these intervals are documented in the constants of this message type (see below).
# Random intervals must be chosen anew per transmission, whereas the Discriminator value is allowed to stay constant
# per node.
#
# In the below description the following terms are used:
# - Allocator - the node that serves allocation requests.
# - Allocatee - the node that requests an allocation from the Allocator.
#
# The response timeout is not explicitly defined for this protocol, as the Allocatee will request the allocation
# Trequest units of time later again, unless the allocation has been granted. Despite this, the implementation can
# consider the value of FOLLOWUP_TIMEOUT_MS as an allocation timeout, if necessary.
#
# On the allocatee's side the protocol is defined through the following set of rules:
#
# Rule A. On initialization:
# 1. The allocatee subscribes to this message.
# 2. The allocatee starts the Request Timer with a random interval of Trequest.
#
# Rule B. On expiration of Request Timer:
# 1. Request Timer restarts with a random interval of Trequest.
# 2. The allocatee broadcasts a first-stage Allocation request message, where the fields are assigned following values:
#    node_id                 - preferred node ID, or zero if the allocatee doesn't have any preference
#    first_part_of_unique_id - true
#    unique_id               - first MAX_LENGTH_OF_UNIQUE_ID_IN_REQUEST bytes of unique ID
#
# Rule C. On any Allocation message, even if other rules also match:
# 1. Request Timer restarts with a random interval of Trequest.
#
# Rule D. On an Allocation message WHERE (source node ID is non-anonymous) AND (allocatee's unique ID starts with the
# bytes available in the field unique_id) AND (unique_id is less than 16 bytes long):
# 1. The allocatee waits for Tfollowup units of time, while listening for other Allocation messages. If an Allocation
#    message is received during this time, the execution of this rule will be terminated. Also see rule C.
# 2. The allocatee broadcasts a second-stage Allocation request message, where the fields are assigned following values:
#    node_id                 - same value as in the first-stage
#    first_part_of_unique_id - false
#    unique_id               - at most MAX_LENGTH_OF_UNIQUE_ID_IN_REQUEST bytes of local unique ID with an offset
#                              equal to number of bytes in the received unique ID
#
# Rule E. On an Allocation message WHERE (source node ID is non-anonymous) AND (unique_id fully matches allocatee's
# unique ID) AND (node_id in the received message is not zero):
# 1. Request Timer stops.
# 2. The allocatee initializes its node_id with the received value.
# 3. The allocatee terminates subscription to Allocation messages.
# 4. Exit.
#

#
# Recommended randomization range for request period.
#
# These definitions have an advisory status; it is OK to pick higher values for both bounds, as it won't affect
# protocol compatibility. In fact, it is advised to pick higher values if the target application is not concerned
# about the time it will spend on completing the dynamic node ID allocation procedure, as it will reduce
# interference with other nodes, possibly of higher importance.
#
# The lower bound shall not be lower than FOLLOWUP_TIMEOUT_MS, otherwise the request may conflict with a followup.
#
uint16 MAX_REQUEST_PERIOD_MS = 1000     # It is OK to exceed this value
uint16 MIN_REQUEST_PERIOD_MS = 600      # It is OK to exceed this value

#
# Recommended randomization range for followup delay.
# The upper bound shall not exceed FOLLOWUP_TIMEOUT_MS, because the allocator will reset the state on its end.
#
uint16 MAX_FOLLOWUP_DELAY_MS = 400
uint16 MIN_FOLLOWUP_DELAY_MS = 0        # Defined only for regularity; will always be zero.

#
# Allocator will reset its state if there was no follow-up request in this amount of time.
#
uint16 FOLLOWUP_TIMEOUT_MS = 500

#
# Any request message can accommodate no more than this number of bytes of unique ID.
# This limitation is needed to ensure that all request transfers are single-frame.
# This limitation does not apply to CAN FD transport.
#
uint8 MAX_LENGTH_OF_UNIQUE_ID_IN_REQUEST = 6

#
# When requesting an allocation, set the field 'node_id' to this value if there's no preference.
#
uint7 ANY_NODE_ID = 0

#
# If transfer is anonymous, this is the preferred ID.
# If transfer is non-anonymous, this is allocated ID.
#
# If the allocatee does not have any preference, this value must be set to zero. In this case, the allocator
# must choose the highest unused node ID value for this allocation (except 126 and 127, that are reserved for
# network maintenance tools). E.g., if the allocation table is empty and the node has requested an allocation
# without any preference, the allocator will grant the node ID 125.
#
# If the preferred node ID is not zero, the allocator will traverse the allocation table starting from the
# preferred node ID upward, until a free node ID is found. If a free node ID could not be found, the
# allocator will restart the search from the preferred node ID downward, until a free node ID is found.
#
# In pseudocode:
#   int findFreeNodeID(const int preferred)
#   {
#       // Search up
#       int candidate = (preferred > 0) ? preferred : 125;
#       while (candidate <= 125)
#       {
#           if (!isOccupied(candidate))
#               return candidate;
#           candidate++;
#       }
#       // Search down
#       candidate = (preferred > 0) ? preferred : 125;
#       while (candidate > 0)
#       {
#           if (!isOccupied(candidate))
#               return candidate;
#           candidate--;
#       }
#       // Not found
#       return -1;
#   }
#
uint7 node_id

#
# If transfer is anonymous, this field indicates first-stage request.
# If transfer is non-anonymous, this field should be assigned zero and ignored.
#
bool first_part_of_unique_id

#
# If transfer is anonymous, this array must not contain more than MAX_LENGTH_OF_UNIQUE_ID_IN_REQUEST items.
# Note that array is tail-optimized, i.e. it will not be prepended with length field.
#
uint8[<=16] unique_id

--- chunk_id: chunk-0030
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 1541
content_hash: 6079674e1e375eb1
prev_chunk_id: chunk-0029
next_chunk_id: chunk-0031
section_heading: LogLevel
document_type: technical_reference

```
#
# This message is used for dynamic Node ID allocation.
#
# When a node needs to request a node ID dynamically, it will transmit an anonymous message transfer of this type.
# In order to reduce probability of CAN ID collisions when multiple nodes are publishing this request, the CAN ID
# field of anonymous message transfer includes a Discriminator, which is a special field that has to be filled with
# random data by the transmitting node. Since Discriminator collisions are likely to happen (probability approx.
# 0.006%), nodes that are requesting dynamic allocations need to be able to handle them correctly. Hence, a collision
# resolution protocol is defined (alike CSMA/CD). The collision resolution protocol is based on two randomized
# transmission intervals:
#
# - Request period - Trequest.
# - Follow up delay - Tfollowup.
#
# Recommended randomization ranges for these intervals are documented in the constants of this message type (see below).
# Random intervals must be chosen anew per transmission, whereas the Discriminator value is allowed to stay constant
# per node.
#
# In the below description the following terms are used:
# - Allocator - the node that serves allocation requests.
# - Allocatee - the node that requests an allocation from the Allocator.
#
# The response timeout is not explicitly defined for this protocol, as the Allocatee will request the allocation
# Trequest units of time later again, unless the allocation has been granted. Despite this, the implementation can
# consider the value of FOLLOWUP_TIMEOUT_MS as an allocation timeout, if necessary.
#
# On the allocatee's side the protocol is defined through the following set of rules:
#
# Rule A. On initialization:
# 1. The allocatee subscribes to this message.
# 2. The allocatee starts the Request Timer with a random interval of Trequest.
#
# Rule B. On expiration of Request Timer:
# 1. Request Timer restarts with a random interval of Trequest.
# 2. The allocatee broadcasts a first-stage Allocation request message, where the fields are assigned following values:
#    node_id                 - preferred node ID, or zero if the allocatee doesn't have any preference
#    first_part_of_unique_id - true
#    unique_id               - first MAX_LENGTH_OF_UNIQUE_ID_IN_REQUEST bytes of unique ID
#
# Rule C. On any Allocation message, even if other rules also match:
# 1. Request Timer restarts with a random interval of Trequest.
#
# Rule D. On an Allocation message WHERE (source node ID is non-anonymous) AND (allocatee's unique ID starts with the
# bytes available in the field unique_id) AND (unique_id is less than 16 bytes long):
# 1. The allocatee waits for Tfollowup units of time, while listening for other Allocation messages. If an Allocation
#    message is received during this time, the execution of this rule will be terminated. Also see rule C.
# 2. The allocatee broadcasts a second-stage Allocation request message, where the fields are assigned following values:
#    node_id                 - same value as in the first-stage
#    first_part_of_unique_id - false
#    unique_id               - at most MAX_LENGTH_OF_UNIQUE_ID_IN_REQUEST bytes of local unique ID with an offset
#                              equal to number of bytes in the received unique ID
#
# Rule E. On an Allocation message WHERE (source node ID is non-anonymous) AND (unique_id fully matches allocatee's
# unique ID) AND (node_id in the received message is not zero):
# 1. Request Timer stops.
# 2. The allocatee initializes its node_id with the received value.
# 3. The allocatee terminates subscription to Allocation messages.
# 4. Exit.
#

#
# Recommended randomization range for request period.
#
# These definitions have an advisory status; it is OK to pick higher values for both bounds, as it won't affect
# protocol compatibility. In fact, it is advised to pick higher values if the target application is not concerned
# about the time it will spend on completing the dynamic node ID allocation procedure, as it will reduce
# interference with other nodes, possibly of higher importance.
#
# The lower bound shall not be lower than FOLLOWUP_TIMEOUT_MS, otherwise the request may conflict with a followup.
#
uint16 MAX_REQUEST_PERIOD_MS = 1000     # It is OK to exceed this value
uint16 MIN_REQUEST_PERIOD_MS = 600      # It is OK to exceed this value

#
# Recommended randomization range for followup delay.
# The upper bound shall not exceed FOLLOWUP_TIMEOUT_MS, because the allocator will reset the state on its end.
#
uint16 MAX_FOLLOWUP_DELAY_MS = 400
uint16 MIN_FOLLOWUP_DELAY_MS = 0        # Defined only for regularity; will always be zero.

#
# Allocator will reset its state if there was no follow-up request in this amount of time.
#
uint16 FOLLOWUP_TIMEOUT_MS = 500

#
# Any request message can accommodate no more than this number of bytes of unique ID.
# This limitation is needed to ensure that all request transfers are single-frame.
# This limitation does not apply to CAN FD transport.
#
uint8 MAX_LENGTH_OF_UNIQUE_ID_IN_REQUEST = 6

#
# When requesting an allocation, set the field 'node_id' to this value if there's no preference.
#
uint7 ANY_NODE_ID = 0

#
# If transfer is anonymous, this is the preferred ID.
# If transfer is non-anonymous, this is allocated ID.
#
# If the allocatee does not have any preference, this value must be set to zero. In this case, the allocator
# must choose the highest unused node ID value for this allocation (except 126 and 127, that are reserved for
# network maintenance tools). E.g., if the allocation table is empty and the node has requested an allocation
# without any preference, the allocator will grant the node ID 125.
#
# If the preferred node ID is not zero, the allocator will traverse the allocation table starting from the
# preferred node ID upward, until a free node ID is found. If a free node ID could not be found, the
# allocator will restart the search from the preferred node ID downward, until a free node ID is found.
#
# In pseudocode:
#   int findFreeNodeID(const int preferred)
#   {
#       // Search up
#       int candidate = (preferred > 0) ? preferred : 125;
#       while (candidate <= 125)
#       {
#           if (!isOccupied(candidate))
#               return candidate;
#           candidate++;
#       }
#       // Search down
#       candidate = (preferred > 0) ? preferred : 125;
#       while (candidate > 0)
#       {
#           if (!isOccupied(candidate))
#               return candidate;
#           candidate--;
#       }
#       // Not found
#       return -1;
#   }
#
uint7 node_id

#
# If transfer is anonymous, this field indicates first-stage request.
# If transfer is non-anonymous, this field should be assigned zero and ignored.
#
bool first_part_of_unique_id

#
# If transfer is anonymous, this array must not contain more than MAX_LENGTH_OF_UNIQUE_ID_IN_REQUEST items.
# Note that array is tail-optimized, i.e. it will not be prepended with length field.
#
uint8[<=16] unique_id
``` ### 30.AppendEntries

- **Namespace path:** `uavcan/protocol/dynamic_node_id/server`
- **Source file:** `uavcan/protocol/dynamic_node_id/server/30.AppendEntries.uavcan`

### DSDL definition

--- chunk_id: chunk-0031
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 665
content_hash: 0d122ea43202690f
prev_chunk_id: chunk-0030
next_chunk_id: chunk-0032
section_heading: LogLevel
document_type: technical_reference

#
# THIS DEFINITION IS SUBJECT TO CHANGE.
#
# This type is a part of the Raft consensus algorithm.
# Please refer to the specification for details.
#

#
# Given min election timeout and cluster size, the maximum recommended request interval can be derived as follows:
#
#   max recommended request interval = (min election timeout) / 2 requests / (cluster size - 1)
#
# The equation assumes that the Leader requests one Follower at a time, so that there's at most one pending call
# at any moment. Such behavior is optimal as it creates uniform bus load, but it is actually implementation-specific.
# Obviously, request interval can be lower than that if needed, but higher values are not recommended as they may
# cause Followers to initiate premature elections in case of intensive frame losses or delays.
#
# Real timeout is randomized in the range (MIN, MAX], according to the Raft paper.
#
uint16 DEFAULT_MIN_ELECTION_TIMEOUT_MS = 2000
uint16 DEFAULT_MAX_ELECTION_TIMEOUT_MS = 4000

#
# Refer to the Raft paper for explanation.
#
uint32 term
uint32 prev_log_term
uint8 prev_log_index
uint8 leader_commit

#
# Worst-case replication time per Follower can be computed as:
#
#   worst replication time = (127 log entries) * (2 trips of next_index) * (request interval per Follower)
#
Entry[<=1] entries

---

#
# Refer to the Raft paper for explanation.
#
uint32 term
bool success
``` ### 31.RequestVote

- **Namespace path:** `uavcan/protocol/dynamic_node_id/server`
- **Source file:** `uavcan/protocol/dynamic_node_id/server/31.RequestVote.uavcan`

### DSDL definition ```
#
# THIS DEFINITION IS SUBJECT TO CHANGE.
#
# This type is a part of the Raft consensus algorithm.
# Please refer to the specification for details.
#

#
# Refer to the Raft paper for explanation.
#
uint32 term
uint32 last_log_term
uint8 last_log_index

---

#
# Refer to the Raft paper for explanation.
#
uint32 term
bool vote_granted
``` ### 390.Discovery

- **Namespace path:** `uavcan/protocol/dynamic_node_id/server`
- **Source file:** `uavcan/protocol/dynamic_node_id/server/390.Discovery.uavcan`

### DSDL definition ```
#
# THIS DEFINITION IS SUBJECT TO CHANGE.
#
# This message is used by allocation servers to find each other's node ID.
# Please refer to the specification for details.
#
# A server should stop publishing this message as soon as it has discovered all other nodes in the cluster.
#
# An exception applies: when a server receives a Discovery message from another server where the list
# of known nodes is incomplete (i.e. len(known_nodes) < configured_cluster_size), the server must
# publish a discovery message once. This condition allows other servers to quickly re-discover the cluster
# after restart.
#

#
# This message should be broadcasted by the server at this interval until all other servers are discovered.
#
uint16 BROADCASTING_PERIOD_MS = 1000

#
# Number of servers in the cluster as configured on the sender.
#
uint8 configured_cluster_size

#
# Node ID of servers that are known to the publishing server, including the publishing server itself.
# Capacity of this array defines maximum size of the server cluster.
#
uint8[<=5] known_nodes

--- chunk_id: chunk-0032
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 512
content_hash: f42d73d0c7823125
prev_chunk_id: chunk-0031
next_chunk_id: chunk-0033
section_heading: Entry
document_type: technical_reference

## Entry

- **Namespace path:** `uavcan/protocol/dynamic_node_id/server`
- **Source file:** `uavcan/protocol/dynamic_node_id/server/Entry.uavcan`

### DSDL definition ```
#
# THIS DEFINITION IS SUBJECT TO CHANGE.
#
# One dynamic node ID allocation entry.
# This type is a part of the Raft consensus algorithm.
# Please refer to the specification for details.
#

uint32 term             # Refer to the Raft paper for explanation.

uint8[16] unique_id     # Unique ID of this allocation.

void1
uint7 node_id           # Node ID of this allocation.
``` ### 15.Begin

- **Namespace path:** `uavcan/protocol/enumeration`
- **Source file:** `uavcan/protocol/enumeration/15.Begin.uavcan`

### DSDL definition ```
#
# This service instructs the node to begin the process of automated enumeration.
#

#
# The node will automatically leave enumeration mode upon expiration of this timeout.
#
uint16 TIMEOUT_CANCEL   = 0     # Stop enumeration immediately
uint16 TIMEOUT_INFINITE = 65535 # Do not stop until explicitly requested
uint16 timeout_sec              # [Seconds]

#
# Name of the parameter to enumerate, e.g. ESC index.
# If the name is left empty, the node will infer the parameter name automatically (autodetect).
# It is highly recommended to always use autodetection in order to avoid dependency on hard-coded parameter names,
# and also allow the enumeratee to possibly enumerate multiple different parameters at once.
# The rule of thumb is to always leave this parameter empty unless you really know what you're doing.
#
uint8[<=92] parameter_name

---

uint8 ERROR_OK                  = 0     # Success
uint8 ERROR_INVALID_MODE        = 1     # The node cannot perform enumeration in its current operating mode
uint8 ERROR_INVALID_PARAMETER   = 2     # The node cannot enumerate on the requested parameter, or it doesn't exist
uint8 ERROR_UNSUPPORTED         = 3     # The node cannot perform enumeration in its current configuration
uint8 ERROR_UNKNOWN             = 255   # Generic error
uint8 error
``` ### 380.Indication

- **Namespace path:** `uavcan/protocol/enumeration`
- **Source file:** `uavcan/protocol/enumeration/380.Indication.uavcan`

### DSDL definition ```
#
# This message will be broadcasted when the node receives user input in the process of enumeration.
#

void6

#
# This field is unused; keep it empty
#
uavcan.protocol.param.NumericValue value

#
# Name of the enumerated parameter.
# This field must always be populated by the enumeratee.
# If multiple parameters were enumerated at once (e.g. ESC index and the direction of rotation),
# the field should contain the name of the most important parameter.
#
uint8[<=92] parameter_name
```

--- chunk_id: chunk-0033
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 652
content_hash: e60003118115e81f
prev_chunk_id: chunk-0032
next_chunk_id: chunk-0034
section_heading: Entry
document_type: technical_reference

### 380.Indication

- **Namespace path:** `uavcan/protocol/enumeration`
- **Source file:** `uavcan/protocol/enumeration/380.Indication.uavcan`

### DSDL definition ```
#
# This message will be broadcasted when the node receives user input in the process of enumeration.
#

void6

#
# This field is unused; keep it empty
#
uavcan.protocol.param.NumericValue value

#
# Name of the enumerated parameter.
# This field must always be populated by the enumeratee.
# If multiple parameters were enumerated at once (e.g. ESC index and the direction of rotation),
# the field should contain the name of the most important parameter.
#
uint8[<=92] parameter_name
``` ### 40.BeginFirmwareUpdate

- **Namespace path:** `uavcan/protocol/file`
- **Source file:** `uavcan/protocol/file/40.BeginFirmwareUpdate.uavcan`

### DSDL definition ```
#
# This service initiates firmware update on a remote node.
#
# The node that is being updated (slave) will retrieve the firmware image file 'image_file_remote_path' from the node
# 'source_node_id' using the file read service, then it will update the firmware and reboot.
#
# The slave can explicitly reject this request if it is not possible to update the firmware at the moment
# (e.g. if the node is busy).
#
# If the slave node accepts this request, the initiator will get a response immediately, before the update process
# actually begins.
#
# While the firmware is being updated, the slave should set its mode (uavcan.protocol.NodeStatus.mode) to
# MODE_SOFTWARE_UPDATE.
#

uint8 source_node_id         # If this field is zero, the caller's Node ID will be used instead.
Path image_file_remote_path

---

#
# Other error codes may be added in the future.
#
uint8 ERROR_OK               = 0
uint8 ERROR_INVALID_MODE     = 1    # Cannot perform the update in the current operating mode or state.
uint8 ERROR_IN_PROGRESS      = 2    # Firmware update is already in progress, and the slave doesn't want to restart.
uint8 ERROR_UNKNOWN          = 255
uint8 error

uint8[<128] optional_error_message   # Detailed description of the error.
``` ### 45.GetInfo

- **Namespace path:** `uavcan/protocol/file`
- **Source file:** `uavcan/protocol/file/45.GetInfo.uavcan`

### DSDL definition ```
#
# Request info about a remote file system entry (file, directory, etc).
#

Path path

---

#
# File size in bytes.
# Should be set to zero for directories.
#
uint40 size

Error error

EntryType entry_type
``` ### 46.GetDirectoryEntryInfo

- **Namespace path:** `uavcan/protocol/file`
- **Source file:** `uavcan/protocol/file/46.GetDirectoryEntryInfo.uavcan`

### DSDL definition ```
#
# This service can be used to retrieve a remote directory listing, one entry per request.
#
# The client should query each entry independently, iterating 'entry_index' from 0 until the last entry is passed,
# in which case the server will report that there is no such entry (via the fields 'entry_type' and 'error').
#
# The entry_index shall be applied to the ordered list of directory entries (e.g. alphabetically ordered). The exact
# sorting criteria does not matter as long as it provides the same ordering for subsequent service calls.
#

uint32 entry_index

Path directory_path

---

Error error

EntryType entry_type

Path entry_full_path  # Ignored/Empty if such entry does not exist.
```

--- chunk_id: chunk-0034
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 670
content_hash: 02424f507a625abf
prev_chunk_id: chunk-0033
next_chunk_id: chunk-0035
section_heading: Entry
document_type: technical_reference

### 46.GetDirectoryEntryInfo

- **Namespace path:** `uavcan/protocol/file`
- **Source file:** `uavcan/protocol/file/46.GetDirectoryEntryInfo.uavcan`

### DSDL definition ```
#
# This service can be used to retrieve a remote directory listing, one entry per request.
#
# The client should query each entry independently, iterating 'entry_index' from 0 until the last entry is passed,
# in which case the server will report that there is no such entry (via the fields 'entry_type' and 'error').
#
# The entry_index shall be applied to the ordered list of directory entries (e.g. alphabetically ordered). The exact
# sorting criteria does not matter as long as it provides the same ordering for subsequent service calls.
#

uint32 entry_index

Path directory_path

---

Error error

EntryType entry_type

Path entry_full_path  # Ignored/Empty if such entry does not exist.
``` ### 47.Delete

- **Namespace path:** `uavcan/protocol/file`
- **Source file:** `uavcan/protocol/file/47.Delete.uavcan`

### DSDL definition ```
#
# Delete remote file system entry.
# If the remote entry is a directory, all nested entries will be removed too.
#

Path path

---

Error error
``` ### 48.Read

- **Namespace path:** `uavcan/protocol/file`
- **Source file:** `uavcan/protocol/file/48.Read.uavcan`

### DSDL definition ```
#
# Read file from a remote node.
# 
# There are two possible outcomes of a successful service call:
#  1. Data array size equals its capacity. This means that the end of the file is not reached yet.
#  2. Data array size is less than its capacity, possibly zero. This means that the end of file is reached.
# 
# Thus, if the client needs to fetch the entire file, it should repeatedly call this service while increasing the
# offset, until incomplete data is returned.
#
# If the object pointed by 'path' cannot be read (e.g. it is a directory or it does not exist), appropriate error code
# will be returned, and data array will be empty.
#

uint40 offset

Path path

---

Error error

uint8[<=256] data
``` ### 49.Write

- **Namespace path:** `uavcan/protocol/file`
- **Source file:** `uavcan/protocol/file/49.Write.uavcan`

### DSDL definition ```
#
# Write into a remote file.
# The server shall place the contents of the field 'data' into the file pointed by 'path' at the offset specified by
# the field 'offset'.
#
# When writing a file, the client should repeatedly call this service with data while advancing offset until the file
# is written completely. When write is complete, the client shall call the service one last time, with the offset
# set to the size of the file and with the data field empty, which will signal the server that the write operation is
# complete.
#
# When the write operation is complete, the server shall truncate the resulting file past the specified offset.
#
# Server implementation advice:
# It is recommended to implement proper handling of concurrent writes to the same file from different clients, for
# example by means of creating a staging area for uncompleted writes (like FTP servers do).
#

uint40 offset

Path path

uint8[<=192] data

---

Error error
```

--- chunk_id: chunk-0035
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 232
content_hash: e988fc56df2ebf56
prev_chunk_id: chunk-0034
next_chunk_id: chunk-0036
section_heading: EntryType
document_type: technical_reference

## EntryType

- **Namespace path:** `uavcan/protocol/file`
- **Source file:** `uavcan/protocol/file/EntryType.uavcan`

### DSDL definition ```
#
# Nested type.
# Represents the type of the file system entry (e.g. file or directory).
# If such entry does not exist, 'flags' must be set to zero.
#

uint8 FLAG_FILE      = 1        # Excludes FLAG_DIRECTORY
uint8 FLAG_DIRECTORY = 2        # Excludes FLAG_FILE
uint8 FLAG_SYMLINK   = 4        # Link target is either FLAG_FILE or FLAG_DIRECTORY
uint8 FLAG_READABLE  = 8
uint8 FLAG_WRITEABLE = 16

uint8 flags
``` ### Error
- **Namespace path:** `uavcan/protocol/file`
- **Source file:** `uavcan/protocol/file/Error.uavcan`

### DSDL definition ```
#
# Nested type.
# File operation result code.
#

int16 OK                = 0
int16 UNKNOWN_ERROR     = 32767

int16 NOT_FOUND         = 2
int16 IO_ERROR          = 5
int16 ACCESS_DENIED     = 13
int16 IS_DIRECTORY      = 21 # I.e. attempt to read/write on a path that points to a directory
int16 INVALID_VALUE     = 22 # E.g. file name is not valid for the target file system
int16 FILE_TOO_LARGE    = 27
int16 OUT_OF_SPACE      = 28
int16 NOT_IMPLEMENTED   = 38

int16 value
```

--- chunk_id: chunk-0036
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 701
content_hash: dc89086429b2f8b1
prev_chunk_id: chunk-0035
next_chunk_id: chunk-0037
section_heading: Path
document_type: technical_reference

## Path

- **Namespace path:** `uavcan/protocol/file`
- **Source file:** `uavcan/protocol/file/Path.uavcan`

### DSDL definition ```
#
# Nested type.
#
# File system path in UTF8.
#
# The only valid separator is forward slash.
#

uint8 SEPARATOR = '/'

uint8[<=200] path
``` ### 10.ExecuteOpcode

- **Namespace path:** `uavcan/protocol/param`
- **Source file:** `uavcan/protocol/param/10.ExecuteOpcode.uavcan`

### DSDL definition ```
#
# Service to control the node configuration.
#

#
# SAVE operation instructs the remote node to save the current configuration parameters into a non-volatile
# storage. The node may require a restart in order for some changes to take effect.
#
# ERASE operation instructs the remote node to clear its configuration storage and reinitialize the parameters
# with their default values. The node may require a restart in order for some changes to take effect.
#
# Other opcodes may be added in the future (for example, an opcode for switching between multiple configurations).
#
uint8 OPCODE_SAVE  = 0  # Save all parameters to non-volatile storage.
uint8 OPCODE_ERASE = 1  # Clear the non-volatile storage; some changes may take effect only after reboot.
uint8 opcode

#
# Reserved, keep zero.
#
int48 argument

---

#
# If 'ok' (the field below) is true, this value is not used and must be kept zero.
# If 'ok' is false, this value may contain error code. Error code constants may be defined in the future.
#
int48 argument

#
# True if the operation has been performed successfully, false otherwise.
#
bool ok
``` ### 11.GetSet

- **Namespace path:** `uavcan/protocol/param`
- **Source file:** `uavcan/protocol/param/11.GetSet.uavcan`

### DSDL definition ```
#
# Get or set a parameter by name or by index.
# Note that access by index should only be used to retrieve the list of parameters; it is highly
# discouraged to use it for anything else, because persistent ordering is not guaranteed.
#

#
# Index of the parameter starting from 0; ignored if name is nonempty.
# Use index only to retrieve the list of parameters.
# Parameter ordering must be well defined (e.g. alphabetical, or any other stable ordering),
# in order for the index access to work.
#
uint13 index

#
# If set - parameter will be assigned this value, then the new value will be returned.
# If not set - current parameter value will be returned.
# Refer to the definition of Value for details.
#
Value value

#
# Name of the parameter; always preferred over index if nonempty.
#
uint8[<=92] name

---

void5

#
# Actual parameter value.
#
# For set requests, it should contain the actual parameter value after the set request was
# executed. The objective is to let the client know if the value could not be updated, e.g.
# due to its range violation, etc.
#
# Empty value (and/or empty name) indicates that there is no such parameter.
#
Value value

void5
Value default_value    # Optional

void6
NumericValue max_value # Optional, not applicable for bool/string

void6
NumericValue min_value # Optional, not applicable for bool/string

#
# Empty name (and/or empty value) in response indicates that there is no such parameter.
#
uint8[<=92] name
```

--- chunk_id: chunk-0037
source_document: dsdl_protocol.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 304
content_hash: 0cfd2696c2d74051
prev_chunk_id: chunk-0036
next_chunk_id: chunk-0038
section_heading: Empty
document_type: technical_reference

## Empty

- **Namespace path:** `uavcan/protocol/param`
- **Source file:** `uavcan/protocol/param/Empty.uavcan`

### DSDL definition ```
#
# Ex nihilo nihil fit.
#
``` ### NumericValue
- **Namespace path:** `uavcan/protocol/param`
- **Source file:** `uavcan/protocol/param/NumericValue.uavcan`

### DSDL definition ```
#
# Numeric-only value.
#
# This is a union, which means that this structure can contain either one of the fields below.
# The structure is prefixed with tag - a selector value that indicates which particular field is encoded.
#

@union                          # Tag is 2 bits long.

Empty empty                     # Empty field, used to represent an undefined value.

int64   integer_value
float32 real_value
``` ### Value
- **Namespace path:** `uavcan/protocol/param`
- **Source file:** `uavcan/protocol/param/Value.uavcan`

### DSDL definition ```
#
# Single parameter value.
#
# This is a union, which means that this structure can contain either one of the fields below.
# The structure is prefixed with tag - a selector value that indicates which particular field is encoded.
#

@union                          # Tag is 3 bit long, so outer structure has 5-bit prefix to ensure proper alignment

Empty empty                     # Empty field, used to represent an undefined value.

int64        integer_value
float32      real_value         # 32-bit type is used to simplify implementation on low-end systems
uint8        boolean_value      # 8-bit value is used for alignment reasons
uint8[<=128] string_value       # Length prefix is exactly one byte long, which ensures proper alignment of payload
```

--- chunk_id: chunk-0038
source_document: dsdl_tunnel.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 273
content_hash: 74c8b8d3151b36e2
prev_chunk_id: chunk-0037
next_chunk_id: chunk-0039
section_heading: UAVCAN DSDL — tunnel
document_type: technical_reference

# UAVCAN DSDL — tunnel

Types under `dsdl/uavcan/tunnel/` (from UAVCAN/dsdl via cvra/uavcan). ### 2010.Broadcast

- **Namespace path:** `uavcan/tunnel`
- **Source file:** `uavcan/tunnel/2010.Broadcast.uavcan`

### DSDL definition ```
#
# This message struct carries arbitrary data in the format of the specified high-level protocol.
# The data will be delivered to all nodes that are interested in tunneled protocols.
# Finer addressing schemes may be implemented using the means provided by the encapsulated protocol.
# The channelID allows for additional routing between the source and target nodes.

Protocol protocol
uint8 channel_id

uint8[<=60] buffer    # TAO rules apply
``` ### 63.Call

- **Namespace path:** `uavcan/tunnel`
- **Source file:** `uavcan/tunnel/63.Call.uavcan`

### DSDL definition ```
#
# This service carries arbitrary data in the format of the specified high-level protocol.
# The data will be delivered to the specified node only (not broadcast), and the addressed node
# will be required to respond (although the response may be empty, if the chosen protocol allows so).
# The specified protocol applies both to the request and to the response. The channelID allows for
# additional routing between the source and target nodes.
#

Protocol protocol
uint8 channel_id

uint8[<=60] buffer    # TAO rules apply

---

uint8[<=60] buffer    # TAO rules apply
```

--- chunk_id: chunk-0039
source_document: dsdl_tunnel.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 57
content_hash: 8ba9ccba97fd480e
prev_chunk_id: chunk-0038
next_chunk_id: chunk-0040
section_heading: Protocol
document_type: technical_reference

## Protocol

- **Namespace path:** `uavcan/tunnel`
- **Source file:** `uavcan/tunnel/Protocol.uavcan`

### DSDL definition ```
#
# This enumeration specifies the encapsulated protocol.
# New protocols are likely to be added in the future.
#

uint8 MAVLINK                   = 0     # MAVLink

uint8 protocol
```

--- chunk_id: chunk-0040
source_document: driver_stm32_driver_README.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 54
content_hash: f7ead05b4d9e67fa
prev_chunk_id: chunk-0039
next_chunk_id: null
document_type: technical_reference

STM32 platform driver
=====================

The directory `driver` contains the STM32 platform driver for Libuavcan. A dedicated example application may be added later here. For now, please consider the following open source projects as a reference:

- https://github.com/PX4/sapog
- https://github.com/Zubax/zubax_gnss
- https://github.com/PX4/Firmware
