--- chunk_id: chunk-0000
source_document: SPEC.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 21
content_hash: c90a6b402931ba51
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: KBMill Desktop
document_type: specification

# KBMill Desktop

Spec sheet for the Linux image that ran. Carroll Miller, d/b/a KBMill. 2026-10-10.

--- chunk_id: chunk-0001
source_document: SPEC.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 244
content_hash: be40762a790065eb
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
section_heading: Names
document_type: specification

## Names

The window is KBMill Desktop. The package inside the image is `vectorforge_pro`. KBMill and that package are the same vendor. The image file is `kbmill-desk.tar`. The tag is `kbmill-desk:0.1.0`. The file is 114298880 bytes. A single-layer DVD-5 holds 4707319808 bytes, so this file fits one DVD. No disc has been burned. ### What the image contains
The image opens a finished brick, marks a chunk seen, edits a chunk, mutes a chunk, and signs the brick. The operating manual is in the image at `/usr/local/share/kbmill/MANUAL.md`. The image can open that file as the brick KBMill_Manual. Inside the image the desk listens on `127.0.0.1:8766`. The calls are `POST /brick/open`, `POST /brick/seen`, `POST /brick/commit`, and `POST /brick/sign`. `GET /` returns the window title and the listen address. The license marker `/usr/local/share/kbmill/license.required` is inside the image. The image asks for an auditor license that names this host. The variable is `VF_AUDIT_LICENSE`. When that variable is unset, the file is `/var/lib/kbmill/license.json`. Docker and Podman both load this file. Nothing is pulled. Podman 3.4 shows the tag as `localhost/kbmill-desk:0.1.0`. The container runs with the network off.

--- chunk_id: chunk-0002
source_document: SPEC.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 185
content_hash: 635d3607439c1969
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: What the image does not contain
document_type: specification

## What the image does not contain

The image does not run the mill. It does not run the public door, the shelf server, or a chat model. It does not charge a card. The license private key is not in the image. `link_bricks` is not a route on this desk. ### The host
One purchase is one host. The host is the fingerprint the image prints, not the hostname. A plant license does not start the desk. A shelf license does not start the desk. A license for another fingerprint does not start the desk. A missing file does not start the desk. The fingerprint command, run inside the container, is `python3 -m vectorforge_pro.plant_license`. That command prints one line and does not read the license. The buyer sends that line through Contact operator. There is no download URL.

--- chunk_id: chunk-0003
source_document: SPEC.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 205
content_hash: 517c763d55c8c299
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: The brick
document_type: specification

## The brick

The brick file is the handoff. The plant writes it. This desk reads it, and a person may edit it and sign it. Signing does not put the brick on the shelf. An unsigned brick still belongs on the shelf. A stale signature still belongs on the shelf. ### What was run
A Linux guest with no copy of the repository loaded this file. Docker and Podman each ran it with the network off. With no license, both refused. With a plant license, both refused. With an auditor license for that guest, both opened a zip brick, marked one chunk seen, and signed it. Opening it again matched. Nothing was fetched. The private key was not on that guest. The screen control that opens a zip by path is not on the window yet. The image answers the calls above. Do not describe a button that is not on the screen.

--- chunk_id: chunk-0004
source_document: LICENSE.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 65
content_hash: 23d939950ddb4f82
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: KBMill Desktop license
document_type: technical_reference

# KBMill Desktop license

This file is the agreement. It is between Carroll Miller, doing business as KBMill, and the person or organization that receives a signed license file for KBMill Desktop. A summary of this file, including a summary written by a model, is not the agreement. 2026-10-10.

--- chunk_id: chunk-0005
source_document: LICENSE.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 246
content_hash: 38abc07c39b408c5
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
section_heading: The grant
document_type: technical_reference

## The grant

KBMill grants the right to run the KBMill Desktop image on one host. The window is KBMill Desktop. The package inside the image is `vectorforge_pro`. KBMill and that package are the same vendor. One purchase is one host. The host is the fingerprint the image prints. The host is not the hostname. The buyer does not edit that line and does not compute it by hand. ### The signed file
KBMill signs a file that names that fingerprint. The private key that signs it stays with KBMill. The key is not in the image, and it is not part of the file the buyer receives. The buyer runs this command inside the desk container:

`python3 -m vectorforge_pro.plant_license`

It prints one line. The buyer sends that line through Contact operator on kbmill.com, or by email to carroll@kbmill.com. KBMill sends the signed file back. There is no download URL. The buyer points `VF_AUDIT_LICENSE` at that file. If the variable is unset, the image reads `/var/lib/kbmill/license.json`. The installed image contains `/usr/local/share/kbmill/license.required`, so it asks for this file. A machine without that marker does not ask.

--- chunk_id: chunk-0006
source_document: LICENSE.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 194
content_hash: ce0edc7f785562cb
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: What the host may do
document_type: technical_reference

## What the host may do

On the named host, the desk may open a finished brick, mark chunks seen, change a chunk, mute a chunk, and sign the brick. The brick file is the handoff. The buyer keeps the brick. ### What this license does not grant
A plant license does not start the desk. A shelf license does not start the desk. A file that names another fingerprint does not start the desk. A missing file does not start the desk. This license does not run the mill, does not run the shelf, and does not include a chat model. Copying the image to another machine does not move the right to run it. Copying a brick does not move that right. The brick does not contain this license. This license does not charge a card. Payment for the public trial stays on kbmill.com.

--- chunk_id: chunk-0007
source_document: LICENSE.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 134
content_hash: 7888f9718400e6c1
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: The shelf
document_type: technical_reference

## The shelf

An unsigned brick still belongs on the shelf. A brick with a stale signature still belongs on the shelf. Signing a brick does not put it on the shelf. The shelf has its own license. A desk license does not start the shelf. ### End
KBMill may end this license in writing if the image is run on a host the file does not name. The buyer may stop using the image on that host. Ending the license does not take the buyer's brick. Questions and failures go to Contact operator, or to carroll@kbmill.com. Carroll Miller, d/b/a KBMill.

--- chunk_id: chunk-0008
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 41
content_hash: c1aaf9eb120a6746
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: KBMill Desktop install and troubleshooting
document_type: technical_reference

# KBMill Desktop install and troubleshooting

This is the install and troubleshooting guide for the desk image. It is not the operating manual. The manual is already inside the image. 2026-10-10.

--- chunk_id: chunk-0009
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 225
content_hash: f02acc2fefeecf05
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
section_heading: Load the file
document_type: technical_reference

## Load the file

The file is `kbmill-desk.tar`. The tag is `kbmill-desk:0.1.0`. The file is 114298880 bytes. It fits one single-layer DVD. Load it with the container engine the machine already allows. Docker or Podman. Do not pull an image. The network can stay off. Podman 3.4 loads this tag as `localhost/kbmill-desk:0.1.0`. Use that name on Podman 3.4. Docker uses `kbmill-desk:0.1.0`. The window is KBMill Desktop. The package inside the image is `vectorforge_pro`. ### Show the fingerprint
Run this inside the desk container. Do not install a package to get it. `python3 -m vectorforge_pro.plant_license`

It prints one line. That line is the fingerprint. It is not the hostname. The command does not read the license. Send that line through Contact operator on kbmill.com, or email it to carroll@kbmill.com. KBMill sends a signed file back. There is no download URL. If the command prints `FINGERPRINT_UNAVAILABLE`, the container cannot see an id. Mount the machine's `/etc/machine-id` at `/host/machine-id`, read-only, and run the command again. A virtual machine usually needs that mount.

--- chunk_id: chunk-0010
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 265
content_hash: 3a2a7358b4064523
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
section_heading: Put the license where the desk reads it
document_type: technical_reference

## Put the license where the desk reads it

Point `VF_AUDIT_LICENSE` at the file KBMill sent. If you do not set the variable, the image reads `/var/lib/kbmill/license.json`. Use the desk file only. A plant license does not start the desk. A shelf license does not start the desk. The image listens on `127.0.0.1:8766` after the license is accepted. `GET /` returns the window title KBMill Desktop and that listen address. ### Open a brick
The brick file is the handoff. The desk opens a finished brick, a folder with `kb.json` and `chunks.jsonl`, or a portable zip. A folder of source PDFs is the wrong object. Send that pile to the plant. The image answers these calls on `127.0.0.1:8766`:

- `POST /brick/open` opens the brick and returns its id and chunk ids. - `POST /brick/seen` marks one chunk seen. - `POST /brick/commit` writes one chunk's text. - `POST /brick/sign` records a name against the brick as it sits. `link_bricks` is not a route on this desk. The screen control that opens a zip by path is not on the window yet. Do not tell a person to click it. The calls above are how this image opens, marks, and signs.

--- chunk_id: chunk-0011
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 288
content_hash: d3c040be86041b14
prev_chunk_id: chunk-0010
next_chunk_id: chunk-0012
section_heading: The manual in the image
document_type: technical_reference

## The manual in the image

The operating manual is at `/usr/local/share/kbmill/MANUAL.md`. The image can open it as the brick KBMill_Manual. Read that manual for the plant, the shelf, and the review screen. This guide is only how to load the desk and what the refusals mean. No chat model is in the image. The organization brings its own. ### When the desk refuses
Use the line in front of you. | What you see | What to do |
|---|---|
| `auditor license missing` | Point `VF_AUDIT_LICENSE` at the desk file KBMill sent, or place that file at `/var/lib/kbmill/license.json`. |
| `auditor license does not name this host` | The file names another machine. Send this machine's fingerprint. Do not send the hostname. |
| `auditor license signature refused` | The file is not a signed desk license. Use the file KBMill sent. |
| `plant license does not start the desk` | That file is a plant license. Use the desk license. |
| `shelf license does not start the desk` | That file is a shelf license. Use the desk license. |
| `host fingerprint unavailable` | Mount `/etc/machine-id` at `/host/machine-id`, read-only, and print the fingerprint again. | A missing license does not open a brick. It does not stop the fingerprint command.

--- chunk_id: chunk-0012
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 148
content_hash: 432b0c22b314c73b
prev_chunk_id: chunk-0011
next_chunk_id: null
section_heading: The shelf
document_type: technical_reference

## The shelf

Signing a brick does not put it on the shelf. Copy the brick into the library folder, then build the catalog from inside the shelf image. An unsigned brick still belongs on the shelf. A stale signature still belongs on the shelf. The shelf does not read the desk's signature to decide whether to search. This brick is named KBMill_Desktop_Install. That is the name for the next KBMill Desktop disc. ### Complaints
There is one path back to the operator. Use Contact operator on kbmill.com, or email carroll@kbmill.com. An air-gapped machine still has this guide and the manual. Send the note from a machine that can reach them.
