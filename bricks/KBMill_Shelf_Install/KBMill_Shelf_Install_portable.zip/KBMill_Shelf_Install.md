--- chunk_id: chunk-0000
source_document: SPEC.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 21
content_hash: 837bf280fefe5ad7
prev_chunk_id: null
next_chunk_id: chunk-0001
section_heading: KBMill shelf
document_type: specification

# KBMill shelf

Spec sheet for the Linux image that ran. Carroll Miller, d/b/a KBMill. 2026-10-10.

--- chunk_id: chunk-0001
source_document: SPEC.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 424
content_hash: 47c68e52dba6855a
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
section_heading: Names
document_type: specification

## Names

This image is the shelf. The Constructor is this shelf. The package inside the image is `vectorforge_pro`. KBMill and that package are the same vendor. The image file is `kbmill-shelf.tar`. The tag is `kbmill-shelf:0.1.0`. The file is 1966346240 bytes. A single-layer DVD-5 holds 4707319808 bytes, so this file fits one DVD. No disc has been burned. This file has not been written as an ISO. ### What the image contains
The image answers a question from bricks it has been given. It does not mill, and it does not edit a brick. No chat model is in the image. The question is embedded with the weights in the image. The baked config is `/usr/local/share/kbmill/shelf.json`. The library folder is `/library`. The listen address is `127.0.0.1:8772`. A model calls the shelf at `/mcp` on that door. The tools are `list_shelf`, `open_set`, and `search_shelf`. `list_shelf` reads the card. `open_set` chooses at most 3 bricks by default, and 4 at the hard stop. `search_shelf` returns cites from those bricks. A muted chunk stays out of the cites. `link_bricks` is not a tool. `GET /status` reports the library folder, whether the card is loaded, and the counts. It does not return a passage. There is no drop page and no config page. The tool call has no password. The catalog is written from inside the image. On the baked library path the command is `python3 -m vectorforge_pro.indexer build /library`. That writes `catalog.json` and `CATALOG.md` in `/library`. A later batch uses `python3 -m vectorforge_pro.indexer update`. The shelf server does not build the catalog by itself. The license marker `/usr/local/share/kbmill/license.required` is inside the image. The image listens only when a signed shelf license names this host. The variable is `VF_SHELF_LICENSE`. When that variable is unset, the file is `/var/lib/kbmill/license.json`. Docker and Podman both load this file. Nothing is pulled. Podman 3.4 shows the tag as `localhost/kbmill-shelf:0.1.0`. The container runs with the network off.

--- chunk_id: chunk-0002
source_document: SPEC.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 182
content_hash: 88080530fdf59cee
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
section_heading: What the image does not contain
document_type: specification

## What the image does not contain

The image does not run the mill, the desk, or the public door. It does not charge a card. The license private key is not in the image. The operating manual is not in this image. There is no upload route. ### The host
One purchase is one host. The host is the fingerprint the image prints, not the hostname. A plant license does not start the shelf. A desk license does not start the shelf. A license for another fingerprint does not start the shelf. A missing file does not start the shelf. The fingerprint command, run inside the shelf container, is `python3 -m vectorforge_pro.plant_license`. That command prints one line and does not read the license. The buyer sends that line through Contact operator. There is no download URL.

--- chunk_id: chunk-0003
source_document: SPEC.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 209
content_hash: b1398123b66f73b8
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: The brick
document_type: specification

## The brick

The brick file is the handoff. The plant writes it. This shelf searches it. The desk may edit it and sign it. An unsigned brick still belongs on the shelf. A stale signature still belongs on the shelf. Copying a brick into the library folder does not put it on the card until the catalog is built from inside this image. ### What was run
A Linux guest with no copy of the repository loaded this file. Docker and Podman each ran it with the network off. With no license, both refused. With a plant license, both refused. With a shelf license for that guest, both listed the card, chose a brick, and returned cites from that brick. `link_bricks` was refused. The weights in the image embedded the question. Nothing was fetched. The private key was not on that guest. The guest's plant door was left running. Loading this file did not replace it.

--- chunk_id: chunk-0004
source_document: LICENSE.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 66
content_hash: 7c358548b66b16c0
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: KBMill shelf license
document_type: technical_reference

# KBMill shelf license

This file is the agreement. It is between Carroll Miller, doing business as KBMill, and the person or organization that receives a signed license file for the KBMill shelf. A summary of this file, including a summary written by a model, is not the agreement. 2026-10-10.

--- chunk_id: chunk-0005
source_document: LICENSE.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 246
content_hash: 70887afe3ca4d092
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
section_heading: The grant
document_type: technical_reference

## The grant

KBMill grants the right to run the KBMill shelf image on one host. The Constructor is this shelf. The package inside the image is `vectorforge_pro`. KBMill and that package are the same vendor. One purchase is one host. The host is the fingerprint the image prints. The host is not the hostname. The buyer does not edit that line and does not compute it by hand. ### The signed file
KBMill signs a file that names that fingerprint. The private key that signs it stays with KBMill. The key is not in the image, and it is not part of the file the buyer receives. The buyer runs this command inside the shelf container:

`python3 -m vectorforge_pro.plant_license`

It prints one line. The buyer sends that line through Contact operator on kbmill.com, or by email to carroll@kbmill.com. KBMill sends the signed file back. There is no download URL. The buyer points `VF_SHELF_LICENSE` at that file. If the variable is unset, the image reads `/var/lib/kbmill/license.json`. The installed image contains `/usr/local/share/kbmill/license.required`, so it asks for this file. A machine without that marker does not ask.

--- chunk_id: chunk-0006
source_document: LICENSE.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 206
content_hash: 8ed707636d945524
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
section_heading: What the host may do
document_type: technical_reference

## What the host may do

On the named host, the shelf may list the card, choose bricks for a question, and return cites from those bricks. It may build the catalog from bricks copied into its library folder. The brick file is the handoff. The buyer keeps the brick. ### What this license does not grant
A plant license does not start the shelf. A desk license does not start the shelf. A file that names another fingerprint does not start the shelf. A missing file does not start the shelf. This license does not run the mill, does not run the desk, and does not include a chat model. Copying the image to another machine does not move the right to run it. Copying a brick does not move that right. The brick does not contain this license. This license does not charge a card. Payment for the public trial stays on kbmill.com.

--- chunk_id: chunk-0007
source_document: LICENSE.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 150
content_hash: 660db8959a595a2e
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: The brick
document_type: technical_reference

## The brick

An unsigned brick still belongs on the shelf. A brick with a stale signature still belongs on the shelf. Signing a brick does not put it on the shelf. Milling a brick does not put it on the shelf. The plant and the desk have their own licenses. A shelf license does not start them. ### End
KBMill may end this license in writing if the image is run on a host the file does not name. The buyer may stop using the image on that host. Ending the license does not take the buyer's brick. Questions and failures go to Contact operator, or to carroll@kbmill.com. Carroll Miller, d/b/a KBMill.

--- chunk_id: chunk-0008
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 41
content_hash: b4cdcd6092bd0a36
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
section_heading: KBMill shelf install and troubleshooting
document_type: technical_reference

# KBMill shelf install and troubleshooting

This is the install and troubleshooting guide for the shelf image. It is not the operating manual. This image does not carry the manual. 2026-10-10.

--- chunk_id: chunk-0009
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 225
content_hash: 901166f3c9097abf
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
section_heading: Load the file
document_type: technical_reference

## Load the file

The file is `kbmill-shelf.tar`. The tag is `kbmill-shelf:0.1.0`. The file is 1966346240 bytes. It fits one single-layer DVD. Load it with the container engine the machine already allows. Docker or Podman. Do not pull an image. The network can stay off. Podman 3.4 loads this tag as `localhost/kbmill-shelf:0.1.0`. Use that name on Podman 3.4. Docker uses `kbmill-shelf:0.1.0`. The Constructor is this shelf. The package inside the image is `vectorforge_pro`. ### Show the fingerprint
Run this inside the shelf container. Do not install a package to get it. `python3 -m vectorforge_pro.plant_license`

It prints one line. That line is the fingerprint. It is not the hostname. The command does not read the license. Send that line through Contact operator on kbmill.com, or email it to carroll@kbmill.com. KBMill sends a signed file back. There is no download URL. If the command prints `FINGERPRINT_UNAVAILABLE`, the container cannot see an id. Mount the machine's `/etc/machine-id` at `/host/machine-id`, read-only, and run the command again. A virtual machine usually needs that mount.

--- chunk_id: chunk-0010
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 285
content_hash: b1989bc2a02d6547
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
section_heading: Put the license where the shelf reads it
document_type: technical_reference

## Put the license where the shelf reads it

Point `VF_SHELF_LICENSE` at the file KBMill sent. If you do not set the variable, the image reads `/var/lib/kbmill/license.json`. Use the shelf file only. A plant license does not start the shelf. A desk license does not start the shelf. The baked config is `/usr/local/share/kbmill/shelf.json`. The library folder in that file is `/library`. The listen address is `127.0.0.1:8772`. A missing license does not stop the fingerprint command. A missing license does stop the shelf from listening. ### Ask the shelf
A model calls the shelf at `/mcp` on `http://127.0.0.1:8772`. The tools are `list_shelf`, `open_set`, and `search_shelf`. They are tool names, not URL paths. Do not post them to the plant door. `list_shelf` reads the card. `open_set` chooses at most 3 bricks by default, and 4 at the hard stop. `search_shelf` returns cites from those bricks. A muted chunk stays out of the cites. `link_bricks` is not a tool. `GET /status` reports the library folder, whether the card is loaded, and the counts. It does not return a passage. There is no drop page and no config page. The tool call has no password. No chat model is in the image. The question is embedded with the weights in the image. The organization brings its own model.

--- chunk_id: chunk-0011
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 349
content_hash: 80c631e045f55e61
prev_chunk_id: chunk-0010
next_chunk_id: chunk-0012
section_heading: Put a brick on the card
document_type: technical_reference

## Put a brick on the card

Copy the brick folder, or the portable zip, into `/library`. Then build the catalog from inside the shelf container. Do not install a package to do it. Do not run this command on the host. `python3 -m vectorforge_pro.indexer build /library`

That writes `catalog.json` and `CATALOG.md` in `/library`. A later batch uses `python3 -m vectorforge_pro.indexer update` against the catalog already in that folder. The shelf server does not build the catalog by itself. The plant does not. The desk does not. Signing a brick does not. An unsigned brick still belongs on the shelf. A stale signature still belongs on the shelf. ### When the shelf refuses
Use the line in front of you. The shelf prints the line and does not listen. | What you see | What to do |
|---|---|
| `shelf license missing` | Point `VF_SHELF_LICENSE` at the shelf file KBMill sent, or place that file at `/var/lib/kbmill/license.json`. |
| `shelf license does not name this host` | The file names another machine. Send this machine's fingerprint. Do not send the hostname. |
| `shelf license signature refused` | The file is not a signed shelf license. A desk license does not start the shelf. Use the file KBMill sent. |
| `plant license does not start the shelf` | That file is a plant license. Use the shelf license. |
| `host fingerprint unavailable` | Mount `/etc/machine-id` at `/host/machine-id`, read-only, and print the fingerprint again. | A missing license does not answer a question. It does not stop the fingerprint command.

--- chunk_id: chunk-0012
source_document: INSTALL.md
page: 1
quality: 1.0
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 102
content_hash: 9f86e9ac42f3011f
prev_chunk_id: chunk-0011
next_chunk_id: null
section_heading: The disc
document_type: technical_reference

## The disc

This brick is named KBMill_Shelf_Install. That is the name for the next KBMill shelf disc. The image file is 1966346240 bytes and fits one DVD. No disc has been burned. This file has not been written as an ISO. ### Complaints
There is one path back to the operator. Use Contact operator on kbmill.com, or email carroll@kbmill.com. An air-gapped machine still has this guide. Send the note from a machine that can reach them.
