# Security report — NASA_AMBR_Engine_Information_Summary

Scan: `vectorforge_kb_security_v1`
When: 2026-08-17T16:54:11

## Verdict

**No blocking findings.**

The plant did not find a blocking match in the checks below. That is not a clearance, a DLP pass, or a promise that the source documents are safe.

## What this scan checked

- AWS-like access keys (AKIA…)
- AWS secret-key assignments
- API keys shaped like sk-…
- PEM / OpenSSH private-key blocks
- Hardcoded password / api_key / secret_token assignments
- Three common prompt-injection phrases (ignore previous instructions / disregard prior rules / you are now in developer mode)
- Home-directory paths in metadata and artifacts (/home/…, /Users/…, C:\Users\…)
- Zip-slip paths in an already-built portable ZIP (if one is on disk)

## What this scan does not check

- Enterprise DLP or data-loss prevention
- PII, PHI, CUI, ITAR, or any classification authority
- Malware, viruses, or macros in the files you uploaded
- A full prompt-injection red team — only the three phrases above
- Legal clearance, copyright, or export-control review
- Vulnerability scanning of code inside the corpus
- Whether those source documents should have been uploaded
- Whether this brick is cleared to join your larger system

This report is an effort to ship a solid package. It does not absolve you of the responsibilities you have for your own system. What to upload, and whether you may share it, is still your trusted people.

## Findings

None.

## How to read this

This report ships with the brick so you can see the plant's own homework. It is a heuristic pass over the milled artifacts, not a security product, and not a stand-in for your system or your trusted people.
