---
kb_id: nasa-ambr-engine-information-summary-may-2009
title: NASA AMBR Engine Information Summary (May 2009)
author: NASA / In-Space Propulsion Technology (ISPT), Glenn Research Center
created_date: 2009-05
classification: us_government
confidence_level: High
domain_tags: ["NASA", "AMBR", "bipropellant", "thruster", "in-space propulsion"]
entity_mentions: ["system specifications", "system-level", "system analysis", "System Summary", "system cost", "system is", "system supplies", "system and", "system hardware", "system shown", "System Components"]
document_type: technical_reference
primary_subject: Advanced Materials Bi-propellant Rocket (AMBR) engine performance and mission use
intended_audience: Spacecraft propulsion engineers / mission designers
sources: [{"filename": "35AMBR_NF-AOrefdocument_May09.pdf", "path": "docs/Test docs/35AMBR_NF-AOrefdocument_May09.pdf", "page_count": 9}]
ingest_provenance: {"captured_at": "2026-07-31T13:39:39.452406", "page_count": 9, "extraction_methods": {"pymupdf": 9}, "avg_extraction_quality": 0.9789, "docling_triage_pages": 0, "docling_triage_rate": 0.0, "extraction_stats": {"page_count": 9, "total_document_pages": 9, "page_range": null, "docling_triage_count": 0, "docling_executed_count": 0, "docling_page_count": 0, "docling_triage_rate": 0.0, "camelot_pages": 0, "tables_extracted": 0, "pass1_ms": 101.27, "pass2_ms": 4.55, "total_ms": 107.55, "pages_per_sec": 83.68}}
dark_data_inferred_fields: ["entity_mentions", "ingest_provenance", "kb_id", "sources"]
date: 2009-05
source_rights: US Government work (NASA); generally not subject to US copyright (17 U.S.C. § 105). Derived retrieval package only.
kb_name: NASA_AMBR_Engine_Information_Summary
created: 2026-07-31T13:39:39.452496
kb_version: 1
schema_version: vectorforge_kb_v1
total_chunks: 22
extraction_quality:
  average: 0.97
embedding_provenance:
  model: nomic-embed-text
  model_version: v1.5
  backend: native
  dimensions: 768
  indexed_at: 2026-07-31T13:39:45.018166
  chunk_count: 22
  strict_air_gapped: true
---

## Extracted Images

Images were extracted from the source documents and saved alongside this Markdown for portability.

![Figure from page 2](images/p002_img00.png)
*Context (from source page): The NASA Science Mission Directorate (SMD) funds the 
In-Space Propulsion Technology (ISPT) Project Office 
located in the NASA John H. Glenn Research Center in 
Cleveland, Ohio. 
 
1.2  System Summary 
The AMBR engine is a high performance bipropell...*
*(Dimensions: 664×362)*

![Figure from page 2](images/p002_img01.jpeg)
*Context (from source page): The NASA Science Mission Directorate (SMD) funds the 
In-Space Propulsion Technology (ISPT) Project Office 
located in the NASA John H. Glenn Research Center in 
Cleveland, Ohio. 
 
1.2  System Summary 
The AMBR engine is a high performance bipropell...*
*(Dimensions: 682×405)*

![Figure from page 3](images/p003_img00.png)
*Context (from source page): For AMBR, the PPI El-FormTM process was finally down-
selected due primarily to the lower development unit costs 
and production cost estimates.  The El-FormTM process 
carries more process risk than CVD since its development is 
less mature than CVD...*
*(Dimensions: 540×408)*

![Figure from page 5](images/p005_img00.jpeg)
*Context (from source page): thrust and performance, would need to be defined based on 
the level of margin required for the application. A notional 
AMBR engine operating box based on performance data is 
shown in Figure 4.  No combustion instability was observed 
in the hotfir...*
*(Dimensions: 969×64)*

![Figure from page 5](images/p005_img01.jpeg)
*Context (from source page): thrust and performance, would need to be defined based on 
the level of margin required for the application. A notional 
AMBR engine operating box based on performance data is 
shown in Figure 4.  No combustion instability was observed 
in the hotfir...*
*(Dimensions: 969×64)*

![Figure from page 5](images/p005_img02.png)
*Context (from source page): thrust and performance, would need to be defined based on 
the level of margin required for the application. A notional 
AMBR engine operating box based on performance data is 
shown in Figure 4.  No combustion instability was observed 
in the hotfir...*
*(Dimensions: 475×112)*

![Figure from page 5](images/p005_img03.jpeg)
*Context (from source page): thrust and performance, would need to be defined based on 
the level of margin required for the application. A notional 
AMBR engine operating box based on performance data is 
shown in Figure 4.  No combustion instability was observed 
in the hotfir...*
*(Dimensions: 969×64)*

![Figure from page 5](images/p005_img04.jpeg)
*Context (from source page): thrust and performance, would need to be defined based on 
the level of margin required for the application. A notional 
AMBR engine operating box based on performance data is 
shown in Figure 4.  No combustion instability was observed 
in the hotfir...*
*(Dimensions: 969×64)*

![Figure from page 5](images/p005_img05.jpeg)
*Context (from source page): thrust and performance, would need to be defined based on 
the level of margin required for the application. A notional 
AMBR engine operating box based on performance data is 
shown in Figure 4.  No combustion instability was observed 
in the hotfir...*
*(Dimensions: 969×64)*

![Figure from page 5](images/p005_img06.jpeg)
*Context (from source page): thrust and performance, would need to be defined based on 
the level of margin required for the application. A notional 
AMBR engine operating box based on performance data is 
shown in Figure 4.  No combustion instability was observed 
in the hotfir...*
*(Dimensions: 969×64)*

![Figure from page 5](images/p005_img07.jpeg)
*Context (from source page): thrust and performance, would need to be defined based on 
the level of margin required for the application. A notional 
AMBR engine operating box based on performance data is 
shown in Figure 4.  No combustion instability was observed 
in the hotfir...*
*(Dimensions: 969×64)*

![Figure from page 5](images/p005_img08.jpeg)
*Context (from source page): thrust and performance, would need to be defined based on 
the level of margin required for the application. A notional 
AMBR engine operating box based on performance data is 
shown in Figure 4.  No combustion instability was observed 
in the hotfir...*
*(Dimensions: 969×64)*

![Figure from page 5](images/p005_img09.jpeg)
*Context (from source page): thrust and performance, would need to be defined based on 
the level of margin required for the application. A notional 
AMBR engine operating box based on performance data is 
shown in Figure 4.  No combustion instability was observed 
in the hotfir...*
*(Dimensions: 969×64)*

![Figure from page 5](images/p005_img10.jpeg)
*Context (from source page): thrust and performance, would need to be defined based on 
the level of margin required for the application. A notional 
AMBR engine operating box based on performance data is 
shown in Figure 4.  No combustion instability was observed 
in the hotfir...*
*(Dimensions: 969×64)*

![Figure from page 5](images/p005_img11.jpeg)
*Context (from source page): thrust and performance, would need to be defined based on 
the level of margin required for the application. A notional 
AMBR engine operating box based on performance data is 
shown in Figure 4.  No combustion instability was observed 
in the hotfir...*
*(Dimensions: 969×64)*

![Figure from page 5](images/p005_img12.jpeg)
*Context (from source page): thrust and performance, would need to be defined based on 
the level of margin required for the application. A notional 
AMBR engine operating box based on performance data is 
shown in Figure 4.  No combustion instability was observed 
in the hotfir...*
*(Dimensions: 969×64)*

![Figure from page 6](images/p006_img00.png)
*Context (from source page): (ACS) thrusters share the hydrazine monopropellant with the 
main engine which also uses the hydrazine from the same 
supply system as fuel for combustion with an oxidizer. 
Appendix A describes the method used to derive the mission 
information. 
 
...*
*(Dimensions: 486×109)*

![Figure from page 7](images/p007_img00.jpeg)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 92×20)*

![Figure from page 7](images/p007_img01.jpeg)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 92×20)*

![Figure from page 7](images/p007_img02.jpeg)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 92×22)*

![Figure from page 7](images/p007_img03.jpeg)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 92×22)*

![Figure from page 7](images/p007_img04.jpeg)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 92×22)*

![Figure from page 7](images/p007_img05.jpeg)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 92×22)*

![Figure from page 7](images/p007_img06.jpeg)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 132×56)*

![Figure from page 7](images/p007_img07.jpeg)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 132×56)*

![Figure from page 7](images/p007_img08.png)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 126×126)*

![Figure from page 7](images/p007_img09.jpeg)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 158×29)*

![Figure from page 7](images/p007_img10.jpeg)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 158×29)*

![Figure from page 7](images/p007_img11.jpeg)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 158×29)*

![Figure from page 7](images/p007_img12.jpeg)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 158×28)*

![Figure from page 7](images/p007_img13.png)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 177×252)*

![Figure from page 7](images/p007_img14.jpeg)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 92×20)*

![Figure from page 7](images/p007_img15.jpeg)
*Context (from source page): Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is cho...*
*(Dimensions: 92×20)*

---

--- chunk_id: chunk-0000
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 1
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 481
content_hash: 044e4118a0d9376d
prev_chunk_id: null
next_chunk_id: chunk-0001
document_type: technical_reference

Advanced Materials Bi-propellant Rocket (AMBR) 
 Engine Information Summary 
May 2009 
 
 
Summary:  The Advanced Material Bi-propellant Rocket 
(AMBR) engine is a high performance (Isp), higher thrust, 
radiation cooled, storable bi-propellant space engine of the 
same physical envelope as the High Performance Apogee 
Thruster (HiPATTM). To provide further information about 
the AMBR engine, this document provides details on 
performance, development, mission implementation, key 
spacecraft integration considerations, project participants 
and approach, contact information, system specifications, 
and a list of references. The In-Space Propulsion 
Technology (ISPT) project team at NASA Glenn Research 
Center (GRC) leads the technology development of the 
AMBR engine. Their NASA partners were Marshall Space 
Flight Center (MSFC) and the Jet Propulsion Laboratory 
(JPL). Aerojet leads the industrial partners selected 
competitively for the technology development via the NASA 
Research Announcement (NRA) process. 1. INTRODUCTION 
 
1.1  Background 
While the need generally exists for higher performance 
propulsion systems, the component technologies have to 
mature for any new, successful engine development to take 
place. In September 2006, a NASA/industry joint effort was 
initiated to boost the (specific impulse, Isp) performance of 
Aerojet’s HiPATTM engine. The motivation was to attain a 
more efficient, storable bi-propellant engine that will benefit 
future NASA’s planetary science missions. By increasing 
the specific impulse and thrust, the more efficient engines 
can enable near-term missions, enhance their science 
capability and returns, reduce mission cost, and cut transit 
time. The developmental effort is called AMBR, which 
stands for the “Advanced Material Bi-propellant Rocket” 
where the “advanced material” refers to the iridium (Ir)-
coated rhenium (Re) combustion chamber fabricated using 
the EL-FormTM process. The AMBR engine development aims for two major 
objectives: 
1. higher specific impulse engine performance 
2. lower 
fabrication 
cost 
for 
the 
iridium/rhenium 
combustion chamber 
 
To initiate the effort, NASA Marshall Space Flight Center 
(NASA-MSFC) and NASA Jet Propulsion Laboratory 
(NASA-JPL) conducted mission-level and system-level 
studies to translate the target engine performance into 
spacecraft performance. Four conceptual missions were 
selected and used for the analyses based on the current 
scientific interest, launch vehicle capability, and trends in 
spacecraft size: 
 
•  
GTO to GEO, 4800 kg, ΔV for GEO insertion only 
~1830 m/s 
•  
Enceladus Orbiter (Titan aerocapture) 6620 kg, ΔV 
~2400 m/s.

--- chunk_id: chunk-0001
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 1
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 512
content_hash: f8176eb572732ed9
prev_chunk_id: chunk-0000
next_chunk_id: chunk-0002
document_type: technical_reference

lower 
fabrication 
cost 
for 
the 
iridium/rhenium 
combustion chamber 
 
To initiate the effort, NASA Marshall Space Flight Center 
(NASA-MSFC) and NASA Jet Propulsion Laboratory 
(NASA-JPL) conducted mission-level and system-level 
studies to translate the target engine performance into 
spacecraft performance. Four conceptual missions were 
selected and used for the analyses based on the current 
scientific interest, launch vehicle capability, and trends in 
spacecraft size: 
 
•  
GTO to GEO, 4800 kg, ΔV for GEO insertion only 
~1830 m/s 
•  
Enceladus Orbiter (Titan aerocapture) 6620 kg, ΔV 
~2400 m/s. •  
Europa Orbiter, 2170 kg, total ΔV ~2600 m/s 
•  
Mars Orbiter, 2250 kg, total ΔV ~1860 m/s 
 
Applying the target AMBR engine specific impulse of 335 
seconds (approximately seven seconds higher than the state-
of-the-art), the study shows a 23 percent payload gain for the 
Mars Orbiter mission. Similar payload gains are also 
evident for the other missions. Additional AMBR engine 
improvements include the increased thrust level as compared 
to the 100 lbf baseline engine HiPATTM with expected 
performance benefits for deep gravity well missions. Also,  
its fabrication cost is lower than the same baseline. The 
chamber fabrication is estimated to be reduced by 30 percent 
(achieved through the higher production yield rate and lower 
rhenium materials cost associated with the combustion 
chamber). Additional cost savings are anticipated due to 
other design and processing changes that have not yet been 
quantified. Hotfire performance verification for the AMBR flight-like, 
developmental prototype engine took place in October of 
2008. It was followed by environmental (shock and 
vibration). Additional envelope testing took place in 
February of 2009 and follow-on testing is planned for 
summer of 2009. The development plan is completed by the 
end of FY2009 with the AMBR engine prototype 
demonstrated in a relevant-ground environment to TRL 6 for 
a range of SMD missions. The NASA In-Space Propulsion Technology Project Office 
contracted the AMBR engine development through a NASA 
Research Announcement (NRA) Cycle 3a contract (contract 
number NNM06AA93C) with the Aerojet Company at 
Redmond, WA. Other contributors to the effort are: 
• 
Jet Propulsion Laboratory performed the mission and 
benefits analysis and the prototype shock test. • 
NASA Marshall Space Flight Center performed the 
AMBR propulsion system analysis, and the high 
temperature refractory metal material analysis and 
testing. • 
NASA Glenn Research Center managed the AMBR 
development since late 2006.

--- chunk_id: chunk-0002
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 1
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 72
content_hash: 37d02557d23782f7
prev_chunk_id: chunk-0001
next_chunk_id: chunk-0003
document_type: technical_reference

• 
NASA Marshall Space Flight Center performed the 
AMBR propulsion system analysis, and the high 
temperature refractory metal material analysis and 
testing. • 
NASA Glenn Research Center managed the AMBR 
development since late 2006. • 
Plasma Process, Inc., Huntsville, AL (PPI) performed 
the Ir/Re chamber fabrication. AMBR Document for New Frontiers Library 
1 
04/29/09

--- chunk_id: chunk-0003
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 2
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 504
content_hash: 992f1cef36cd00b3
prev_chunk_id: chunk-0002
next_chunk_id: chunk-0004
section_heading: 1.2  System Summary
document_type: technical_reference

The NASA Science Mission Directorate (SMD) funds the 
In-Space Propulsion Technology (ISPT) Project Office 
located in the NASA John H. Glenn Research Center in 
Cleveland, Ohio. 1.2  System Summary 
The AMBR engine is a high performance bipropellant 
engine using the iridium/rhenium chamber technology to 
obtain 333.5 seconds specific impulse (Isp) with nitrogen 
tetroxide (NTO) and hydrazine (N2H4) propellants. AMBR 
engine promises to benefit significantly interplanetary 
missions by enabling reduced launch weight and/or 
increased payload and reducing propulsion system cost. Figures 1 and 2 are a line drawing containing physical 
dimensions and a color graphic of the AMBR thruster. 23.5(596.9)
2.47 (62.74)
Dimensions: inches (mm)
14.600
(370.84)
0.38 (9.52)
23.5(596.9)
2.47 (62.74)
Dimensions: inches (mm)
14.600
(370.84)
0.38 (9.52)
 
 
Figure 1. AMBR Thruster Physical Dimensions 
 
 
 
 
Figure 2. A Color Rendition of the AMBR Thruster 
 
AMBR 
engine 
development 
targeted 
the 
following 
specifications: 
• 
335 seconds steady-state Isp with NTO/N2H4 (by test) 
• 
3-10 years mission life (by analysis & similarity) 
• 
one hour operating (firing) time (by test) 
 
AMBR Document for New Frontiers Library 
2

Table 1 shows AMBR design characteristics side-by-side 
with the Aerojet’s HiPATTM Dual Mode engine, which is the 
baseline for AMBR development. Table 1:  AMBR Characteristics Demonstrated 
Compared with the Baseline HiPATTM Thruster 
 
DESIGN 
CHARACTERISTIC
AMBR 
HiPATTM DM 
Thrust (lbf) 
150 
100 
Specific Impulse (sec 
333.5 
328 
Inlet Pressure (psia 
275 
250 
Oxidizer/Fuel Ratio 
1.1 
1.0 
Expansion Ratio 
400:1 
375:1 
Physical Envelope 
Within existing HIPAT envelope 
Propellant Valves 
Existing R-4D valves 
 
AMBR is capable of operating at a temperature of 2470ºK.[4]  
The iridium/rhenium combustion chamber enables radiation 
cooling which sustains efficiency. It is fabricated using the 
advanced and cost reducing electroform process called EL-
FormTM. This process was selected after evaluating a group 
of 
candidates--Chemical 
Vapor 
Deposition 
(CVD), 
electroforming (El-Form), Low Pressure Plasma Spray 
(LPPS) and Vacuum Plasma Spray (VPS). Of the processes listed above, the well understood CVD is 
the incumbent process used to fabricate the R-4D-15 
HiPATTM thrust chambers. The only other process that has 
been used to fabricate an Ir/Re chamber for a bipropellant 
engine was El-FormTM. It was used successfully in 2004 to 
fabricate and test the Aerojet’s development engine R-42DM. Finally, neither LPPS nor VPS were ever used; therefore, 
they were dropped from consideration due to the lack of 
technical maturity.

--- chunk_id: chunk-0004
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 2
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 146
content_hash: 21c28e2da5c41e7b
prev_chunk_id: chunk-0003
next_chunk_id: chunk-0005
section_heading: 1.2  System Summary
document_type: technical_reference

It was used successfully in 2004 to 
fabricate and test the Aerojet’s development engine R-42DM. Finally, neither LPPS nor VPS were ever used; therefore, 
they were dropped from consideration due to the lack of 
technical maturity. The Figures of Merit used for the decision matrix were: 
• 
Cost – Nonrecurring 
• 
Cost – Recurring  
• 
Schedule – Nonrecurring 
• 
Schedule – Recurring 
• 
Producibility 
• 
Performance – Mechanical Properties 
• 
Performance – Thermal 
• 
Performance – Oxidation Resistance 
• 
Performance – Mass 
• 
Heritage/Risk – Design 
• 
Heritage/Risk – Manufacturing 
Weighting factors were assigned to the Figures of Merit 
based on the primary performance goals of the program. 2 
04/29/09

--- chunk_id: chunk-0005
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 2
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 42
content_hash: 3d380f2cc327d852
prev_chunk_id: chunk-0004
next_chunk_id: chunk-0006
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 1. AMBR Thruster Physical Dimensions](images/p002_img00.png)
*Figure 1. AMBR Thruster Physical Dimensions*

![Figure 2. A Color Rendition of the AMBR Thruster](images/p002_img01.jpeg)
*Figure 2. A Color Rendition of the AMBR Thruster*

--- chunk_id: chunk-0006
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 3
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 417
content_hash: a896c39925ddb683
prev_chunk_id: chunk-0005
next_chunk_id: chunk-0007
document_type: technical_reference

For AMBR, the PPI El-FormTM process was finally down-
selected due primarily to the lower development unit costs 
and production cost estimates. The El-FormTM process 
carries more process risk than CVD since its development is 
less mature than CVD. However, the added risk is deemed 
worth the potential rewards in reduced costs. Figure 3 below is a top-level schematic for a representative 
dual mode AMBR propulsion system. The system is “dual 
mode” because the same spacecraft fuel system supplies 
both the main engine and the Attitude Controlling System 
(ACS) thrusters (specific impulse of 210 seconds). Because 
of the similarity, the name ACS is interchangeable with 
Reaction Control System (RCS). This AMBR system and 
its components are designed and sized to enable assessments 
for potential mission benefit brought by the system. [4]  
 
 
 
Figure 3. Example of AMBR Propulsion System 
 
 
 
This representative AMBR propulsion system is single-fault-
tolerant based on flight proven HiPATTM design and can use 
a significant amount of the HiPATTM heritage hardware. Most of the system hardware is at Technology Readiness 
Level (TRL) of 9 (flight proven through successful mission 
operations). The component masses (e.g., valves, regulators, 
filters, etc.) are based on those onboard flight proven 
spacecraft like the Mercury Messenger and Space Shuttle. A 
ten percent design contingency is used for the hardware.  Factors of Safety: 
o Propellant Tanks – 1.5 
o Pressurant Tanks – 1.5 
 Materials: 
o Propellant Tanks – Ti (6Al-4V) 
o Pressurant Tanks – COPV 
 Operating Pressures 
o Propellant Tanks – 2.6 MPa (400 psia)  
 
o Pressurant Tanks – 31 MPa (4,500 psia) down to 
5.5 MPa (800 psia) 
 
1.3  Subsystem Summaries 
 Anti-slosh/propellant management device ~10 percent 
 Propellant-tank shell mass 
For the representative AMBR system shown above, the 
pressure vessel characteristics are: 
 Propellant tank ullage – 5 percent (regulated) 
 
 Propellant residual – 1 percent 
 
AMBR Document for New Frontiers Library 
3 
04/29/09

--- chunk_id: chunk-0007
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 3
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 29
content_hash: 53d42caa6782b565
prev_chunk_id: chunk-0006
next_chunk_id: chunk-0008
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 3 below is a top-level schematic for a representative](images/p003_img00.png)
*Figure 3 below is a top-level schematic for a representative*

--- chunk_id: chunk-0008
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 4
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 136
content_hash: 1f807b02fcab1deb
prev_chunk_id: chunk-0007
next_chunk_id: chunk-0009
document_type: technical_reference

 Helium pressurant – sized for isothermal blowdown 
As seen in Table 1, AMBR’s propellant inlet pressure is 
required to be 275 psia. Hence the tank pressure is set at 
275 psia and the tank is designed with a safety factor of 1.5. Tank material is fixed as titanium (6Al-4V), ullage volume 
at five percent and a surface tension propellant management 
device (PMD) is assumed to add ten percent to tank weight 
with one percent of the initial propellant load unusable. Table 2 shows a component list for the representative 
AMBR engine system. It contains mass estimates for a 
Europa orbiter mission.

--- chunk_id: chunk-0009
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 4
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 472
content_hash: 890963a324ce3ad5
prev_chunk_id: chunk-0008
next_chunk_id: chunk-0010
document_type: technical_reference

Table 2 shows a component list for the representative 
AMBR engine system. It contains mass estimates for a 
Europa orbiter mission. Table 2:  Representative Component List for an AMBR Engine System (Europa Orbiter Mission) 
 
Europa Lander
Comments:
Quantity
Propulsion System Components
(kg)
(lbm)
(kg)
(lbm)
2
Pressurant Tank (COPV)
10.5
23.1
21.0
46.2 Calculated Hardware
3
Fill and Drain Valve, Hign Press He
0.1
0.2
0.3
0.7 Messenger Hardware
6
Filter, He
0.11
0.2
0.7
1.5 Messenger Hardware
7
Pyro Valve, Pressurant
0.2
0.4
1.4
3.1 Messenger Hardware
Unit Mass
Total Mass
2
Pressure Regulator
2.31
5.1
4.6
10.2 STS OMS
1
High Pressure Transducer
0.23
0.5
0.2
0.5 Messenger Hardware
4
Check Valves
1.36
3.0
5.4
12.0 STS OMS
4
Transducer, Low pressure
0.23
0.5
0.9
2.0 Messenger Hardware
0
Burst Disk
0.1
0.2
0.0
0.0 STS OMS
0
Relief Valve
2.31
5.1
0.0
0.0 STS OMS
4
Ground Checkout Hand Valve
0.07
0.2
0.3
0.6 Messenger Hardware
2
Propellant Tanks, Fuel (w/ PMD)
18.1
39.8
36.2
79.6 Calculated Hardware
1
Propellant Tanks, Oxidizer (w/ PMD)
25
55.0
25.0
55.0 Calculated Hardware
3
Pyro Valve, Propellant
0.2
0.4
0.6
1.3 Messenger Hardware
2
ISO Valve, Propellant, RCS
0.65
1.4
1.3
2.9 Messenger Hardware
6
Fill and Drain Valve, Propellant
0.15
0.3
0.9
2.0 Messenger Hardware
3
Filter, Propellant
0.29
0.6
0.9
1.9 Messenger Hardware
6
Transducer, Low pressure
0.23
0.5
1.4
3.0 Messenger Hardware
12
RCS Thruster (22 N, 5 lbf thrust)
0.65
1.4
7.8
17.2 Aerojet MR-106E 22N
2
AMBR Thruster (91 N, 200 lbf thrust)
5.5
12.0
10.9
24.0
Miscellaneous Hardware
10%
12.0
26.4
Design Contingency
10%
13.2
29.0
Total Dry Weight
145.0
318.9
Propellant:  Usable
1111.7
2445.8
               Residuals
11.1
24.5
Pressurant:  Helium
1.7
3.8
TOTAL PROPULSION SYSTEM
1269.6
2793.0
 
 
 
The assumption is made that the spacecraft propellant 
requirements will determine the tank size. This assumption 
may not be practical as it is often preferable to select an 
existing flight proven tank, even though the size may not be 
optimal, to avoid the developmental cost for a new tank. Pressurant tanks are the next largest mass element of a 
propulsion system.

--- chunk_id: chunk-0010
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 4
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 249
content_hash: 695bf1a7beef3493
prev_chunk_id: chunk-0009
next_chunk_id: chunk-0011
document_type: technical_reference

This assumption 
may not be practical as it is often preferable to select an 
existing flight proven tank, even though the size may not be 
optimal, to avoid the developmental cost for a new tank. Pressurant tanks are the next largest mass element of a 
propulsion system. Propellants are pressure fed from the 
tanks to the engine, so a composite-overwrapped helium 
pressure vessel was selected with size calculated assuming 
adiabatic blowdown of gas initially at 4500 psia down to a 
minimum regulator inlet limit of 800 psia. For MSFC’s system model, component masses are based on 
the mass of existing hardware that is flight proven in the 
space environment (TRL 9) in spacecraft like the Mercury 
Messenger or Space Shuttle. Additionally, ten percent 
design contingency is applied to ensure that system mass is 
not under-estimated. 2. PERFORMANCE SUMMARY 
 
2.1 Performance Characteristics 
The AMBR engine peak performance characteristics are 
thrust level of 150 lbf, Isp of 333.5 seconds, greater than one 
hour operating (firing) time for a single burn, and 3-10 yrs 
mission life. A nominal operating condition, at reduced 
AMBR Document for New Frontiers Library 
4 
04/29/09

--- chunk_id: chunk-0011
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 5
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 253
content_hash: 63243121f1067ab7
prev_chunk_id: chunk-0010
next_chunk_id: chunk-0012
document_type: technical_reference

thrust and performance, would need to be defined based on 
the level of margin required for the application. A notional 
AMBR engine operating box based on performance data is 
shown in Figure 4. No combustion instability was observed 
in the hotfire testing using a substitute copper combustion 
chamber. Preliminary performance hotfire testing using the 
AMBR prototype Ir/Re chamber was completed in October 
of  2008. Figure 4:  Notional operating box for AMBR engine 
 
NASA MSFC and NASA JPL conducted mission level and 
system level studies to extrapolate improved engine 
performance into spacecraft requirements and performance. JPL chose four reference missions for this analysis based on 
scientific interest, current launch vehicle capability, and 
trends in spacecraft size (at the time when the analysis was 
performed 2006-2007 using the 200 lbf thrust baseline). Table 3 shows a summary of the results of the analyses. The 
Delft University of Technology provided the propulsion 
requirements for a GEO-sat, extrapolated for 15-year service 
life. [1] 
 
Table 3:  Summary of the Reference Missions 
 
 
 
The performance analysis assumes a dual-mode propulsion 
system. In a dual mode system, Attitude Control System 
AMBR Document for New Frontiers Library 
5 
04/29/09

--- chunk_id: chunk-0012
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 5
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 104
content_hash: 6f9957db0336be32
prev_chunk_id: chunk-0011
next_chunk_id: chunk-0013
section_heading: Figures
document_type: technical_reference

## Figures

![Figure 4:  Notional operating box for AMBR engine](images/p005_img00.jpeg)
*Figure 4:  Notional operating box for AMBR engine*

![Figure 4:  Notional operating box for AMBR engine](images/p005_img01.jpeg)
*Figure 4:  Notional operating box for AMBR engine*

![Figure from page 5](images/p005_img02.png)

![Figure from page 5](images/p005_img03.jpeg)

![Figure from page 5](images/p005_img04.jpeg)

![Figure from page 5](images/p005_img05.jpeg)

![Figure from page 5](images/p005_img06.jpeg)

![Figure from page 5](images/p005_img07.jpeg)

![Figure from page 5](images/p005_img08.jpeg)

![Figure from page 5](images/p005_img09.jpeg)

![Figure from page 5](images/p005_img10.jpeg)

![Figure from page 5](images/p005_img11.jpeg)

![Figure from page 5](images/p005_img12.jpeg)

--- chunk_id: chunk-0013
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 6
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 36
content_hash: 03589261225f64cd
prev_chunk_id: chunk-0012
next_chunk_id: chunk-0014
document_type: technical_reference

(ACS) thrusters share the hydrazine monopropellant with the 
main engine which also uses the hydrazine from the same 
supply system as fuel for combustion with an oxidizer.

--- chunk_id: chunk-0014
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 6
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 456
content_hash: 83da360fd59798c0
prev_chunk_id: chunk-0013
next_chunk_id: chunk-0015
section_heading: Appendix A describes the method used to derive the mission
document_type: technical_reference

Appendix A describes the method used to derive the mission 
information. Table 4 shows a summary of the propellant mass estimates 
calculated for reference missions at various main engine Isp 
values. The baseline Isp is 320 seconds for the GEO 
missions and 325 seconds for the planetary missions. AMBR thruster has an Isp of 335 seconds. The analysis 
assumes an ACS Isp of 230 seconds for monopropellant 
hydrazine. Table 4:  Propellant Estimates for the Four (4) Reference Missions 
 
 
 
 
These reference missions show the mass performance and 
benefits of the AMBR engine. 2.2  Benefits Over SOA 
The baseline engine for AMBR’s development is HiPATTM. The latter is currently the highest performing biprop engine 
in the 100-lbf thrust range with a specific impulse Isp of 328 
seconds. In contrast, the improved AMBR engine yields up 
to 150-lbf thrust, and its specific impulse is 333.5 seconds. Because of the increased specific impulse and thrust, the 
most significant benefit of AMBR is the mass benefit. AMBR’s increased thrust at 150 lbf enables better Thrust 
Vector Control (TVC). For example, a single engine is 
preferred for spacecraft with 150 lbf thrust operating for 
transit or orbit insertion. Compared to multiple engines 
supplying the same thrust, a single engine simplifies the 
gimbals and thrust vector control. Higher thrust level also provides options for descent and 
ascent in terms of the capability to carry a heavier load or a 
spacecraft design using fewer engines. AMBR’s utilization as a dual-mode engine, allows 
integration with the spacecraft RCS and ACS, using the 
same propellant, and simplifying the propulsion system 
design and operation. 2.3 Summary:  Potential Application to Candidate New 
Frontiers Missions 
The In-Space Propulsion Technology Project Office 
performed a high level assessment of the AMBR 
technology’s applicability towards the various candidate 
missions. The New Frontiers Program issued the results in 
the Community Announcement, May 12, 2008. Results of 
this assessment are in Table 5. The assessment in Table 5 is 
only preliminary and AMBR must be assessed specifically 
for each mission scenario. . AMBR Document for New Frontiers Library 
6 
04/29/09

--- chunk_id: chunk-0015
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 6
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 8
content_hash: 4206c0f4358f5534
prev_chunk_id: chunk-0014
next_chunk_id: chunk-0016
section_heading: Figures
document_type: technical_reference

## Figures

![Figure from page 6](images/p006_img00.png)

--- chunk_id: chunk-0016
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 7
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 422
content_hash: d50699be9d5ffe1d
prev_chunk_id: chunk-0015
next_chunk_id: chunk-0017
document_type: technical_reference

Table 5:  AMBR’s Applicability to Candidate NF Missions 
 
 
AMBR Benefits 
 
 
 
 
 
 
Comet Surface Sample 
Return (CSSR) 
• Small body rendezvous and sample return missions have 
significant ∆V requirements. If a chemically feasible 
target is chosen, the improved Isp would have clear 
benefits with little added risk. • AMBR improves: 
•   Propellant mass fraction 
•   Spacecraft margin/risk 
• High degree of applicability for a chemical CSSR 
Venus In-Situ Explorer 
(VISE) 
• A Venus In-Situ Explorer will benefit from direct entry, 
and therefore, not require any significant deep space 
maneuvers. • An orbiter mission would benefit from AMBR’s 
improved performance. • Limited VISE applicability 
Atkins, Basin Sample 
Return (ABSR) 
• Dependant on mission architecture and lander and ascent 
stage mass, AMBR may have appropriate thrust and 
throttle-ability. • A bipropellant engine may add unnecessary complexity to 
ABSR. • Limited ABSR applicability 
 
 
Asteroid 
SR 
• Asteroid SR chemical mission are extremely target 
dependent. Some asteroids are easier to reach than the 
moon, while many are chemically infeasible. • For targets applicable to chemical bi-propellant engines, 
AMBR would be appropriate. • High degree of applicability for a subset of ASR 
Ganymede or Io 
Observer 
• Orbiter missions to Ganymede and Io are propulsive 
challenges that could benefit from engine performance. Any chemical solution would clearly benefit from a bi-
propellant AMBR class engine. • Limited published analyses on Ganymede and Io Mission 
architectures. Analysis needed. • Applicable for Observers 
 
Trojan/Centaur 
• Trojan and Centaur chemical flyby missions obtain their 
necessary velocities by the launch vehicle and would most 
likely not require significant deep space maneuvers. • AMBR is not applicable for flyby mission. • A Trojan rendezvous mission requires significant post 
launch ∆V. • Applicable for rendezvous missions. Network Science 
• If mass and controlled descent requirements are 
appropriate, AMBR may have limited applicability. • Limited published analyses on network architecture. • Not applicable 
 
 
 
 
 
 
AMBR Document for New Frontiers Library 
7 
04/29/09

--- chunk_id: chunk-0017
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 7
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 88
content_hash: 6cf9423a315814b1
prev_chunk_id: chunk-0016
next_chunk_id: chunk-0018
section_heading: Figures
document_type: technical_reference

## Figures

![Figure from page 7](images/p007_img00.jpeg)

![Figure from page 7](images/p007_img01.jpeg)

![Figure from page 7](images/p007_img02.jpeg)

![Figure from page 7](images/p007_img03.jpeg)

![Figure from page 7](images/p007_img04.jpeg)

![Figure from page 7](images/p007_img05.jpeg)

![Figure from page 7](images/p007_img06.jpeg)

![Figure from page 7](images/p007_img07.jpeg)

![Figure from page 7](images/p007_img08.png)

![Figure from page 7](images/p007_img09.jpeg)

![Figure from page 7](images/p007_img10.jpeg)

![Figure from page 7](images/p007_img11.jpeg)

![Figure from page 7](images/p007_img12.jpeg)

![Figure from page 7](images/p007_img13.png)

![Figure from page 7](images/p007_img14.jpeg)

![Figure from page 7](images/p007_img15.jpeg)

--- chunk_id: chunk-0018
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 8
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 502
content_hash: a8fb1fe097bf5839
prev_chunk_id: chunk-0017
next_chunk_id: chunk-0019
section_heading: 3. DEVELOPMENT SUMMARY (UNDER ISPT)
document_type: technical_reference

AMBR Document for New Frontiers Library 
8 
3. DEVELOPMENT SUMMARY (UNDER ISPT) 
 
 
 
 
3.1  Status 
Initiated in year 2006, the AMBR effort has so far completed: 
essfully collected for use 
 a copp
rmance envelope hot fire testing in 
pleted the vibration and shock 
l envelope testing was completed in February 
of 2009. 1. Baseline effort: by hot-firing a developmental HiPATTM 
engine, the thermal, propellant flow and pressure 
dynamic information were succ
in the AMBR thruster design. 2. Injector risk mitigation:  the injector design was verified 
capable of achieving the developmental goal of 335 
seconds Isp. This was accomplished using
er 
chamber for very short duration hotfire runs. 3. The AMBR engine completed the fabrication and the 
preliminary perfo
October of 2008. 4. The AMBR engine com
testing in January 2009. 5. Additiona
 
3.2  Key Activities (Summary) 
Beginning in the latter part of year 2006, AMBR thruster 
evelopment progresses via a number of stages: 
rmation for use in designing the prototype. y successful for meeting program goal. combustion chamber, 
on. Perform shock and vibration environmental 
 Perform post-environmental performance 
llowed by 
dditional performance and duration testing. d
 
• 
Stage 1: Baseline Hotfire Test: 
hotfire 
developmental HiPATTM engine to collect thermal and 
dynamic info
Completed 
• 
Stage 2: Injector Design Verification/Risk Mitigation:  
verify injector design using a copper chamber; found 
design highl
Completed 
• 
Stage 3: Fabricate and test the AMBR prototype 
thruster: components needing fabrication include the 
complete injector assembly,
nozzle, and nozzle extensi
Completed 
• 
Stage 4:
testing. Completed 
• 
Stage 5:
testing. Completed 
• 
Perform engine inspection and analysis fo
a

8 
04/29/09 
: 
 
 
4. NEW FRONTIERS MISSION IMPLEMENTATION 
 
 
4.1  Subsystem Selection 
Information needed for selecting subsystems is given 
throughout this document. Section 1.2 System Summary 
describes the AMBR system details which are the basis for 
ubsystem selection. s
 
4.2  Planned ISPT Tasks 
Taken from Section 3.2 Key Activities, the remainder tasks 
of the AMBR development include: 
• 
Perform engine inspection and analysis following by 
additional performance and duration testing. 4.3  Timetable for Completing TRL 6 
Upon completing all planned tasks and successfully passing 
the engine performance verification and environmental tests, 
AMBR engine system will demonstrate its intended 
application in a relevant environment on the ground. The 
plan is having AMBR engine ready for flight development in 
009.

--- chunk_id: chunk-0019
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 8
quality: 0.98
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 248
content_hash: de0c6297a37f3283
prev_chunk_id: chunk-0018
next_chunk_id: chunk-0020
section_heading: 4.3  Timetable for Completing TRL 6
document_type: technical_reference

4.3  Timetable for Completing TRL 6 
Upon completing all planned tasks and successfully passing 
the engine performance verification and environmental tests, 
AMBR engine system will demonstrate its intended 
application in a relevant environment on the ground. The 
plan is having AMBR engine ready for flight development in 
009. 2
 
4.4  Mission Success 
The AMBR propulsion system development summarized 
here was done with rigor and depth of considerations 
required for a high performance bi-propellant system 
suitable for NASA planetary missions. The development is 
accomplished via a multi-year, multi-partner (NASA Centers, 
PL, Aerojet Corporation, etc,). ngines delivered, >650 
own, 100 percent success rate. [2] 
 
5. CONTACT INFORMATION 
 to the AMBR 
ngine to the following individual: 
s Project Office 
, Mail Stop:  77-4 
4135 
David.J.Anderson@nasa.gov 
J
 
The AMBR technology is an improvement upon the existing 
HiPATTM engine, a member of the Aerojet Corporation’s R-
4D Family of thrusters. The R-4D family of thrusters has 
the following heritage:  >1000 e
fl
 
Please direct all inquiries and requests related
e
 
David J. Anderson 
NASA In-Space Propulsion Technologie
NASA John H. Glenn Research Center 
21000 Brookpark Road
Cleveland, OH 4
(216) 433-8709

--- chunk_id: chunk-0020
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 9
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 512
content_hash: bd60d24f9bfbf7d0
prev_chunk_id: chunk-0019
next_chunk_id: chunk-0021
document_type: technical_reference

REFERENCES 
 
 
[1] Scott Miller, Scott Henderson, Aerojet General 
Corporation, et al., “Performance Optimization of 
Storable 
Bipropellant 
Engines 
to 
Fully 
Exploit 
Advanced Material Technologies,” 2006 NASA Science 
and Technology Conference, July 2007 
 
[2] Aerojet 
Space 
Propulsion, 
Redmond, 
WA, 
“Performance Optimization of Storable Bipropellant 
Engines 
to 
Fully 
Exploit 
Advanced 
Material 
Technologies—NASA Cycle 3A NRA Program Kickoff 
Meeting,” 2006-H-3411, September 28, 2006 
 
[3] Aerojet Space Propulsion, Redmond, WA, project 
review packages including the Based Period Test 
Readiness Review (TRR), post hotfire Technical 
Interchange Meeting (TIM), Option I Manufacturing 
Readiness Review (MRR), copper chamber TRR and 
post hotfire TIM, 2006-2008 
 
[4] Ron Portz, et al, “Advanced Chemical Propulsion 
System 
Study,” 
AIAA 
2007-5433, 
43rd 
AIAA/ASME/SAE/ASEE Joint Propulsion Conference, 
July 2007 
[5] Chris England, NASA JPL, a number of NASA/JPL 
internal briefing charts and spreadsheet report, 2007 
 
[6] Jack Chapman, NASA MSFC, “Hot Rocket Propulsion 
System Sizing Performance Comparison,” a NASA 
internal report, 2007 
 
[7] D. Krismer, A. Dorantes, S. Miller, C. Stechman, F. Lu, 
“Qualification 
Testing 
of 
a 
High 
Performance 
Bipropellant Rocket Engine Using MON-3 and 
Hydrazine,” AIAA Paper 2003-4775, July 2003 
 
[8] Robert Hickman and Sandra Elam, NASA MSFC, Scott 
O’Dell and Anatoliy Shchetkovskiy, Plasma Process, 
Inc., “High Temperature Materials for Chemical 
Propulsion Applications,” 54th JANNAF Propulsion 
Meeting, Denver Colorado, May 14-14, 2007 
 
 
 
 
 
APPENDICES 
 
 
A. METHOD FOR DERIVING THE REFERENCE MISSION 
INFORMATION: 
 
For each mission, the mass of the spacecraft at launch is 
estimated based on the expected launch vehicle capability 
and the terminal velocity which the launch vehicle is 
obligated to impart. The spacecraft trajectory is planned, in 
some cases taking advantage of planetary momentum 
exchange to modify the spacecraft velocity. Main engine 
burns are an essential part of trajectory planning to keep the 
spacecraft on course. In one case, the scientific 
requirements of the mission require deployment of 
spacecraft elements such as a heat shield or independent 
landing craft, requiring accounting for the mass decrements. Demands placed on the attitude control system are modeled 
based on historical data, acceptable limits of spacecraft  
pointing and statistical distributions of spacecraft attitude 
perturbations due to internal and external influences. The 
calculated propellant load is increased by one percent to 
account for the inability of propellant tanks to completely 
discharge their contents. Finally, because of the 
uncertainties inherent in engineering, a five percent margin 
is added to the propellant load.

--- chunk_id: chunk-0021
source_document: 35AMBR_NF-AOrefdocument_May09.pdf
page: 9
quality: 0.97
subject_tags: ["general"]
role_tags: ["Engineer"]
token_count: 160
content_hash: b21f61aa4f0dcb2e
prev_chunk_id: chunk-0020
next_chunk_id: null
document_type: technical_reference

The 
calculated propellant load is increased by one percent to 
account for the inability of propellant tanks to completely 
discharge their contents. Finally, because of the 
uncertainties inherent in engineering, a five percent margin 
is added to the propellant load. Once the accounting is in place for mass and velocity 
changes, assumptions are made regarding the efficiency of 
the propulsion system elements. These assumptions are 
based on a database of past engine performance or in this 
case on the goals for improved main engine performance. The propellant mass required to execute the velocity changes 
required by trajectory planning and ACS analysis are 
determined by means of the rocket equation or similar 
calculation. AMBR Document for New Frontiers Library 
9 
04/29/09
